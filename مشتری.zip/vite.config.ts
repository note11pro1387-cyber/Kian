// vite.config.ts

import { defineConfig, type Plugin } from 'vite';
import react from '@vitejs/plugin-react';
import { VitePWA } from 'vite-plugin-pwa';
import { fileURLToPath, URL } from 'node:url';
import { createRequire } from 'node:module';
import path from 'node:path';
import fs from 'node:fs';

const require = createRequire(import.meta.url);

// ═══════════════════════════════════════════════════════════════════════════
// Plugin: copy SQLite Wasm assets into dist/ so they can be loaded at runtime
// ═══════════════════════════════════════════════════════════════════════════

function sqliteWasmAssetsPlugin(): Plugin {
  const WASM_FILES = ['sqlite3.wasm'];

  return {
    name: 'sqlite-wasm-assets',
    apply: 'build',
    async writeBundle() {
      const root = process.cwd();

      let pkgDir = '';
      try {
        const pkgPath = require.resolve('@sqlite.org/sqlite-wasm/package.json');
        pkgDir = path.dirname(pkgPath);
      } catch {
        console.warn(
          '[sqlite-wasm-assets] Could not resolve @sqlite.org/sqlite-wasm. Skipping asset copy.'
        );
        return;
      }

      const candidates = [
        pkgDir,
        path.join(pkgDir, 'dist'),
        path.join(pkgDir, 'build'),
        path.join(root, 'node_modules', '@sqlite.org', 'sqlite-wasm'),
      ];

      let sourceDir = '';
      for (const dir of candidates) {
        const wasmPath = path.join(dir, 'sqlite3.wasm');
        if (fs.existsSync(wasmPath)) {
          sourceDir = dir;
          break;
        }
      }

      if (!sourceDir) {
        console.warn(
          '[sqlite-wasm-assets] Could not locate sqlite3.wasm in package directories.'
        );
        return;
      }

      const destDir = path.join(root, 'dist', 'sqlite-wasm');
      fs.mkdirSync(destDir, { recursive: true });

      let copied = 0;
      for (const file of WASM_FILES) {
        const src = path.join(sourceDir, file);
        if (!fs.existsSync(src)) continue;
        const dest = path.join(destDir, file);
        fs.copyFileSync(src, dest);
        copied += 1;
      }

      console.info(`[sqlite-wasm-assets] Copied ${copied} SQLite WASM asset(s).`);
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Plugin: ensure dist/ contains robots.txt
// ═══════════════════════════════════════════════════════════════════════════

function apkShellAssetsPlugin(): Plugin {
  return {
    name: 'apk-shell-assets',
    apply: 'build',
    async writeBundle() {
      const dist = path.join(process.cwd(), 'dist');
      if (!fs.existsSync(dist)) return;

      const robotsPath = path.join(dist, 'robots.txt');
      fs.writeFileSync(robotsPath, 'User-agent: *\nDisallow: /\n', 'utf8');
    },
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Vite Config
// ═══════════════════════════════════════════════════════════════════════════

export default defineConfig(({ mode }) => {
  const isProduction = mode === 'production';

  return {
    base: './',

    plugins: [
      react({
        jsxRuntime: 'automatic',
      }),

      VitePWA({
        registerType: 'prompt',
        injectRegister: 'auto',

        manifest: false,

        strategies: 'generateSW',
        filename: 'sw.js',
        srcDir: 'public',
        outDir: 'dist',
        scope: './',

        workbox: {
          globPatterns: ['**/*.{js,css,html,woff2,woff,svg,png,ico,webmanifest}'],
          globIgnores: ['**/sqlite-wasm/**', '**/assets/images/**'],
          maximumFileSizeToCacheInBytes: 5 * 1024 * 1024,
          navigateFallback: 'index.html',
          navigateFallbackDenylist: [/^\/api\//, /^\/sqlite-wasm\//],

          runtimeCaching: [
            {
              urlPattern: /\/sqlite-wasm\/.*/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'sqlite-wasm-v1',
                expiration: {
                  maxEntries: 10,
                  maxAgeSeconds: 60 * 60 * 24 * 30,
                },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
            {
              urlPattern: /\.(?:woff2|woff)$/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'fonts-v2',
                expiration: {
                  maxEntries: 20,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
            {
              urlPattern:
                /^https:\/\/cdn\.jsdelivr\.net\/gh\/rastikerdar\/vazirmatn.*\.woff2$/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'remote-vazirmatn',
                expiration: {
                  maxEntries: 16,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
            {
              urlPattern:
                /^https:\/\/raw\.githubusercontent\.com\/rastikerdar\/vazirmatn\/.*\.woff2$/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'remote-vazirmatn-raw',
                expiration: {
                  maxEntries: 16,
                  maxAgeSeconds: 60 * 60 * 24 * 365,
                },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
            {
              urlPattern: /\.(?:svg|png|jpg|jpeg|webp|ico)$/i,
              handler: 'CacheFirst',
              options: {
                cacheName: 'images-v2',
                expiration: {
                  maxEntries: 150,
                  maxAgeSeconds: 60 * 60 * 24 * 180,
                },
                cacheableResponse: { statuses: [0, 200] },
              },
            },
          ],

          skipWaiting: false,
          clientsClaim: true,
          cleanupOutdatedCaches: true,
        },

        devOptions: {
          enabled: false,
          type: 'module',
          navigateFallback: 'index.html',
        },

        includeAssets: [
          'assets/svg/logo-mark.svg',
          'assets/svg/logo-wordmark.svg',
          'assets/svg/empty-finance.svg',
          'assets/svg/security-shield.svg',
          'assets/svg/backup-box.svg',
          'assets/images/apple-touch-icon.png',
          'robots.txt',
        ],
      }),

      sqliteWasmAssetsPlugin(),
      apkShellAssetsPlugin(),
    ],

    resolve: {
      alias: {
        '@': fileURLToPath(new URL('./src', import.meta.url)),
      },
      extensions: ['.ts', '.tsx', '.js', '.jsx', '.json'],
    },

    server: {
      port: 5173,
      strictPort: false,
      host: true,
      open: false,
      cors: true,
    },

    preview: {
      port: 4173,
      strictPort: false,
      host: true,
    },

    build: {
      target: 'es2022',
      outDir: 'dist',
      assetsDir: 'assets',
      emptyOutDir: true,
      cssCodeSplit: false,
      sourcemap: false,
      minify: 'oxc',
      reportCompressedSize: false,
      chunkSizeWarningLimit: 1500,
      assetsInlineLimit: 4096,

      rolldownOptions: {
        input: {
          main: path.resolve(process.cwd(), 'index.html'),
        },
        output: {
          chunkFileNames: 'assets/js/[name]-[hash].js',
          entryFileNames: 'assets/js/[name]-[hash].js',
          assetFileNames: (assetInfo) => {
            const name = assetInfo.names?.[0] ?? assetInfo.name ?? '';
            const ext = name.split('.').pop()?.toLowerCase() ?? '';
            if (ext === 'css') return 'assets/css/[name]-[hash][extname]';
            if (['woff', 'woff2', 'ttf', 'otf', 'eot'].includes(ext)) {
              return 'assets/fonts/[name]-[hash][extname]';
            }
            if (['png', 'jpg', 'jpeg', 'gif', 'webp', 'avif'].includes(ext)) {
              return 'assets/images/[name]-[hash][extname]';
            }
            if (ext === 'svg') return 'assets/svg/[name]-[hash][extname]';
            if (ext === 'wasm') return 'assets/wasm/[name]-[hash][extname]';
            return 'assets/[name]-[hash][extname]';
          },
        },
      },
    },

    optimizeDeps: {
      exclude: ['@sqlite.org/sqlite-wasm', '@capacitor-community/sqlite'],
      include: [
        'react',
        'react-dom',
        'react-dom/client',
        'react-router',
        'zustand',
        'zustand/middleware',
        'react-hook-form',
        'zod',
        'motion',
        'motion/react',
        'lucide-react',
        'i18next',
        'react-i18next',
        'jalaali-js',
        'xlsx',
        '@tanstack/react-virtual',
      ],
    },

    worker: {
      format: 'es',
      plugins: () => [],
    },

    css: {
      devSourcemap: true,
      modules: {
        localsConvention: 'camelCaseOnly',
        generateScopedName: '[name]__[local]___[hash:base64:5]',
      },
      preprocessorOptions: {},
    },

    assetsInclude: ['**/*.woff2', '**/*.woff', '**/*.wasm', '**/*.finbackup'],

    json: {
      stringify: false,
      namedExports: true,
    },

    envPrefix: 'VITE_',
    envDir: '.',

    logLevel: isProduction ? 'warn' : 'info',
    clearScreen: true,
  };
});
