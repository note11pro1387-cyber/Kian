FinSecure visual assets

PWA/app icons:
- images/icon-512.png
- images/icon-maskable-512.png
- images/apple-touch-icon.png

Branding:
- svg/logo-mark.svg
- svg/logo-wordmark.svg

Empty/security illustrations:
- svg/empty-finance.svg
- svg/security-shield.svg
- svg/backup-box.svg

Receipt/invoice photos are NOT static assets and should not be copied here; those belong to transaction attachment storage.
