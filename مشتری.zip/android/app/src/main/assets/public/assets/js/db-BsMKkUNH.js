const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["./esm-DZfTcUqw.js","./main-DAo1FgKR.js","./preload-helper-Cy9oG8kG.js","./esm-BeVXMOMT.js"])))=>i.map(i=>d[i]);
import{t as e}from"./preload-helper-Cy9oG8kG.js";var t=Object.create,n=Object.defineProperty,r=Object.getOwnPropertyDescriptor,i=Object.getOwnPropertyNames,a=Object.getPrototypeOf,o=Object.prototype.hasOwnProperty,s=(e,t)=>()=>(t||e((t={exports:{}}).exports,t),t.exports),c=(e,t)=>{let r={};for(var i in e)n(r,i,{get:e[i],enumerable:!0});return t||n(r,Symbol.toStringTag,{value:`Module`}),r},l=(e,t,a,s)=>{if(t&&typeof t==`object`||typeof t==`function`)for(var c=i(t),l=0,u=c.length,d;l<u;l++)d=c[l],!o.call(e,d)&&d!==a&&n(e,d,{get:(e=>t[e]).bind(null,d),enumerable:!(s=r(t,d))||s.enumerable});return e},u=(e,r,i)=>(i=e==null?{}:t(a(e)),l(r||!e||!e.__esModule?n(i,`default`,{value:e,enumerable:!0}):i,e)),d={DEPOSIT:`deposit`,EXPENSE:`expense`},f={ACTIVE:`active`,DELETED:`soft_deleted`},p={BANK:`bank`,CASH:`cash`,CARD:`card`,TREASURY:`treasury`},m={ACTIVE:`active`,ARCHIVED:`archived`},h={PERSON:`person`,COMPANY:`company`},g={CONTRACTOR:`contractor`,EMPLOYEE:`employee`,CUSTOMER:`customer`,SUPPLIER:`supplier`,OTHER:`other`},_={ACTIVE:`active`,ARCHIVED:`archived`},ee={ACTIVE:`active`,DONE:`done`,PAUSED:`paused`,ARCHIVED:`archived`},te={EXPENSE:`expense`,INCOME:`income`,BOTH:`both`},ne={ACTIVE:`active`,ARCHIVED:`archived`},v={CREATE:`create`,EDIT:`edit`,DELETE:`delete`,RESTORE:`restore`,IMPORT:`import`,BACKUP_RESTORE:`backup_restore`,SECURITY_CHANGE:`security_change`,EXPORT:`export`,MASTER_RECOVERY_USED:`master_recovery_used`,UPDATE:`edit`,SETTINGS:`security_change`,SECURITY:`security_change`,BACKUP:`backup_restore`},y={TRANSACTION:`transaction`,ACCOUNT:`account`,PARTY:`party`,PROJECT:`project`,SECURITY:`security`,SYSTEM:`system`},b={ANALYZING:`analyzing`,PREVIEWING:`previewing`,COMMITTED:`committed`,CANCELLED:`cancelled`,FAILED:`failed`},re={IMPORTED:`imported`,SKIPPED:`skipped`,UPDATED:`updated`,CONFLICT:`conflict`,ERROR:`error`},ie={EXACT:`exact`,LIKELY:`likely`,POSSIBLE:`possible`,UNIQUE:`unique`},ae={FULL:`full`,DATA_EXPORT:`data_export`},oe={P0:`P0`,P1:`P1`,P2:`P2`,P3:`P3`,P4:`P4`},se={NEGATIVE_BALANCE:`negative_balance`,DUPLICATE_CANDIDATE:`duplicate_candidate`,RECONCILIATION_MISMATCH:`reconciliation_mismatch`,BACKUP_REMINDER:`backup_reminder`,SYNC_CONFLICT:`sync_conflict`,INFO:`info`,DUPLICATE:`duplicate_candidate`,RECONCILIATION:`reconciliation_mismatch`,BACKUP:`backup_reminder`},ce={INFO:`info`,WARNING:`warning`,CRITICAL:`critical`,DANGER:`critical`},le={NO_INCOME:`no_income`,NO_EXPENSE:`no_expense`,NEGATIVE_BALANCE:`negative_balance`,OPENING_BEFORE_RANGE:`opening_before_range`,DATA_CHANGED:`data_changed`},ue={PIN:`pin`,PATTERN:`pattern`,BIOMETRIC:`biometric`},de={NEW_TRANSACTION:`new-transaction`,NEW_ACCOUNT:`new-account`,NEW_PARTY:`new-party`,NEW_PROJECT:`new-project`},fe=s(((e,t)=>{t.exports={toJalaali:r,toGregorian:i,isValidJalaaliDate:a,isLeapJalaaliYear:o,jalaaliMonthLength:s,jalCal:l,j2d:u,d2j:d,g2d:f,d2g:p,jalaaliToDateObject:h,jalaaliWeek:m};var n=[-61,9,38,199,426,686,756,818,1111,1181,1210,1635,2060,2097,2192,2262,2324,2394,2456,3178];function r(e,t,n){return Object.prototype.toString.call(e)===`[object Date]`&&(n=e.getDate(),t=e.getMonth()+1,e=e.getFullYear()),d(f(e,t,n))}function i(e,t,n){return p(u(e,t,n))}function a(e,t,n){return e>=-61&&e<=3177&&t>=1&&t<=12&&n>=1&&n<=s(e,t)}function o(e){return c(e)===0}function s(e,t){return t<=6?31:t<=11||o(e)?30:29}function c(e){var t=n.length,r=n[0],i,a,o,s,c;if(e<r||e>=n[t-1])throw Error(`Invalid Jalaali year `+e);for(c=1;c<t&&(i=n[c],a=i-r,!(e<i));c+=1)r=i;return s=e-r,a-s<6&&(s=s-a+g(a+4,33)*33),o=_(_(s+1,33)-1,4),o===-1&&(o=4),o}function l(e,t){var r=n.length,i=e+621,a=-14,o=n[0],s,c,l,u,d,f,p;if(e<o||e>=n[r-1])throw Error(`Invalid Jalaali year `+e);for(p=1;p<r&&(s=n[p],c=s-o,!(e<s));p+=1)a=a+g(c,33)*8+g(_(c,33),4),o=s;return f=e-o,a=a+g(f,33)*8+g(_(f,33)+3,4),_(c,33)===4&&c-f===4&&(a+=1),u=g(i,4)-g((g(i,100)+1)*3,4)-150,d=20+a-u,t?{gy:i,march:d}:(c-f<6&&(f=f-c+g(c+4,33)*33),l=_(_(f+1,33)-1,4),l===-1&&(l=4),{leap:l,gy:i,march:d})}function u(e,t,n){var r=l(e,!0);return f(r.gy,3,r.march)+(t-1)*31-g(t,7)*(t-7)+n-1}function d(e){var t=p(e).gy,n=t-621,r=l(n,!1),i=f(t,3,r.march),a,o,s=e-i;if(s>=0){if(s<=185)return o=1+g(s,31),a=_(s,31)+1,{jy:n,jm:o,jd:a};s-=186}else --n,s+=179,r.leap===1&&(s+=1);return o=7+g(s,30),a=_(s,30)+1,{jy:n,jm:o,jd:a}}function f(e,t,n){var r=g((e+g(t-8,6)+100100)*1461,4)+g(153*_(t+9,12)+2,5)+n-34840408;return r=r-g(g(e+100100+g(t-8,6),100)*3,4)+752,r}function p(e){var t=4*e+139361631,n,r,i,a;return t=t+g(g(4*e+183187720,146097)*3,4)*4-3908,n=g(_(t,1461),4)*5+308,r=g(_(n,153),5)+1,i=_(g(n,153),12)+1,a=g(t,1461)-100100+g(8-i,6),{gy:a,gm:i,gd:r}}function m(e,t,n){var r=h(e,t,n).getDay(),i=r==6?0:-(r+1),a=6+i;return{saturday:d(u(e,t,n+i)),friday:d(u(e,t,n+a))}}function h(e,t,n,r,a,o,s){var c=i(e,t,n);return new Date(c.gy,c.gm-1,c.gd,r||0,a||0,o||0,s||0)}function g(e,t){return~~(e/t)}function _(e,t){return e-~~(e/t)*t}})),pe=fe(),me=`۰۱۲۳۴۵۶۷۸۹`,he=`٠١٢٣٤٥٦٧٨٩`;function x(e){let t=``;for(let n of e){let e=me.indexOf(n);if(e>=0){t+=String(e);continue}let r=he.indexOf(n);if(r>=0){t+=String(r);continue}t+=n}return t}function S(e){return e.replace(/ي/g,`ی`).replace(/ك/g,`ک`).replace(/[\u200B-\u200D\uFEFF]/g,``).replace(/\u00A0/g,` `).replace(/\s+/g,` `).toLowerCase().trim()}function ge(e){let t=e<0n,n=(t?-e:e).toString().replace(/\B(?=(\d{3})+(?!\d))/g,`,`);return t?`-`+n:n}function _e(e){if(!e)return null;let t=x(e).replace(/[,\s،]/g,``).trim();if(!/^-?\d+$/.test(t))return null;try{return BigInt(t)}catch{return null}}function ve(e){let t=x(e).replace(/[,\s،]/g,``);if(!t||!/^\d+([+\-]\d+)*$/.test(t))return null;let n=t.split(/(?=[+\-])/),r=0n;for(let e of n)e.startsWith(`+`)?r+=BigInt(e.slice(1)):e.startsWith(`-`)?r-=BigInt(e.slice(1)):r+=BigInt(e);return r>0n?r:null}var ye=[``,`یک`,`دو`,`سه`,`چهار`,`پنج`,`شش`,`هفت`,`هشت`,`نه`],be=[`ده`,`یازده`,`دوازده`,`سیزده`,`چهارده`,`پانزده`,`شانزده`,`هفده`,`هجده`,`نوزده`],xe=[``,``,`بیست`,`سی`,`چهل`,`پنجاه`,`شصت`,`هفتاد`,`هشتاد`,`نود`],Se=[``,`صد`,`دویست`,`سیصد`,`چهارصد`,`پانصد`,`ششصد`,`هفتصد`,`هشتصد`,`نهصد`],Ce=[``,`هزار`,`میلیون`,`میلیارد`,`تریلیون`];function we(e){if(e===0)return``;let t=[],n=Math.floor(e/100),r=e%100;if(n>0&&t.push(Se[n]),r>=10&&r<20)t.push(be[r-10]);else{let e=Math.floor(r/10),n=r%10;e>0&&t.push(xe[e]),n>0&&t.push(ye[n])}return t.join(` و `)}function Te(e){if(e===0n)return`صفر`;if(e<0n)return`منفی `+Te(-e);let t=[],n=e,r=0;for(;n>0n&&r<Ce.length;){let e=Number(n%1000n);if(e>0){let n=we(e),i=Ce[r];i===``?t.unshift(n):e===1&&i===`هزار`?t.unshift(i):t.unshift(n+` `+i)}n/=1000n,r+=1}if(n>0n)throw Error(`مبلغ از محدوده‌ی تبدیل به حروف فارسی خارج است (حداکثر ۱۵ رقم)`);return t.join(` و `)}function C(e){return e<10?`0`+e:String(e)}function Ee(e){let t=e.split(`-`);if(t.length!==3)return null;let n=Number(t[0]),r=Number(t[1]),i=Number(t[2]);return!Number.isFinite(n)||!Number.isFinite(r)||!Number.isFinite(i)?null:{y:n,m:r,d:i}}function w(e,t,n){if(t<1||t>12||n<1||n>31)return!1;let r=new Date(e,t-1,n);return r.getFullYear()===e&&r.getMonth()===t-1&&r.getDate()===n}function De(e,t,n){if(!Number.isFinite(e)||!Number.isFinite(t)||!Number.isFinite(n)||!w(e,t,n))return null;let{jy:r,jm:i,jd:a}=(0,pe.toJalaali)(e,t,n);return{jy:r,jm:i,jd:a}}function Oe(e,t,n){if(!Number.isFinite(e)||!Number.isFinite(t)||!Number.isFinite(n)||t<1||t>12||n<1||n>31)return null;let{gy:r,gm:i,gd:a}=(0,pe.toGregorian)(e,t,n);return w(r,i,a)?{gy:r,gm:i,gd:a}:null}function T(e){let t=Ee(e);return t?De(t.y,t.m,t.d):null}function ke(e){let t=T(e);return t?`${t.jy}/${C(t.jm)}/${C(t.jd)}`:``}function Ae(e){let t=T(e);return t?`${t.jy}${C(t.jm)}${C(t.jd)}`:``}function je(e){let t=x(e).trim().split(`/`);if(t.length!==3)return null;let n=Oe(Number(t[0]),Number(t[1]),Number(t[2]));return n?`${n.gy}-${C(n.gm)}-${C(n.gd)}`:null}function Me(e){let t=x(e).trim();if(!t)return null;if(/^\d{4}-\d{1,2}-\d{1,2}$/.test(t)){let e=t.split(`-`),n=Number(e[0]),r=Number(e[1]),i=Number(e[2]);return w(n,r,i)?`${n}-${C(r)}-${C(i)}`:null}return/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(t)?je(t):null}function Ne(){let e=new Date;return`${e.getFullYear()}-${C(e.getMonth()+1)}-${C(e.getDate())}`}function Pe(){return new Date().toISOString()}var Fe=c({SCHEMA_VERSION:()=>2,SETTINGS_KEYS:()=>E,accountRepo:()=>rt,alertsRepo:()=>_t,auditRepo:()=>dt,backupRepo:()=>mt,categoryRepo:()=>ot,dbUtils:()=>yt,draftRepo:()=>ft,generateDevicePrefix:()=>A,generateULID:()=>k,getDatabase:()=>L,getDevicePrefix:()=>Q,getWorkspaceId:()=>Z,importRepo:()=>ht,initDatabase:()=>Ye,isNativePlatform:()=>D,partyRepo:()=>it,projectRepo:()=>at,securityRepo:()=>pt,settingsRepo:()=>$,transactionRepo:()=>ut,workspaceRepo:()=>vt}),E={THEME:`theme`,LANGUAGE:`language`,COMPANY_NAME:`company_name`,LAST_BACKUP_AT:`last_backup_at`,PERFORMANCE_TIER:`performance_tier`,ONBOARDING_DONE:`onboarding_done`,SECURITY_PROMPT_COUNT:`security_prompt_count`,DEVICE_PREFIX:`device_prefix`,WORKSPACE_ID:`workspace_id`,PRIVACY_HIDE_AMOUNTS:`privacy_hide_amounts`,ASSET_CACHE_VERSION:`asset_cache_version`},Ie=`finsecure`,Le=2;function Re(){return typeof window>`u`?null:window.Capacitor??null}function D(){return Re()?.isNativePlatform?.()===!0}function O(e){if(!Number.isInteger(e)||e<=0)throw Error(`Secure random byte length must be a positive integer`);let t=globalThis.crypto;if(!t||typeof t.getRandomValues!=`function`)throw Error(`Secure random generator is unavailable. Cannot proceed with security-sensitive operation.`);let n=new Uint8Array(e);return t.getRandomValues(n),n}var ze=`0123456789ABCDEFGHJKMNPQRSTVWXYZ`;function k(){let e=Date.now(),t=``,n=e;for(let e=0;e<10;e++)t=ze[n%32]+t,n=Math.floor(n/32);let r=O(16),i=``;for(let e=0;e<16;e++)i+=ze[r[e]%32];return t+i}function A(){let e=O(4),t=``;for(let n=0;n<3;n++)t+=`ABCDEFGHJKLMNPQRSTUVWXYZ23456789`[e[n]%32];return t}function j(e){let t=Number(e);if(!Number.isSafeInteger(t))throw Error(`Money value exceeds JavaScript safe integer range for database storage`);return t}function M(e){return e===null?null:j(e)}function Be(e){return e==null?0n:BigInt(typeof e==`string`?e:Math.trunc(e))}function Ve(e){return e==null?null:BigInt(typeof e==`string`?e:Math.trunc(e))}function He(e){return e?1:0}function N(e){return e===1}function P(){return new Date().toISOString()}var Ue=`CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
  ).CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    bank_name TEXT,
    account_number TEXT,
    card_number TEXT,
    description TEXT,
    opening_balance INTEGER NOT NULL DEFAULT 0,
    opening_balance_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT,
    updated_by TEXT,
    CHECK (type IN ('bank','cash','card','treasury')),
    CHECK (status IN ('active','archived')),
    CHECK (opening_balance >= 0)
  ).CREATE INDEX IF NOT EXISTS idx_accounts_workspace ON accounts(workspace_id).CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status).CREATE INDEX IF NOT EXISTS idx_accounts_sort ON accounts(sort_order, name).CREATE TABLE IF NOT EXISTS parties (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    type TEXT NOT NULL,
    phone TEXT,
    card_number TEXT,
    account_number TEXT,
    role TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK (type IN ('person','company')),
    CHECK (status IN ('active','archived')),
    CHECK (role IS NULL OR role IN ('contractor','employee','customer','supplier','other'))
  ).CREATE INDEX IF NOT EXISTS idx_parties_workspace ON parties(workspace_id).CREATE INDEX IF NOT EXISTS idx_parties_normalized ON parties(normalized_name).CREATE INDEX IF NOT EXISTS idx_parties_status ON parties(status).CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    code TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    budget_amount INTEGER,
    description TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK (status IN ('active','done','paused','archived')),
    CHECK (budget_amount IS NULL OR budget_amount >= 0)
  ).CREATE INDEX IF NOT EXISTS idx_projects_workspace ON projects(workspace_id).CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status).CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    parent_id TEXT REFERENCES categories(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    is_custom INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active',
    CHECK (type IN ('expense','income','both')),
    CHECK (status IN ('active','archived')),
    CHECK (is_custom IN (0,1))
  ).CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_id).CREATE INDEX IF NOT EXISTS idx_categories_type ON categories(type).CREATE INDEX IF NOT EXISTS idx_categories_status ON categories(status).CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    display_code TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    amount INTEGER NOT NULL,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    party_id TEXT REFERENCES parties(id) ON DELETE SET NULL,
    category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    custom_category_text TEXT,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    transaction_date TEXT NOT NULL,
    transaction_time TEXT,
    reference_code TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    version INTEGER NOT NULL DEFAULT 1,
    device_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT,
    updated_by TEXT,
    deleted_at TEXT,
    CHECK (type IN ('deposit','expense')),
    CHECK (status IN ('active','soft_deleted')),
    CHECK (amount > 0)
  ).CREATE INDEX IF NOT EXISTS idx_tx_workspace ON transactions(workspace_id).CREATE INDEX IF NOT EXISTS idx_tx_account_date ON transactions(account_id, transaction_date DESC).CREATE INDEX IF NOT EXISTS idx_tx_party_date ON transactions(party_id, transaction_date DESC).CREATE INDEX IF NOT EXISTS idx_tx_project_date ON transactions(project_id, transaction_date DESC).CREATE INDEX IF NOT EXISTS idx_tx_category_date ON transactions(category_id, transaction_date DESC).CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(transaction_date DESC).CREATE INDEX IF NOT EXISTS idx_tx_status ON transactions(status).CREATE INDEX IF NOT EXISTS idx_tx_type_status ON transactions(type, status).CREATE INDEX IF NOT EXISTS idx_tx_display ON transactions(display_code).CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    type TEXT NOT NULL DEFAULT 'image',
    file_name TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    thumbnail_key TEXT,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    sha256 TEXT NOT NULL,
    created_at TEXT NOT NULL,
    CHECK (size_bytes >= 0)
  ).CREATE INDEX IF NOT EXISTS idx_attachments_tx ON attachments(transaction_id).CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    action TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT,
    actor_label TEXT,
    device_id TEXT,
    created_at TEXT NOT NULL,
    CHECK (entity_type IN ('transaction','account','party','project','security','system')),
    CHECK (action IN (
      'create','edit','delete','restore','import',
      'backup_restore','security_change','export','master_recovery_used'
    ))
  ).CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id).CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at DESC).CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_events(action).CREATE TABLE IF NOT EXISTS import_jobs (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    stats_json TEXT,
    CHECK (status IN ('analyzing','previewing','committed','cancelled','failed'))
  ).CREATE TABLE IF NOT EXISTS import_records (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES import_jobs(id) ON DELETE CASCADE,
    row_number INTEGER NOT NULL,
    row_hash TEXT NOT NULL,
    decision TEXT NOT NULL,
    matched_transaction_id TEXT,
    duplicate_score TEXT,
    error_message TEXT,
    CHECK (decision IN ('imported','skipped','updated','conflict','error')),
    CHECK (duplicate_score IS NULL OR duplicate_score IN ('exact','likely','possible','unique'))
  ).CREATE INDEX IF NOT EXISTS idx_import_records_job ON import_records(job_id).CREATE INDEX IF NOT EXISTS idx_import_records_hash ON import_records(row_hash).CREATE TABLE IF NOT EXISTS import_mappings (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mapping_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  ).CREATE TABLE IF NOT EXISTS security_profiles (
    id TEXT PRIMARY KEY CHECK (id = 'default'),
    pin_hash TEXT,
    pattern_hash TEXT,
    biometric_enabled INTEGER NOT NULL DEFAULT 0,
    primary_method TEXT,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    lockout_until TEXT,
    recovery_used_count INTEGER NOT NULL DEFAULT 0,
    lock_timeout_seconds INTEGER NOT NULL DEFAULT 0,
    configured_at TEXT,
    CHECK (primary_method IS NULL OR primary_method IN ('pin','pattern')),
    CHECK (biometric_enabled IN (0,1)),
    CHECK (failed_attempts >= 0),
    CHECK (recovery_used_count >= 0),
    CHECK (lock_timeout_seconds >= 0)
  ).CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  ).CREATE TABLE IF NOT EXISTS backup_records (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'full',
    size_bytes INTEGER NOT NULL,
    transaction_count INTEGER NOT NULL,
    schema_version INTEGER NOT NULL,
    app_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    checksum TEXT NOT NULL,
    CHECK (type IN ('full','data_export')),
    CHECK (size_bytes >= 0),
    CHECK (transaction_count >= 0),
    CHECK (schema_version > 0)
  ).CREATE INDEX IF NOT EXISTS idx_backup_created ON backup_records(created_at DESC).CREATE TABLE IF NOT EXISTS drafts (
    id TEXT PRIMARY KEY,
    form_type TEXT NOT NULL DEFAULT 'transaction',
    form_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  ).CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    severity TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    message_key TEXT NOT NULL,
    message_params_json TEXT,
    created_at TEXT NOT NULL,
    read_at TEXT,
    resolved_at TEXT,
    CHECK (type IN (
      'negative_balance','duplicate_candidate','reconciliation_mismatch',
      'backup_reminder','sync_conflict','info'
    )),
    CHECK (severity IN ('info','warning','critical')),
    CHECK (entity_type IS NULL OR entity_type IN ('transaction','account','party','project','security','system'))
  ).CREATE INDEX IF NOT EXISTS idx_alerts_unread ON alerts(read_at).CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(type).CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    label TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
  ).CREATE TABLE IF NOT EXISTS sync_records (
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    version INTEGER NOT NULL,
    synced_at TEXT,
    conflict INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (entity_type, entity_id)
  )`.split(`.`),We=[{id:`cat-seed-exp-materials`,name:`خرید مصالح`,type:`expense`,sortOrder:10},{id:`cat-seed-exp-salary`,name:`دستمزد`,type:`expense`,sortOrder:20},{id:`cat-seed-exp-transport`,name:`حمل‌ونقل`,type:`expense`,sortOrder:30},{id:`cat-seed-exp-services`,name:`خدمات`,type:`expense`,sortOrder:40},{id:`cat-seed-exp-equipment`,name:`تجهیزات`,type:`expense`,sortOrder:50},{id:`cat-seed-exp-rent`,name:`اجاره`,type:`expense`,sortOrder:60},{id:`cat-seed-exp-bills`,name:`قبوض`,type:`expense`,sortOrder:70},{id:`cat-seed-exp-repairs`,name:`تعمیرات`,type:`expense`,sortOrder:80},{id:`cat-seed-exp-advance`,name:`پیش‌پرداخت`,type:`expense`,sortOrder:90},{id:`cat-seed-exp-settlement`,name:`تسویه`,type:`expense`,sortOrder:100},{id:`cat-seed-exp-other`,name:`سایر`,type:`expense`,sortOrder:999},{id:`cat-seed-inc-project`,name:`واریز پروژه`,type:`income`,sortOrder:10},{id:`cat-seed-inc-customer`,name:`تسویه مشتری`,type:`income`,sortOrder:20},{id:`cat-seed-inc-capital`,name:`سرمایه`,type:`income`,sortOrder:30},{id:`cat-seed-inc-other`,name:`سایر`,type:`income`,sortOrder:999}],Ge=[{key:E.THEME,value:`dark`},{key:E.LANGUAGE,value:`fa`},{key:E.ONBOARDING_DONE,value:`false`},{key:E.SECURITY_PROMPT_COUNT,value:`0`},{key:E.PRIVACY_HIDE_AMOUNTS,value:`false`},{key:E.ASSET_CACHE_VERSION,value:`1`}];async function Ke(){let t=`financial-db-encryption-secret`,{Preferences:n}=await e(async()=>{let{Preferences:e}=await import(`./esm-DZfTcUqw.js`);return{Preferences:e}},__vite__mapDeps([0,1,2]),import.meta.url),r=await n.get({key:t});if(r.value&&r.value.length>0)return r.value;let i=O(32),a=``;for(let e of i)a+=e.toString(16).padStart(2,`0`);return await n.set({key:t,value:a}),a}var qe=class{sqlite=null;db=null;async open(){let{CapacitorSQLite:t,SQLiteConnection:n}=await e(()=>import(`./esm-BeVXMOMT.js`),__vite__mapDeps([3,1,2]),import.meta.url),r=new n(t),i=await Ke();try{(await r.isSecretStored()).result===!0?await r.checkEncryptionSecret(i):await r.setEncryptionSecret(i)}catch(e){throw Error(`Native database encryption initialization failed: ${e instanceof Error?e.message:String(e)}`)}let a=await r.createConnection(Ie,!0,`secret`,Le,!1);await a.open(),await a.execute(`PRAGMA foreign_keys = ON`),this.sqlite=r,this.db=a}getDb(){if(!this.db)throw Error(`Native DB not open`);return this.db}async execute(e,t=[]){await this.getDb().execute(e,t)}async query(e,t=[]){return(await this.getDb().query(e,t)).values??[]}async queryOne(e,t=[]){let n=await this.query(e,t);return n.length>0?n[0]:null}async transaction(e){let t=this.getDb();await t.execute(`BEGIN`);try{let n=await e(this);return await t.execute(`COMMIT`),n}catch(e){try{await t.execute(`ROLLBACK`)}catch{}throw e}}async close(){if(!(!this.db||!this.sqlite)){try{await this.db.close()}catch{}try{await this.sqlite.closeConnection(Ie,!1)}catch{}this.db=null,this.sqlite=null}}},Je=class{worker=null;nextRequestId=1;pending=new Map;queueTail=Promise.resolve();handleMessage=e=>{let t=e.data,n=this.pending.get(t.requestId);if(!n)return;if(this.pending.delete(t.requestId),t.ok){n.resolve(t.result);return}let r=Error(t.error.message);r.name=t.error.name??`SQLiteWorkerError`,t.error.stack&&(r.stack=t.error.stack),n.reject(r)};handleError=e=>{let t=e.error instanceof Error?e.error:Error(e.message||`SQLite worker failed`),n=this.worker;this.worker=null,this.rejectPending(t),n?.terminate()};rejectPending(e){for(let t of this.pending.values())t.reject(e);this.pending.clear()}assertWorker(){if(!this.worker)throw Error(`Web SQLite worker is not open`);return this.worker}request(e){let t=this.assertWorker(),n=this.nextRequestId++;return new Promise((r,i)=>{this.pending.set(n,{resolve:e=>r(e),reject:i});let a={...e,requestId:n};t.postMessage(a)})}withQueue(e){let t=this.queueTail,n;return this.queueTail=new Promise(e=>{n=e}),t.then(e).finally(n)}rawExecute(e,t=[]){return this.request({type:`exec`,sql:e,params:[...t]})}rawQuery(e,t=[]){return this.request({type:`query`,sql:e,params:[...t]})}async open(){if(this.worker)return;let e=new Worker(new URL(``+new URL(`../db.worker-Cjkc9t4O.js`,import.meta.url).href,``+import.meta.url),{type:`module`});e.addEventListener(`message`,this.handleMessage),e.addEventListener(`error`,this.handleError),this.worker=e;try{await this.request({type:`open`})}catch(t){throw e.removeEventListener(`message`,this.handleMessage),e.removeEventListener(`error`,this.handleError),e.terminate(),this.worker=null,t}}async execute(e,t=[]){await this.withQueue(()=>this.rawExecute(e,t))}async query(e,t=[]){return this.withQueue(()=>this.rawQuery(e,t))}async queryOne(e,t=[]){let n=await this.query(e,t);return n.length>0?n[0]:null}async transaction(e){return this.withQueue(async()=>{await this.rawExecute(`BEGIN`);let t={execute:(e,t=[])=>this.rawExecute(e,t),query:(e,t=[])=>this.rawQuery(e,t),queryOne:async(e,t=[])=>{let n=await this.rawQuery(e,t);return n.length>0?n[0]:null}};try{let n=await e(t);return await this.rawExecute(`COMMIT`),n}catch(e){try{await this.rawExecute(`ROLLBACK`)}catch{}throw e}})}async close(){this.worker&&await this.withQueue(async()=>{let e=this.worker;if(e)try{await this.request({type:`close`})}finally{e.removeEventListener(`message`,this.handleMessage),e.removeEventListener(`error`,this.handleError),e.terminate(),this.worker=null,this.rejectPending(Error(`Web SQLite worker closed`))}})}},F=null,I=null;function Ye(){return F?Promise.resolve():I||(I=(async()=>{let e=D()?new qe:new Je;try{await e.open(),await e.execute(`PRAGMA foreign_keys = ON`),await Ze(e),await Qe(e),await $e(e),await et(e),await tt(e),F=e}catch(t){try{await e.close()}catch{}throw t}})().finally(()=>{I=null}),I)}function L(){if(!F)throw Error(`Database not initialized`);return F}function R(){return L()}async function Xe(e){return(await e.queryOne(`PRAGMA user_version`))?.user_version??0}async function Ze(e){await Xe(e)>=2||await e.transaction(async e=>{for(let t of Ue)await e.execute(t);await e.execute(`PRAGMA user_version = 2`)})}async function Qe(e){for(let t of We)await e.execute(`INSERT OR IGNORE INTO categories
        (id, parent_id, name, type, is_custom, sort_order, status)
       VALUES (?, NULL, ?, ?, 0, ?, 'active')`,[t.id,t.name,t.type,t.sortOrder])}async function $e(e){for(let t of Ge)await e.execute(`INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)`,[t.key,t.value])}async function et(e){let t=await e.queryOne(`SELECT id FROM workspaces LIMIT 1`);if(t)return t.id;let n=k();return await e.execute(`INSERT INTO workspaces (id, name, created_at) VALUES (?, ?, ?)`,[n,`شرکت`,P()]),await e.execute(`INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)`,[E.WORKSPACE_ID,n]),n}async function tt(e){if((await e.queryOne(`SELECT value FROM app_settings WHERE key = ?`,[E.DEVICE_PREFIX]))?.value)return;let t=A();await e.execute(`INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)`,[E.DEVICE_PREFIX,t])}function z(e){return{id:e.id,workspaceId:e.workspace_id,name:e.name,type:e.type,bankName:e.bank_name,accountNumber:e.account_number,cardNumber:e.card_number,description:e.description,openingBalance:Be(e.opening_balance),openingBalanceDate:e.opening_balance_date,status:e.status,sortOrder:e.sort_order,createdAt:e.created_at,updatedAt:e.updated_at,createdBy:e.created_by,updatedBy:e.updated_by}}function B(e){return{id:e.id,workspaceId:e.workspace_id,name:e.name,normalizedName:e.normalized_name,type:e.type,phone:e.phone,cardNumber:e.card_number,accountNumber:e.account_number,role:e.role??null,notes:e.notes,status:e.status,createdAt:e.created_at,updatedAt:e.updated_at}}function V(e){return{id:e.id,workspaceId:e.workspace_id,name:e.name,code:e.code,status:e.status,budgetAmount:Ve(e.budget_amount),description:e.description,createdAt:e.created_at,updatedAt:e.updated_at}}function H(e){return{id:e.id,parentId:e.parent_id,name:e.name,type:e.type,isCustom:N(e.is_custom),sortOrder:e.sort_order,status:e.status}}function U(e){return{id:e.id,workspaceId:e.workspace_id,displayCode:e.display_code,type:e.type,amount:Be(e.amount),accountId:e.account_id,partyId:e.party_id,categoryId:e.category_id,customCategoryText:e.custom_category_text,projectId:e.project_id,transactionDate:e.transaction_date,transactionTime:e.transaction_time,referenceCode:e.reference_code,description:e.description,status:e.status,version:e.version,deviceId:e.device_id,createdAt:e.created_at,updatedAt:e.updated_at,createdBy:e.created_by,updatedBy:e.updated_by,deletedAt:e.deleted_at}}function W(e){return{id:e.id,workspaceId:e.workspace_id,entityType:e.entity_type,entityId:e.entity_id,action:e.action,beforeJson:e.before_json,afterJson:e.after_json,actorLabel:e.actor_label,deviceId:e.device_id,createdAt:e.created_at}}function nt(e){return{id:`default`,pinHash:e.pin_hash,patternHash:e.pattern_hash,biometricEnabled:N(e.biometric_enabled),primaryMethod:e.primary_method??null,failedAttempts:e.failed_attempts,lockoutUntil:e.lockout_until,recoveryUsedCount:e.recovery_used_count,lockTimeoutSeconds:e.lock_timeout_seconds,configuredAt:e.configured_at}}async function G(e,t){await e.execute(`INSERT INTO audit_events
      (id, workspace_id, entity_type, entity_id, action,
       before_json, after_json, actor_label, device_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,[k(),t.workspaceId,t.entityType,t.entityId,t.action,t.before===null?null:JSON.stringify(t.before),t.after===null?null:JSON.stringify(t.after),t.actorLabel,t.deviceId??null,P()])}function K(e){return e.toString()}function q(e){return{id:e.id,workspaceId:e.workspaceId,name:e.name,type:e.type,bankName:e.bankName,accountNumber:e.accountNumber,cardNumber:e.cardNumber,description:e.description,openingBalance:K(e.openingBalance),openingBalanceDate:e.openingBalanceDate,status:e.status,sortOrder:e.sortOrder}}function J(e){return{id:e.id,workspaceId:e.workspaceId,name:e.name,type:e.type,phone:e.phone,cardNumber:e.cardNumber,accountNumber:e.accountNumber,role:e.role,notes:e.notes,status:e.status}}function Y(e){return{id:e.id,workspaceId:e.workspaceId,name:e.name,code:e.code,status:e.status,budgetAmount:e.budgetAmount===null?null:K(e.budgetAmount),description:e.description}}function X(e){return{id:e.id,workspaceId:e.workspaceId,displayCode:e.displayCode,type:e.type,amount:K(e.amount),accountId:e.accountId,partyId:e.partyId,categoryId:e.categoryId,customCategoryText:e.customCategoryText,projectId:e.projectId,transactionDate:e.transactionDate,transactionTime:e.transactionTime,referenceCode:e.referenceCode,description:e.description,status:e.status,version:e.version}}async function Z(e){let t=await(e??R()).queryOne(`SELECT id FROM workspaces LIMIT 1`);if(!t)throw Error(`Workspace not found`);return t.id}async function Q(e){let t=await $.get(E.DEVICE_PREFIX,e);if(t)return t;let n=A();return await $.set(E.DEVICE_PREFIX,n,e),n}var $={async getAll(e){return(e??R()).query(`SELECT key, value FROM app_settings`)},async get(e,t){return(await(t??R()).queryOne(`SELECT value FROM app_settings WHERE key = ?`,[e]))?.value??null},async set(e,t,n){await(n??R()).execute(`INSERT INTO app_settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,[e,t])},async getBoolean(e,t,n){let r=await this.get(e,n);return r===null?t:r===`true`||r===`1`},async getNumber(e,t,n){let r=await this.get(e,n);if(r===null)return t;let i=Number(r);return Number.isFinite(i)?i:t}},rt={async list(e=!1,t){let n=t??R(),r=e?`SELECT * FROM accounts ORDER BY sort_order ASC, name ASC`:`SELECT * FROM accounts WHERE status = 'active'
         ORDER BY sort_order ASC, name ASC`;return(await n.query(r)).map(z)},async findById(e,t){let n=await(t??R()).queryOne(`SELECT * FROM accounts WHERE id = ?`,[e]);return n?z(n):null},async create(e,t){let n=async t=>{let n=await Z(t),r=k(),i=P(),a=e.openingBalanceDate??i.slice(0,10);await t.execute(`INSERT INTO accounts
          (id, workspace_id, name, type, bank_name, account_number, card_number,
           description, opening_balance, opening_balance_date, status,
           sort_order, created_at, updated_at, created_by, updated_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, NULL, NULL)`,[r,n,e.name,e.type,e.bankName,e.accountNumber,e.cardNumber,e.description,j(e.openingBalance),a,e.sortOrder,i,i]);let o={id:r,workspaceId:n,name:e.name,type:e.type,bankName:e.bankName,accountNumber:e.accountNumber,cardNumber:e.cardNumber,description:e.description,openingBalance:e.openingBalance,openingBalanceDate:a,status:m.ACTIVE,sortOrder:e.sortOrder,createdAt:i,updatedAt:i,createdBy:null,updatedBy:null};return await G(t,{workspaceId:n,entityType:y.ACCOUNT,entityId:r,action:v.CREATE,before:null,after:q(o),actorLabel:null}),o};return t?n(t):R().transaction(n)},async update(e,t,n=null,r){let i=async r=>{let i=await r.queryOne(`SELECT * FROM accounts WHERE id = ?`,[e]);if(!i)return null;let a=z(i),o=[],s=[];if(t.name!==void 0&&(o.push(`name = ?`),s.push(t.name)),t.bankName!==void 0&&(o.push(`bank_name = ?`),s.push(t.bankName)),t.accountNumber!==void 0&&(o.push(`account_number = ?`),s.push(t.accountNumber)),t.cardNumber!==void 0&&(o.push(`card_number = ?`),s.push(t.cardNumber)),t.description!==void 0&&(o.push(`description = ?`),s.push(t.description)),t.openingBalance!==void 0&&(o.push(`opening_balance = ?`),s.push(j(t.openingBalance))),t.openingBalanceDate!==void 0&&(o.push(`opening_balance_date = ?`),s.push(t.openingBalanceDate??P().slice(0,10))),t.status!==void 0&&(o.push(`status = ?`),s.push(t.status)),t.sortOrder!==void 0&&(o.push(`sort_order = ?`),s.push(t.sortOrder)),o.length===0)return a;o.push(`updated_at = ?`),s.push(P()),o.push(`updated_by = ?`),s.push(n),s.push(e),await r.execute(`UPDATE accounts SET ${o.join(`, `)} WHERE id = ?`,s);let c=await r.queryOne(`SELECT * FROM accounts WHERE id = ?`,[e]);if(!c)return null;let l=z(c);return await G(r,{workspaceId:l.workspaceId,entityType:y.ACCOUNT,entityId:e,action:v.EDIT,before:q(a),after:q(l),actorLabel:n}),l};return r?i(r):R().transaction(i)},async archive(e,t){await this.update(e,{status:m.ARCHIVED},null,t)},async unarchive(e,t){await this.update(e,{status:m.ACTIVE},null,t)}},it={async list(e=!1,t){let n=t??R(),r=e?`SELECT * FROM parties ORDER BY name ASC`:`SELECT * FROM parties WHERE status = 'active' ORDER BY name ASC`;return(await n.query(r)).map(B)},async findById(e,t){let n=await(t??R()).queryOne(`SELECT * FROM parties WHERE id = ?`,[e]);return n?B(n):null},async search(e,t=20,n){let r=n??R(),i=S(e);return i?(await r.query(`SELECT * FROM parties
       WHERE status = 'active' AND normalized_name LIKE ?
       ORDER BY name ASC
       LIMIT ?`,[`%${i}%`,t])).map(B):this.list(!1,n)},async create(e,t){let n=async t=>{let n=await Z(t),r=k(),i=P(),a=S(e.name);await t.execute(`INSERT INTO parties
          (id, workspace_id, name, normalized_name, type, phone, card_number,
           account_number, role, notes, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`,[r,n,e.name,a,e.type,e.phone,e.cardNumber,e.accountNumber,e.role,e.notes,i,i]);let o={id:r,workspaceId:n,name:e.name,normalizedName:a,type:e.type,phone:e.phone,cardNumber:e.cardNumber,accountNumber:e.accountNumber,role:e.role,notes:e.notes,status:_.ACTIVE,createdAt:i,updatedAt:i};return await G(t,{workspaceId:n,entityType:y.PARTY,entityId:r,action:v.CREATE,before:null,after:J(o),actorLabel:null}),o};return t?n(t):R().transaction(n)},async update(e,t,n=null,r){let i=async r=>{let i=await r.queryOne(`SELECT * FROM parties WHERE id = ?`,[e]);if(!i)return null;let a=B(i),o=[],s=[];if(t.name!==void 0&&(o.push(`name = ?`),s.push(t.name),o.push(`normalized_name = ?`),s.push(S(t.name))),t.type!==void 0&&(o.push(`type = ?`),s.push(t.type)),t.phone!==void 0&&(o.push(`phone = ?`),s.push(t.phone)),t.cardNumber!==void 0&&(o.push(`card_number = ?`),s.push(t.cardNumber)),t.accountNumber!==void 0&&(o.push(`account_number = ?`),s.push(t.accountNumber)),t.role!==void 0&&(o.push(`role = ?`),s.push(t.role)),t.notes!==void 0&&(o.push(`notes = ?`),s.push(t.notes)),t.status!==void 0&&(o.push(`status = ?`),s.push(t.status)),o.length===0)return a;o.push(`updated_at = ?`),s.push(P()),s.push(e),await r.execute(`UPDATE parties SET ${o.join(`, `)} WHERE id = ?`,s);let c=await r.queryOne(`SELECT * FROM parties WHERE id = ?`,[e]);if(!c)return null;let l=B(c);return await G(r,{workspaceId:l.workspaceId,entityType:y.PARTY,entityId:e,action:v.EDIT,before:J(a),after:J(l),actorLabel:n}),l};return r?i(r):R().transaction(i)},async deactivate(e,t){await this.update(e,{status:_.ARCHIVED},null,t)},async activate(e,t){await this.update(e,{status:_.ACTIVE},null,t)}},at={async list(e){return(await(e??R()).query(`SELECT * FROM projects ORDER BY name ASC`)).map(V)},async findById(e,t){let n=await(t??R()).queryOne(`SELECT * FROM projects WHERE id = ?`,[e]);return n?V(n):null},async create(e,t){let n=async t=>{let n=await Z(t),r=k(),i=P();await t.execute(`INSERT INTO projects
          (id, workspace_id, name, code, status, budget_amount, description,
           created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,[r,n,e.name,e.code,e.status,M(e.budgetAmount),e.description,i,i]);let a={id:r,workspaceId:n,name:e.name,code:e.code,status:e.status,budgetAmount:e.budgetAmount,description:e.description,createdAt:i,updatedAt:i};return await G(t,{workspaceId:n,entityType:y.PROJECT,entityId:r,action:v.CREATE,before:null,after:Y(a),actorLabel:null}),a};return t?n(t):R().transaction(n)},async update(e,t,n=null,r){let i=async r=>{let i=await r.queryOne(`SELECT * FROM projects WHERE id = ?`,[e]);if(!i)return null;let a=V(i),o=[],s=[];if(t.name!==void 0&&(o.push(`name = ?`),s.push(t.name)),t.code!==void 0&&(o.push(`code = ?`),s.push(t.code)),t.status!==void 0&&(o.push(`status = ?`),s.push(t.status)),t.budgetAmount!==void 0&&(o.push(`budget_amount = ?`),s.push(M(t.budgetAmount))),t.description!==void 0&&(o.push(`description = ?`),s.push(t.description)),o.length===0)return a;o.push(`updated_at = ?`),s.push(P()),s.push(e),await r.execute(`UPDATE projects SET ${o.join(`, `)} WHERE id = ?`,s);let c=await r.queryOne(`SELECT * FROM projects WHERE id = ?`,[e]);if(!c)return null;let l=V(c);return await G(r,{workspaceId:l.workspaceId,entityType:y.PROJECT,entityId:e,action:v.EDIT,before:Y(a),after:Y(l),actorLabel:n}),l};return r?i(r):R().transaction(i)}},ot={async list(e=!1,t){let n=t??R(),r=e?`SELECT * FROM categories ORDER BY sort_order ASC, name ASC`:`SELECT * FROM categories WHERE status = 'active'
         ORDER BY sort_order ASC, name ASC`;return(await n.query(r)).map(H)},async findByType(e,t){return(await(t??R()).query(`SELECT * FROM categories
       WHERE status = 'active' AND (type = ? OR type = 'both')
       ORDER BY sort_order ASC, name ASC`,[e])).map(H)},async findById(e,t){let n=await(t??R()).queryOne(`SELECT * FROM categories WHERE id = ?`,[e]);return n?H(n):null},async create(e,t){let n=async t=>{let n=k();await t.execute(`INSERT INTO categories
          (id, parent_id, name, type, is_custom, sort_order, status)
         VALUES (?, ?, ?, ?, 1, ?, 'active')`,[n,e.parentId,e.name,e.type,e.sortOrder]);let r={id:n,parentId:e.parentId,name:e.name,type:e.type,isCustom:!0,sortOrder:e.sortOrder,status:ne.ACTIVE};return await G(t,{workspaceId:await Z(t),entityType:y.SYSTEM,entityId:n,action:v.CREATE,before:null,after:{...r},actorLabel:null}),r};return t?n(t):R().transaction(n)},async deactivate(e,t){await(t??R()).execute(`UPDATE categories SET status = 'archived' WHERE id = ?`,[e])}};function st(e,t,n){let r=Ae(t),i=`${e===`deposit`?`DEP`:`EXP`}-${r}-`;return{pattern:`${i}%-${n}`,seqStart:i.length+1}}async function ct(e,t,n,r){let{pattern:i,seqStart:a}=st(t,n,r);return((await e.queryOne(`SELECT MAX(CAST(SUBSTR(display_code, ?, 5) AS INTEGER)) AS max_seq
     FROM transactions
     WHERE display_code LIKE ?`,[a,i]))?.max_seq??0)+1}function lt(e,t,n,r){let i=Ae(t);return`${e===`deposit`?`DEP`:`EXP`}-${i}-${String(n).padStart(5,`0`)}-${r}`}var ut={async list(e,t){let n=t??R(),r=[],i=[];if(e.statuses.length===0)r.push(`status = 'active'`);else{let t=e.statuses.map(()=>`?`).join(`,`);r.push(`status IN (${t})`),i.push(...e.statuses)}if(e.types.length>0){let t=e.types.map(()=>`?`).join(`,`);r.push(`type IN (${t})`),i.push(...e.types)}if(e.accountIds.length>0){let t=e.accountIds.map(()=>`?`).join(`,`);r.push(`account_id IN (${t})`),i.push(...e.accountIds)}if(e.partyIds.length>0){let t=e.partyIds.map(()=>`?`).join(`,`);r.push(`party_id IN (${t})`),i.push(...e.partyIds)}if(e.projectIds.length>0){let t=e.projectIds.map(()=>`?`).join(`,`);r.push(`project_id IN (${t})`),i.push(...e.projectIds)}if(e.categoryIds.length>0){let t=e.categoryIds.map(()=>`?`).join(`,`);r.push(`category_id IN (${t})`),i.push(...e.categoryIds)}e.dateFrom&&(r.push(`transaction_date >= ?`),i.push(e.dateFrom)),e.dateTo&&(r.push(`transaction_date <= ?`),i.push(e.dateTo)),e.amountMin!==null&&(r.push(`amount >= ?`),i.push(j(e.amountMin))),e.amountMax!==null&&(r.push(`amount <= ?`),i.push(j(e.amountMax)));let a=r.length>0?`WHERE ${r.join(` AND `)}`:``;return(await n.query(`SELECT * FROM transactions ${a}
       ORDER BY transaction_date DESC, transaction_time DESC, created_at DESC`,i)).map(U)},async listAll(e){return(await(e??R()).query(`SELECT * FROM transactions ORDER BY transaction_date DESC, created_at DESC`)).map(U)},async listActive(e){return(await(e??R()).query(`SELECT * FROM transactions WHERE status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`)).map(U)},async listByAccount(e,t){return(await(t??R()).query(`SELECT * FROM transactions
       WHERE account_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,[e])).map(U)},async listByParty(e,t){return(await(t??R()).query(`SELECT * FROM transactions
       WHERE party_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,[e])).map(U)},async listByProject(e,t){return(await(t??R()).query(`SELECT * FROM transactions
       WHERE project_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,[e])).map(U)},async findById(e,t){let n=await(t??R()).queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]);return n?U(n):null},async findByDisplayCode(e,t){let n=await(t??R()).queryOne(`SELECT * FROM transactions WHERE display_code = ?`,[e]);return n?U(n):null},async create(e,t){let n=async t=>{let n=await Z(t),r=await Q(t),i=k(),a=P(),o=await ct(t,e.type,e.transactionDate,r),s=lt(e.type,e.transactionDate,o,r);await t.execute(`INSERT INTO transactions
          (id, workspace_id, display_code, type, amount, account_id, party_id,
           category_id, custom_category_text, project_id, transaction_date,
           transaction_time, reference_code, description, status, version,
           device_id, created_at, updated_at, created_by, updated_by, deleted_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 1,
                 NULL, ?, ?, ?, NULL, NULL)`,[i,n,s,e.type,j(e.amount),e.accountId,e.partyId,e.categoryId,e.customCategoryText,e.projectId,e.transactionDate,e.transactionTime,e.referenceCode,e.description,a,a,e.createdBy]);let c={id:i,workspaceId:n,displayCode:s,type:e.type,amount:e.amount,accountId:e.accountId,partyId:e.partyId,categoryId:e.categoryId,customCategoryText:e.customCategoryText,projectId:e.projectId,transactionDate:e.transactionDate,transactionTime:e.transactionTime,referenceCode:e.referenceCode,description:e.description,status:f.ACTIVE,version:1,deviceId:null,createdAt:a,updatedAt:a,createdBy:e.createdBy,updatedBy:null,deletedAt:null};return await G(t,{workspaceId:n,entityType:y.TRANSACTION,entityId:i,action:v.CREATE,before:null,after:X(c),actorLabel:e.createdBy}),c};return t?n(t):R().transaction(n)},async update(e,t,n){let r=async n=>{let r=await n.queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]);if(!r)return null;let i=U(r),a=[],o=[];if(t.amount!==void 0&&(a.push(`amount = ?`),o.push(j(t.amount))),t.accountId!==void 0&&(a.push(`account_id = ?`),o.push(t.accountId)),t.partyId!==void 0&&(a.push(`party_id = ?`),o.push(t.partyId)),t.categoryId!==void 0&&(a.push(`category_id = ?`),o.push(t.categoryId)),t.customCategoryText!==void 0&&(a.push(`custom_category_text = ?`),o.push(t.customCategoryText)),t.projectId!==void 0&&(a.push(`project_id = ?`),o.push(t.projectId)),t.transactionDate!==void 0&&(a.push(`transaction_date = ?`),o.push(t.transactionDate)),t.transactionTime!==void 0&&(a.push(`transaction_time = ?`),o.push(t.transactionTime)),t.referenceCode!==void 0&&(a.push(`reference_code = ?`),o.push(t.referenceCode)),t.description!==void 0&&(a.push(`description = ?`),o.push(t.description)),a.length===0)return i;a.push(`version = version + 1`),a.push(`updated_at = ?`),o.push(P()),a.push(`updated_by = ?`),o.push(t.updatedBy??null),o.push(e),await n.execute(`UPDATE transactions SET ${a.join(`, `)} WHERE id = ?`,o);let s=await n.queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]);if(!s)return null;let c=U(s);return await G(n,{workspaceId:c.workspaceId,entityType:y.TRANSACTION,entityId:e,action:v.EDIT,before:X(i),after:X(c),actorLabel:t.updatedBy??null}),c};return n?r(n):R().transaction(r)},async softDelete(e,t=null,n){let r=async n=>{let r=await n.queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]);if(!r)return!1;let i=U(r),a=P();return await n.execute(`UPDATE transactions
         SET status = 'soft_deleted', deleted_at = ?, updated_at = ?,
             version = version + 1
         WHERE id = ?`,[a,a,e]),await G(n,{workspaceId:i.workspaceId,entityType:y.TRANSACTION,entityId:e,action:v.DELETE,before:X(i),after:null,actorLabel:t}),!0};return n?r(n):R().transaction(r)},async restore(e,t=null,n){let r=async n=>{let r=await n.queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]);if(!r)return!1;let i=U(r),a=P();await n.execute(`UPDATE transactions
         SET status = 'active', deleted_at = NULL, updated_at = ?,
             version = version + 1
         WHERE id = ?`,[a,e]);let o=await n.queryOne(`SELECT * FROM transactions WHERE id = ?`,[e]),s=o?U(o):null;return await G(n,{workspaceId:i.workspaceId,entityType:y.TRANSACTION,entityId:e,action:v.RESTORE,before:X(i),after:s?X(s):null,actorLabel:t}),!0};return n?r(n):R().transaction(r)},async countByAccount(e,t){return(await(t??R()).queryOne(`SELECT COUNT(*) AS count FROM transactions
       WHERE account_id = ? AND status = 'active'`,[e]))?.count??0}},dt={async list(e=100,t){return(await(t??R()).query(`SELECT * FROM audit_events ORDER BY created_at DESC LIMIT ?`,[e])).map(W)},async listByEntity(e,t,n){return(await(n??R()).query(`SELECT * FROM audit_events
       WHERE entity_type = ? AND entity_id = ?
       ORDER BY created_at DESC`,[e,t])).map(W)},async listByAction(e,t=100,n){return(await(n??R()).query(`SELECT * FROM audit_events WHERE action = ? ORDER BY created_at DESC LIMIT ?`,[e,t])).map(W)},async countAll(e){return(await(e??R()).queryOne(`SELECT COUNT(*) AS count FROM audit_events`))?.count??0}},ft={async get(e,t){let n=await(t??R()).queryOne(`SELECT * FROM drafts WHERE id = ?`,[e]);return n?{id:n.id,formType:n.form_type,formJson:n.form_json,updatedAt:n.updated_at}:null},async save(e,t,n=`transaction`,r){await(r??R()).execute(`INSERT INTO drafts (id, form_type, form_json, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         form_type = excluded.form_type,
         form_json = excluded.form_json,
         updated_at = excluded.updated_at`,[e,n,t,P()])},async clear(e,t){await(t??R()).execute(`DELETE FROM drafts WHERE id = ?`,[e])},async listAll(e){return(await(e??R()).query(`SELECT * FROM drafts ORDER BY updated_at DESC`)).map(e=>({id:e.id,formType:e.form_type,formJson:e.form_json,updatedAt:e.updated_at}))}},pt={async get(e){let t=await(e??R()).queryOne(`SELECT * FROM security_profiles WHERE id = 'default'`);return t?nt(t):null},async ensureInitialized(e){return await this.get(e)||(await(e??R()).execute(`INSERT INTO security_profiles
        (id, pin_hash, pattern_hash, biometric_enabled, primary_method,
         failed_attempts, lockout_until, recovery_used_count,
         lock_timeout_seconds, configured_at)
       VALUES ('default', NULL, NULL, 0, NULL, 0, NULL, 0, 0, NULL)`),{id:`default`,pinHash:null,patternHash:null,biometricEnabled:!1,primaryMethod:null,failedAttempts:0,lockoutUntil:null,recoveryUsedCount:0,lockTimeoutSeconds:0,configuredAt:null})},async update(e,t){let n=t??R(),r=[],i=[];e.pinHash!==void 0&&(r.push(`pin_hash = ?`),i.push(e.pinHash)),e.patternHash!==void 0&&(r.push(`pattern_hash = ?`),i.push(e.patternHash)),e.biometricEnabled!==void 0&&(r.push(`biometric_enabled = ?`),i.push(He(e.biometricEnabled))),e.primaryMethod!==void 0&&(r.push(`primary_method = ?`),i.push(e.primaryMethod)),e.failedAttempts!==void 0&&(r.push(`failed_attempts = ?`),i.push(e.failedAttempts)),e.lockoutUntil!==void 0&&(r.push(`lockout_until = ?`),i.push(e.lockoutUntil)),e.recoveryUsedCount!==void 0&&(r.push(`recovery_used_count = ?`),i.push(e.recoveryUsedCount)),e.lockTimeoutSeconds!==void 0&&(r.push(`lock_timeout_seconds = ?`),i.push(e.lockTimeoutSeconds)),e.configuredAt!==void 0&&(r.push(`configured_at = ?`),i.push(e.configuredAt)),r.length!==0&&await n.execute(`UPDATE security_profiles SET ${r.join(`, `)} WHERE id = 'default'`,i)},async reset(e){await(e??R()).execute(`DELETE FROM security_profiles WHERE id = 'default'`)}},mt={async list(e=20,t){return(await(t??R()).query(`SELECT * FROM backup_records ORDER BY created_at DESC LIMIT ?`,[e])).map(e=>({id:e.id,fileName:e.file_name,type:e.type,sizeBytes:e.size_bytes,transactionCount:e.transaction_count,schemaVersion:e.schema_version,appVersion:e.app_version,createdAt:e.created_at,checksum:e.checksum}))},async create(e,t){let n=t??R(),r=k(),i=P();return await n.execute(`INSERT INTO backup_records
        (id, file_name, type, size_bytes, transaction_count, schema_version,
         app_version, created_at, checksum)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,[r,e.fileName,e.type,e.sizeBytes,e.transactionCount,e.schemaVersion,e.appVersion,i,e.checksum]),{id:r,fileName:e.fileName,type:e.type,sizeBytes:e.sizeBytes,transactionCount:e.transactionCount,schemaVersion:e.schemaVersion,appVersion:e.appVersion,createdAt:i,checksum:e.checksum}}},ht={async createJob(e,t){let n=t??R(),r=k(),i=P();return await n.execute(`INSERT INTO import_jobs (id, file_name, started_at, finished_at, status, stats_json)
       VALUES (?, ?, ?, NULL, 'analyzing', NULL)`,[r,e,i]),{id:r,fileName:e,startedAt:i,finishedAt:null,status:b.ANALYZING,statsJson:null}},async updateJobStatus(e,t,n,r){let i=r??R(),a=t===b.COMMITTED||t===b.CANCELLED||t===b.FAILED?P():null;await i.execute(`UPDATE import_jobs SET status = ?, stats_json = ?, finished_at = ? WHERE id = ?`,[t,n,a,e])},async addRecord(e,t){let n=t??R(),r=k();await n.execute(`INSERT INTO import_records
        (id, job_id, row_number, row_hash, decision,
         matched_transaction_id, duplicate_score, error_message)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,[r,e.jobId,e.rowNumber,e.rowHash,e.decision,e.matchedTransactionId,e.duplicateScore,e.errorMessage])},async findRecordByHash(e,t){let n=await(t??R()).queryOne(`SELECT id, job_id, decision FROM import_records WHERE row_hash = ? LIMIT 1`,[e]);return n?{id:n.id,jobId:n.job_id,decision:n.decision}:null},async listMappings(e){return(await(e??R()).query(`SELECT * FROM import_mappings ORDER BY created_at DESC`)).map(e=>({id:e.id,name:e.name,mappingJson:e.mapping_json,createdAt:e.created_at}))},async saveMapping(e,t,n){let r=n??R(),i=k(),a=P();return await r.execute(`INSERT INTO import_mappings (id, name, mapping_json, created_at)
       VALUES (?, ?, ?, ?)`,[i,e,t,a]),{id:i,name:e,mappingJson:t,createdAt:a}}};function gt(e){let t=null;if(e.message_params_json)try{let n=JSON.parse(e.message_params_json);n&&typeof n==`object`&&!Array.isArray(n)&&(t=n)}catch{t=null}return{id:e.id,type:e.type,severity:e.severity,entityType:e.entity_type??null,entityId:e.entity_id,messageKey:e.message_key,messageParams:t,createdAt:e.created_at,readAt:e.read_at,resolvedAt:e.resolved_at}}var _t={async list(e={},t){let n=t??R(),r=[];e.onlyUnread&&r.push(`read_at IS NULL`),e.onlyUnresolved&&r.push(`resolved_at IS NULL`);let i=r.length>0?`WHERE ${r.join(` AND `)}`:``,a=e.limit??200;return(await n.query(`SELECT * FROM alerts ${i} ORDER BY created_at DESC LIMIT ?`,[a])).map(gt)},async create(e,t){let n=t??R(),r=k(),i=P();return await n.execute(`INSERT INTO alerts
        (id, type, severity, entity_type, entity_id, message_key,
         message_params_json, created_at, read_at, resolved_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)`,[r,e.type,e.severity,e.entityType,e.entityId,e.messageKey,e.messageParams===null?null:JSON.stringify(e.messageParams),i]),{id:r,type:e.type,severity:e.severity,entityType:e.entityType,entityId:e.entityId,messageKey:e.messageKey,messageParams:e.messageParams,createdAt:i,readAt:null,resolvedAt:null}},async markRead(e,t){await(t??R()).execute(`UPDATE alerts SET read_at = ? WHERE id = ? AND read_at IS NULL`,[P(),e])},async markAllRead(e){await(e??R()).execute(`UPDATE alerts SET read_at = ? WHERE read_at IS NULL`,[P()])},async resolve(e,t){await(t??R()).execute(`UPDATE alerts SET resolved_at = ? WHERE id = ? AND resolved_at IS NULL`,[P(),e])},async unreadCount(e){return(await(e??R()).queryOne(`SELECT COUNT(*) AS count FROM alerts
       WHERE read_at IS NULL AND resolved_at IS NULL`))?.count??0},async deleteById(e,t){await(t??R()).execute(`DELETE FROM alerts WHERE id = ?`,[e])}},vt={async get(e){let t=await(e??R()).queryOne(`SELECT * FROM workspaces LIMIT 1`);return t?{id:t.id,name:t.name,createdAt:t.created_at}:null}},yt={generateULID:k,generateDevicePrefix:A,toDbMoney:j,toDbMoneyNullable:M,fromDbMoney:Be,fromDbMoneyNullable:Ve,toDbBool:He,fromDbBool:N,nowISO:P,isNativePlatform:D,randomBytes:O};export{f as $,ke as A,ne as B,x as C,ve as D,Te as E,ce as F,b as G,de as H,se as I,h as J,g as K,v as L,fe as M,m as N,Me as O,p as P,le as Q,y as R,T as S,Pe as T,ie as U,te as V,re as W,ue as X,oe as Y,ee as Z,$ as _,mt as a,ge as b,Fe as c,Q as d,d as et,Z as f,pt as g,at as h,dt as i,Ne as j,_e as k,ft as l,it as m,rt as n,c as nt,ot as o,ht as p,_ as q,_t as r,u as rt,yt as s,E as t,s as tt,L as u,ut as v,S as w,Oe as x,vt as y,ae as z};