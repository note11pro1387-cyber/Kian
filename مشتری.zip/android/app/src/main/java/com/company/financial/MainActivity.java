package com.company.financial;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
