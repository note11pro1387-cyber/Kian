// vitest.config.ts

import { defineConfig } from 'vitest/config';
import react from '@vitejs/plugin-react';
import { fileURLToPath, URL } from 'node:url';

export default defineConfig({
  plugins: [react()],

  resolve: {
    alias: {
      '@': fileURLToPath(new URL('./src', import.meta.url)),
    },
  },

  test: {
    environment: 'jsdom',

    environmentOptions: {
      jsdom: {
        url: 'http://localhost/',
        pretendToBeVisual: true,
      },
    },

    globals: true,

    setupFiles: ['./tests/setup.ts'],

    // طبق SPEC v2.0 بخش ۳۸: این هرگز نباید true باشد
    passWithNoTests: false,

    include: ['tests/**/*.{test,spec}.{ts,tsx}', 'src/**/*.{test,spec}.{ts,tsx}'],

    exclude: [
      'node_modules/**',
      'dist/**',
      'build/**',
      'android/**',
      'ios/**',
      'tests/e2e/**',
      '**/*.d.ts',
    ],

    fileParallelism: true,

    sequence: {
      shuffle: false,
      concurrent: false,
    },

    testTimeout: 10_000,
    hookTimeout: 10_000,
    teardownTimeout: 5_000,

    reporters: ['default'],
    watch: false,
    isolate: true,

    clearMocks: true,
    mockReset: true,
    restoreMocks: true,

    coverage: {
      provider: 'v8',
      reporter: ['text', 'json', 'html', 'lcov'],
      reportsDirectory: './coverage',

      include: ['src/**/*.{ts,tsx}'],

      exclude: [
        'src/main.tsx',
        'src/**/*.d.ts',
        'src/**/*.test.{ts,tsx}',
        'src/**/*.spec.{ts,tsx}',
        'src/types.ts',
        'src/i18n.ts',
        'src/ui/**',
        'src/styles.css',
      ],

      thresholds: {
        'src/formatters.ts': {
          statements: 90,
          branches: 85,
          functions: 90,
          lines: 90,
        },

        'src/domain.ts': {
          statements: 90,
          branches: 85,
          functions: 90,
          lines: 90,
        },

        'src/validation.ts': {
          statements: 85,
          branches: 80,
          functions: 85,
          lines: 85,
        },

        'src/backup.ts': {
          statements: 80,
          branches: 75,
          functions: 80,
          lines: 80,
        },

        'src/importExport.ts': {
          statements: 75,
          branches: 70,
          functions: 75,
          lines: 75,
        },

        lines: 60,
        functions: 60,
        branches: 55,
        statements: 60,
      },
    },

    pool: 'threads',

    silent: false,
    logHeapUsage: false,
    bail: 0,
  },

  define: {
    'import.meta.env.VITE_APP_VERSION': JSON.stringify('1.0.0-test'),
    'import.meta.env.MODE': JSON.stringify('test'),
    'import.meta.env.DEV': JSON.stringify(false),
    'import.meta.env.PROD': JSON.stringify(false),
    'import.meta.env.SSR': JSON.stringify(false),
  },
});
