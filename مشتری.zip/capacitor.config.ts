// capacitor.config.ts

import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.company.financial',
  appName: 'مدیریت مالی',
  webDir: 'dist',
  
  loggingBehavior: 'none',
  
  server: {
    androidScheme: 'https',
    hostname: 'localhost',
    cleartext: false,
    allowNavigation: [],
  },
  
  android: {
    path: 'android',
    allowMixedContent: false,
    captureInput: true,
    webContentsDebuggingEnabled: false,
    appendUserAgent: 'FinancialApp/1.0',
    buildOptions: {
      releaseType: 'APK',
      signingType: 'apksigner',
    },
  },
  
  ios: {
    path: 'ios',
    contentInset: 'always',
    preferredContentMode: 'mobile',
    scheme: 'financial-app',
    webContentsDebuggingEnabled: false,
    limitsNavigationsToAppBoundDomains: true,
  },
  
  plugins: {
    CapacitorSQLite: {
      androidDatabaseLocation: 'default',
      androidIsEncryption: true,
      androidBiometric: {
        biometricAuth: false,
        biometricTitle: 'ورود با بیومتریک',
        biometricSubTitle: 'برای دسترسی به دیتابیس، هویت خود را تأیید کنید',
      },
      iosDatabaseLocation: 'Library/CapacitorDatabase',
      iosIsEncryption: true,
      iosKeychainPrefix: 'financial-app',
      iosBiometric: {
        biometricAuth: false,
        biometricTitle: 'Biometric login for financial app',
        biometricSubTitle: 'Log in using your biometric',
      },
    },
    
    Camera: {},
    Filesystem: {},
    Share: {},
    Haptics: {},
    
    Preferences: {
      group: 'FinancialAppPreferences',
    },
    
    StatusBar: {
      style: 'dark',
      backgroundColor: '#0b1020',
      overlaysWebView: false,
    },
    
    App: {},
  },
  
  includePlugins: [
    '@capacitor/app',
    '@capacitor/camera',
    '@capacitor/filesystem',
    '@capacitor/haptics',
    '@capacitor/preferences',
    '@capacitor/share',
    '@capacitor/status-bar',
    '@capacitor-community/sqlite',
  ],
};

export default config;
