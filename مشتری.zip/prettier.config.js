// prettier.config.js

const config = {
  printWidth: 90,
  tabWidth: 2,
  useTabs: false,
  endOfLine: 'lf',

  semi: true,
  singleQuote: true,
  quoteProps: 'as-needed',
  trailingComma: 'es5',
  bracketSpacing: true,
  bracketSameLine: false,
  arrowParens: 'always',

  jsxSingleQuote: false,
  jsxBracketSameLine: false,

  htmlWhitespaceSensitivity: 'css',
  vueIndentScriptAndStyle: false,

  proseWrap: 'preserve',

  embeddedLanguageFormatting: 'auto',

  overrides: [
    {
      files: ['*.md', 'README.md'],
      options: { proseWrap: 'preserve', tabWidth: 2 },
    },
    {
      files: ['*.json', '*.jsonc', 'tsconfig*.json', 'package.json'],
      options: { printWidth: 100, tabWidth: 2 },
    },
    {
      files: ['*.yml', '*.yaml'],
      options: { tabWidth: 2, singleQuote: false },
    },
    {
      files: ['*.css'],
      options: { printWidth: 100, singleQuote: false },
    },
    {
      files: ['android/**/*.java', 'android/**/*.kt', 'android/**/*.gradle'],
      options: { tabWidth: 4 },
    },
  ],
};

export default config;
