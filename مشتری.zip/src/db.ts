// ============================================================================
//  src/db.ts
//  لایه‌ی داده‌ی SQLite — دو Adapter (Native/Web) + Migration + Repository ها
// ============================================================================
//
//  ── قوانین این فایل ────────────────────────────────────────────────────
//
//   ۱. تنها نقطه‌ی دسترسی مستقیم SQL در کل پروژه.
//   ۲. هیچ import از React، UI یا Capacitor در Type/Interface آن استفاده نمی‌شود.
//   ۳. جهت وابستگی: Services → db.ts (فقط یک‌طرفه).
//   ۴. تمام محاسبات مالی در domain.ts است، این فایل فقط ذخیره/خواندن.
//   ۵. رمزنگاری Native با SQLCipher واقعی. هیچ `no-encryption` در Production.
//   ۶. `randomBytes` Fail-Closed اگر crypto در دسترس نباشد.
// ============================================================================

import {
  AccountStatus,
  AuditAction,
  AuditEntityType,
  CategoryStatus,
  ImportStatus,
  PartyStatus,
  TransactionStatus,
} from './types';

import type {
  Account,
  AccountId,
  AccountStatus as AccountStatusType,
  AccountType as AccountTypeType,
  AlertItem,
  AlertSeverity,
  AlertType,
  AppSetting,
  Attachment,
  AttachmentId,
  AuditEntityType as AuditEntityTypeType,
  AuditEvent,
  BackupRecord,
  BackupType as BackupTypeValue,
  Category,
  CategoryId,
  CategoryStatus as CategoryStatusType,
  CategoryType as CategoryTypeValue,
  ClockTime,
  CreateAccountInput,
  CreateCategoryInput,
  CreatePartyInput,
  CreateProjectInput,
  CreateTransactionInput,
  DisplayCode,
  Draft,
  DraftKey as DraftKeyType,
  ImportDecision as ImportDecisionValue,
  ImportJob,
  ImportJobId,
  ImportMapping,
  ImportRecordId,
  ImportStatus as ImportStatusValue,
  ISODate,
  ISOTimestamp,
  Money,
  Party,
  PartyId,
  PartyRole as PartyRoleValue,
  PartyStatus as PartyStatusType,
  PartyType as PartyTypeValue,
  PrimarySecurityMethod as PrimarySecurityMethodValue,
  Project,
  ProjectId,
  ProjectStatus as ProjectStatusType,
  SecurityProfile,
  Transaction,
  TransactionId,
  TransactionFilter,
  TransactionStatus as TransactionStatusType,
  TransactionType as TransactionTypeValue,
  ULID,
  UpdateAccountInput,
  UpdatePartyInput,
  UpdateProjectInput,
  UpdateTransactionInput,
} from './types';

import { toJalaliCompact, normalizePersianText } from './formatters';

// ============================================================================
//  Constants
// ============================================================================

export const SCHEMA_VERSION = 2;

export const SETTINGS_KEYS = {
  THEME: 'theme',
  LANGUAGE: 'language',
  COMPANY_NAME: 'company_name',
  LAST_BACKUP_AT: 'last_backup_at',
  PERFORMANCE_TIER: 'performance_tier',
  ONBOARDING_DONE: 'onboarding_done',
  SECURITY_PROMPT_COUNT: 'security_prompt_count',
  DEVICE_PREFIX: 'device_prefix',
  WORKSPACE_ID: 'workspace_id',
  PRIVACY_HIDE_AMOUNTS: 'privacy_hide_amounts',
  ASSET_CACHE_VERSION: 'asset_cache_version',
} as const;

export type SettingsKey = (typeof SETTINGS_KEYS)[keyof typeof SETTINGS_KEYS];

const NATIVE_DB_NAME = 'finsecure';
const NATIVE_DB_VERSION = 2;

// ============================================================================
//  Platform detection
// ============================================================================

interface CapacitorGlobal {
  isNativePlatform?: () => boolean;
}

function getCapacitor(): CapacitorGlobal | null {
  if (typeof window === 'undefined') return null;
  return (window as { Capacitor?: CapacitorGlobal }).Capacitor ?? null;
}

export function isNativePlatform(): boolean {
  const cap = getCapacitor();
  return cap?.isNativePlatform?.() === true;
}

// ============================================================================
//  Secure random — Fail-Closed
// ============================================================================

/**
 * تولید بایت تصادفی امن.
 *
 * طبق SPEC v2.0 §۵ و §۹.۸، هیچ fallback به Math.random مجاز نیست.
 * اگر crypto.getRandomValues در دسترس نباشد، عملیات امنیتی fail می‌شود.
 */
function randomBytes(n: number): Uint8Array {
  if (!Number.isInteger(n) || n <= 0) {
    throw new Error('Secure random byte length must be a positive integer');
  }

  const cryptoObj = globalThis.crypto;
  if (!cryptoObj || typeof cryptoObj.getRandomValues !== 'function') {
    throw new Error(
      'Secure random generator is unavailable. Cannot proceed with security-sensitive operation.'
    );
  }

  const arr = new Uint8Array(n);
  cryptoObj.getRandomValues(arr);
  return arr;
}

// ============================================================================
//  ULID
// ============================================================================

const CROCKFORD = '0123456789ABCDEFGHJKMNPQRSTVWXYZ';

export function generateULID(): ULID {
  const now = Date.now();
  let timePart = '';
  let t = now;
  for (let i = 0; i < 10; i++) {
    timePart = CROCKFORD[t % 32] + timePart;
    t = Math.floor(t / 32);
  }
  const bytes = randomBytes(16);
  let randomPart = '';
  for (let i = 0; i < 16; i++) {
    randomPart += CROCKFORD[bytes[i]! % 32];
  }
  return timePart + randomPart;
}

export function generateDevicePrefix(): string {
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  const bytes = randomBytes(4);
  let result = '';
  for (let i = 0; i < 3; i++) {
    result += alphabet[bytes[i]! % alphabet.length];
  }
  return result;
}

// ============================================================================
//  Money conversions
// ============================================================================

function toDbMoney(m: Money): number {
  const n = Number(m);
  if (!Number.isSafeInteger(n)) {
    throw new Error(
      'Money value exceeds JavaScript safe integer range for database storage'
    );
  }
  return n;
}

function toDbMoneyNullable(m: Money | null): number | null {
  if (m === null) return null;
  return toDbMoney(m);
}

function fromDbMoney(v: number | string | null | undefined): Money {
  if (v === null || v === undefined) return 0n;
  return BigInt(typeof v === 'string' ? v : Math.trunc(v));
}

function fromDbMoneyNullable(v: number | string | null | undefined): Money | null {
  if (v === null || v === undefined) return null;
  return BigInt(typeof v === 'string' ? v : Math.trunc(v));
}

function toDbBool(b: boolean): number {
  return b ? 1 : 0;
}

function fromDbBool(v: number | null | undefined): boolean {
  return v === 1;
}

function nowISO(): ISOTimestamp {
  return new Date().toISOString();
}

// ============================================================================
//  Schema — V2 (SPEC v2.0)
// ============================================================================

const SCHEMA_V2_STATEMENTS: readonly string[] = [
  // ── workspaces ─────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS workspaces (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,

  // ── accounts ───────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS accounts (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    bank_name TEXT,
    account_number TEXT,
    card_number TEXT,
    description TEXT,
    opening_balance INTEGER NOT NULL DEFAULT 0,
    opening_balance_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'active',
    sort_order INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT,
    updated_by TEXT,
    CHECK (type IN ('bank','cash','card','treasury')),
    CHECK (status IN ('active','archived')),
    CHECK (opening_balance >= 0)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_accounts_workspace ON accounts(workspace_id)`,
  `CREATE INDEX IF NOT EXISTS idx_accounts_status ON accounts(status)`,
  `CREATE INDEX IF NOT EXISTS idx_accounts_sort ON accounts(sort_order, name)`,

  // ── parties ────────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS parties (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    normalized_name TEXT NOT NULL,
    type TEXT NOT NULL,
    phone TEXT,
    card_number TEXT,
    account_number TEXT,
    role TEXT,
    notes TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK (type IN ('person','company')),
    CHECK (status IN ('active','archived')),
    CHECK (role IS NULL OR role IN ('contractor','employee','customer','supplier','other'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_parties_workspace ON parties(workspace_id)`,
  `CREATE INDEX IF NOT EXISTS idx_parties_normalized ON parties(normalized_name)`,
  `CREATE INDEX IF NOT EXISTS idx_parties_status ON parties(status)`,

  // ── projects ───────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS projects (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    name TEXT NOT NULL,
    code TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    budget_amount INTEGER,
    description TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    CHECK (status IN ('active','done','paused','archived')),
    CHECK (budget_amount IS NULL OR budget_amount >= 0)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_projects_workspace ON projects(workspace_id)`,
  `CREATE INDEX IF NOT EXISTS idx_projects_status ON projects(status)`,

  // ── categories (purpose_categories) ────────────────────────────────
  `CREATE TABLE IF NOT EXISTS categories (
    id TEXT PRIMARY KEY,
    parent_id TEXT REFERENCES categories(id) ON DELETE RESTRICT,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    is_custom INTEGER NOT NULL DEFAULT 0,
    sort_order INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'active',
    CHECK (type IN ('expense','income','both')),
    CHECK (status IN ('active','archived')),
    CHECK (is_custom IN (0,1))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_categories_parent ON categories(parent_id)`,
  `CREATE INDEX IF NOT EXISTS idx_categories_type ON categories(type)`,
  `CREATE INDEX IF NOT EXISTS idx_categories_status ON categories(status)`,

  // ── transactions ───────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS transactions (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL REFERENCES workspaces(id),
    display_code TEXT NOT NULL UNIQUE,
    type TEXT NOT NULL,
    amount INTEGER NOT NULL,
    account_id TEXT NOT NULL REFERENCES accounts(id) ON DELETE RESTRICT,
    party_id TEXT REFERENCES parties(id) ON DELETE SET NULL,
    category_id TEXT REFERENCES categories(id) ON DELETE SET NULL,
    custom_category_text TEXT,
    project_id TEXT REFERENCES projects(id) ON DELETE SET NULL,
    transaction_date TEXT NOT NULL,
    transaction_time TEXT,
    reference_code TEXT,
    description TEXT,
    status TEXT NOT NULL DEFAULT 'active',
    version INTEGER NOT NULL DEFAULT 1,
    device_id TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL,
    created_by TEXT,
    updated_by TEXT,
    deleted_at TEXT,
    CHECK (type IN ('deposit','expense')),
    CHECK (status IN ('active','soft_deleted')),
    CHECK (amount > 0)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_tx_workspace ON transactions(workspace_id)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_account_date ON transactions(account_id, transaction_date DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_party_date ON transactions(party_id, transaction_date DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_project_date ON transactions(project_id, transaction_date DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_category_date ON transactions(category_id, transaction_date DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_date ON transactions(transaction_date DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_status ON transactions(status)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_type_status ON transactions(type, status)`,
  `CREATE INDEX IF NOT EXISTS idx_tx_display ON transactions(display_code)`,

  // ── attachments ────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS attachments (
    id TEXT PRIMARY KEY,
    transaction_id TEXT NOT NULL REFERENCES transactions(id) ON DELETE CASCADE,
    type TEXT NOT NULL DEFAULT 'image',
    file_name TEXT NOT NULL,
    storage_key TEXT NOT NULL,
    thumbnail_key TEXT,
    mime_type TEXT NOT NULL,
    size_bytes INTEGER NOT NULL,
    sha256 TEXT NOT NULL,
    created_at TEXT NOT NULL,
    CHECK (size_bytes >= 0)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_attachments_tx ON attachments(transaction_id)`,

  // ── audit_events (append-only) ─────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS audit_events (
    id TEXT PRIMARY KEY,
    workspace_id TEXT NOT NULL,
    entity_type TEXT NOT NULL,
    entity_id TEXT,
    action TEXT NOT NULL,
    before_json TEXT,
    after_json TEXT,
    actor_label TEXT,
    device_id TEXT,
    created_at TEXT NOT NULL,
    CHECK (entity_type IN ('transaction','account','party','project','security','system')),
    CHECK (action IN (
      'create','edit','delete','restore','import',
      'backup_restore','security_change','export','master_recovery_used'
    ))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_audit_entity ON audit_events(entity_type, entity_id)`,
  `CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_events(created_at DESC)`,
  `CREATE INDEX IF NOT EXISTS idx_audit_action ON audit_events(action)`,

  // ── import_jobs ────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS import_jobs (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    started_at TEXT NOT NULL,
    finished_at TEXT,
    status TEXT NOT NULL,
    stats_json TEXT,
    CHECK (status IN ('analyzing','previewing','committed','cancelled','failed'))
  )`,

  // ── import_records ─────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS import_records (
    id TEXT PRIMARY KEY,
    job_id TEXT NOT NULL REFERENCES import_jobs(id) ON DELETE CASCADE,
    row_number INTEGER NOT NULL,
    row_hash TEXT NOT NULL,
    decision TEXT NOT NULL,
    matched_transaction_id TEXT,
    duplicate_score TEXT,
    error_message TEXT,
    CHECK (decision IN ('imported','skipped','updated','conflict','error')),
    CHECK (duplicate_score IS NULL OR duplicate_score IN ('exact','likely','possible','unique'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_import_records_job ON import_records(job_id)`,
  `CREATE INDEX IF NOT EXISTS idx_import_records_hash ON import_records(row_hash)`,

  // ── import_mappings ────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS import_mappings (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    mapping_json TEXT NOT NULL,
    created_at TEXT NOT NULL
  )`,

  // ── security_profiles ──────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS security_profiles (
    id TEXT PRIMARY KEY CHECK (id = 'default'),
    pin_hash TEXT,
    pattern_hash TEXT,
    biometric_enabled INTEGER NOT NULL DEFAULT 0,
    primary_method TEXT,
    failed_attempts INTEGER NOT NULL DEFAULT 0,
    lockout_until TEXT,
    recovery_used_count INTEGER NOT NULL DEFAULT 0,
    lock_timeout_seconds INTEGER NOT NULL DEFAULT 0,
    configured_at TEXT,
    CHECK (primary_method IS NULL OR primary_method IN ('pin','pattern')),
    CHECK (biometric_enabled IN (0,1)),
    CHECK (failed_attempts >= 0),
    CHECK (recovery_used_count >= 0),
    CHECK (lock_timeout_seconds >= 0)
  )`,

  // ── app_settings ───────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS app_settings (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
  )`,

  // ── backup_records ─────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS backup_records (
    id TEXT PRIMARY KEY,
    file_name TEXT NOT NULL,
    type TEXT NOT NULL DEFAULT 'full',
    size_bytes INTEGER NOT NULL,
    transaction_count INTEGER NOT NULL,
    schema_version INTEGER NOT NULL,
    app_version TEXT NOT NULL,
    created_at TEXT NOT NULL,
    checksum TEXT NOT NULL,
    CHECK (type IN ('full','data_export')),
    CHECK (size_bytes >= 0),
    CHECK (transaction_count >= 0),
    CHECK (schema_version > 0)
  )`,
  `CREATE INDEX IF NOT EXISTS idx_backup_created ON backup_records(created_at DESC)`,

  // ── drafts ─────────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS drafts (
    id TEXT PRIMARY KEY,
    form_type TEXT NOT NULL DEFAULT 'transaction',
    form_json TEXT NOT NULL,
    updated_at TEXT NOT NULL
  )`,

  // ── alerts ─────────────────────────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS alerts (
    id TEXT PRIMARY KEY,
    type TEXT NOT NULL,
    severity TEXT NOT NULL,
    entity_type TEXT,
    entity_id TEXT,
    message_key TEXT NOT NULL,
    message_params_json TEXT,
    created_at TEXT NOT NULL,
    read_at TEXT,
    resolved_at TEXT,
    CHECK (type IN (
      'negative_balance','duplicate_candidate','reconciliation_mismatch',
      'backup_reminder','sync_conflict','info'
    )),
    CHECK (severity IN ('info','warning','critical')),
    CHECK (entity_type IS NULL OR entity_type IN ('transaction','account','party','project','security','system'))
  )`,
  `CREATE INDEX IF NOT EXISTS idx_alerts_unread ON alerts(read_at)`,
  `CREATE INDEX IF NOT EXISTS idx_alerts_type ON alerts(type)`,

  // ── devices (Phase 2 — Sync) ──────────────────────────────────────
  `CREATE TABLE IF NOT EXISTS devices (
    id TEXT PRIMARY KEY,
    label TEXT,
    first_seen TEXT NOT NULL,
    last_seen TEXT NOT NULL
  )`,

  // ── sync_records (Phase 2 — Sync) ─────────────────────────────────
  `CREATE TABLE IF NOT EXISTS sync_records (
    entity_type TEXT NOT NULL,
    entity_id TEXT NOT NULL,
    version INTEGER NOT NULL,
    synced_at TEXT,
    conflict INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (entity_type, entity_id)
  )`,
];

// ============================================================================
//  Seed data
// ============================================================================

interface SeedCategory {
  id: string;
  name: string;
  type: CategoryTypeValue;
  sortOrder: number;
}

const SEED_CATEGORIES: readonly SeedCategory[] = [
  // ── Expense ────────────────────────────────────────────────────────
  {
    id: 'cat-seed-exp-materials',
    name: 'خرید مصالح',
    type: 'expense',
    sortOrder: 10,
  },
  { id: 'cat-seed-exp-salary', name: 'دستمزد', type: 'expense', sortOrder: 20 },
  {
    id: 'cat-seed-exp-transport',
    name: 'حمل‌ونقل',
    type: 'expense',
    sortOrder: 30,
  },
  {
    id: 'cat-seed-exp-services',
    name: 'خدمات',
    type: 'expense',
    sortOrder: 40,
  },
  {
    id: 'cat-seed-exp-equipment',
    name: 'تجهیزات',
    type: 'expense',
    sortOrder: 50,
  },
  { id: 'cat-seed-exp-rent', name: 'اجاره', type: 'expense', sortOrder: 60 },
  { id: 'cat-seed-exp-bills', name: 'قبوض', type: 'expense', sortOrder: 70 },
  {
    id: 'cat-seed-exp-repairs',
    name: 'تعمیرات',
    type: 'expense',
    sortOrder: 80,
  },
  {
    id: 'cat-seed-exp-advance',
    name: 'پیش‌پرداخت',
    type: 'expense',
    sortOrder: 90,
  },
  {
    id: 'cat-seed-exp-settlement',
    name: 'تسویه',
    type: 'expense',
    sortOrder: 100,
  },
  { id: 'cat-seed-exp-other', name: 'سایر', type: 'expense', sortOrder: 999 },

  // ── Income ────────────────────────────────────────────────────────
  {
    id: 'cat-seed-inc-project',
    name: 'واریز پروژه',
    type: 'income',
    sortOrder: 10,
  },
  {
    id: 'cat-seed-inc-customer',
    name: 'تسویه مشتری',
    type: 'income',
    sortOrder: 20,
  },
  { id: 'cat-seed-inc-capital', name: 'سرمایه', type: 'income', sortOrder: 30 },
  { id: 'cat-seed-inc-other', name: 'سایر', type: 'income', sortOrder: 999 },
];

interface DefaultSetting {
  key: SettingsKey;
  value: string;
}

const DEFAULT_SETTINGS: readonly DefaultSetting[] = [
  { key: SETTINGS_KEYS.THEME, value: 'dark' },
  { key: SETTINGS_KEYS.LANGUAGE, value: 'fa' },
  { key: SETTINGS_KEYS.ONBOARDING_DONE, value: 'false' },
  { key: SETTINGS_KEYS.SECURITY_PROMPT_COUNT, value: '0' },
  { key: SETTINGS_KEYS.PRIVACY_HIDE_AMOUNTS, value: 'false' },
  { key: SETTINGS_KEYS.ASSET_CACHE_VERSION, value: '1' },
];

// ============================================================================
//  TxContext + DBConnection interfaces
// ============================================================================

export interface TxContext {
  execute(sql: string, params?: readonly unknown[]): Promise<void>;
  query<T = Record<string, unknown>>(
    sql: string,
    params?: readonly unknown[]
  ): Promise<T[]>;
  queryOne<T = Record<string, unknown>>(
    sql: string,
    params?: readonly unknown[]
  ): Promise<T | null>;
}

export interface DBConnection extends TxContext {
  transaction<T>(fn: (tx: TxContext) => Promise<T>): Promise<T>;
  close(): Promise<void>;
}

// ============================================================================
//  Native adapter — SQLCipher real encryption
// ============================================================================

interface NativeCapSQLiteResult {
  result?: boolean;
}

interface NativeSQLiteConnection {
  createConnection(
    database: string,
    encrypted: boolean,
    mode: string,
    version: number,
    readonly: boolean
  ): Promise<NativeDB>;

  isSecretStored(): Promise<NativeCapSQLiteResult>;
  setEncryptionSecret(passphrase: string): Promise<void>;
  checkEncryptionSecret(passphrase: string): Promise<void>;

  closeConnection(database: string, readonly: boolean): Promise<void>;
}

interface NativeDB {
  open(): Promise<void>;
  close(): Promise<void>;
  execute(statement: string, values?: readonly unknown[]): Promise<unknown>;
  query(statement: string, values?: readonly unknown[]): Promise<{ values?: unknown[] }>;
}

async function resolveNativeDatabaseSecret(): Promise<string> {
  // ⚠️ توجه: پیاده‌سازی نهایی باید از Android Keystore استفاده کند
  // (SPEC v2.0 §۸.۱). این stub از @capacitor/preferences استفاده می‌کند
  // که SharedPreferences پایه است — نه Keystore. SecurityPlugin.kt در
  // فاز ۱۰ این را با Keystore جایگزین می‌کند و قبل از Release باید
  // تکمیل شود.
  const SECRET_KEY = 'financial-db-encryption-secret';

  const { Preferences } = await import('@capacitor/preferences');

  const existing = await Preferences.get({ key: SECRET_KEY });
  if (existing.value && existing.value.length > 0) {
    return existing.value;
  }

  const bytes = randomBytes(32);
  let secret = '';
  for (const byte of bytes) {
    secret += byte.toString(16).padStart(2, '0');
  }

  await Preferences.set({ key: SECRET_KEY, value: secret });
  return secret;
}

class NativeConnection implements DBConnection {
  private sqlite: NativeSQLiteConnection | null = null;
  private db: NativeDB | null = null;

  async open(): Promise<void> {
    const mod = await import('@capacitor-community/sqlite');
    const { CapacitorSQLite, SQLiteConnection } = mod;

    const sqlite = new SQLiteConnection(
      CapacitorSQLite
    ) as unknown as NativeSQLiteConnection;

    const secret = await resolveNativeDatabaseSecret();

    try {
      const secretState = await sqlite.isSecretStored();
      if (secretState.result === true) {
        await sqlite.checkEncryptionSecret(secret);
      } else {
        await sqlite.setEncryptionSecret(secret);
      }
    } catch (err) {
      throw new Error(
        `Native database encryption initialization failed: ${
          err instanceof Error ? err.message : String(err)
        }`
      );
    }

    const db = await sqlite.createConnection(
      NATIVE_DB_NAME,
      true,
      'secret',
      NATIVE_DB_VERSION,
      false
    );

    await db.open();
    await db.execute('PRAGMA foreign_keys = ON');

    this.sqlite = sqlite;
    this.db = db;
  }

  private getDb(): NativeDB {
    if (!this.db) throw new Error('Native DB not open');
    return this.db;
  }

  async execute(sql: string, params: readonly unknown[] = []): Promise<void> {
    const db = this.getDb();
    await db.execute(sql, params);
  }

  async query<T = Record<string, unknown>>(
    sql: string,
    params: readonly unknown[] = []
  ): Promise<T[]> {
    const db = this.getDb();
    const result = await db.query(sql, params);
    return (result.values ?? []) as T[];
  }

  async queryOne<T = Record<string, unknown>>(
    sql: string,
    params: readonly unknown[] = []
  ): Promise<T | null> {
    const rows = await this.query<T>(sql, params);
    return rows.length > 0 ? rows[0]! : null;
  }

  async transaction<T>(fn: (tx: TxContext) => Promise<T>): Promise<T> {
    const db = this.getDb();
    await db.execute('BEGIN');
    try {
      const result = await fn(this);
      await db.execute('COMMIT');
      return result;
    } catch (err) {
      try {
        await db.execute('ROLLBACK');
      } catch {
        // ignore
      }
      throw err;
    }
  }

  async close(): Promise<void> {
    if (!this.db || !this.sqlite) return;
    try {
      await this.db.close();
    } catch {
      // ignore
    }
    try {
      await this.sqlite.closeConnection(NATIVE_DB_NAME, false);
    } catch {
      // ignore
    }
    this.db = null;
    this.sqlite = null;
  }
}

// ============================================================================
//  Web adapter — SQLite WASM + OPFS
// ============================================================================

interface WorkerRequestBase {
  requestId: number;
}

type WorkerRequestPayload =
  | { type: 'open' }
  | { type: 'exec'; sql: string; params: unknown[] }
  | { type: 'query'; sql: string; params: unknown[] }
  | { type: 'close' };

type WorkerRequest = WorkerRequestPayload & WorkerRequestBase;

interface WorkerResponse {
  requestId: number;
  ok: true;
  result?: unknown;
}

interface WorkerErrorResponse {
  requestId: number;
  ok: false;
  error: {
    name?: string;
    message: string;
    stack?: string;
  };
}

type WorkerResponseMessage = WorkerResponse | WorkerErrorResponse;

type PendingWorkerRequest = {
  resolve: (value: unknown) => void;
  reject: (reason?: unknown) => void;
};

class WebConnection implements DBConnection {
  private worker: Worker | null = null;
  private nextRequestId = 1;
  private readonly pending = new Map<number, PendingWorkerRequest>();
  private queueTail: Promise<void> = Promise.resolve();

  private readonly handleMessage = (
    event: MessageEvent<WorkerResponseMessage>
  ): void => {
    const message = event.data;
    const pending = this.pending.get(message.requestId);
    if (!pending) return;

    this.pending.delete(message.requestId);

    if (message.ok) {
      pending.resolve(message.result);
      return;
    }

    const error = new Error(message.error.message);
    error.name = message.error.name ?? 'SQLiteWorkerError';
    if (message.error.stack) error.stack = message.error.stack;
    pending.reject(error);
  };

  private readonly handleError = (event: ErrorEvent): void => {
    const error =
      event.error instanceof Error
        ? event.error
        : new Error(event.message || 'SQLite worker failed');

    const worker = this.worker;
    this.worker = null;
    this.rejectPending(error);
    worker?.terminate();
  };

  private rejectPending(reason: Error): void {
    for (const pending of this.pending.values()) {
      pending.reject(reason);
    }
    this.pending.clear();
  }

  private assertWorker(): Worker {
    if (!this.worker) throw new Error('Web SQLite worker is not open');
    return this.worker;
  }

  private request<T>(request: WorkerRequestPayload): Promise<T> {
    const worker = this.assertWorker();
    const requestId = this.nextRequestId++;

    return new Promise<T>((resolve, reject) => {
      this.pending.set(requestId, {
        resolve: (value) => resolve(value as T),
        reject,
      });

      const message: WorkerRequest = { ...request, requestId };
      worker.postMessage(message);
    });
  }

  private withQueue<T>(operation: () => Promise<T>): Promise<T> {
    const previous = this.queueTail;
    let release!: () => void;

    this.queueTail = new Promise<void>((resolve) => {
      release = resolve;
    });

    return previous.then(operation).finally(release);
  }

  private rawExecute(sql: string, params: readonly unknown[] = []): Promise<void> {
    return this.request<void>({
      type: 'exec',
      sql,
      params: [...params],
    });
  }

  private rawQuery<T = Record<string, unknown>>(
    sql: string,
    params: readonly unknown[] = []
  ): Promise<T[]> {
    return this.request<T[]>({
      type: 'query',
      sql,
      params: [...params],
    });
  }

  async open(): Promise<void> {
    if (this.worker) return;

    const worker = new Worker(
      new URL('./db.worker.ts', import.meta.url),
      { type: 'module' }
    );

    worker.addEventListener('message', this.handleMessage);
    worker.addEventListener('error', this.handleError);
    this.worker = worker;

    try {
      await this.request<void>({ type: 'open' });
    } catch (error) {
      worker.removeEventListener('message', this.handleMessage);
      worker.removeEventListener('error', this.handleError);
      worker.terminate();
      this.worker = null;
      throw error;
    }
  }

  async execute(sql: string, params: readonly unknown[] = []): Promise<void> {
    await this.withQueue(() => this.rawExecute(sql, params));
  }

  async query<T = Record<string, unknown>>(
    sql: string,
    params: readonly unknown[] = []
  ): Promise<T[]> {
    return this.withQueue(() => this.rawQuery<T>(sql, params));
  }

  async queryOne<T = Record<string, unknown>>(
    sql: string,
    params: readonly unknown[] = []
  ): Promise<T | null> {
    const rows = await this.query<T>(sql, params);
    return rows.length > 0 ? rows[0]! : null;
  }

  async transaction<T>(fn: (tx: TxContext) => Promise<T>): Promise<T> {
    return this.withQueue(async () => {
      await this.rawExecute('BEGIN');

      const tx: TxContext = {
        execute: (sql, params = []) => this.rawExecute(sql, params),
        query: <R = Record<string, unknown>>(sql: string, params: readonly unknown[] = []) =>
          this.rawQuery<R>(sql, params),
        queryOne: async <R = Record<string, unknown>>(
          sql: string,
          params: readonly unknown[] = []
        ) => {
          const rows = await this.rawQuery<R>(sql, params);
          return rows.length > 0 ? rows[0]! : null;
        },
      };

      try {
        const result = await fn(tx);
        await this.rawExecute('COMMIT');
        return result;
      } catch (error) {
        try {
          await this.rawExecute('ROLLBACK');
        } catch {
          // Preserve the original transaction error.
        }
        throw error;
      }
    });
  }

  async close(): Promise<void> {
    if (!this.worker) return;

    await this.withQueue(async () => {
      const worker = this.worker;
      if (!worker) return;

      try {
        await this.request<void>({ type: 'close' });
      } finally {
        worker.removeEventListener('message', this.handleMessage);
        worker.removeEventListener('error', this.handleError);
        worker.terminate();
        this.worker = null;
        this.rejectPending(new Error('Web SQLite worker closed'));
      }
    });
  }
}

// ============================================================================
//  Init / Close
// ============================================================================

let db: DBConnection | null = null;
let dbInitPromise: Promise<void> | null = null;

export function initDatabase(): Promise<void> {
  if (db) return Promise.resolve();
  if (dbInitPromise) return dbInitPromise;

  dbInitPromise = (async () => {
    const connection: DBConnection = isNativePlatform()
      ? new NativeConnection()
      : new WebConnection();

    try {
      await (connection as unknown as { open: () => Promise<void> }).open();

      await connection.execute('PRAGMA foreign_keys = ON');

      await runMigrations(connection);
      await seedCategories(connection);
      await ensureDefaultSettings(connection);
      await ensureWorkspace(connection);
      await ensureDevicePrefix(connection);

      db = connection;
    } catch (error) {
      try {
        await connection.close();
      } catch {
        // Preserve the original initialization error.
      }
      throw error;
    }
  })().finally(() => {
    dbInitPromise = null;
  });

  return dbInitPromise;
}

export async function closeDatabase(): Promise<void> {
  if (!db) return;
  const current = db;
  db = null;
  await current.close();
}

export function getDatabase(): DBConnection {
  if (!db) throw new Error('Database not initialized');
  return db;
}

function requireDb(): DBConnection {
  return getDatabase();
}

// ============================================================================
//  Migrations
// ============================================================================

async function getUserVersion(conn: TxContext): Promise<number> {
  const row = await conn.queryOne<{ user_version: number }>('PRAGMA user_version');
  return row?.user_version ?? 0;
}

async function runMigrations(conn: DBConnection): Promise<void> {
  const currentVersion = await getUserVersion(conn);

  if (currentVersion >= SCHEMA_VERSION) return;

  // نسخه‌ی ۱ هرگز به‌صورت public منتشر نشد، پس هیچ مسیر مهاجرت از v1
  // مورد نیاز نیست. نصب‌های تازه مستقیماً اسکیمای v2 را می‌گیرند.
  await conn.transaction(async (tx) => {
    for (const sql of SCHEMA_V2_STATEMENTS) {
      await tx.execute(sql);
    }
    await tx.execute(`PRAGMA user_version = ${SCHEMA_VERSION}`);
  });
}

async function seedCategories(conn: TxContext): Promise<void> {
  for (const cat of SEED_CATEGORIES) {
    await conn.execute(
      `INSERT OR IGNORE INTO categories
        (id, parent_id, name, type, is_custom, sort_order, status)
       VALUES (?, NULL, ?, ?, 0, ?, 'active')`,
      [cat.id, cat.name, cat.type, cat.sortOrder]
    );
  }
}

async function ensureDefaultSettings(conn: TxContext): Promise<void> {
  for (const setting of DEFAULT_SETTINGS) {
    await conn.execute(`INSERT OR IGNORE INTO app_settings (key, value) VALUES (?, ?)`, [
      setting.key,
      setting.value,
    ]);
  }
}

async function ensureWorkspace(conn: TxContext): Promise<ULID> {
  const existing = await conn.queryOne<{ id: string }>(
    'SELECT id FROM workspaces LIMIT 1'
  );
  if (existing) {
    return existing.id;
  }

  const id = generateULID();
  await conn.execute('INSERT INTO workspaces (id, name, created_at) VALUES (?, ?, ?)', [
    id,
    'شرکت',
    nowISO(),
  ]);
  await conn.execute(`INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)`, [
    SETTINGS_KEYS.WORKSPACE_ID,
    id,
  ]);
  return id;
}

async function ensureDevicePrefix(conn: TxContext): Promise<void> {
  const existing = await conn.queryOne<{ value: string }>(
    `SELECT value FROM app_settings WHERE key = ?`,
    [SETTINGS_KEYS.DEVICE_PREFIX]
  );
  if (existing?.value) return;

  const prefix = generateDevicePrefix();
  await conn.execute(`INSERT OR REPLACE INTO app_settings (key, value) VALUES (?, ?)`, [
    SETTINGS_KEYS.DEVICE_PREFIX,
    prefix,
  ]);
}

// ============================================================================
//  Row mappers
// ============================================================================

interface AccountRow {
  id: string;
  workspace_id: string;
  name: string;
  type: string;
  bank_name: string | null;
  account_number: string | null;
  card_number: string | null;
  description: string | null;
  opening_balance: number;
  opening_balance_date: string;
  status: string;
  sort_order: number;
  created_at: string;
  updated_at: string;
  created_by: string | null;
  updated_by: string | null;
}

function mapAccount(row: AccountRow): Account {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    name: row.name,
    type: row.type as AccountTypeType,
    bankName: row.bank_name,
    accountNumber: row.account_number,
    cardNumber: row.card_number,
    description: row.description,
    openingBalance: fromDbMoney(row.opening_balance),
    openingBalanceDate: row.opening_balance_date,
    status: row.status as AccountStatusType,
    sortOrder: row.sort_order,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
  };
}

interface PartyRow {
  id: string;
  workspace_id: string;
  name: string;
  normalized_name: string;
  type: string;
  phone: string | null;
  card_number: string | null;
  account_number: string | null;
  role: string | null;
  notes: string | null;
  status: string;
  created_at: string;
  updated_at: string;
}

function mapParty(row: PartyRow): Party {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    name: row.name,
    normalizedName: row.normalized_name,
    type: row.type as PartyTypeValue,
    phone: row.phone,
    cardNumber: row.card_number,
    accountNumber: row.account_number,
    role: (row.role as PartyRoleValue | null) ?? null,
    notes: row.notes,
    status: row.status as PartyStatusType,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

interface ProjectRow {
  id: string;
  workspace_id: string;
  name: string;
  code: string | null;
  status: string;
  budget_amount: number | null;
  description: string | null;
  created_at: string;
  updated_at: string;
}

function mapProject(row: ProjectRow): Project {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    name: row.name,
    code: row.code,
    status: row.status as ProjectStatusType,
    budgetAmount: fromDbMoneyNullable(row.budget_amount),
    description: row.description,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
  };
}

interface CategoryRow {
  id: string;
  parent_id: string | null;
  name: string;
  type: string;
  is_custom: number;
  sort_order: number;
  status: string;
}

function mapCategory(row: CategoryRow): Category {
  return {
    id: row.id,
    parentId: row.parent_id,
    name: row.name,
    type: row.type as CategoryTypeValue,
    isCustom: fromDbBool(row.is_custom),
    sortOrder: row.sort_order,
    status: row.status as CategoryStatusType,
  };
}

interface TransactionRow {
  id: string;
  workspace_id: string;
  display_code: string;
  type: string;
  amount: number;
  account_id: string;
  party_id: string | null;
  category_id: string | null;
  custom_category_text: string | null;
  project_id: string | null;
  transaction_date: string;
  transaction_time: string | null;
  reference_code: string | null;
  description: string | null;
  status: string;
  version: number;
  device_id: string | null;
  created_at: string;
  updated_at: string;
  created_by: string | null;
  updated_by: string | null;
  deleted_at: string | null;
}

function mapTransaction(row: TransactionRow): Transaction {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    displayCode: row.display_code,
    type: row.type as TransactionTypeValue,
    amount: fromDbMoney(row.amount),
    accountId: row.account_id,
    partyId: row.party_id,
    categoryId: row.category_id,
    customCategoryText: row.custom_category_text,
    projectId: row.project_id,
    transactionDate: row.transaction_date,
    transactionTime: row.transaction_time,
    referenceCode: row.reference_code,
    description: row.description,
    status: row.status as TransactionStatusType,
    version: row.version,
    deviceId: row.device_id,
    createdAt: row.created_at,
    updatedAt: row.updated_at,
    createdBy: row.created_by,
    updatedBy: row.updated_by,
    deletedAt: row.deleted_at,
  };
}

interface AttachmentRow {
  id: string;
  transaction_id: string;
  type: string;
  file_name: string;
  storage_key: string;
  thumbnail_key: string | null;
  mime_type: string;
  size_bytes: number;
  sha256: string;
  created_at: string;
}

function mapAttachment(row: AttachmentRow): Attachment {
  return {
    id: row.id,
    transactionId: row.transaction_id,
    type: row.type,
    fileName: row.file_name,
    storageKey: row.storage_key,
    thumbnailKey: row.thumbnail_key,
    mimeType: row.mime_type,
    sizeBytes: row.size_bytes,
    sha256: row.sha256,
    createdAt: row.created_at,
  };
}

interface AuditEventRow {
  id: string;
  workspace_id: string;
  entity_type: string;
  entity_id: string | null;
  action: string;
  before_json: string | null;
  after_json: string | null;
  actor_label: string | null;
  device_id: string | null;
  created_at: string;
}

function mapAuditEvent(row: AuditEventRow): AuditEvent {
  return {
    id: row.id,
    workspaceId: row.workspace_id,
    entityType: row.entity_type as AuditEntityTypeType,
    entityId: row.entity_id,
    action: row.action as AuditAction,
    beforeJson: row.before_json,
    afterJson: row.after_json,
    actorLabel: row.actor_label,
    deviceId: row.device_id,
    createdAt: row.created_at,
  };
}

interface SecurityRow {
  id: string;
  pin_hash: string | null;
  pattern_hash: string | null;
  biometric_enabled: number;
  primary_method: string | null;
  failed_attempts: number;
  lockout_until: string | null;
  recovery_used_count: number;
  lock_timeout_seconds: number;
  configured_at: string | null;
}

function mapSecurityProfile(row: SecurityRow): SecurityProfile {
  return {
    id: 'default',
    pinHash: row.pin_hash,
    patternHash: row.pattern_hash,
    biometricEnabled: fromDbBool(row.biometric_enabled),
    primaryMethod: (row.primary_method as PrimarySecurityMethodValue | null) ?? null,
    failedAttempts: row.failed_attempts,
    lockoutUntil: row.lockout_until,
    recoveryUsedCount: row.recovery_used_count,
    lockTimeoutSeconds: row.lock_timeout_seconds,
    configuredAt: row.configured_at,
  };
}

// ============================================================================
//  Audit write helper (used by all repos)
// ============================================================================

interface WriteAuditInput {
  workspaceId: ULID;
  entityType: AuditEntityTypeType;
  entityId: ULID | null;
  action: AuditAction;
  before: unknown;
  after: unknown;
  actorLabel: string | null;
  deviceId?: string | null;
}

async function writeAudit(tx: TxContext, input: WriteAuditInput): Promise<void> {
  await tx.execute(
    `INSERT INTO audit_events
      (id, workspace_id, entity_type, entity_id, action,
       before_json, after_json, actor_label, device_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [
      generateULID(),
      input.workspaceId,
      input.entityType,
      input.entityId,
      input.action,
      input.before === null ? null : JSON.stringify(input.before),
      input.after === null ? null : JSON.stringify(input.after),
      input.actorLabel,
      input.deviceId ?? null,
      nowISO(),
    ]
  );
}

// ============================================================================
//  Money serialization for audit
// ============================================================================

function serializeMoney(m: Money): string {
  return m.toString();
}

function serializeAccount(a: Account): Record<string, unknown> {
  return {
    id: a.id,
    workspaceId: a.workspaceId,
    name: a.name,
    type: a.type,
    bankName: a.bankName,
    accountNumber: a.accountNumber,
    cardNumber: a.cardNumber,
    description: a.description,
    openingBalance: serializeMoney(a.openingBalance),
    openingBalanceDate: a.openingBalanceDate,
    status: a.status,
    sortOrder: a.sortOrder,
  };
}

function serializeParty(p: Party): Record<string, unknown> {
  return {
    id: p.id,
    workspaceId: p.workspaceId,
    name: p.name,
    type: p.type,
    phone: p.phone,
    cardNumber: p.cardNumber,
    accountNumber: p.accountNumber,
    role: p.role,
    notes: p.notes,
    status: p.status,
  };
}

function serializeProject(p: Project): Record<string, unknown> {
  return {
    id: p.id,
    workspaceId: p.workspaceId,
    name: p.name,
    code: p.code,
    status: p.status,
    budgetAmount: p.budgetAmount === null ? null : serializeMoney(p.budgetAmount),
    description: p.description,
  };
}

function serializeTransaction(t: Transaction): Record<string, unknown> {
  return {
    id: t.id,
    workspaceId: t.workspaceId,
    displayCode: t.displayCode,
    type: t.type,
    amount: serializeMoney(t.amount),
    accountId: t.accountId,
    partyId: t.partyId,
    categoryId: t.categoryId,
    customCategoryText: t.customCategoryText,
    projectId: t.projectId,
    transactionDate: t.transactionDate,
    transactionTime: t.transactionTime,
    referenceCode: t.referenceCode,
    description: t.description,
    status: t.status,
    version: t.version,
  };
}

// ============================================================================
//  Workspace helper
// ============================================================================

export async function getWorkspaceId(tx?: TxContext): Promise<ULID> {
  const conn = tx ?? requireDb();
  const row = await conn.queryOne<{ id: string }>('SELECT id FROM workspaces LIMIT 1');
  if (!row) {
    throw new Error('Workspace not found');
  }
  return row.id;
}

export async function getDevicePrefix(tx?: TxContext): Promise<string> {
  const value = await settingsRepo.get(SETTINGS_KEYS.DEVICE_PREFIX, tx);
  if (value) return value;
  const prefix = generateDevicePrefix();
  await settingsRepo.set(SETTINGS_KEYS.DEVICE_PREFIX, prefix, tx);
  return prefix;
}

// ============================================================================
//  Settings repository
// ============================================================================

export const settingsRepo = {
  async getAll(tx?: TxContext): Promise<AppSetting[]> {
    const conn = tx ?? requireDb();
    return conn.query<{ key: string; value: string }>(
      'SELECT key, value FROM app_settings'
    );
  },

  async get(key: string, tx?: TxContext): Promise<string | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{ value: string }>(
      'SELECT value FROM app_settings WHERE key = ?',
      [key]
    );
    return row?.value ?? null;
  },

  async set(key: string, value: string, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(
      `INSERT INTO app_settings (key, value) VALUES (?, ?)
       ON CONFLICT(key) DO UPDATE SET value = excluded.value`,
      [key, value]
    );
  },

  async getBoolean(key: string, fallback: boolean, tx?: TxContext): Promise<boolean> {
    const value = await this.get(key, tx);
    if (value === null) return fallback;
    return value === 'true' || value === '1';
  },

  async getNumber(key: string, fallback: number, tx?: TxContext): Promise<number> {
    const value = await this.get(key, tx);
    if (value === null) return fallback;
    const n = Number(value);
    return Number.isFinite(n) ? n : fallback;
  },
};

// ============================================================================
//  Account repository
// ============================================================================

export const accountRepo = {
  async list(includeArchived = false, tx?: TxContext): Promise<Account[]> {
    const conn = tx ?? requireDb();
    const sql = includeArchived
      ? `SELECT * FROM accounts ORDER BY sort_order ASC, name ASC`
      : `SELECT * FROM accounts WHERE status = 'active'
         ORDER BY sort_order ASC, name ASC`;
    const rows = await conn.query<AccountRow>(sql);
    return rows.map(mapAccount);
  },

  async findById(id: AccountId, tx?: TxContext): Promise<Account | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<AccountRow>('SELECT * FROM accounts WHERE id = ?', [
      id,
    ]);
    return row ? mapAccount(row) : null;
  },

  async create(input: CreateAccountInput, tx?: TxContext): Promise<Account> {
    const run = async (t: TxContext): Promise<Account> => {
      const workspaceId = await getWorkspaceId(t);
      const id = generateULID();
      const now = nowISO();
      const openingDate = input.openingBalanceDate ?? now.slice(0, 10);

      await t.execute(
        `INSERT INTO accounts
          (id, workspace_id, name, type, bank_name, account_number, card_number,
           description, opening_balance, opening_balance_date, status,
           sort_order, created_at, updated_at, created_by, updated_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?, ?, NULL, NULL)`,
        [
          id,
          workspaceId,
          input.name,
          input.type,
          input.bankName,
          input.accountNumber,
          input.cardNumber,
          input.description,
          toDbMoney(input.openingBalance),
          openingDate,
          input.sortOrder,
          now,
          now,
        ]
      );

      const account: Account = {
        id,
        workspaceId,
        name: input.name,
        type: input.type,
        bankName: input.bankName,
        accountNumber: input.accountNumber,
        cardNumber: input.cardNumber,
        description: input.description,
        openingBalance: input.openingBalance,
        openingBalanceDate: openingDate,
        status: AccountStatus.ACTIVE,
        sortOrder: input.sortOrder,
        createdAt: now,
        updatedAt: now,
        createdBy: null,
        updatedBy: null,
      };

      await writeAudit(t, {
        workspaceId,
        entityType: AuditEntityType.ACCOUNT,
        entityId: id,
        action: AuditAction.CREATE,
        before: null,
        after: serializeAccount(account),
        actorLabel: null,
      });

      return account;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async update(
    id: AccountId,
    changes: UpdateAccountInput,
    actorLabel: string | null = null,
    tx?: TxContext
  ): Promise<Account | null> {
    const run = async (t: TxContext): Promise<Account | null> => {
      const existingRow = await t.queryOne<AccountRow>(
        'SELECT * FROM accounts WHERE id = ?',
        [id]
      );
      if (!existingRow) return null;
      const before = mapAccount(existingRow);

      const fields: string[] = [];
      const values: unknown[] = [];

      if (changes.name !== undefined) {
        fields.push('name = ?');
        values.push(changes.name);
      }
      if (changes.bankName !== undefined) {
        fields.push('bank_name = ?');
        values.push(changes.bankName);
      }
      if (changes.accountNumber !== undefined) {
        fields.push('account_number = ?');
        values.push(changes.accountNumber);
      }
      if (changes.cardNumber !== undefined) {
        fields.push('card_number = ?');
        values.push(changes.cardNumber);
      }
      if (changes.description !== undefined) {
        fields.push('description = ?');
        values.push(changes.description);
      }
      if (changes.openingBalance !== undefined) {
        fields.push('opening_balance = ?');
        values.push(toDbMoney(changes.openingBalance));
      }
      if (changes.openingBalanceDate !== undefined) {
        fields.push('opening_balance_date = ?');
        values.push(changes.openingBalanceDate ?? nowISO().slice(0, 10));
      }
      if (changes.status !== undefined) {
        fields.push('status = ?');
        values.push(changes.status);
      }
      if (changes.sortOrder !== undefined) {
        fields.push('sort_order = ?');
        values.push(changes.sortOrder);
      }

      if (fields.length === 0) return before;

      fields.push('updated_at = ?');
      values.push(nowISO());
      fields.push('updated_by = ?');
      values.push(actorLabel);
      values.push(id);

      await t.execute(`UPDATE accounts SET ${fields.join(', ')} WHERE id = ?`, values);

      const updatedRow = await t.queryOne<AccountRow>(
        'SELECT * FROM accounts WHERE id = ?',
        [id]
      );
      if (!updatedRow) return null;
      const after = mapAccount(updatedRow);

      await writeAudit(t, {
        workspaceId: after.workspaceId,
        entityType: AuditEntityType.ACCOUNT,
        entityId: id,
        action: AuditAction.EDIT,
        before: serializeAccount(before),
        after: serializeAccount(after),
        actorLabel,
      });

      return after;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async archive(id: AccountId, tx?: TxContext): Promise<void> {
    await this.update(id, { status: AccountStatus.ARCHIVED }, null, tx);
  },

  async unarchive(id: AccountId, tx?: TxContext): Promise<void> {
    await this.update(id, { status: AccountStatus.ACTIVE }, null, tx);
  },
};

// ============================================================================
//  Party repository
// ============================================================================

export const partyRepo = {
  async list(includeArchived = false, tx?: TxContext): Promise<Party[]> {
    const conn = tx ?? requireDb();
    const sql = includeArchived
      ? `SELECT * FROM parties ORDER BY name ASC`
      : `SELECT * FROM parties WHERE status = 'active' ORDER BY name ASC`;
    const rows = await conn.query<PartyRow>(sql);
    return rows.map(mapParty);
  },

  async findById(id: PartyId, tx?: TxContext): Promise<Party | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<PartyRow>('SELECT * FROM parties WHERE id = ?', [id]);
    return row ? mapParty(row) : null;
  },

  async search(query: string, limit = 20, tx?: TxContext): Promise<Party[]> {
    const conn = tx ?? requireDb();
    const normalized = normalizePersianText(query);
    if (!normalized) {
      return this.list(false, tx);
    }
    const rows = await conn.query<PartyRow>(
      `SELECT * FROM parties
       WHERE status = 'active' AND normalized_name LIKE ?
       ORDER BY name ASC
       LIMIT ?`,
      [`%${normalized}%`, limit]
    );
    return rows.map(mapParty);
  },

  async create(input: CreatePartyInput, tx?: TxContext): Promise<Party> {
    const run = async (t: TxContext): Promise<Party> => {
      const workspaceId = await getWorkspaceId(t);
      const id = generateULID();
      const now = nowISO();
      const normalizedName = normalizePersianText(input.name);

      await t.execute(
        `INSERT INTO parties
          (id, workspace_id, name, normalized_name, type, phone, card_number,
           account_number, role, notes, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', ?, ?)`,
        [
          id,
          workspaceId,
          input.name,
          normalizedName,
          input.type,
          input.phone,
          input.cardNumber,
          input.accountNumber,
          input.role,
          input.notes,
          now,
          now,
        ]
      );

      const party: Party = {
        id,
        workspaceId,
        name: input.name,
        normalizedName,
        type: input.type,
        phone: input.phone,
        cardNumber: input.cardNumber,
        accountNumber: input.accountNumber,
        role: input.role,
        notes: input.notes,
        status: PartyStatus.ACTIVE,
        createdAt: now,
        updatedAt: now,
      };

      await writeAudit(t, {
        workspaceId,
        entityType: AuditEntityType.PARTY,
        entityId: id,
        action: AuditAction.CREATE,
        before: null,
        after: serializeParty(party),
        actorLabel: null,
      });

      return party;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async update(
    id: PartyId,
    changes: UpdatePartyInput,
    actorLabel: string | null = null,
    tx?: TxContext
  ): Promise<Party | null> {
    const run = async (t: TxContext): Promise<Party | null> => {
      const existingRow = await t.queryOne<PartyRow>(
        'SELECT * FROM parties WHERE id = ?',
        [id]
      );
      if (!existingRow) return null;
      const before = mapParty(existingRow);

      const fields: string[] = [];
      const values: unknown[] = [];

      if (changes.name !== undefined) {
        fields.push('name = ?');
        values.push(changes.name);
        fields.push('normalized_name = ?');
        values.push(normalizePersianText(changes.name));
      }
      if (changes.type !== undefined) {
        fields.push('type = ?');
        values.push(changes.type);
      }
      if (changes.phone !== undefined) {
        fields.push('phone = ?');
        values.push(changes.phone);
      }
      if (changes.cardNumber !== undefined) {
        fields.push('card_number = ?');
        values.push(changes.cardNumber);
      }
      if (changes.accountNumber !== undefined) {
        fields.push('account_number = ?');
        values.push(changes.accountNumber);
      }
      if (changes.role !== undefined) {
        fields.push('role = ?');
        values.push(changes.role);
      }
      if (changes.notes !== undefined) {
        fields.push('notes = ?');
        values.push(changes.notes);
      }
      if (changes.status !== undefined) {
        fields.push('status = ?');
        values.push(changes.status);
      }

      if (fields.length === 0) return before;

      fields.push('updated_at = ?');
      values.push(nowISO());
      values.push(id);

      await t.execute(`UPDATE parties SET ${fields.join(', ')} WHERE id = ?`, values);

      const updatedRow = await t.queryOne<PartyRow>(
        'SELECT * FROM parties WHERE id = ?',
        [id]
      );
      if (!updatedRow) return null;
      const after = mapParty(updatedRow);

      await writeAudit(t, {
        workspaceId: after.workspaceId,
        entityType: AuditEntityType.PARTY,
        entityId: id,
        action: AuditAction.EDIT,
        before: serializeParty(before),
        after: serializeParty(after),
        actorLabel,
      });

      return after;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async deactivate(id: PartyId, tx?: TxContext): Promise<void> {
    await this.update(id, { status: PartyStatus.ARCHIVED }, null, tx);
  },

  async activate(id: PartyId, tx?: TxContext): Promise<void> {
    await this.update(id, { status: PartyStatus.ACTIVE }, null, tx);
  },
};

// ============================================================================
//  Project repository
// ============================================================================

export const projectRepo = {
  async list(tx?: TxContext): Promise<Project[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<ProjectRow>('SELECT * FROM projects ORDER BY name ASC');
    return rows.map(mapProject);
  },

  async findById(id: ProjectId, tx?: TxContext): Promise<Project | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<ProjectRow>('SELECT * FROM projects WHERE id = ?', [
      id,
    ]);
    return row ? mapProject(row) : null;
  },

  async create(input: CreateProjectInput, tx?: TxContext): Promise<Project> {
    const run = async (t: TxContext): Promise<Project> => {
      const workspaceId = await getWorkspaceId(t);
      const id = generateULID();
      const now = nowISO();

      await t.execute(
        `INSERT INTO projects
          (id, workspace_id, name, code, status, budget_amount, description,
           created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          id,
          workspaceId,
          input.name,
          input.code,
          input.status,
          toDbMoneyNullable(input.budgetAmount),
          input.description,
          now,
          now,
        ]
      );

      const project: Project = {
        id,
        workspaceId,
        name: input.name,
        code: input.code,
        status: input.status,
        budgetAmount: input.budgetAmount,
        description: input.description,
        createdAt: now,
        updatedAt: now,
      };

      await writeAudit(t, {
        workspaceId,
        entityType: AuditEntityType.PROJECT,
        entityId: id,
        action: AuditAction.CREATE,
        before: null,
        after: serializeProject(project),
        actorLabel: null,
      });

      return project;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async update(
    id: ProjectId,
    changes: UpdateProjectInput,
    actorLabel: string | null = null,
    tx?: TxContext
  ): Promise<Project | null> {
    const run = async (t: TxContext): Promise<Project | null> => {
      const existingRow = await t.queryOne<ProjectRow>(
        'SELECT * FROM projects WHERE id = ?',
        [id]
      );
      if (!existingRow) return null;
      const before = mapProject(existingRow);

      const fields: string[] = [];
      const values: unknown[] = [];

      if (changes.name !== undefined) {
        fields.push('name = ?');
        values.push(changes.name);
      }
      if (changes.code !== undefined) {
        fields.push('code = ?');
        values.push(changes.code);
      }
      if (changes.status !== undefined) {
        fields.push('status = ?');
        values.push(changes.status);
      }
      if (changes.budgetAmount !== undefined) {
        fields.push('budget_amount = ?');
        values.push(toDbMoneyNullable(changes.budgetAmount));
      }
      if (changes.description !== undefined) {
        fields.push('description = ?');
        values.push(changes.description);
      }

      if (fields.length === 0) return before;

      fields.push('updated_at = ?');
      values.push(nowISO());
      values.push(id);

      await t.execute(`UPDATE projects SET ${fields.join(', ')} WHERE id = ?`, values);

      const updatedRow = await t.queryOne<ProjectRow>(
        'SELECT * FROM projects WHERE id = ?',
        [id]
      );
      if (!updatedRow) return null;
      const after = mapProject(updatedRow);

      await writeAudit(t, {
        workspaceId: after.workspaceId,
        entityType: AuditEntityType.PROJECT,
        entityId: id,
        action: AuditAction.EDIT,
        before: serializeProject(before),
        after: serializeProject(after),
        actorLabel,
      });

      return after;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },
};

// ============================================================================
//  Category repository
// ============================================================================

export const categoryRepo = {
  async list(includeArchived = false, tx?: TxContext): Promise<Category[]> {
    const conn = tx ?? requireDb();
    const sql = includeArchived
      ? `SELECT * FROM categories ORDER BY sort_order ASC, name ASC`
      : `SELECT * FROM categories WHERE status = 'active'
         ORDER BY sort_order ASC, name ASC`;
    const rows = await conn.query<CategoryRow>(sql);
    return rows.map(mapCategory);
  },

  async findByType(type: CategoryTypeValue, tx?: TxContext): Promise<Category[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<CategoryRow>(
      `SELECT * FROM categories
       WHERE status = 'active' AND (type = ? OR type = 'both')
       ORDER BY sort_order ASC, name ASC`,
      [type]
    );
    return rows.map(mapCategory);
  },

  async findById(id: CategoryId, tx?: TxContext): Promise<Category | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<CategoryRow>(
      'SELECT * FROM categories WHERE id = ?',
      [id]
    );
    return row ? mapCategory(row) : null;
  },

  async create(input: CreateCategoryInput, tx?: TxContext): Promise<Category> {
    const run = async (t: TxContext): Promise<Category> => {
      const id = generateULID();
      await t.execute(
        `INSERT INTO categories
          (id, parent_id, name, type, is_custom, sort_order, status)
         VALUES (?, ?, ?, ?, 1, ?, 'active')`,
        [id, input.parentId, input.name, input.type, input.sortOrder]
      );
      const category: Category = {
        id,
        parentId: input.parentId,
        name: input.name,
        type: input.type,
        isCustom: true,
        sortOrder: input.sortOrder,
        status: CategoryStatus.ACTIVE,
      };
      const workspaceId = await getWorkspaceId(t);
      await writeAudit(t, {
        workspaceId,
        entityType: AuditEntityType.SYSTEM,
        entityId: id,
        action: AuditAction.CREATE,
        before: null,
        after: { ...category },
        actorLabel: null,
      });
      return category;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async deactivate(id: CategoryId, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(`UPDATE categories SET status = 'archived' WHERE id = ?`, [id]);
  },
};

// ============================================================================
//  Transaction repository
// ============================================================================

function buildDisplayCodePattern(
  kind: TransactionTypeValue,
  date: ISODate,
  devicePrefix: string
): { pattern: string; seqStart: number } {
  const compact = toJalaliCompact(date);
  const prefix = kind === 'deposit' ? 'DEP' : 'EXP';
  const fullPrefix = `${prefix}-${compact}-`;
  return {
    pattern: `${fullPrefix}%-${devicePrefix}`,
    seqStart: fullPrefix.length + 1,
  };
}

async function getNextDailySequence(
  conn: TxContext,
  kind: TransactionTypeValue,
  date: ISODate,
  devicePrefix: string
): Promise<number> {
  const { pattern, seqStart } = buildDisplayCodePattern(kind, date, devicePrefix);

  const row = await conn.queryOne<{ max_seq: number | null }>(
    `SELECT MAX(CAST(SUBSTR(display_code, ?, 5) AS INTEGER)) AS max_seq
     FROM transactions
     WHERE display_code LIKE ?`,
    [seqStart, pattern]
  );

  return (row?.max_seq ?? 0) + 1;
}

function buildDisplayCode(
  kind: TransactionTypeValue,
  date: ISODate,
  sequence: number,
  devicePrefix: string
): DisplayCode {
  const compact = toJalaliCompact(date);
  const prefix = kind === 'deposit' ? 'DEP' : 'EXP';
  const seq = String(sequence).padStart(5, '0');
  return `${prefix}-${compact}-${seq}-${devicePrefix}`;
}

export const transactionRepo = {
  async list(filter: TransactionFilter, tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const conditions: string[] = [];
    const params: unknown[] = [];

    if (filter.statuses.length === 0) {
      conditions.push(`status = 'active'`);
    } else {
      const placeholders = filter.statuses.map(() => '?').join(',');
      conditions.push(`status IN (${placeholders})`);
      params.push(...filter.statuses);
    }

    if (filter.types.length > 0) {
      const placeholders = filter.types.map(() => '?').join(',');
      conditions.push(`type IN (${placeholders})`);
      params.push(...filter.types);
    }

    if (filter.accountIds.length > 0) {
      const placeholders = filter.accountIds.map(() => '?').join(',');
      conditions.push(`account_id IN (${placeholders})`);
      params.push(...filter.accountIds);
    }

    if (filter.partyIds.length > 0) {
      const placeholders = filter.partyIds.map(() => '?').join(',');
      conditions.push(`party_id IN (${placeholders})`);
      params.push(...filter.partyIds);
    }

    if (filter.projectIds.length > 0) {
      const placeholders = filter.projectIds.map(() => '?').join(',');
      conditions.push(`project_id IN (${placeholders})`);
      params.push(...filter.projectIds);
    }

    if (filter.categoryIds.length > 0) {
      const placeholders = filter.categoryIds.map(() => '?').join(',');
      conditions.push(`category_id IN (${placeholders})`);
      params.push(...filter.categoryIds);
    }

    if (filter.dateFrom) {
      conditions.push('transaction_date >= ?');
      params.push(filter.dateFrom);
    }
    if (filter.dateTo) {
      conditions.push('transaction_date <= ?');
      params.push(filter.dateTo);
    }
    if (filter.amountMin !== null) {
      conditions.push('amount >= ?');
      params.push(toDbMoney(filter.amountMin));
    }
    if (filter.amountMax !== null) {
      conditions.push('amount <= ?');
      params.push(toDbMoney(filter.amountMax));
    }

    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const rows = await conn.query<TransactionRow>(
      `SELECT * FROM transactions ${where}
       ORDER BY transaction_date DESC, transaction_time DESC, created_at DESC`,
      params
    );
    return rows.map(mapTransaction);
  },

  async listAll(tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<TransactionRow>(
      'SELECT * FROM transactions ORDER BY transaction_date DESC, created_at DESC'
    );
    return rows.map(mapTransaction);
  },

  async listActive(tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<TransactionRow>(
      `SELECT * FROM transactions WHERE status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`
    );
    return rows.map(mapTransaction);
  },

  async listByAccount(accountId: AccountId, tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<TransactionRow>(
      `SELECT * FROM transactions
       WHERE account_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,
      [accountId]
    );
    return rows.map(mapTransaction);
  },

  async listByParty(partyId: PartyId, tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<TransactionRow>(
      `SELECT * FROM transactions
       WHERE party_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,
      [partyId]
    );
    return rows.map(mapTransaction);
  },

  async listByProject(projectId: ProjectId, tx?: TxContext): Promise<Transaction[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<TransactionRow>(
      `SELECT * FROM transactions
       WHERE project_id = ? AND status = 'active'
       ORDER BY transaction_date DESC, created_at DESC`,
      [projectId]
    );
    return rows.map(mapTransaction);
  },

  async findById(id: TransactionId, tx?: TxContext): Promise<Transaction | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<TransactionRow>(
      'SELECT * FROM transactions WHERE id = ?',
      [id]
    );
    return row ? mapTransaction(row) : null;
  },

  async findByDisplayCode(
    code: DisplayCode,
    tx?: TxContext
  ): Promise<Transaction | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<TransactionRow>(
      'SELECT * FROM transactions WHERE display_code = ?',
      [code]
    );
    return row ? mapTransaction(row) : null;
  },

  async create(input: CreateTransactionInput, tx?: TxContext): Promise<Transaction> {
    const run = async (t: TxContext): Promise<Transaction> => {
      const workspaceId = await getWorkspaceId(t);
      const devicePrefix = await getDevicePrefix(t);
      const id = generateULID();
      const now = nowISO();
      const sequence = await getNextDailySequence(
        t,
        input.type,
        input.transactionDate,
        devicePrefix
      );
      const displayCode = buildDisplayCode(
        input.type,
        input.transactionDate,
        sequence,
        devicePrefix
      );

      await t.execute(
        `INSERT INTO transactions
          (id, workspace_id, display_code, type, amount, account_id, party_id,
           category_id, custom_category_text, project_id, transaction_date,
           transaction_time, reference_code, description, status, version,
           device_id, created_at, updated_at, created_by, updated_by, deleted_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'active', 1,
                 NULL, ?, ?, ?, NULL, NULL)`,
        [
          id,
          workspaceId,
          displayCode,
          input.type,
          toDbMoney(input.amount),
          input.accountId,
          input.partyId,
          input.categoryId,
          input.customCategoryText,
          input.projectId,
          input.transactionDate,
          input.transactionTime,
          input.referenceCode,
          input.description,
          now,
          now,
          input.createdBy,
        ]
      );

      const transaction: Transaction = {
        id,
        workspaceId,
        displayCode,
        type: input.type,
        amount: input.amount,
        accountId: input.accountId,
        partyId: input.partyId,
        categoryId: input.categoryId,
        customCategoryText: input.customCategoryText,
        projectId: input.projectId,
        transactionDate: input.transactionDate,
        transactionTime: input.transactionTime,
        referenceCode: input.referenceCode,
        description: input.description,
        status: TransactionStatus.ACTIVE,
        version: 1,
        deviceId: null,
        createdAt: now,
        updatedAt: now,
        createdBy: input.createdBy,
        updatedBy: null,
        deletedAt: null,
      };

      await writeAudit(t, {
        workspaceId,
        entityType: AuditEntityType.TRANSACTION,
        entityId: id,
        action: AuditAction.CREATE,
        before: null,
        after: serializeTransaction(transaction),
        actorLabel: input.createdBy,
      });

      return transaction;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async update(
    id: TransactionId,
    changes: UpdateTransactionInput,
    tx?: TxContext
  ): Promise<Transaction | null> {
    const run = async (t: TxContext): Promise<Transaction | null> => {
      const existingRow = await t.queryOne<TransactionRow>(
        'SELECT * FROM transactions WHERE id = ?',
        [id]
      );
      if (!existingRow) return null;
      const before = mapTransaction(existingRow);

      const fields: string[] = [];
      const values: unknown[] = [];

      if (changes.amount !== undefined) {
        fields.push('amount = ?');
        values.push(toDbMoney(changes.amount));
      }
      if (changes.accountId !== undefined) {
        fields.push('account_id = ?');
        values.push(changes.accountId);
      }
      if (changes.partyId !== undefined) {
        fields.push('party_id = ?');
        values.push(changes.partyId);
      }
      if (changes.categoryId !== undefined) {
        fields.push('category_id = ?');
        values.push(changes.categoryId);
      }
      if (changes.customCategoryText !== undefined) {
        fields.push('custom_category_text = ?');
        values.push(changes.customCategoryText);
      }
      if (changes.projectId !== undefined) {
        fields.push('project_id = ?');
        values.push(changes.projectId);
      }
      if (changes.transactionDate !== undefined) {
        fields.push('transaction_date = ?');
        values.push(changes.transactionDate);
      }
      if (changes.transactionTime !== undefined) {
        fields.push('transaction_time = ?');
        values.push(changes.transactionTime);
      }
      if (changes.referenceCode !== undefined) {
        fields.push('reference_code = ?');
        values.push(changes.referenceCode);
      }
      if (changes.description !== undefined) {
        fields.push('description = ?');
        values.push(changes.description);
      }

      if (fields.length === 0) return before;

      fields.push('version = version + 1');
      fields.push('updated_at = ?');
      values.push(nowISO());
      fields.push('updated_by = ?');
      values.push(changes.updatedBy ?? null);
      values.push(id);

      await t.execute(
        `UPDATE transactions SET ${fields.join(', ')} WHERE id = ?`,
        values
      );

      const updatedRow = await t.queryOne<TransactionRow>(
        'SELECT * FROM transactions WHERE id = ?',
        [id]
      );
      if (!updatedRow) return null;
      const after = mapTransaction(updatedRow);

      await writeAudit(t, {
        workspaceId: after.workspaceId,
        entityType: AuditEntityType.TRANSACTION,
        entityId: id,
        action: AuditAction.EDIT,
        before: serializeTransaction(before),
        after: serializeTransaction(after),
        actorLabel: changes.updatedBy ?? null,
      });

      return after;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async softDelete(
    id: TransactionId,
    actorLabel: string | null = null,
    tx?: TxContext
  ): Promise<boolean> {
    const run = async (t: TxContext): Promise<boolean> => {
      const existingRow = await t.queryOne<TransactionRow>(
        'SELECT * FROM transactions WHERE id = ?',
        [id]
      );
      if (!existingRow) return false;
      const before = mapTransaction(existingRow);

      const now = nowISO();
      await t.execute(
        `UPDATE transactions
         SET status = 'soft_deleted', deleted_at = ?, updated_at = ?,
             version = version + 1
         WHERE id = ?`,
        [now, now, id]
      );

      await writeAudit(t, {
        workspaceId: before.workspaceId,
        entityType: AuditEntityType.TRANSACTION,
        entityId: id,
        action: AuditAction.DELETE,
        before: serializeTransaction(before),
        after: null,
        actorLabel,
      });

      return true;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async restore(
    id: TransactionId,
    actorLabel: string | null = null,
    tx?: TxContext
  ): Promise<boolean> {
    const run = async (t: TxContext): Promise<boolean> => {
      const existingRow = await t.queryOne<TransactionRow>(
        'SELECT * FROM transactions WHERE id = ?',
        [id]
      );
      if (!existingRow) return false;
      const before = mapTransaction(existingRow);

      const now = nowISO();
      await t.execute(
        `UPDATE transactions
         SET status = 'active', deleted_at = NULL, updated_at = ?,
             version = version + 1
         WHERE id = ?`,
        [now, id]
      );

      const updatedRow = await t.queryOne<TransactionRow>(
        'SELECT * FROM transactions WHERE id = ?',
        [id]
      );
      const after = updatedRow ? mapTransaction(updatedRow) : null;

      await writeAudit(t, {
        workspaceId: before.workspaceId,
        entityType: AuditEntityType.TRANSACTION,
        entityId: id,
        action: AuditAction.RESTORE,
        before: serializeTransaction(before),
        after: after ? serializeTransaction(after) : null,
        actorLabel,
      });

      return true;
    };

    if (tx) return run(tx);
    return requireDb().transaction(run);
  },

  async countByAccount(accountId: AccountId, tx?: TxContext): Promise<number> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{ count: number }>(
      `SELECT COUNT(*) AS count FROM transactions
       WHERE account_id = ? AND status = 'active'`,
      [accountId]
    );
    return row?.count ?? 0;
  },
};

// ============================================================================
//  Attachment repository
// ============================================================================

export const attachmentRepo = {
  async listByTransaction(
    transactionId: TransactionId,
    tx?: TxContext
  ): Promise<Attachment[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<AttachmentRow>(
      'SELECT * FROM attachments WHERE transaction_id = ? ORDER BY created_at ASC',
      [transactionId]
    );
    return rows.map(mapAttachment);
  },

  async create(
    input: {
      transactionId: TransactionId;
      type?: string;
      fileName: string;
      storageKey: string;
      thumbnailKey: string | null;
      mimeType: string;
      sizeBytes: number;
      sha256: string;
    },
    tx?: TxContext
  ): Promise<Attachment> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    const now = nowISO();
    const type = input.type ?? 'image';

    await conn.execute(
      `INSERT INTO attachments
        (id, transaction_id, type, file_name, storage_key, thumbnail_key,
         mime_type, size_bytes, sha256, created_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        input.transactionId,
        type,
        input.fileName,
        input.storageKey,
        input.thumbnailKey,
        input.mimeType,
        input.sizeBytes,
        input.sha256,
        now,
      ]
    );

    return {
      id,
      transactionId: input.transactionId,
      type,
      fileName: input.fileName,
      storageKey: input.storageKey,
      thumbnailKey: input.thumbnailKey,
      mimeType: input.mimeType,
      sizeBytes: input.sizeBytes,
      sha256: input.sha256,
      createdAt: now,
    };
  },

  async remove(id: AttachmentId, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute('DELETE FROM attachments WHERE id = ?', [id]);
  },
};

// ============================================================================
//  Audit repository
// ============================================================================

export const auditRepo = {
  async list(limit = 100, tx?: TxContext): Promise<AuditEvent[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<AuditEventRow>(
      'SELECT * FROM audit_events ORDER BY created_at DESC LIMIT ?',
      [limit]
    );
    return rows.map(mapAuditEvent);
  },

  async listByEntity(
    entityType: string,
    entityId: string,
    tx?: TxContext
  ): Promise<AuditEvent[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<AuditEventRow>(
      `SELECT * FROM audit_events
       WHERE entity_type = ? AND entity_id = ?
       ORDER BY created_at DESC`,
      [entityType, entityId]
    );
    return rows.map(mapAuditEvent);
  },

  async listByAction(
    action: AuditAction,
    limit = 100,
    tx?: TxContext
  ): Promise<AuditEvent[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<AuditEventRow>(
      'SELECT * FROM audit_events WHERE action = ? ORDER BY created_at DESC LIMIT ?',
      [action, limit]
    );
    return rows.map(mapAuditEvent);
  },

  async countAll(tx?: TxContext): Promise<number> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{ count: number }>(
      'SELECT COUNT(*) AS count FROM audit_events'
    );
    return row?.count ?? 0;
  },
};

// ============================================================================
//  Draft repository
// ============================================================================

export const draftRepo = {
  async get(id: DraftKeyType, tx?: TxContext): Promise<Draft | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{
      id: string;
      form_type: string;
      form_json: string;
      updated_at: string;
    }>('SELECT * FROM drafts WHERE id = ?', [id]);
    if (!row) return null;
    return {
      id: row.id as DraftKeyType,
      formType: row.form_type,
      formJson: row.form_json,
      updatedAt: row.updated_at,
    };
  },

  async save(
    id: DraftKeyType,
    formJson: string,
    formType = 'transaction',
    tx?: TxContext
  ): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(
      `INSERT INTO drafts (id, form_type, form_json, updated_at)
       VALUES (?, ?, ?, ?)
       ON CONFLICT(id) DO UPDATE SET
         form_type = excluded.form_type,
         form_json = excluded.form_json,
         updated_at = excluded.updated_at`,
      [id, formType, formJson, nowISO()]
    );
  },

  async clear(id: DraftKeyType, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute('DELETE FROM drafts WHERE id = ?', [id]);
  },

  async listAll(tx?: TxContext): Promise<Draft[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<{
      id: string;
      form_type: string;
      form_json: string;
      updated_at: string;
    }>('SELECT * FROM drafts ORDER BY updated_at DESC');
    return rows.map((row) => ({
      id: row.id as DraftKeyType,
      formType: row.form_type,
      formJson: row.form_json,
      updatedAt: row.updated_at,
    }));
  },
};

// ============================================================================
//  Security repository
// ============================================================================

export const securityRepo = {
  async get(tx?: TxContext): Promise<SecurityProfile | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<SecurityRow>(
      `SELECT * FROM security_profiles WHERE id = 'default'`
    );
    return row ? mapSecurityProfile(row) : null;
  },

  async ensureInitialized(tx?: TxContext): Promise<SecurityProfile> {
    const existing = await this.get(tx);
    if (existing) return existing;

    const conn = tx ?? requireDb();
    await conn.execute(
      `INSERT INTO security_profiles
        (id, pin_hash, pattern_hash, biometric_enabled, primary_method,
         failed_attempts, lockout_until, recovery_used_count,
         lock_timeout_seconds, configured_at)
       VALUES ('default', NULL, NULL, 0, NULL, 0, NULL, 0, 0, NULL)`
    );

    return {
      id: 'default',
      pinHash: null,
      patternHash: null,
      biometricEnabled: false,
      primaryMethod: null,
      failedAttempts: 0,
      lockoutUntil: null,
      recoveryUsedCount: 0,
      lockTimeoutSeconds: 0,
      configuredAt: null,
    };
  },

  async update(
    changes: {
      pinHash?: string | null;
      patternHash?: string | null;
      biometricEnabled?: boolean;
      primaryMethod?: PrimarySecurityMethodValue | null;
      failedAttempts?: number;
      lockoutUntil?: string | null;
      recoveryUsedCount?: number;
      lockTimeoutSeconds?: number;
      configuredAt?: string | null;
    },
    tx?: TxContext
  ): Promise<void> {
    const conn = tx ?? requireDb();
    const fields: string[] = [];
    const values: unknown[] = [];

    if (changes.pinHash !== undefined) {
      fields.push('pin_hash = ?');
      values.push(changes.pinHash);
    }
    if (changes.patternHash !== undefined) {
      fields.push('pattern_hash = ?');
      values.push(changes.patternHash);
    }
    if (changes.biometricEnabled !== undefined) {
      fields.push('biometric_enabled = ?');
      values.push(toDbBool(changes.biometricEnabled));
    }
    if (changes.primaryMethod !== undefined) {
      fields.push('primary_method = ?');
      values.push(changes.primaryMethod);
    }
    if (changes.failedAttempts !== undefined) {
      fields.push('failed_attempts = ?');
      values.push(changes.failedAttempts);
    }
    if (changes.lockoutUntil !== undefined) {
      fields.push('lockout_until = ?');
      values.push(changes.lockoutUntil);
    }
    if (changes.recoveryUsedCount !== undefined) {
      fields.push('recovery_used_count = ?');
      values.push(changes.recoveryUsedCount);
    }
    if (changes.lockTimeoutSeconds !== undefined) {
      fields.push('lock_timeout_seconds = ?');
      values.push(changes.lockTimeoutSeconds);
    }
    if (changes.configuredAt !== undefined) {
      fields.push('configured_at = ?');
      values.push(changes.configuredAt);
    }

    if (fields.length === 0) return;

    await conn.execute(
      `UPDATE security_profiles SET ${fields.join(', ')} WHERE id = 'default'`,
      values
    );
  },

  async reset(tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(`DELETE FROM security_profiles WHERE id = 'default'`);
  },
};

// ============================================================================
//  Backup repository
// ============================================================================

export const backupRepo = {
  async list(limit = 20, tx?: TxContext): Promise<BackupRecord[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<{
      id: string;
      file_name: string;
      type: string;
      size_bytes: number;
      transaction_count: number;
      schema_version: number;
      app_version: string;
      created_at: string;
      checksum: string;
    }>('SELECT * FROM backup_records ORDER BY created_at DESC LIMIT ?', [limit]);
    return rows.map((row) => ({
      id: row.id,
      fileName: row.file_name,
      type: row.type as BackupTypeValue,
      sizeBytes: row.size_bytes,
      transactionCount: row.transaction_count,
      schemaVersion: row.schema_version,
      appVersion: row.app_version,
      createdAt: row.created_at,
      checksum: row.checksum,
    }));
  },

  async create(
    input: {
      fileName: string;
      type: BackupTypeValue;
      sizeBytes: number;
      transactionCount: number;
      schemaVersion: number;
      appVersion: string;
      checksum: string;
    },
    tx?: TxContext
  ): Promise<BackupRecord> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    const now = nowISO();

    await conn.execute(
      `INSERT INTO backup_records
        (id, file_name, type, size_bytes, transaction_count, schema_version,
         app_version, created_at, checksum)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        input.fileName,
        input.type,
        input.sizeBytes,
        input.transactionCount,
        input.schemaVersion,
        input.appVersion,
        now,
        input.checksum,
      ]
    );

    return {
      id,
      fileName: input.fileName,
      type: input.type,
      sizeBytes: input.sizeBytes,
      transactionCount: input.transactionCount,
      schemaVersion: input.schemaVersion,
      appVersion: input.appVersion,
      createdAt: now,
      checksum: input.checksum,
    };
  },
};

// ============================================================================
//  Import repository
// ============================================================================

export const importRepo = {
  async createJob(fileName: string, tx?: TxContext): Promise<ImportJob> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    const now = nowISO();
    await conn.execute(
      `INSERT INTO import_jobs (id, file_name, started_at, finished_at, status, stats_json)
       VALUES (?, ?, ?, NULL, 'analyzing', NULL)`,
      [id, fileName, now]
    );
    return {
      id,
      fileName,
      startedAt: now,
      finishedAt: null,
      status: ImportStatus.ANALYZING,
      statsJson: null,
    };
  },

  async updateJobStatus(
    id: ImportJobId,
    status: ImportStatusValue,
    statsJson: string | null,
    tx?: TxContext
  ): Promise<void> {
    const conn = tx ?? requireDb();
    const finishedAt =
      status === ImportStatus.COMMITTED ||
      status === ImportStatus.CANCELLED ||
      status === ImportStatus.FAILED
        ? nowISO()
        : null;
    await conn.execute(
      `UPDATE import_jobs SET status = ?, stats_json = ?, finished_at = ? WHERE id = ?`,
      [status, statsJson, finishedAt, id]
    );
  },

  async addRecord(
    input: {
      jobId: ImportJobId;
      rowNumber: number;
      rowHash: string;
      decision: ImportDecisionValue;
      matchedTransactionId: TransactionId | null;
      duplicateScore: string | null;
      errorMessage: string | null;
    },
    tx?: TxContext
  ): Promise<void> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    await conn.execute(
      `INSERT INTO import_records
        (id, job_id, row_number, row_hash, decision,
         matched_transaction_id, duplicate_score, error_message)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        id,
        input.jobId,
        input.rowNumber,
        input.rowHash,
        input.decision,
        input.matchedTransactionId,
        input.duplicateScore,
        input.errorMessage,
      ]
    );
  },

  async findRecordByHash(
    rowHash: string,
    tx?: TxContext
  ): Promise<{
    id: ImportRecordId;
    jobId: ImportJobId;
    decision: ImportDecisionValue;
  } | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{
      id: string;
      job_id: string;
      decision: string;
    }>('SELECT id, job_id, decision FROM import_records WHERE row_hash = ? LIMIT 1', [
      rowHash,
    ]);
    if (!row) return null;
    return {
      id: row.id,
      jobId: row.job_id,
      decision: row.decision as ImportDecisionValue,
    };
  },

  async listMappings(tx?: TxContext): Promise<ImportMapping[]> {
    const conn = tx ?? requireDb();
    const rows = await conn.query<{
      id: string;
      name: string;
      mapping_json: string;
      created_at: string;
    }>('SELECT * FROM import_mappings ORDER BY created_at DESC');
    return rows.map((row) => ({
      id: row.id,
      name: row.name,
      mappingJson: row.mapping_json,
      createdAt: row.created_at,
    }));
  },

  async saveMapping(
    name: string,
    mappingJson: string,
    tx?: TxContext
  ): Promise<ImportMapping> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    const now = nowISO();
    await conn.execute(
      `INSERT INTO import_mappings (id, name, mapping_json, created_at)
       VALUES (?, ?, ?, ?)`,
      [id, name, mappingJson, now]
    );
    return { id, name, mappingJson, createdAt: now };
  },
};

// ============================================================================
//  Alerts repository
// ============================================================================

interface AlertRow {
  id: string;
  type: string;
  severity: string;
  entity_type: string | null;
  entity_id: string | null;
  message_key: string;
  message_params_json: string | null;
  created_at: string;
  read_at: string | null;
  resolved_at: string | null;
}

function mapAlert(row: AlertRow): AlertItem {
  let params: Record<string, string | number> | null = null;
  if (row.message_params_json) {
    try {
      const parsed = JSON.parse(row.message_params_json) as unknown;
      if (parsed && typeof parsed === 'object' && !Array.isArray(parsed)) {
        params = parsed as Record<string, string | number>;
      }
    } catch {
      params = null;
    }
  }

  return {
    id: row.id,
    type: row.type as AlertType,
    severity: row.severity as AlertSeverity,
    entityType: (row.entity_type as AuditEntityTypeType | null) ?? null,
    entityId: row.entity_id,
    messageKey: row.message_key,
    messageParams: params,
    createdAt: row.created_at,
    readAt: row.read_at,
    resolvedAt: row.resolved_at,
  };
}

export const alertsRepo = {
  async list(
    options: {
      onlyUnread?: boolean;
      onlyUnresolved?: boolean;
      limit?: number;
    } = {},
    tx?: TxContext
  ): Promise<AlertItem[]> {
    const conn = tx ?? requireDb();
    const conditions: string[] = [];
    if (options.onlyUnread) conditions.push('read_at IS NULL');
    if (options.onlyUnresolved) conditions.push('resolved_at IS NULL');

    const where = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const limit = options.limit ?? 200;

    const rows = await conn.query<AlertRow>(
      `SELECT * FROM alerts ${where} ORDER BY created_at DESC LIMIT ?`,
      [limit]
    );
    return rows.map(mapAlert);
  },

  async create(
    input: {
      type: AlertType;
      severity: AlertSeverity;
      entityType: AuditEntityTypeType | null;
      entityId: ULID | null;
      messageKey: string;
      messageParams: Record<string, string | number> | null;
    },
    tx?: TxContext
  ): Promise<AlertItem> {
    const conn = tx ?? requireDb();
    const id = generateULID();
    const now = nowISO();

    await conn.execute(
      `INSERT INTO alerts
        (id, type, severity, entity_type, entity_id, message_key,
         message_params_json, created_at, read_at, resolved_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, NULL, NULL)`,
      [
        id,
        input.type,
        input.severity,
        input.entityType,
        input.entityId,
        input.messageKey,
        input.messageParams === null ? null : JSON.stringify(input.messageParams),
        now,
      ]
    );

    return {
      id,
      type: input.type,
      severity: input.severity,
      entityType: input.entityType,
      entityId: input.entityId,
      messageKey: input.messageKey,
      messageParams: input.messageParams,
      createdAt: now,
      readAt: null,
      resolvedAt: null,
    };
  },

  async markRead(id: ULID, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(`UPDATE alerts SET read_at = ? WHERE id = ? AND read_at IS NULL`, [
      nowISO(),
      id,
    ]);
  },

  async markAllRead(tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(`UPDATE alerts SET read_at = ? WHERE read_at IS NULL`, [nowISO()]);
  },

  async resolve(id: ULID, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute(
      `UPDATE alerts SET resolved_at = ? WHERE id = ? AND resolved_at IS NULL`,
      [nowISO(), id]
    );
  },

  async unreadCount(tx?: TxContext): Promise<number> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{ count: number }>(
      `SELECT COUNT(*) AS count FROM alerts
       WHERE read_at IS NULL AND resolved_at IS NULL`
    );
    return row?.count ?? 0;
  },

  async deleteById(id: ULID, tx?: TxContext): Promise<void> {
    const conn = tx ?? requireDb();
    await conn.execute('DELETE FROM alerts WHERE id = ?', [id]);
  },
};

// ============================================================================
//  Workspace repository
// ============================================================================

export const workspaceRepo = {
  async get(tx?: TxContext): Promise<{
    id: ULID;
    name: string;
    createdAt: ISOTimestamp;
  } | null> {
    const conn = tx ?? requireDb();
    const row = await conn.queryOne<{
      id: string;
      name: string;
      created_at: string;
    }>('SELECT * FROM workspaces LIMIT 1');
    if (!row) return null;
    return { id: row.id, name: row.name, createdAt: row.created_at };
  },
};

// ============================================================================
//  Utility exports
// ============================================================================

export const dbUtils = {
  generateULID,
  generateDevicePrefix,
  toDbMoney,
  toDbMoneyNullable,
  fromDbMoney,
  fromDbMoneyNullable,
  toDbBool,
  fromDbBool,
  nowISO,
  isNativePlatform,
  randomBytes,
};

// ============================================================================
//  Type re-exports
// ============================================================================

export type { ClockTime, DisplayCode };

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
