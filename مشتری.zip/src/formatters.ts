// ============================================================================
//  src/formatters.ts
//  توابع خالص تبدیل مبلغ، تاریخ، حروف فارسی و نرمالایز متن
// ============================================================================
//
//  این فایل هیچ وابستگی به React، Capacitor یا دیتابیس ندارد.
//
//  ── تغییرات SPEC v2.0 ─────────────────────────────────────────────────
//
//   ۱. اضافه‌شدن `fromJalali(jy, jm, jd)` که برمی‌گرداند `{ gy, gm, gd }`.
//      این تابع جایگزین `require('jalaali-js')` در `sheets.tsx` می‌شود.
//   ۲. تابع قدیمی `fromJalali(string)` به `parseJalaliString` (private)
//      تغییر نام یافت.
//   ۳. `numberToPersianWords` حفظ شده و در برابر مبالغ صفر و منفی امن است.
// ============================================================================

import { toJalaali, toGregorian } from 'jalaali-js';
import type {
  ClockTime,
  DisplayCode,
  ISODate,
  ISOTimestamp,
  Language,
  Money,
} from './types';

// ═══════════════════════════════════════════════════════════════════════════
// Digit normalization
// ═══════════════════════════════════════════════════════════════════════════

const PERSIAN_DIGITS = '۰۱۲۳۴۵۶۷۸۹';
const ARABIC_DIGITS  = '٠١٢٣٤٥٦٧٨٩';

/**
 * تبدیل ارقام فارسی و عربی به انگلیسی.
 * سایر کاراکترها دست‌نخورده باقی می‌مانند.
 */
export function normalizeDigits(input: string): string {
  let out = '';
  for (const ch of input) {
    const p = PERSIAN_DIGITS.indexOf(ch);
    if (p >= 0) {
      out += String(p);
      continue;
    }
    const a = ARABIC_DIGITS.indexOf(ch);
    if (a >= 0) {
      out += String(a);
      continue;
    }
    out += ch;
  }
  return out;
}

/**
 * نرمالایز متن فارسی برای جستجو و مقایسه:
 *   - تبدیل ی/ي و ک/ك عربی به فارسی
 *   - حذف کاراکترهای نامرئی (ZWNJ/ZWS/BOM)
 *   - تبدیل فاصله‌ی نیم‌پهن و چند-فاصله‌ای به یک فاصله
 *   - toLowerCase برای جستجوی انگلیسی هم‌زمان
 */
export function normalizePersianText(input: string): string {
  return input
    .replace(/ي/g, 'ی')
    .replace(/ك/g, 'ک')
    .replace(/[\u200B-\u200D\uFEFF]/g, '')
    .replace(/\u00A0/g, ' ')
    .replace(/\s+/g, ' ')
    .toLowerCase()
    .trim();
}

// ═══════════════════════════════════════════════════════════════════════════
// Money formatting
// ═══════════════════════════════════════════════════════════════════════════

/**
 * نمایش مبلغ بدون واحد، با جداکننده‌ی سه‌رقمی.
 * مثال: `35,000,000` یا `-35,000,000`
 */
export function formatMoneyPlain(amount: Money): string {
  const negative = amount < 0n;
  const abs = negative ? -amount : amount;
  const raw = abs.toString();
  const withSep = raw.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
  return negative ? '-' + withSep : withSep;
}

/**
 * نمایش مبلغ با واحد تومان.
 * مثال: `35,000,000 تومان`
 */
export function formatMoney(amount: Money): string {
  return formatMoneyPlain(amount) + ' تومان';
}

// ═══════════════════════════════════════════════════════════════════════════
// Money parsing
// ═══════════════════════════════════════════════════════════════════════════

/**
 * تجزیه‌ی یک رشته به Money.
 * نرمالایز ارقام و حذف جداکننده‌ها قبل از BigInt.
 * برمی‌گرداند null اگر نامعتبر باشد.
 */
export function parseMoney(input: string): Money | null {
  if (!input) return null;
  const cleaned = normalizeDigits(input).replace(/[,\s،]/g, '').trim();
  if (!/^-?\d+$/.test(cleaned)) return null;
  try {
    return BigInt(cleaned);
  } catch {
    return null;
  }
}

/**
 * تجزیه‌ی Quick Expression مثل `10000000+5000000-2000000`.
 * فقط اجازه‌ی `+` و `-` و ارقام داده می‌شود.
 * برمی‌گرداند مبلغ نهایی (باید > 0 باشد).
 */
export function parseAmountExpression(input: string): Money | null {
  const cleaned = normalizeDigits(input).replace(/[,\s،]/g, '');
  if (!cleaned) return null;
  if (!/^\d+([+\-]\d+)*$/.test(cleaned)) return null;

  const parts = cleaned.split(/(?=[+\-])/);
  let result = 0n;
  for (const part of parts) {
    if (part.startsWith('+')) {
      result += BigInt(part.slice(1));
    } else if (part.startsWith('-')) {
      result -= BigInt(part.slice(1));
    } else {
      result += BigInt(part);
    }
  }
  return result > 0n ? result : null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Number to Persian words
// ═══════════════════════════════════════════════════════════════════════════

const ONES = ['', 'یک', 'دو', 'سه', 'چهار', 'پنج', 'شش', 'هفت', 'هشت', 'نه'];
const TEENS = [
  'ده',
  'یازده',
  'دوازده',
  'سیزده',
  'چهارده',
  'پانزده',
  'شانزده',
  'هفده',
  'هجده',
  'نوزده',
];
const TENS = ['', '', 'بیست', 'سی', 'چهل', 'پنجاه', 'شصت', 'هفتاد', 'هشتاد', 'نود'];
const HUNDREDS = [
  '',
  'صد',
  'دویست',
  'سیصد',
  'چهارصد',
  'پانصد',
  'ششصد',
  'هفتصد',
  'هشتصد',
  'نهصد',
];

/**
 * مقیاس‌های سه‌رقمی. پشتیبانی تا ۹۹۹,۹۹۹,۹۹۹,۹۹۹,۹۹۹ (۱۵ رقم).
 * index 0 → 10^0، index 4 → 10^12.
 */
const SCALES = ['', 'هزار', 'میلیون', 'میلیارد', 'تریلیون'];

/**
 * تبدیل یک عدد سه‌رقمی (0..999) به حروف فارسی.
 */
function threeDigitToWords(n: number): string {
  if (n === 0) return '';

  const parts: string[] = [];
  const h = Math.floor(n / 100);
  const rest = n % 100;

  if (h > 0) parts.push(HUNDREDS[h]!);

  if (rest >= 10 && rest < 20) {
    parts.push(TEENS[rest - 10]!);
  } else {
    const t = Math.floor(rest / 10);
    const o = rest % 10;
    if (t > 0) parts.push(TENS[t]!);
    if (o > 0) parts.push(ONES[o]!);
  }

  return parts.join(' و ');
}

/**
 * تبدیل مبلغ به حروف فارسی.
 * مثال: 35,000,000 → «سی و پنج میلیون»
 */
export function numberToPersianWords(amount: Money): string {
  if (amount === 0n) return 'صفر';
  if (amount < 0n) return 'منفی ' + numberToPersianWords(-amount);

  const groups: string[] = [];
  let remaining = amount;
  let scaleIdx = 0;

  while (remaining > 0n && scaleIdx < SCALES.length) {
    const seg = Number(remaining % 1000n);
    if (seg > 0) {
      const words = threeDigitToWords(seg);
      const scale = SCALES[scaleIdx]!;
      if (scale === '') {
        groups.unshift(words);
      } else if (seg === 1 && scale === 'هزار') {
        groups.unshift(scale);
      } else {
        groups.unshift(words + ' ' + scale);
      }
    }
    remaining = remaining / 1000n;
    scaleIdx += 1;
  }

  // اگر عددی از SCALES فراتر رفت، امن‌تر است که هشدار بدهیم.
  // SPEC v2.0 سقف را ۱۵ رقم تعیین کرده و این تابع تا همان سقف کار می‌کند.
  if (remaining > 0n) {
    throw new Error(
      'مبلغ از محدوده‌ی تبدیل به حروف فارسی خارج است (حداکثر ۱۵ رقم)'
    );
  }

  return groups.join(' و ');
}

// ═══════════════════════════════════════════════════════════════════════════
// Date — internal helpers
// ═══════════════════════════════════════════════════════════════════════════

function pad2(n: number): string {
  return n < 10 ? '0' + n : String(n);
}

function parseISODate(iso: ISODate): { y: number; m: number; d: number } | null {
  const parts = iso.split('-');
  if (parts.length !== 3) return null;
  const y = Number(parts[0]);
  const m = Number(parts[1]);
  const d = Number(parts[2]);
  if (!Number.isFinite(y) || !Number.isFinite(m) || !Number.isFinite(d)) return null;
  return { y, m, d };
}

function isValidGregorian(y: number, m: number, d: number): boolean {
  if (m < 1 || m > 12) return false;
  if (d < 1 || d > 31) return false;
  const dt = new Date(y, m - 1, d);
  return (
    dt.getFullYear() === y &&
    dt.getMonth() === m - 1 &&
    dt.getDate() === d
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// Jalali ↔ Gregorian
// ═══════════════════════════════════════════════════════════════════════════

export interface JalaliParts {
  jy: number;
  jm: number;
  jd: number;
}

export interface GregorianParts {
  gy: number;
  gm: number;
  gd: number;
}

/**
 * تبدیل تاریخ میلادی (سه عدد) به جلالی.
 * اگر ورودی نامعتبر باشد، null برمی‌گرداند.
 */
export function toJalaliParts(gy: number, gm: number, gd: number): JalaliParts | null {
  if (!Number.isFinite(gy) || !Number.isFinite(gm) || !Number.isFinite(gd)) {
    return null;
  }
  if (!isValidGregorian(gy, gm, gd)) return null;
  const { jy, jm, jd } = toJalaali(gy, gm, gd);
  return { jy, jm, jd };
}

/**
 * تبدیل تاریخ جلالی (سه عدد) به میلادی.
 * اگر ورودی نامعتبر باشد، null برمی‌گرداند.
 *
 * این تابع، جایگزین `require('jalaali-js').toGregorian` در سایر فایل‌ها است.
 */
export function fromJalali(jy: number, jm: number, jd: number): GregorianParts | null {
  if (!Number.isFinite(jy) || !Number.isFinite(jm) || !Number.isFinite(jd)) {
    return null;
  }
  if (jm < 1 || jm > 12) return null;
  if (jd < 1 || jd > 31) return null;

  const { gy, gm, gd } = toGregorian(jy, jm, jd);
  if (!isValidGregorian(gy, gm, gd)) return null;
  return { gy, gm, gd };
}

// ═══════════════════════════════════════════════════════════════════════════
// ISO date ↔ Jalali string
// ═══════════════════════════════════════════════════════════════════════════

/**
 * دریافت بخش‌های جلالی از یک تاریخ ISO میلادی.
 */
export function getJalaliParts(iso: ISODate): JalaliParts | null {
  const parsed = parseISODate(iso);
  if (!parsed) return null;
  return toJalaliParts(parsed.y, parsed.m, parsed.d);
}

/**
 * تبدیل ISO میلادی به رشته‌ی شمسی نمایشی.
 * مثال: `2026-09-06` → `1405/06/15`
 */
export function toJalali(iso: ISODate): string {
  const parts = getJalaliParts(iso);
  if (!parts) return '';
  return `${parts.jy}/${pad2(parts.jm)}/${pad2(parts.jd)}`;
}

/**
 * تبدیل ISO میلادی به رشته‌ی شمسی فشرده (بدون جداکننده‌ی تاریخ).
 * مثال: `2026-09-06` → `14050615`
 */
export function toJalaliCompact(iso: ISODate): string {
  const parts = getJalaliParts(iso);
  if (!parts) return '';
  return `${parts.jy}${pad2(parts.jm)}${pad2(parts.jd)}`;
}

/**
 * تجزیه‌ی رشته‌ی شمسی به ISO میلادی.
 * می‌پذیرد: `1405/06/15` یا `۱۴۰۵/۰۶/۱۵`
 * برمی‌گرداند: `2026-09-06` یا null.
 */
function parseJalaliString(jalali: string): ISODate | null {
  const cleaned = normalizeDigits(jalali).trim();
  const parts = cleaned.split('/');
  if (parts.length !== 3) return null;

  const jy = Number(parts[0]);
  const jm = Number(parts[1]);
  const jd = Number(parts[2]);

  const result = fromJalali(jy, jm, jd);
  if (!result) return null;

  return `${result.gy}-${pad2(result.gm)}-${pad2(result.gd)}`;
}

/**
 * تجزیه‌ی یک رشته‌ی تاریخ به ISO میلادی.
 * هم ISO میلادی را قبول می‌کند هم شمسی.
 */
export function parseDate(input: string): ISODate | null {
  const cleaned = normalizeDigits(input).trim();
  if (!cleaned) return null;

  // ISO میلادی: YYYY-MM-DD
  if (/^\d{4}-\d{1,2}-\d{1,2}$/.test(cleaned)) {
    const parts = cleaned.split('-');
    const y = Number(parts[0]);
    const m = Number(parts[1]);
    const d = Number(parts[2]);
    if (!isValidGregorian(y, m, d)) return null;
    return `${y}-${pad2(m)}-${pad2(d)}`;
  }

  // شمسی: YYYY/MM/DD
  if (/^\d{4}\/\d{1,2}\/\d{1,2}$/.test(cleaned)) {
    return parseJalaliString(cleaned);
  }

  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Display formatting
// ═══════════════════════════════════════════════════════════════════════════

const JALALI_MONTHS_FA = [
  'فروردین',
  'اردیبهشت',
  'خرداد',
  'تیر',
  'مرداد',
  'شهریور',
  'مهر',
  'آبان',
  'آذر',
  'دی',
  'بهمن',
  'اسفند',
];

const GREGORIAN_MONTHS_EN = [
  'January',
  'February',
  'March',
  'April',
  'May',
  'June',
  'July',
  'August',
  'September',
  'October',
  'November',
  'December',
];

/**
 * نمایش تاریخ بر اساس زبان.
 * fa: `15 شهریور 1405`
 * en: `September 6, 2026`
 */
export function formatDate(iso: ISODate, lang: Language): string {
  const parsed = parseISODate(iso);
  if (!parsed) return '';

  if (lang === 'fa') {
    const { jy, jm, jd } = toJalaali(parsed.y, parsed.m, parsed.d);
    return `${jd} ${JALALI_MONTHS_FA[jm - 1]} ${jy}`;
  }

  return `${GREGORIAN_MONTHS_EN[parsed.m - 1]} ${parsed.d}, ${parsed.y}`;
}

/**
 * نمایش تاریخ از یک timestamp ISO.
 */
export function formatTimestamp(iso: ISOTimestamp, lang: Language): string {
  const dt = new Date(iso);
  if (Number.isNaN(dt.getTime())) return '';
  const dateIso = `${dt.getFullYear()}-${pad2(dt.getMonth() + 1)}-${pad2(dt.getDate())}`;
  return formatDate(dateIso, lang);
}

// ═══════════════════════════════════════════════════════════════════════════
// Now helpers
// ═══════════════════════════════════════════════════════════════════════════

/**
 * تاریخ امروز به فرم ISO میلادی.
 */
export function todayISO(): ISODate {
  const now = new Date();
  return `${now.getFullYear()}-${pad2(now.getMonth() + 1)}-${pad2(now.getDate())}`;
}

/**
 * timestamp کامل الان.
 */
export function nowISO(): ISOTimestamp {
  return new Date().toISOString();
}

// ═══════════════════════════════════════════════════════════════════════════
// Display code
// ═══════════════════════════════════════════════════════════════════════════

/**
 * تولید کد نمایشی برای تراکنش.
 * فرمت: <PREFIX>-<YYYYMMDD شمسی>-<SEQ 5رقمی>
 */
export function generateDisplayCode(
  date: ISODate,
  sequence: number,
  devicePrefix: string,
  kind: 'deposit' | 'expense'
): DisplayCode {
  const compact = toJalaliCompact(date);
  const prefix = kind === 'deposit' ? 'DEP' : 'EXP';
  const seq = String(sequence).padStart(5, '0');
  return `${prefix}-${compact}-${seq}-${devicePrefix}`;
}

/**
 * تولید پیشوند دستگاه — ۳ کاراکتر از hash.
 */
export function generateDevicePrefix(seed: string): string {
  let hash = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    hash ^= seed.charCodeAt(i);
    hash = Math.imul(hash, 16777619);
  }
  const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let prefix = '';
  let n = hash >>> 0;
  for (let i = 0; i < 3; i++) {
    prefix += alphabet[n % alphabet.length];
    n = Math.floor(n / alphabet.length);
  }
  return prefix;
}

// ═══════════════════════════════════════════════════════════════════════════
// Search key
// ═══════════════════════════════════════════════════════════════════════════

/**
 * ساخت کلید جستجوی نرمال‌شده از چند بخش.
 */
export function buildSearchKey(
  ...parts: Array<string | null | undefined>
): string {
  const joined = parts
    .filter((p): p is string => typeof p === 'string' && p.length > 0)
    .join(' ');
  return normalizePersianText(joined);
}

// ═══════════════════════════════════════════════════════════════════════════
// Time helpers
// ═══════════════════════════════════════════════════════════════════════════

/**
 * اعتبارسنجی ساعت `HH:MM`.
 */
export function isValidClockTime(value: string): boolean {
  return /^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(value);
}

/**
 * نرمالایز ساعت — از ارقام فارسی به انگلیسی.
 */
export function normalizeClockTime(input: string): ClockTime | null {
  const cleaned = normalizeDigits(input).trim();
  if (!isValidClockTime(cleaned)) return null;
  return cleaned;
}

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════