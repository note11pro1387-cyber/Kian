// src/performance.ts

import { PerformanceTier } from './types';
import type { ISOTimestamp } from './types';
import { settingsRepo, SETTINGS_KEYS } from './db';
import { nowISO } from './formatters';

// ─── Constants ─────────────────────────────────────────────────────────

const TIER_ORDER: readonly PerformanceTier[] = [
  PerformanceTier.P0,
  PerformanceTier.P1,
  PerformanceTier.P2,
  PerformanceTier.P3,
  PerformanceTier.P4,
];

const DEFAULT_TIER: PerformanceTier = PerformanceTier.P0;
const REDUCED_MOTION_FLOOR: PerformanceTier = PerformanceTier.P2;

const EVAL_INTERVAL_MS = 1_000;
const SECTION_STRIKE_WINDOW_MS = 10_000;
const GLOBAL_SECTIONS_WINDOW_MS = 30_000;
const GLOBAL_SECTIONS_THRESHOLD = 2;

const DOWNGRADE_COOLDOWN_MS = 1_000;
const RECOVERY_BASE_MS = 10_000;
const RECOVERY_MAX_MS = 120_000;
const RECOVERY_MULTIPLIER = 2;

const LONG_TASK_MICRO_MS = 50;
const LONG_TASK_MODERATE_MS = 100;
const LONG_TASK_SEVERE_MS = 200;

const FRAME_SAMPLE_WINDOW = 60;
const FRAME_P95_MODERATE_MS = 28;
const FRAME_P95_SEVERE_MS = 45;
const FRAME_SAMPLE_MIN_COUNT = 20;

const STRIKE_TTL_MS = 60_000;
const MAX_STRIKES_PER_SECTION = 100;

const PERSIST_DEBOUNCE_MS = 800;
const BOOT_SUPPRESSION_MS = 2_000;

// ─── Types ─────────────────────────────────────────────────────────────

export type Severity = 'micro' | 'moderate' | 'severe' | 'sustained';
export type StrikeSource = 'longtask' | 'frame' | 'manual';

interface StrikeEvent {
  at: number;
  severity: Severity;
  durationMs: number;
  source: StrikeSource;
}

interface SectionRecord {
  id: string;
  element: Element | null;
  tier: PerformanceTier;
  activeWindows: number;
  strikes: StrikeEvent[];
  lastDowngradeAt: number;
  lastUpgradeAt: number;
  recoveryWindowMs: number;
  stableSince: number;
  locked: boolean;
}

export interface DiagnosticsSection {
  id: string;
  tier: PerformanceTier;
  activeWindows: number;
  recentStrikes: number;
  locked: boolean;
}

export interface Diagnostics {
  globalTier: PerformanceTier;
  effectiveTier: PerformanceTier;
  prefersReducedMotion: boolean;
  prefersReducedTransparency: boolean;
  observerSupported: boolean;
  frameSamplerRunning: boolean;
  isBackgrounded: boolean;
  sectionCount: number;
  activeSectionCount: number;
  recentGlobalStrikes: number;
  sections: DiagnosticsSection[];
  startedAt: ISOTimestamp | null;
  lastDowngradeAt: number | null;
}

export interface PerformanceEngineOptions {
  eagerStart?: boolean;
  persistTier?: boolean;
}

// ─── Tier math ─────────────────────────────────────────────────────────

function tierIdx(t: PerformanceTier): number {
  const i = TIER_ORDER.indexOf(t);
  return i < 0 ? 0 : i;
}

function tierFromIdx(i: number): PerformanceTier {
  const clamped = Math.max(0, Math.min(TIER_ORDER.length - 1, i));
  return TIER_ORDER[clamped]!;
}

function degrade(t: PerformanceTier, steps = 1): PerformanceTier {
  return tierFromIdx(tierIdx(t) + steps);
}

function upgrade(t: PerformanceTier, steps = 1): PerformanceTier {
  return tierFromIdx(tierIdx(t) - steps);
}

function worseTier(a: PerformanceTier, b: PerformanceTier): PerformanceTier {
  return tierIdx(a) >= tierIdx(b) ? a : b;
}

function severityFromDuration(ms: number): Severity {
  if (ms >= LONG_TASK_SEVERE_MS) return 'severe';
  if (ms >= LONG_TASK_MODERATE_MS) return 'moderate';
  return 'micro';
}

// ─── Environment ───────────────────────────────────────────────────────

function hasDocument(): boolean {
  return typeof document !== 'undefined';
}

function hasWindow(): boolean {
  return typeof window !== 'undefined';
}

function hasRaf(): boolean {
  return hasWindow() && typeof window.requestAnimationFrame === 'function';
}

function hasPerformanceObserver(): boolean {
  if (!hasWindow()) return false;
  return typeof (window as { PerformanceObserver?: unknown }).PerformanceObserver === 'function';
}

function supportsLongTaskObserver(): boolean {
  if (!hasPerformanceObserver()) return false;
  try {
    const PerfObserver = (window as { PerformanceObserver: typeof PerformanceObserver }).PerformanceObserver;
    const supported = PerfObserver.supportedEntryTypes;
    return Array.isArray(supported) && supported.indexOf('longtask') !== -1;
  } catch {
    return false;
  }
}

function matchReducedMotion(): boolean {
  if (!hasWindow() || typeof window.matchMedia !== 'function') return false;
  try {
    return window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  } catch {
    return false;
  }
}

function matchReducedTransparency(): boolean {
  if (!hasWindow() || typeof window.matchMedia !== 'function') return false;
  try {
    return window.matchMedia('(prefers-reduced-transparency: reduce)').matches;
  } catch {
    return false;
  }
}

function requestFrame(cb: (t: number) => void): number {
  if (!hasRaf()) return 0;
  return window.requestAnimationFrame(cb);
}

function cancelFrame(id: number): void {
  if (!hasWindow() || typeof window.cancelAnimationFrame !== 'function') return;
  window.cancelAnimationFrame(id);
}

// ─── Frame sampler ─────────────────────────────────────────────────────

class FrameSampler {
  private running = false;
  private rafId = 0;
  private lastFrameTime = 0;
  private deltas: number[] = [];
  private readonly onResult: (p95: number, sampleCount: number) => void;

  constructor(onResult: (p95: number, sampleCount: number) => void) {
    this.onResult = onResult;
  }

  start(): void {
    if (this.running || !hasRaf()) return;
    this.running = true;
    this.lastFrameTime = 0;
    this.deltas = [];
    this.rafId = requestFrame(this.tick);
  }

  stop(): void {
    if (!this.running) return;
    this.running = false;
    if (this.rafId) {
      cancelFrame(this.rafId);
      this.rafId = 0;
    }
    this.deltas = [];
  }

  isRunning(): boolean {
    return this.running;
  }

  reset(): void {
    this.deltas = [];
    this.lastFrameTime = 0;
  }

  private tick = (now: number): void => {
    if (!this.running) return;

    if (this.lastFrameTime > 0) {
      const delta = now - this.lastFrameTime;
      if (delta > 0 && delta < 500) {
        this.deltas.push(delta);
        if (this.deltas.length > FRAME_SAMPLE_WINDOW) {
          this.deltas.shift();
        }
      }
    }
    this.lastFrameTime = now;

    if (this.deltas.length >= FRAME_SAMPLE_MIN_COUNT) {
      const p95 = this.computeP95();
      this.onResult(p95, this.deltas.length);
      if (this.deltas.length >= FRAME_SAMPLE_WINDOW) {
        this.deltas = this.deltas.slice(-FRAME_SAMPLE_MIN_COUNT);
      }
    }

    this.rafId = requestFrame(this.tick);
  };

  private computeP95(): number {
    if (this.deltas.length === 0) return 0;
    const sorted = [...this.deltas].sort((a, b) => a - b);
    const idx = Math.min(sorted.length - 1, Math.floor(sorted.length * 0.95));
    return sorted[idx]!;
  }
}

// ─── PerformanceEngine ─────────────────────────────────────────────────

export class PerformanceEngine {
  private globalTier: PerformanceTier = DEFAULT_TIER;
  private readonly sections = new Map<string, SectionRecord>();
  private readonly listeners = new Set<() => void>();

  private observer: PerformanceObserver | null = null;
  private readonly sampler: FrameSampler;

  private evalTimer: ReturnType<typeof setInterval> | null = null;
  private persistTimer: ReturnType<typeof setTimeout> | null = null;

  private prefersReducedMotion = false;
  private prefersReducedTransparency = false;

  private started = false;
  private startedAt: ISOTimestamp | null = null;
  private isBackgrounded = false;

  private recentGlobalStrikes: StrikeEvent[] = [];

  private lastDowngradeAt: number | null = null;
  private suppressObserverStrikes = false;

  private readonly persistTierEnabled: boolean;

  private visibilityHandler: (() => void) | null = null;
  private reducedMotionMq: MediaQueryList | null = null;
  private reducedMotionHandler: ((e: MediaQueryListEvent) => void) | null = null;
  private reducedTransparencyMq: MediaQueryList | null = null;
  private reducedTransparencyHandler: ((e: MediaQueryListEvent) => void) | null = null;

  constructor(options: PerformanceEngineOptions = {}) {
    this.persistTierEnabled = options.persistTier !== false;
    this.sampler = new FrameSampler((p95, count) => this.handleFrameSample(p95, count));
    if (options.eagerStart) {
      void this.start();
    }
  }

  async start(): Promise<void> {
    if (this.started) return;
    this.started = true;
    this.startedAt = nowISO();

    await this.loadPersistedTier();
    this.detectPreferences();
    this.subscribeVisibility();
    this.subscribePreferences();
    this.installObserver();

    this.evalTimer = setInterval(() => this.evaluate(), EVAL_INTERVAL_MS);

    this.applyGlobalToDom();
    this.notify();
  }

  stop(): void {
    if (!this.started) return;
    this.started = false;

    this.uninstallObserver();
    this.sampler.stop();

    if (this.evalTimer !== null) {
      clearInterval(this.evalTimer);
      this.evalTimer = null;
    }

    if (this.persistTimer !== null) {
      clearTimeout(this.persistTimer);
      this.persistTimer = null;
      void this.persistTierNow();
    }

    this.unsubscribeVisibility();
    this.unsubscribePreferences();

    this.startedAt = null;
  }

  isStarted(): boolean {
    return this.started;
  }

  private async loadPersistedTier(): Promise<void> {
    if (!this.persistTierEnabled) return;
    try {
      const stored = await settingsRepo.get(SETTINGS_KEYS.PERFORMANCE_TIER);
      if (!stored) return;
      if (!TIER_ORDER.includes(stored as PerformanceTier)) return;
      this.globalTier = stored as PerformanceTier;
      this.suppressObserverStrikes = true;
      setTimeout(() => {
        this.suppressObserverStrikes = false;
      }, BOOT_SUPPRESSION_MS);
    } catch {
      // silent
    }
  }

  private schedulePersistTier(): void {
    if (!this.persistTierEnabled) return;
    if (this.persistTimer !== null) clearTimeout(this.persistTimer);
    this.persistTimer = setTimeout(() => {
      this.persistTimer = null;
      void this.persistTierNow();
    }, PERSIST_DEBOUNCE_MS);
  }

  private async persistTierNow(): Promise<void> {
    if (!this.persistTierEnabled) return;
    try {
      await settingsRepo.set(SETTINGS_KEYS.PERFORMANCE_TIER, this.globalTier);
    } catch {
      // silent
    }
  }

  private detectPreferences(): void {
    this.prefersReducedMotion = matchReducedMotion();
    this.prefersReducedTransparency = matchReducedTransparency();
  }

  private subscribePreferences(): void {
    if (!hasWindow() || typeof window.matchMedia !== 'function') return;

    try {
      this.reducedMotionMq = window.matchMedia('(prefers-reduced-motion: reduce)');
      this.reducedMotionHandler = (e) => {
        this.prefersReducedMotion = e.matches;
        this.applyGlobalToDom();
        this.notify();
      };
      this.reducedMotionMq.addEventListener('change', this.reducedMotionHandler);
    } catch {
      // silent
    }

    try {
      this.reducedTransparencyMq = window.matchMedia('(prefers-reduced-transparency: reduce)');
      this.reducedTransparencyHandler = (e) => {
        this.prefersReducedTransparency = e.matches;
        this.applyGlobalToDom();
        this.notify();
      };
      this.reducedTransparencyMq.addEventListener('change', this.reducedTransparencyHandler);
    } catch {
      // silent
    }
  }

  private unsubscribePreferences(): void {
    if (this.reducedMotionMq && this.reducedMotionHandler) {
      try {
        this.reducedMotionMq.removeEventListener('change', this.reducedMotionHandler);
      } catch {
        // silent
      }
    }
    this.reducedMotionMq = null;
    this.reducedMotionHandler = null;

    if (this.reducedTransparencyMq && this.reducedTransparencyHandler) {
      try {
        this.reducedTransparencyMq.removeEventListener('change', this.reducedTransparencyHandler);
      } catch {
        // silent
      }
    }
    this.reducedTransparencyMq = null;
    this.reducedTransparencyHandler = null;
  }

  private subscribeVisibility(): void {
    if (!hasDocument()) return;
    this.visibilityHandler = () => {
      const hidden = document.visibilityState === 'hidden';
      this.isBackgrounded = hidden;
      if (hidden) {
        this.sampler.stop();
      } else if (this.activeSectionCount() > 0) {
        this.sampler.start();
      }
      this.notify();
    };
    document.addEventListener('visibilitychange', this.visibilityHandler);
  }

  private unsubscribeVisibility(): void {
    if (!hasDocument() || !this.visibilityHandler) return;
    document.removeEventListener('visibilitychange', this.visibilityHandler);
    this.visibilityHandler = null;
  }

  private installObserver(): void {
    if (!supportsLongTaskObserver()) return;

    try {
      const PerfObserver = (window as { PerformanceObserver: typeof PerformanceObserver }).PerformanceObserver;
      this.observer = new PerfObserver((list) => {
        this.handleLongTasks(list.getEntries());
      });
      this.observer.observe({ entryTypes: ['longtask'] });
    } catch {
      this.observer = null;
    }
  }

  private uninstallObserver(): void {
    if (!this.observer) return;
    try {
      this.observer.disconnect();
    } catch {
      // silent
    }
    this.observer = null;
  }

  private handleLongTasks(entries: readonly PerformanceEntry[]): void {
    if (!this.started || this.suppressObserverStrikes) return;

    for (const entry of entries) {
      const duration = entry.duration;
      if (duration < LONG_TASK_MICRO_MS) continue;
      this.recordStrike(null, duration, 'longtask');
    }
  }

  private handleFrameSample(p95: number, sampleCount: number): void {
    if (!this.started || sampleCount < FRAME_SAMPLE_MIN_COUNT) return;

    if (p95 >= FRAME_P95_SEVERE_MS) {
      this.recordStrike(null, p95, 'frame');
      return;
    }
    if (p95 >= FRAME_P95_MODERATE_MS) {
      this.recordStrike(null, p95, 'frame');
    }
  }

  private recordStrike(
    sectionId: string | null,
    durationMs: number,
    source: StrikeSource
  ): void {
    const severity = severityFromDuration(durationMs);
    const now = Date.now();

    const strike: StrikeEvent = { at: now, severity, durationMs, source };

    if (sectionId && this.sections.has(sectionId)) {
      const section = this.sections.get(sectionId)!;
      section.strikes.push(strike);
      this.pruneStrikes(section);
      this.evaluateSection(section);
      return;
    }

    const active = this.activeSections();
    if (active.length > 0) {
      for (const section of active) {
        section.strikes.push(strike);
        this.pruneStrikes(section);
        this.evaluateSection(section);
      }
      return;
    }

    this.recentGlobalStrikes.push(strike);
    this.pruneGlobalStrikes();
    this.evaluateGlobal();
  }

  reportJank(sectionId: string | null, durationMs: number): void {
    this.recordStrike(sectionId, durationMs, 'manual');
  }

  private pruneStrikes(section: SectionRecord): void {
    const cutoff = Date.now() - STRIKE_TTL_MS;
    section.strikes = section.strikes.filter((s) => s.at >= cutoff);
    if (section.strikes.length > MAX_STRIKES_PER_SECTION) {
      section.strikes = section.strikes.slice(-MAX_STRIKES_PER_SECTION);
    }
  }

  private pruneGlobalStrikes(): void {
    const cutoff = Date.now() - STRIKE_TTL_MS;
    this.recentGlobalStrikes = this.recentGlobalStrikes.filter((s) => s.at >= cutoff);
  }

  registerSection(id: string, element: Element | null = null): void {
    if (this.sections.has(id)) {
      const existing = this.sections.get(id)!;
      if (element && existing.element !== element) {
        existing.element = element;
        this.applySectionToDom(existing);
      }
      return;
    }

    const now = Date.now();
    const section: SectionRecord = {
      id,
      element,
      tier: this.globalTier,
      activeWindows: 0,
      strikes: [],
      lastDowngradeAt: 0,
      lastUpgradeAt: now,
      recoveryWindowMs: RECOVERY_BASE_MS,
      stableSince: now,
      locked: false,
    };

    this.sections.set(id, section);
    this.applySectionToDom(section);
    this.notify();
  }

  unregisterSection(id: string): void {
    const section = this.sections.get(id);
    if (!section) return;
    if (section.element) {
      try {
        section.element.removeAttribute('data-perf-tier');
      } catch {
        // silent
      }
    }
    this.sections.delete(id);
    if (this.activeSectionCount() === 0) {
      this.sampler.stop();
    }
    this.notify();
  }

  beginActiveWindow(id: string): void {
    const section = this.sections.get(id);
    if (!section) return;

    section.activeWindows += 1;
    this.applyGlobalToDom();

    if (!this.isBackgrounded && !this.sampler.isRunning()) {
      this.sampler.start();
    }

    this.notify();
  }

  endActiveWindow(id: string): void {
    const section = this.sections.get(id);
    if (!section) return;
    section.activeWindows = Math.max(0, section.activeWindows - 1);

    if (this.activeSectionCount() === 0) {
      this.sampler.stop();
      this.sampler.reset();
    }

    this.notify();
  }

  private activeSections(): SectionRecord[] {
    const out: SectionRecord[] = [];
    for (const section of this.sections.values()) {
      if (section.activeWindows > 0) out.push(section);
    }
    return out;
  }

  private activeSectionCount(): number {
    let count = 0;
    for (const section of this.sections.values()) {
      if (section.activeWindows > 0) count++;
    }
    return count;
  }

  private evaluate(): void {
    if (!this.started) return;

    for (const section of this.sections.values()) {
      this.pruneStrikes(section);
      this.evaluateSection(section);
    }

    this.pruneGlobalStrikes();
    this.evaluateGlobal();
  }

  private evaluateSection(section: SectionRecord): void {
    if (section.locked || this.isBackgrounded) return;

    const now = Date.now();
    const recentSevere = section.strikes.filter(
      (s) =>
        s.at >= now - SECTION_STRIKE_WINDOW_MS &&
        (s.severity === 'severe' || s.severity === 'sustained')
    );

    const recentModerateOrWorse = section.strikes.filter(
      (s) => s.at >= now - SECTION_STRIKE_WINDOW_MS && s.severity !== 'micro'
    );

    const shouldDowngrade =
      recentSevere.length >= 1 || recentModerateOrWorse.length >= 3;

    if (shouldDowngrade) {
      if (now - section.lastDowngradeAt < DOWNGRADE_COOLDOWN_MS) return;

      const nextTier = degrade(section.tier, 1);
      if (nextTier === section.tier) {
        section.locked = true;
        this.notify();
        return;
      }

      section.tier = nextTier;
      section.lastDowngradeAt = now;
      section.stableSince = now;
      section.recoveryWindowMs = RECOVERY_BASE_MS;

      if (nextTier === PerformanceTier.P4) {
        section.locked = true;
      }

      this.applySectionToDom(section);
      this.notify();
      return;
    }

    if (section.tier === PerformanceTier.P0) return;
    if (now - section.stableSince < section.recoveryWindowMs) return;
    if (now - section.lastUpgradeAt < RECOVERY_BASE_MS) return;

    const upgraded = upgrade(section.tier, 1);
    section.tier = upgraded;
    section.lastUpgradeAt = now;
    section.stableSince = now;
    section.recoveryWindowMs = Math.min(
      RECOVERY_MAX_MS,
      section.recoveryWindowMs * RECOVERY_MULTIPLIER
    );

    this.applySectionToDom(section);
    this.notify();
  }

  private evaluateGlobal(): void {
    if (this.isBackgrounded) return;

    const now = Date.now();

    const recentSevere = this.recentGlobalStrikes.filter(
      (s) =>
        s.at >= now - SECTION_STRIKE_WINDOW_MS &&
        (s.severity === 'severe' || s.severity === 'sustained')
    );

    const shouldDowngradeFromGlobal =
      recentSevere.length >= 2 ||
      this.recentGlobalStrikes.filter(
        (s) => s.severity !== 'micro' && s.at >= now - SECTION_STRIKE_WINDOW_MS
      ).length >= 5;

    const distinctStruckSections = this.countRecentlyStruckSections(now);
    const shouldDowngradeFromSections = distinctStruckSections >= GLOBAL_SECTIONS_THRESHOLD;

    if (!shouldDowngradeFromGlobal && !shouldDowngradeFromSections) return;

    if (
      this.lastDowngradeAt !== null &&
      now - this.lastDowngradeAt < DOWNGRADE_COOLDOWN_MS
    ) {
      return;
    }

    const nextTier = degrade(this.globalTier, 1);
    if (nextTier === this.globalTier) return;

    this.globalTier = nextTier;
    this.lastDowngradeAt = now;

    for (const section of this.sections.values()) {
      section.tier = nextTier;
      section.stableSince = now;
      section.lastUpgradeAt = now;
      section.recoveryWindowMs = RECOVERY_BASE_MS;
      section.strikes = [];
      section.locked = nextTier === PerformanceTier.P4;
      this.applySectionToDom(section);
    }

    this.recentGlobalStrikes = [];

    this.applyGlobalToDom();
    this.schedulePersistTier();
    this.notify();
  }

  private countRecentlyStruckSections(now: number): number {
    let count = 0;
    for (const section of this.sections.values()) {
      const hasRecent = section.strikes.some(
        (s) => s.at >= now - GLOBAL_SECTIONS_WINDOW_MS && s.severity !== 'micro'
      );
      if (hasRecent) count++;
    }
    return count;
  }

  private applyGlobalToDom(): void {
    if (!hasDocument()) return;
    try {
      const root = document.documentElement;
      const effective = this.getEffectiveTier();
      root.setAttribute('data-perf-tier', effective);
      root.setAttribute('data-perf-motion', this.prefersReducedMotion ? 'reduced' : 'normal');
      root.setAttribute('data-perf-transparency', this.prefersReducedTransparency ? 'reduced' : 'normal');
    } catch {
      // silent
    }
  }

  private applySectionToDom(section: SectionRecord): void {
    if (!section.element) return;
    try {
      section.element.setAttribute('data-perf-tier', section.tier);
    } catch {
      // silent
    }
  }

  getGlobalTier(): PerformanceTier {
    return this.globalTier;
  }

  getEffectiveTier(): PerformanceTier {
    let tier = this.globalTier;
    if (this.prefersReducedMotion) tier = worseTier(tier, REDUCED_MOTION_FLOOR);
    if (this.prefersReducedTransparency) tier = worseTier(tier, REDUCED_MOTION_FLOOR);
    return tier;
  }

  getSectionTier(id: string): PerformanceTier {
    const section = this.sections.get(id);
    return section ? section.tier : this.getEffectiveTier();
  }

  isReducedMotion(): boolean {
    return this.prefersReducedMotion;
  }

  isReducedTransparency(): boolean {
    return this.prefersReducedTransparency;
  }

  subscribe(listener: () => void): () => void {
    this.listeners.add(listener);
    return () => {
      this.listeners.delete(listener);
    };
  }

  private notify(): void {
    for (const listener of this.listeners) {
      try {
        listener();
      } catch {
        // silent
      }
    }
  }

  async resetProfile(): Promise<void> {
    this.globalTier = DEFAULT_TIER;
    this.recentGlobalStrikes = [];
    this.lastDowngradeAt = null;

    for (const section of this.sections.values()) {
      section.tier = DEFAULT_TIER;
      section.strikes = [];
      section.activeWindows = 0;
      section.recoveryWindowMs = RECOVERY_BASE_MS;
      section.locked = false;
      section.stableSince = Date.now();
      section.lastUpgradeAt = Date.now();
      this.applySectionToDom(section);
    }

    if (this.persistTierEnabled) {
      try {
        await settingsRepo.set(SETTINGS_KEYS.PERFORMANCE_TIER, DEFAULT_TIER);
      } catch {
        // silent
      }
    }

    this.applyGlobalToDom();
    this.notify();
  }

  getDiagnostics(): Diagnostics {
    const now = Date.now();
    const sections: DiagnosticsSection[] = [];

    for (const section of this.sections.values()) {
      const recentStrikes = section.strikes.filter((s) => s.at >= now - STRIKE_TTL_MS).length;
      sections.push({
        id: section.id,
        tier: section.tier,
        activeWindows: section.activeWindows,
        recentStrikes,
        locked: section.locked,
      });
    }

    return {
      globalTier: this.globalTier,
      effectiveTier: this.getEffectiveTier(),
      prefersReducedMotion: this.prefersReducedMotion,
      prefersReducedTransparency: this.prefersReducedTransparency,
      observerSupported: supportsLongTaskObserver(),
      frameSamplerRunning: this.sampler.isRunning(),
      isBackgrounded: this.isBackgrounded,
      sectionCount: this.sections.size,
      activeSectionCount: this.activeSectionCount(),
      recentGlobalStrikes: this.recentGlobalStrikes.length,
      sections,
      startedAt: this.startedAt,
      lastDowngradeAt: this.lastDowngradeAt,
    };
  }
}

// ─── Singleton ─────────────────────────────────────────────────────────

export const performanceEngine = new PerformanceEngine();

export async function startPerformanceEngine(): Promise<void> {
  await performanceEngine.start();
}

export function stopPerformanceEngine(): void {
  performanceEngine.stop();
}

export function getEffectivePerformanceTier(): PerformanceTier {
  return performanceEngine.getEffectiveTier();
}

export function getGlobalPerformanceTier(): PerformanceTier {
  return performanceEngine.getGlobalTier();
}

export function getSectionPerformanceTier(id: string): PerformanceTier {
  return performanceEngine.getSectionTier(id);
}

export function isReducedMotionEnabled(): boolean {
  return performanceEngine.isReducedMotion();
}

export function isReducedTransparencyEnabled(): boolean {
  return performanceEngine.isReducedTransparency();
}

export function subscribePerformance(listener: () => void): () => void {
  return performanceEngine.subscribe(listener);
}

export function registerPerformanceSection(id: string, element?: Element | null): void {
  performanceEngine.registerSection(id, element ?? null);
}

export function unregisterPerformanceSection(id: string): void {
  performanceEngine.unregisterSection(id);
}

export function beginPerformanceWindow(id: string): void {
  performanceEngine.beginActiveWindow(id);
}

export function endPerformanceWindow(id: string): void {
  performanceEngine.endActiveWindow(id);
}

export function getPerformanceDiagnostics(): Diagnostics {
  return performanceEngine.getDiagnostics();
}

export async function resetPerformanceProfile(): Promise<void> {
  await performanceEngine.resetProfile();
}
