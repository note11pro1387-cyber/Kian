// ============================================================================
//  src/types.ts
//  تمام Typeهای پروژه — تنها منبع حقیقت (Single Source of Truth)
// ============================================================================
//
//  این فایل، فونداسیون کل پروژه است. تمام Typeها و Interfaceهایی که در هر
//  فایل دیگر استفاده می‌شوند، اینجا تعریف شده‌اند و هیچ فایل دیگری حق ندارد
//  نوع مشابهی بسازد.
//
//  ── قوانین این فایل ─────────────────────────────────────────────────────
//
//   ۱. هیچ Import داخلی ندارد. تنها وابستگی‌اش زبان TypeScript است.
//   ۲. هیچ Logic اجرایی ندارد. فقط Type، Interface، Const Object.
//   ۳. نام‌گذاری:
//        - Type و Interface: PascalCase
//        - Property: camelCase
//        - کلید const object: UPPER_SNAKE
//   ۴. مقادیر پولی همیشه `Money` (bigint در Runtime، INTEGER در SQLite،
//      String در JSON). هرگز number.
//   ۵. تاریخ‌ها همیشه میلادی در دیتابیس (ISODate = YYYY-MM-DD)، فقط
//      نمایش شمسی در UI.
//   ۶. تمام IDها ULID هستند.
//
//  ── تغییرات این نسخه (SPEC v2.0) ───────────────────────────────────────
//
//   - SecurityProfile: اضافه‌شدن primaryMethod و configuredAt
//   - AuditAction: تطبیق با SPEC v2.0 §۲.۲.۸ (create/edit/delete/restore/
//     import/backup_restore/security_change/export/master_recovery_used)
//     با aliasهای سازگاری برای Phase 3
//   - AlertType: تطبیق با SPEC v2.0 §۲.۲.۱۰
//   - AlertSeverity: تطبیق (info/warning/critical) با alias سازگاری
// ============================================================================

// ============================================================================
//  ۱. PRIMITIVES — نوع‌های پایه
// ============================================================================

/**
 * ULID — شناسه یکتای ۲۶ کاراکتری.
 */
export type ULID = string;

/**
 * تاریخ به فرم ISO 8601 — فقط بخش تاریخ: YYYY-MM-DD (میلادی).
 */
export type ISODate = string;

/**
 * زمان کامل ISO 8601 — برای createdAt، updatedAt، at.
 */
export type ISOTimestamp = string;

/**
 * ساعت روز به فرم ۲۴ ساعته: HH:MM.
 */
export type ClockTime = string;

/**
 * کد نمایشی انسان-خوان برای تراکنش.
 * فرمت: <DEVICE_PREFIX>-<YYYYMMDD>-<SEQUENCE>
 * مثال: D7A-14050615-00089
 */
export type DisplayCode = string;

/**
 * مبلغ به تومان صحیح.
 *
 * - در TypeScript: bigint برای محاسبه
 * - در SQLite: INTEGER
 * - در JSON (backup): String
 * - در نمایش: 35,000,000 تومان (اعداد انگلیسی، همیشه)
 */
export type Money = bigint;

// ============================================================================
//  ۲. IDهای خاص هر Entity
// ============================================================================

export type AccountId = ULID;
export type PartyId = ULID;
export type ProjectId = ULID;
export type CategoryId = ULID;
export type TransactionId = ULID;
export type AttachmentId = ULID;
export type AuditEventId = ULID;
export type ImportJobId = ULID;
export type ImportRecordId = ULID;
export type ImportMappingId = ULID;
export type BackupRecordId = ULID;

// ============================================================================
//  ۳. ENUMS — به‌صورت const object + union type
// ============================================================================

// ── تراکنش ────────────────────────────────────────────────────────────────

export const TransactionType = {
  DEPOSIT: 'deposit',
  EXPENSE: 'expense',
} as const;
export type TransactionType = (typeof TransactionType)[keyof typeof TransactionType];

export const TransactionStatus = {
  ACTIVE: 'active',
  DELETED: 'soft_deleted',
} as const;
export type TransactionStatus =
  (typeof TransactionStatus)[keyof typeof TransactionStatus];

// ── حساب ─────────────────────────────────────────────────────────────────

export const AccountType = {
  BANK: 'bank',
  CASH: 'cash',
  CARD: 'card',
  TREASURY: 'treasury',
} as const;
export type AccountType = (typeof AccountType)[keyof typeof AccountType];

/**
 * وضعیت حساب — طبق SPEC v2.0 §۲.۲.۲
 * STATUS_ACTIVE و STATUS_ARCHIVED canonical هستند.
 */
export const AccountStatus = {
  ACTIVE: 'active',
  ARCHIVED: 'archived',
} as const;
export type AccountStatus = (typeof AccountStatus)[keyof typeof AccountStatus];

// ── شخص / شرکت ───────────────────────────────────────────────────────────

export const PartyType = {
  PERSON: 'person',
  COMPANY: 'company',
} as const;
export type PartyType = (typeof PartyType)[keyof typeof PartyType];

export const PartyRole = {
  CONTRACTOR: 'contractor',
  EMPLOYEE: 'employee',
  CUSTOMER: 'customer',
  SUPPLIER: 'supplier',
  OTHER: 'other',
} as const;
export type PartyRole = (typeof PartyRole)[keyof typeof PartyRole];

/**
 * وضعیت شخص — طبق SPEC v2.0 §۲.۲.۳
 */
export const PartyStatus = {
  ACTIVE: 'active',
  ARCHIVED: 'archived',
} as const;
export type PartyStatus = (typeof PartyStatus)[keyof typeof PartyStatus];

// ── پروژه ────────────────────────────────────────────────────────────────

export const ProjectStatus = {
  ACTIVE: 'active',
  DONE: 'done',
  PAUSED: 'paused',
  ARCHIVED: 'archived',
} as const;
export type ProjectStatus = (typeof ProjectStatus)[keyof typeof ProjectStatus];

// ── دسته‌بندی (بابت) ─────────────────────────────────────────────────────

export const CategoryType = {
  EXPENSE: 'expense',
  INCOME: 'income',
  BOTH: 'both',
} as const;
export type CategoryType = (typeof CategoryType)[keyof typeof CategoryType];

export const CategoryStatus = {
  ACTIVE: 'active',
  ARCHIVED: 'archived',
} as const;
export type CategoryStatus = (typeof CategoryStatus)[keyof typeof CategoryStatus];

// ── Audit ────────────────────────────────────────────────────────────────

/**
 * اقدامات Audit — طبق SPEC v2.0 §۲.۲.۸
 *
 * Aliasهای سازگاری برای Update/Settings/Security/Backup نگه داشته شده‌اند
 * تا کد موجود در Phase 3 بدون شکستن کامپایل، مهاجرت شود. پس از مهاجرت کامل،
 * این Aliasها حذف خواهند شد.
 */
export const AuditAction = {
  // ── Canonical actions (SPEC v2.0) ────────────────────────────────────
  CREATE: 'create',
  EDIT: 'edit',
  DELETE: 'delete',
  RESTORE: 'restore',
  IMPORT: 'import',
  BACKUP_RESTORE: 'backup_restore',
  SECURITY_CHANGE: 'security_change',
  EXPORT: 'export',
  MASTER_RECOVERY_USED: 'master_recovery_used',

  // ── Legacy aliases (mapped to canonical values, will be removed in Phase 3+) ──
  UPDATE: 'edit',
  SETTINGS: 'security_change',
  SECURITY: 'security_change',
  BACKUP: 'backup_restore',
} as const;
export type AuditAction = (typeof AuditAction)[keyof typeof AuditAction];

/**
 * Entity types شناخته‌شده برای Audit — طبق SPEC v2.0 §۲.۲.۸
 */
export const AuditEntityType = {
  TRANSACTION: 'transaction',
  ACCOUNT: 'account',
  PARTY: 'party',
  PROJECT: 'project',
  SECURITY: 'security',
  SYSTEM: 'system',
} as const;
export type AuditEntityType = (typeof AuditEntityType)[keyof typeof AuditEntityType];

// ── Import ───────────────────────────────────────────────────────────────

export const ImportStatus = {
  ANALYZING: 'analyzing',
  PREVIEWING: 'previewing',
  COMMITTED: 'committed',
  CANCELLED: 'cancelled',
  FAILED: 'failed',
} as const;
export type ImportStatus = (typeof ImportStatus)[keyof typeof ImportStatus];

export const ImportDecision = {
  IMPORTED: 'imported',
  SKIPPED: 'skipped',
  UPDATED: 'updated',
  CONFLICT: 'conflict',
  ERROR: 'error',
} as const;
export type ImportDecision = (typeof ImportDecision)[keyof typeof ImportDecision];

// ── تشخیص تکراری ─────────────────────────────────────────────────────────

export const DuplicateLevel = {
  EXACT: 'exact',
  LIKELY: 'likely',
  POSSIBLE: 'possible',
  UNIQUE: 'unique',
} as const;
export type DuplicateLevel = (typeof DuplicateLevel)[keyof typeof DuplicateLevel];

// ── Restore Backup ──────────────────────────────────────────────────────

export const RestoreMode = {
  MERGE: 'merge',
  REPLACE: 'replace',
} as const;
export type RestoreMode = (typeof RestoreMode)[keyof typeof RestoreMode];

export const BackupType = {
  FULL: 'full',
  DATA_EXPORT: 'data_export',
} as const;
export type BackupType = (typeof BackupType)[keyof typeof BackupType];

// ── ظاهر و زبان ──────────────────────────────────────────────────────────

export const Theme = {
  DARK: 'dark',
  LIGHT: 'light',
} as const;
export type Theme = (typeof Theme)[keyof typeof Theme];

export const Language = {
  FA: 'fa',
  EN: 'en',
} as const;
export type Language = (typeof Language)[keyof typeof Language];

// ── Performance ─────────────────────────────────────────────────────────

export const PerformanceTier = {
  P0: 'P0',
  P1: 'P1',
  P2: 'P2',
  P3: 'P3',
  P4: 'P4',
} as const;
export type PerformanceTier = (typeof PerformanceTier)[keyof typeof PerformanceTier];

// ── هشدارها ──────────────────────────────────────────────────────────────

/**
 * نوع هشدار — طبق SPEC v2.0 §۲.۲.۱۰
 *
 * Aliasهای قدیمی برای سازگاری در Phase 3 نگه داشته شده‌اند.
 */
export const AlertType = {
  // ── Canonical values ─────────────────────────────────────────────────
  NEGATIVE_BALANCE: 'negative_balance',
  DUPLICATE_CANDIDATE: 'duplicate_candidate',
  RECONCILIATION_MISMATCH: 'reconciliation_mismatch',
  BACKUP_REMINDER: 'backup_reminder',
  SYNC_CONFLICT: 'sync_conflict',
  INFO: 'info',

  // ── Legacy aliases ───────────────────────────────────────────────────
  DUPLICATE: 'duplicate_candidate',
  RECONCILIATION: 'reconciliation_mismatch',
  BACKUP: 'backup_reminder',
} as const;
export type AlertType = (typeof AlertType)[keyof typeof AlertType];

/**
 * شدت هشدار — طبق SPEC v2.0 §۲.۲.۱۰
 * Canonical: info/warning/critical
 */
export const AlertSeverity = {
  INFO: 'info',
  WARNING: 'warning',
  CRITICAL: 'critical',

  // Legacy alias
  DANGER: 'critical',
} as const;
export type AlertSeverity = (typeof AlertSeverity)[keyof typeof AlertSeverity];

// ── هشدارهای گزارش ──────────────────────────────────────────────────────

export const ReportWarningCode = {
  NO_INCOME: 'no_income',
  NO_EXPENSE: 'no_expense',
  NEGATIVE_BALANCE: 'negative_balance',
  OPENING_BEFORE_RANGE: 'opening_before_range',
  DATA_CHANGED: 'data_changed',
} as const;
export type ReportWarningCode =
  (typeof ReportWarningCode)[keyof typeof ReportWarningCode];

// ── امنیت ────────────────────────────────────────────────────────────────

/**
 * روش اصلی امنیت — طبق SPEC v2.0 §۲.۲.۱۳
 */
export const PrimarySecurityMethod = {
  PIN: 'pin',
  PATTERN: 'pattern',
  BIOMETRIC: 'biometric',
} as const;
export type PrimarySecurityMethod =
  (typeof PrimarySecurityMethod)[keyof typeof PrimarySecurityMethod];

// ============================================================================
//  ۴. ENTITIES اصلی
// ============================================================================

// ── Workspace ────────────────────────────────────────────────────────────

export interface Workspace {
  id: ULID;
  name: string;
  createdAt: ISOTimestamp;
}

// ── Account ──────────────────────────────────────────────────────────────

/**
 * حساب مالی — طبق SPEC v2.0 §۲.۲.۲
 *
 * نکته‌ی معماری: openingBalance در دیتابیس ذخیره می‌شود، ولی balance
 * (موجودی لحظه‌ای) هرگز ذخیره نمی‌شود.
 */
export interface Account {
  id: AccountId;
  workspaceId: ULID;
  name: string;
  type: AccountType;
  bankName: string | null;
  accountNumber: string | null;
  cardNumber: string | null;
  description: string | null;
  openingBalance: Money;
  openingBalanceDate: ISODate;
  status: AccountStatus;
  sortOrder: number;
  createdAt: ISOTimestamp;
  updatedAt: ISOTimestamp;
  createdBy: string | null;
  updatedBy: string | null;
}

// ── Party ────────────────────────────────────────────────────────────────

export interface Party {
  id: PartyId;
  workspaceId: ULID;
  name: string;
  /** نام نرمالایز‌شده برای جستجو */
  normalizedName: string;
  type: PartyType;
  phone: string | null;
  cardNumber: string | null;
  accountNumber: string | null;
  role: PartyRole | null;
  notes: string | null;
  status: PartyStatus;
  createdAt: ISOTimestamp;
  updatedAt: ISOTimestamp;
}

// ── Project ──────────────────────────────────────────────────────────────

export interface Project {
  id: ProjectId;
  workspaceId: ULID;
  name: string;
  code: string | null;
  status: ProjectStatus;
  /** بودجه‌ی اختیاری. اگر null، پروژه بدون سقف بودجه است */
  budgetAmount: Money | null;
  description: string | null;
  createdAt: ISOTimestamp;
  updatedAt: ISOTimestamp;
}

// ── Category (بابت) ──────────────────────────────────────────────────────

export interface Category {
  id: CategoryId;
  /** null برای دسته‌های سطح اول */
  parentId: CategoryId | null;
  name: string;
  type: CategoryType;
  isCustom: boolean;
  sortOrder: number;
  status: CategoryStatus;
}

// ── Transaction ──────────────────────────────────────────────────────────

export interface Transaction {
  id: TransactionId;
  workspaceId: ULID;
  displayCode: DisplayCode;
  type: TransactionType;
  amount: Money;
  accountId: AccountId;
  /** برای expense اجباری، برای deposit اختیاری */
  partyId: PartyId | null;
  categoryId: CategoryId | null;
  /** اگر کاربر «سایر» را انتخاب و متن دلخواه نوشته */
  customCategoryText: string | null;
  projectId: ProjectId | null;
  transactionDate: ISODate;
  transactionTime: ClockTime | null;
  referenceCode: string | null;
  description: string | null;
  status: TransactionStatus;
  version: number;
  deviceId: string | null;
  createdAt: ISOTimestamp;
  updatedAt: ISOTimestamp;
  createdBy: string | null;
  updatedBy: string | null;
  deletedAt: ISOTimestamp | null;
}

// ── Attachment ───────────────────────────────────────────────────────────

export interface Attachment {
  id: AttachmentId;
  transactionId: TransactionId;
  type: string;
  fileName: string;
  storageKey: string;
  thumbnailKey: string | null;
  mimeType: string;
  sizeBytes: number;
  sha256: string;
  createdAt: ISOTimestamp;
}

// ============================================================================
//  ۵. ENTITIES پشتیبان
// ============================================================================

// ── AuditEvent ───────────────────────────────────────────────────────────

export interface AuditEvent {
  id: AuditEventId;
  workspaceId: ULID;
  entityType: AuditEntityType;
  entityId: ULID | null;
  action: AuditAction;
  beforeJson: string | null;
  afterJson: string | null;
  actorLabel: string | null;
  deviceId: string | null;
  createdAt: ISOTimestamp;
}

// ── ImportJob ────────────────────────────────────────────────────────────

export interface ImportJob {
  id: ImportJobId;
  fileName: string;
  startedAt: ISOTimestamp;
  finishedAt: ISOTimestamp | null;
  status: ImportStatus;
  statsJson: string | null;
}

// ── ImportRecord ─────────────────────────────────────────────────────────

export interface ImportRecord {
  id: ImportRecordId;
  jobId: ImportJobId;
  rowNumber: number;
  rowHash: string;
  decision: ImportDecision;
  matchedTransactionId: TransactionId | null;
  duplicateScore: DuplicateLevel | null;
  errorMessage: string | null;
}

// ── ImportMapping ────────────────────────────────────────────────────────

export interface ImportMapping {
  id: ImportMappingId;
  name: string;
  mappingJson: string;
  createdAt: ISOTimestamp;
}

// ── BackupRecord ─────────────────────────────────────────────────────────

export interface BackupRecord {
  id: BackupRecordId;
  fileName: string;
  type: BackupType;
  sizeBytes: number;
  transactionCount: number;
  schemaVersion: number;
  appVersion: string;
  createdAt: ISOTimestamp;
  checksum: string;
}

// ── Draft ────────────────────────────────────────────────────────────────

export const DraftKey = {
  NEW_TRANSACTION: 'new-transaction',
  NEW_ACCOUNT: 'new-account',
  NEW_PARTY: 'new-party',
  NEW_PROJECT: 'new-project',
} as const;
export type DraftKey = (typeof DraftKey)[keyof typeof DraftKey];

export interface Draft {
  id: DraftKey;
  formType: string;
  formJson: string;
  updatedAt: ISOTimestamp;
}

// ============================================================================
//  ۶. امنیت، تنظیمات، Alert
// ============================================================================

// ── SecurityProfile ──────────────────────────────────────────────────────

/**
 * پروفایل امنیتی — طبق SPEC v2.0 §۲.۲.۱۳
 *
 * تغییرات نسبت به نسخه قبل:
 *   - اضافه: primaryMethod ('pin' | 'pattern' | 'biometric' | null)
 *   - اضافه: configuredAt (زمان اولین تنظیم)
 *   - حذف: createdAt/updatedAt (طبق SPEC v2.0 نیستند)
 */
export interface SecurityProfile {
  id: 'default';
  pinHash: string | null;
  patternHash: string | null;
  biometricEnabled: boolean;
  primaryMethod: PrimarySecurityMethod | null;
  failedAttempts: number;
  lockoutUntil: ISOTimestamp | null;
  recoveryUsedCount: number;
  lockTimeoutSeconds: number;
  configuredAt: ISOTimestamp | null;
}

// ── AppSettings ──────────────────────────────────────────────────────────

export interface AppSetting {
  key: string;
  value: string;
}

// ── Alert ────────────────────────────────────────────────────────────────

/**
 * Alert — طبق SPEC v2.0 §۲.۲.۱۰
 * پیام به‌صورت messageKey ذخیره می‌شود (کلید i18n)، نه متن خام.
 */
export interface AlertItem {
  id: ULID;
  type: AlertType;
  severity: AlertSeverity;
  entityType: AuditEntityType | null;
  entityId: ULID | null;
  messageKey: string;
  messageParams: Record<string, string | number> | null;
  createdAt: ISOTimestamp;
  readAt: ISOTimestamp | null;
  resolvedAt: ISOTimestamp | null;
}

// ── Backup Container ────────────────────────────────────────────────────

export interface BackupHeader {
  magic: 'FINSECURE1';
  formatVersion: number;
  schemaVersion: number;
  appVersion: string;
  createdAt: ISOTimestamp;
  workspaceId: ULID;
  pbkdf2Salt: string;
  aesIv: string;
  checksum: string;
}

export interface BackupPayload {
  workspace: Workspace;
  accounts: Account[];
  parties: Party[];
  projects: Project[];
  categories: Category[];
  transactions: Transaction[];
  auditEvents: AuditEvent[];
  settings: AppSetting[];
  backupRecords: BackupRecord[];
  deviceName: string;
}

// ============================================================================
//  ۷. DOMAIN — ساختارهای محاسباتی و گزارشی
// ============================================================================

export interface BalanceResult {
  accountId: AccountId;
  openingBalance: Money;
  totalInflow: Money;
  totalOutflow: Money;
  balance: Money;
  isNegative: boolean;
  transactionCount: number;
}

export interface PeriodReport {
  start: ISODate;
  end: ISODate;
  openingPosition: Money;
  periodInflow: Money;
  periodOutflow: Money;
  closingPosition: Money;
  netChange: Money;
  transactions: Transaction[];
  byCategory: CategoryBreakdown[];
  byParty: PartyBreakdown[];
  byProject: ProjectBreakdown[];
  byAccount: AccountBreakdown[];
  warnings: ReportWarning[];
  generatedAt: ISOTimestamp;
}

export interface ReportWarning {
  code: ReportWarningCode;
  message: string;
  relatedId: ULID | null;
}

export interface BreakdownBase {
  id: ULID;
  name: string;
  total: Money;
  count: number;
}

export interface CategoryBreakdown extends BreakdownBase {
  id: CategoryId;
}
export interface PartyBreakdown extends BreakdownBase {
  id: PartyId;
}
export interface ProjectBreakdown extends BreakdownBase {
  id: ProjectId;
}
export interface AccountBreakdown extends BreakdownBase {
  id: AccountId;
}

export interface DuplicateScore {
  level: DuplicateLevel;
  score: number;
  matchedTransactionId: TransactionId | null;
  reasons: string[];
}

// ============================================================================
//  ۸. INPUT / COMMAND
// ============================================================================

export interface CreateTransactionInput {
  type: TransactionType;
  amount: Money;
  accountId: AccountId;
  partyId: PartyId | null;
  categoryId: CategoryId | null;
  customCategoryText: string | null;
  projectId: ProjectId | null;
  transactionDate: ISODate;
  transactionTime: ClockTime | null;
  referenceCode: string | null;
  description: string | null;
  createdBy: string | null;
}

export interface UpdateTransactionInput {
  amount?: Money;
  accountId?: AccountId;
  partyId?: PartyId | null;
  categoryId?: CategoryId | null;
  customCategoryText?: string | null;
  projectId?: ProjectId | null;
  transactionDate?: ISODate;
  transactionTime?: ClockTime | null;
  referenceCode?: string | null;
  description?: string | null;
  updatedBy?: string | null;
}

export interface CreateAccountInput {
  name: string;
  type: AccountType;
  bankName: string | null;
  accountNumber: string | null;
  cardNumber: string | null;
  description: string | null;
  openingBalance: Money;
  openingBalanceDate: ISODate | null;
  sortOrder: number;
}

export interface UpdateAccountInput {
  name?: string;
  bankName?: string | null;
  accountNumber?: string | null;
  cardNumber?: string | null;
  description?: string | null;
  openingBalance?: Money;
  openingBalanceDate?: ISODate | null;
  status?: AccountStatus;
  sortOrder?: number;
}

export interface CreatePartyInput {
  name: string;
  type: PartyType;
  phone: string | null;
  cardNumber: string | null;
  accountNumber: string | null;
  role: PartyRole | null;
  notes: string | null;
}

export interface UpdatePartyInput {
  name?: string;
  type?: PartyType;
  phone?: string | null;
  cardNumber?: string | null;
  accountNumber?: string | null;
  role?: PartyRole | null;
  notes?: string | null;
  status?: PartyStatus;
}

export interface CreateProjectInput {
  name: string;
  code: string | null;
  status: ProjectStatus;
  budgetAmount: Money | null;
  description: string | null;
}

export interface UpdateProjectInput {
  name?: string;
  code?: string | null;
  status?: ProjectStatus;
  budgetAmount?: Money | null;
  description?: string | null;
}

export interface CreateCategoryInput {
  parentId: CategoryId | null;
  name: string;
  type: CategoryType;
  sortOrder: number;
}

export interface UpdateCategoryInput {
  name?: string;
  sortOrder?: number;
  status?: CategoryStatus;
}

export interface ImportCommitInput {
  jobId: ImportJobId;
  columnMap: Record<string, string>;
  decisions: Map<number, ImportDecision>;
}

export interface CreateBackupInput {
  passphrase: string;
}

export interface RestoreBackupInput {
  fileContent: ArrayBuffer;
  passphrase: string;
  mode: RestoreMode;
}

// ============================================================================
//  ۹. FILTER
// ============================================================================

export interface TransactionFilter {
  types: TransactionType[];
  accountIds: AccountId[];
  partyIds: PartyId[];
  projectIds: ProjectId[];
  categoryIds: CategoryId[];
  statuses: TransactionStatus[];
  dateFrom: ISODate | null;
  dateTo: ISODate | null;
  amountMin: Money | null;
  amountMax: Money | null;
  searchQuery: string;
}

export interface ReportFilter {
  start: ISODate;
  end: ISODate;
  accountIds: AccountId[];
  partyIds: PartyId[];
  projectIds: ProjectId[];
  categoryIds: CategoryId[];
  types: TransactionType[];
}

// ============================================================================
//  ۱۰. UI STATE
// ============================================================================

export const ToastKind = {
  SUCCESS: 'success',
  ERROR: 'error',
  INFO: 'info',
  WARNING: 'warning',
} as const;
export type ToastKind = (typeof ToastKind)[keyof typeof ToastKind];

export interface ToastMessage {
  id: ULID;
  kind: ToastKind;
  message: string;
  actionLabel?: string | undefined;
  onAction?: (() => void) | undefined;
  durationMs?: number | undefined;
}

export const BootPhase = {
  STARTING: 'starting',
  DATABASE: 'database',
  SECURITY: 'security',
  SETTINGS: 'settings',
  READY: 'ready',
  FAILED: 'failed',
} as const;
export type BootPhase = (typeof BootPhase)[keyof typeof BootPhase];

export interface BootState {
  phase: BootPhase;
  progress: number;
  error: string | null;
}

export const LockState = {
  UNLOCKED: 'unlocked',
  LOCKED: 'locked',
  RECOVERY: 'recovery',
} as const;
export type LockState = (typeof LockState)[keyof typeof LockState];

// ============================================================================
//  ۱۱. RESULT TYPES
// ============================================================================

export interface Ok<T> {
  ok: true;
  value: T;
}

export interface Err {
  ok: false;
  code: string;
  message: string;
  detail?: unknown;
}

export type Result<T> = Ok<T> | Err;

export interface VerifyResult {
  success: boolean;
  remainingAttempts: number;
  lockedUntil: ISOTimestamp | null;
}

export interface RecoveryResult {
  success: boolean;
  mustReset: boolean;
  message: string;
}

export interface RestoreResult {
  success: boolean;
  mode: RestoreMode;
  counts: {
    imported: number;
    skipped: number;
    conflicts: number;
  };
  message: string;
}

// ============================================================================
//  پایان فایل
// ============================================================================
