import sqlite3InitModule from '@sqlite.org/sqlite-wasm';

const WEB_DB_FILE = '/finsecure.sqlite3';
const VFS_NAME = 'finsecure-opfs-sahpool';

interface SQLiteDatabase {
  exec(
    arg:
      | string
      | {
          sql: string;
          bind?: unknown[];
          rowMode?: string;
          callback?: (row: unknown) => void;
        }
  ): unknown;
  close(): void;
}

interface SQLiteModule {
  installOpfsSAHPoolVfs(options?: {
    name?: string;
    directory?: string;
    initialCapacity?: number;
  }): Promise<{
    OpfsSAHPoolDb: new (filename: string) => SQLiteDatabase;
  }>;
}

type WorkerRequest =
  | { requestId: number; type: 'open' }
  | { requestId: number; type: 'exec'; sql: string; params: unknown[] }
  | { requestId: number; type: 'query'; sql: string; params: unknown[] }
  | { requestId: number; type: 'close' };

interface WorkerSuccess {
  requestId: number;
  ok: true;
  result?: unknown;
}

interface WorkerFailure {
  requestId: number;
  ok: false;
  error: {
    name?: string;
    message: string;
    stack?: string;
  };
}

type WorkerResponse = WorkerSuccess | WorkerFailure;

let sqliteDb: SQLiteDatabase | null = null;
let poolUtil: Awaited<ReturnType<SQLiteModule['installOpfsSAHPoolVfs']>> | null = null;
let initialization: Promise<void> | null = null;

function serializeError(error: unknown): WorkerFailure['error'] {
  if (error instanceof Error) {
    const serialized: WorkerFailure['error'] = {
      name: error.name,
      message: error.message,
    };
    if (error.stack !== undefined) {
      serialized.stack = error.stack;
    }
    return serialized;
  }

  return {
    name: 'SQLiteWorkerError',
    message: typeof error === 'string' ? error : String(error),
  };
}

async function ensureOpen(): Promise<void> {
  if (sqliteDb) return;
  if (initialization) return initialization;

  initialization = (async () => {
    const sqlite3 = (await sqlite3InitModule()) as unknown as SQLiteModule;

    if (typeof sqlite3.installOpfsSAHPoolVfs !== 'function') {
      throw new Error(
        'Persistent OPFS storage is unavailable in this SQLite Wasm build.'
      );
    }

    if (!poolUtil) {
      poolUtil = await sqlite3.installOpfsSAHPoolVfs({
        name: VFS_NAME,
        initialCapacity: 6,
      });
    }

    const Database = poolUtil?.OpfsSAHPoolDb;
    if (typeof Database !== 'function') {
      throw new Error('OPFS SyncAccessHandle pool VFS failed to initialize.');
    }

    sqliteDb = new Database(WEB_DB_FILE);
    sqliteDb.exec('PRAGMA foreign_keys = ON');
  })().finally(() => {
    initialization = null;
  });

  try {
    await initialization;
  } catch (error) {
    sqliteDb = null;
    throw error;
  }
}

function getDatabase(): SQLiteDatabase {
  if (!sqliteDb) throw new Error('SQLite worker database is not open.');
  return sqliteDb;
}

const workerScope = globalThis as unknown as {
  addEventListener(
    type: 'message',
    listener: (event: MessageEvent<WorkerRequest>) => void | Promise<void>
  ): void;
  postMessage(message: WorkerResponse): void;
};

workerScope.addEventListener('message', async (event) => {
  const request = event.data;

  try {
    switch (request.type) {
      case 'open': {
        await ensureOpen();
        workerScope.postMessage({
          requestId: request.requestId,
          ok: true,
        });
        return;
      }

      case 'exec': {
        const db = getDatabase();
        if (request.params.length === 0) {
          db.exec(request.sql);
        } else {
          db.exec({
            sql: request.sql,
            bind: [...request.params],
          });
        }

        workerScope.postMessage({
          requestId: request.requestId,
          ok: true,
        });
        return;
      }

      case 'query': {
        const db = getDatabase();
        const rows: unknown[] = [];
        db.exec({
          sql: request.sql,
          bind: [...request.params],
          rowMode: 'object',
          callback: (row) => {
            rows.push(row);
          },
        });

        workerScope.postMessage({
          requestId: request.requestId,
          ok: true,
          result: rows,
        });
        return;
      }

      case 'close': {
        try {
          sqliteDb?.close();
        } finally {
          sqliteDb = null;
        }

        workerScope.postMessage({
          requestId: request.requestId,
          ok: true,
        });
        return;
      }
    }
  } catch (error) {
    workerScope.postMessage({
      requestId: request.requestId,
      ok: false,
      error: serializeError(error),
    });
  }
});
