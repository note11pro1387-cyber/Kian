// src/backup.ts

import { AuditEntityType, BackupType } from './types';
import type {
  Account,
  AppSetting,
  AuditEvent,
  BackupHeader,
  BackupRecord,
  Category,
  ISOTimestamp,
  Party,
  Project,
  Result,
  RestoreMode,
  RestoreResult,
  Transaction,
  Workspace,
} from './types';

import {
  getDatabase,
  accountRepo,
  auditRepo,
  backupRepo,
  categoryRepo,
  getWorkspaceId,
  partyRepo,
  projectRepo,
  settingsRepo,
  transactionRepo,
  workspaceRepo,
  dbUtils,
  SETTINGS_KEYS,
} from './db';

import { nowISO } from './formatters';

// ═══════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════

export const BACKUP_MAGIC = 'FINSECURE1';
export const BACKUP_FORMAT_VERSION = 1;
export const BACKUP_SCHEMA_VERSION = 2;
export const BACKUP_APP_VERSION = '1.0.0';

const PBKDF2_ITERATIONS = 100_000;
const PBKDF2_SALT_BYTES = 16;
const AES_IV_BYTES = 12;
const AES_KEY_BITS = 256;

const MIN_PASSPHRASE_LENGTH = 8;
const MAX_PASSPHRASE_LENGTH = 200;

// ═══════════════════════════════════════════════════════════════════════════
// Encoding helpers
// ═══════════════════════════════════════════════════════════════════════════

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  const chunk = 8192;
  for (let i = 0; i < bytes.length; i += chunk) {
    const slice = bytes.subarray(i, i + chunk);
    binary += String.fromCharCode.apply(null, Array.from(slice) as unknown as number[]);
  }
  if (typeof btoa === 'function') return btoa(binary);
  return Buffer.from(bytes).toString('base64');
}

function base64ToBytes(b64: string): Uint8Array {
  let binary: string;
  if (typeof atob === 'function') {
    binary = atob(b64);
  } else {
    binary = Buffer.from(b64, 'base64').toString('binary');
  }
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

function bytesToHex(bytes: Uint8Array): string {
  let out = '';
  for (let i = 0; i < bytes.length; i++) {
    const h = bytes[i]!.toString(16);
    out += h.length === 1 ? '0' + h : h;
  }
  return out;
}

// Fail-Closed secure random. No Math.random fallback.
function randomBytes(n: number): Uint8Array {
  if (!Number.isInteger(n) || n <= 0) {
    throw new Error('Secure random byte length must be a positive integer');
  }

  const cryptoObj = globalThis.crypto;
  if (!cryptoObj || typeof cryptoObj.getRandomValues !== 'function') {
    throw new Error(
      'Secure random generator is unavailable. Cannot proceed with security-sensitive operation.'
    );
  }

  const arr = new Uint8Array(n);
  cryptoObj.getRandomValues(arr);
  return arr;
}

function utf8Encode(s: string): Uint8Array {
  if (typeof TextEncoder !== 'undefined') return new TextEncoder().encode(s);
  const out: number[] = [];
  for (let i = 0; i < s.length; i++) {
    const code = s.charCodeAt(i);
    if (code < 0x80) out.push(code);
    else if (code < 0x800) {
      out.push(0xc0 | (code >> 6));
      out.push(0x80 | (code & 0x3f));
    } else {
      out.push(0xe0 | (code >> 12));
      out.push(0x80 | ((code >> 6) & 0x3f));
      out.push(0x80 | (code & 0x3f));
    }
  }
  return new Uint8Array(out);
}

function utf8Decode(bytes: Uint8Array): string {
  if (typeof TextDecoder !== 'undefined') return new TextDecoder().decode(bytes);
  let out = '';
  for (let i = 0; i < bytes.length; ) {
    const c = bytes[i++]!;
    if (c < 0x80) {
      out += String.fromCharCode(c);
    } else if (c < 0xe0) {
      out += String.fromCharCode(((c & 0x1f) << 6) | (bytes[i++]! & 0x3f));
    } else if (c < 0xf0) {
      out += String.fromCharCode(
        ((c & 0x0f) << 12) | ((bytes[i++]! & 0x3f) << 6) | (bytes[i++]! & 0x3f)
      );
    } else {
      const cp =
        ((c & 0x07) << 18) |
        ((bytes[i++]! & 0x3f) << 12) |
        ((bytes[i++]! & 0x3f) << 6) |
        (bytes[i++]! & 0x3f);
      const diff = cp - 0x10000;
      out += String.fromCharCode(0xd800 + (diff >> 10), 0xdc00 + (diff & 0x3ff));
    }
  }
  return out;
}

function concatBytes(...arrays: Uint8Array[]): Uint8Array {
  let total = 0;
  for (const a of arrays) total += a.length;
  const out = new Uint8Array(total);
  let offset = 0;
  for (const a of arrays) {
    out.set(a, offset);
    offset += a.length;
  }
  return out;
}

// ═══════════════════════════════════════════════════════════════════════════
// Crypto: PBKDF2 + AES-GCM
// ═══════════════════════════════════════════════════════════════════════════

async function deriveKey(passphrase: string, salt: Uint8Array): Promise<CryptoKey> {
  const cryptoObj = (globalThis as { crypto?: Crypto }).crypto;
  if (!cryptoObj || !cryptoObj.subtle) {
    throw new Error('Web Crypto API در دسترس نیست');
  }

  const passphraseBytes = utf8Encode(passphrase);
  const passphraseBuffer = new ArrayBuffer(passphraseBytes.byteLength);
  new Uint8Array(passphraseBuffer).set(passphraseBytes);

  const keyMaterial = await cryptoObj.subtle.importKey(
    'raw',
    passphraseBuffer,
    { name: 'PBKDF2' },
    false,
    ['deriveKey']
  );

  const saltBuffer = new Uint8Array(salt).buffer;

  return cryptoObj.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: saltBuffer,
      iterations: PBKDF2_ITERATIONS,
      hash: 'SHA-256',
    },
    keyMaterial,
    { name: 'AES-GCM', length: AES_KEY_BITS },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encryptPayload(
  payload: Uint8Array,
  passphrase: string
): Promise<{ ciphertext: Uint8Array; salt: Uint8Array; iv: Uint8Array }> {
  const cryptoObj = (globalThis as { crypto?: Crypto }).crypto;
  if (!cryptoObj || !cryptoObj.subtle) {
    throw new Error('Web Crypto API در دسترس نیست');
  }

  const salt = randomBytes(PBKDF2_SALT_BYTES);
  const iv = randomBytes(AES_IV_BYTES);
  const key = await deriveKey(passphrase, salt);

  const payloadBuffer = new Uint8Array(payload).buffer;
  const ivBuffer = new Uint8Array(iv).buffer;

  const ciphertext = await cryptoObj.subtle.encrypt(
    { name: 'AES-GCM', iv: ivBuffer },
    key,
    payloadBuffer
  );

  return {
    ciphertext: new Uint8Array(ciphertext),
    salt,
    iv,
  };
}

async function decryptPayload(
  ciphertext: Uint8Array,
  salt: Uint8Array,
  iv: Uint8Array,
  passphrase: string
): Promise<Uint8Array> {
  const cryptoObj = (globalThis as { crypto?: Crypto }).crypto;
  if (!cryptoObj || !cryptoObj.subtle) {
    throw new Error('Web Crypto API در دسترس نیست');
  }

  const key = await deriveKey(passphrase, salt);

  const ciphertextBuffer = new Uint8Array(ciphertext).buffer;
  const ivBuffer = new Uint8Array(iv).buffer;

  try {
    const plaintext = await cryptoObj.subtle.decrypt(
      { name: 'AES-GCM', iv: ivBuffer },
      key,
      ciphertextBuffer
    );
    return new Uint8Array(plaintext);
  } catch {
    throw new Error('عبارت عبور نادرست است یا فایل آسیب دیده');
  }
}

async function sha256Hex(bytes: Uint8Array): Promise<string> {
  const cryptoObj = (globalThis as { crypto?: Crypto }).crypto;
  if (!cryptoObj || !cryptoObj.subtle) {
    throw new Error('Web Crypto API در دسترس نیست');
  }
  const buffer = new Uint8Array(bytes).buffer;
  const hash = await cryptoObj.subtle.digest('SHA-256', buffer);
  return bytesToHex(new Uint8Array(hash));
}

// ═══════════════════════════════════════════════════════════════════════════
// Serialization — aligned with current types
// ═══════════════════════════════════════════════════════════════════════════

interface SerializedAccount extends Omit<Account, 'openingBalance'> {
  openingBalance: string;
}

interface SerializedProject extends Omit<Project, 'budgetAmount'> {
  budgetAmount: string | null;
}

interface SerializedTransaction extends Omit<Transaction, 'amount'> {
  amount: string;
}

interface SerializedPayload {
  workspace: Workspace;
  accounts: SerializedAccount[];
  parties: Party[];
  projects: SerializedProject[];
  categories: Category[];
  transactions: SerializedTransaction[];
  auditEvents: AuditEvent[];
  settings: AppSetting[];
  backupRecords: BackupRecord[];
  deviceName: string;
}

function serializeAccount(a: Account): SerializedAccount {
  return { ...a, openingBalance: a.openingBalance.toString() };
}

function serializeProject(p: Project): SerializedProject {
  return {
    ...p,
    budgetAmount: p.budgetAmount === null ? null : p.budgetAmount.toString(),
  };
}

function serializeTransaction(t: Transaction): SerializedTransaction {
  return { ...t, amount: t.amount.toString() };
}

function deserializeAccount(a: SerializedAccount): Account {
  return { ...a, openingBalance: BigInt(a.openingBalance) };
}

function deserializeProject(p: SerializedProject): Project {
  return {
    ...p,
    budgetAmount: p.budgetAmount === null ? null : BigInt(p.budgetAmount),
  };
}

function deserializeTransaction(t: SerializedTransaction): Transaction {
  return { ...t, amount: BigInt(t.amount) };
}

// ═══════════════════════════════════════════════════════════════════════════
// Container format
// ═══════════════════════════════════════════════════════════════════════════

interface BackupContainer {
  header: BackupHeader;
  ciphertext: Uint8Array;
}

function packContainer(header: BackupHeader, ciphertext: Uint8Array): Uint8Array {
  const headerJson = JSON.stringify(header);
  const headerBytes = utf8Encode(headerJson);

  const headerLengthBytes = new Uint8Array(4);
  const len = headerBytes.length;
  headerLengthBytes[0] = (len >>> 24) & 0xff;
  headerLengthBytes[1] = (len >>> 16) & 0xff;
  headerLengthBytes[2] = (len >>> 8) & 0xff;
  headerLengthBytes[3] = len & 0xff;

  return concatBytes(headerLengthBytes, headerBytes, ciphertext);
}

function unpackContainer(bytes: Uint8Array): BackupContainer {
  if (bytes.length < 4) {
    throw new Error('فایل پشتیبان معتبر نیست');
  }

  const len = (bytes[0]! << 24) | (bytes[1]! << 16) | (bytes[2]! << 8) | bytes[3]!;

  if (len <= 0 || len > bytes.length - 4) {
    throw new Error('ساختار فایل پشتیبان معتبر نیست');
  }

  const headerBytes = bytes.subarray(4, 4 + len);
  const ciphertext = bytes.subarray(4 + len);

  let header: BackupHeader;
  try {
    const parsed = JSON.parse(utf8Decode(headerBytes)) as unknown;
    header = parsed as BackupHeader;
  } catch {
    throw new Error('هدر فایل پشتیبان معتبر نیست');
  }

  return { header, ciphertext };
}

function validateHeader(header: BackupHeader): void {
  if (header.magic !== BACKUP_MAGIC) {
    throw new Error('این فایل یک پشتیبان معتبر نیست');
  }
  if (header.formatVersion > BACKUP_FORMAT_VERSION) {
    throw new Error(
      `این فایل با نسخه‌ی جدیدتری از برنامه ساخته شده است (نسخه‌ی فرمت: ${header.formatVersion})`
    );
  }
  if (header.schemaVersion > BACKUP_SCHEMA_VERSION) {
    throw new Error(
      `پایگاه داده‌ی این فایل جدیدتر از نسخه‌ی فعلی برنامه است (نسخه‌ی اسکیما: ${header.schemaVersion})`
    );
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Device name
// ═══════════════════════════════════════════════════════════════════════════

function getDeviceName(): string {
  if (typeof navigator === 'undefined') return 'دستگاه ناشناس';
  const ua = navigator.userAgent ?? '';
  if (/Android/i.test(ua)) return 'Android';
  if (/iPhone|iPad/i.test(ua)) return 'iOS';
  if (/Windows/i.test(ua)) return 'Windows';
  if (/Mac/i.test(ua)) return 'macOS';
  if (/Linux/i.test(ua)) return 'Linux';
  return 'دستگاه ناشناس';
}

// ═══════════════════════════════════════════════════════════════════════════
// Audit helper — uses action='backup_create'/'backup_restore', entity='system'
// ═══════════════════════════════════════════════════════════════════════════

async function writeBackupAuditEvent(
  action: 'backup_create' | 'backup_restore',
  detail: Record<string, unknown> | null
): Promise<void> {
  const conn = getDatabase();
  await conn.transaction(async (tx) => {
    const workspaceId = await getWorkspaceId(tx);
    await tx.execute(
      `INSERT INTO audit_events
        (id, workspace_id, entity_type, entity_id, action,
         before_json, after_json, actor_label, device_id, created_at)
       VALUES (?, ?, ?, NULL, ?, NULL, ?, ?, NULL, ?)`,
      [
        dbUtils.generateULID(),
        workspaceId,
        AuditEntityType.SYSTEM,
        action,
        detail === null ? null : JSON.stringify(detail),
        'system',
        nowISO(),
      ]
    );
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// Create backup
// ═══════════════════════════════════════════════════════════════════════════

export interface CreateBackupOptions {
  passphrase: string;
}

export interface CreateBackupOutput {
  data: Uint8Array;
  fileName: string;
  sizeBytes: number;
  transactionCount: number;
  header: BackupHeader;
}

export async function createBackup(
  options: CreateBackupOptions
): Promise<Result<CreateBackupOutput>> {
  const { passphrase } = options;

  if (
    passphrase.length < MIN_PASSPHRASE_LENGTH ||
    passphrase.length > MAX_PASSPHRASE_LENGTH
  ) {
    return {
      ok: false,
      code: 'VALIDATION',
      message: `عبارت عبور باید بین ${MIN_PASSPHRASE_LENGTH} تا ${MAX_PASSPHRASE_LENGTH} کاراکتر باشد`,
    };
  }

  try {
    const [
      workspace,
      accounts,
      parties,
      projects,
      categories,
      transactions,
      auditEvents,
      settings,
      backupRecords,
    ] = await Promise.all([
      workspaceRepo.get(),
      accountRepo.list(true),
      partyRepo.list(true),
      projectRepo.list(),
      categoryRepo.list(true),
      transactionRepo.listAll(),
      auditRepo.list(1000),
      settingsRepo.getAll(),
      backupRepo.list(100),
    ]);

    if (!workspace) {
      return {
        ok: false,
        code: 'WORKSPACE_MISSING',
        message: 'فضای کاری یافت نشد',
      };
    }

    const payload: SerializedPayload = {
      workspace: {
        id: workspace.id,
        name: workspace.name,
        createdAt: workspace.createdAt,
      },
      accounts: accounts.map(serializeAccount),
      parties,
      projects: projects.map(serializeProject),
      categories,
      transactions: transactions.map(serializeTransaction),
      auditEvents,
      settings,
      backupRecords,
      deviceName: getDeviceName(),
    };

    const payloadJson = JSON.stringify(payload);
    const payloadBytes = utf8Encode(payloadJson);

    const { ciphertext, salt, iv } = await encryptPayload(payloadBytes, passphrase);

    const checksum = await sha256Hex(ciphertext);

    const now = nowISO();
    const header: BackupHeader = {
      magic: BACKUP_MAGIC,
      formatVersion: BACKUP_FORMAT_VERSION,
      schemaVersion: BACKUP_SCHEMA_VERSION,
      appVersion: BACKUP_APP_VERSION,
      createdAt: now,
      workspaceId: workspace.id,
      pbkdf2Salt: bytesToBase64(salt),
      aesIv: bytesToBase64(iv),
      checksum,
    };

    const container = packContainer(header, ciphertext);

    const fileName = buildBackupFileName();

    await backupRepo.create({
      fileName,
      type: BackupType.FULL,
      sizeBytes: container.length,
      transactionCount: transactions.length,
      schemaVersion: BACKUP_SCHEMA_VERSION,
      appVersion: BACKUP_APP_VERSION,
      checksum,
    });

    await settingsRepo.set(SETTINGS_KEYS.LAST_BACKUP_AT, now);

    await writeBackupAuditEvent('backup_create', {
      fileName,
      transactionCount: transactions.length,
      sizeBytes: container.length,
    });

    return {
      ok: true,
      value: {
        data: container,
        fileName,
        sizeBytes: container.length,
        transactionCount: transactions.length,
        header,
      },
    };
  } catch (e) {
    return {
      ok: false,
      code: 'BACKUP_FAILED',
      message: e instanceof Error ? e.message : 'پشتیبان‌گیری با خطا مواجه شد',
    };
  }
}

function buildBackupFileName(): string {
  const now = new Date();
  const iso = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')}`;
  const time = `${String(now.getHours()).padStart(2, '0')}${String(now.getMinutes()).padStart(2, '0')}`;
  return `CompanyFinance_Backup_${iso}_${time}.finbackup`;
}

// ═══════════════════════════════════════════════════════════════════════════
// Inspect backup
// ═══════════════════════════════════════════════════════════════════════════

export interface BackupInspection {
  header: BackupHeader;
  valid: boolean;
  warnings: string[];
}

export function inspectBackup(data: Uint8Array | ArrayBuffer): Result<BackupInspection> {
  try {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const { header } = unpackContainer(bytes);
    validateHeader(header);

    const warnings: string[] = [];

    if (header.formatVersion < BACKUP_FORMAT_VERSION) {
      warnings.push(
        `این فایل با نسخه‌ی قدیمی‌تر برنامه ساخته شده است (فرمت: ${header.formatVersion})`
      );
    }

    if (header.schemaVersion < BACKUP_SCHEMA_VERSION) {
      warnings.push(
        `اسکیمای این فایل قدیمی است (${header.schemaVersion}) و پس از بازیابی به‌روزرسانی می‌شود`
      );
    }

    return {
      ok: true,
      value: {
        header,
        valid: true,
        warnings,
      },
    };
  } catch (e) {
    return {
      ok: false,
      code: 'INVALID_BACKUP',
      message: e instanceof Error ? e.message : 'فایل پشتیبان معتبر نیست',
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Restore backup
// ═══════════════════════════════════════════════════════════════════════════

export interface RestoreOptions {
  fileContent: Uint8Array | ArrayBuffer;
  passphrase: string;
  mode: RestoreMode;
}

export interface RestoreDetailedResult extends RestoreResult {
  workspaceName: string | null;
  backupCreatedAt: ISOTimestamp | null;
  backupTransactionCount: number;
}

export async function restoreBackup(
  options: RestoreOptions
): Promise<Result<RestoreDetailedResult>> {
  const { fileContent, passphrase, mode } = options;

  if (passphrase.length < MIN_PASSPHRASE_LENGTH) {
    return {
      ok: false,
      code: 'VALIDATION',
      message: 'عبارت عبور الزامی است',
    };
  }

  let parsedPayload: SerializedPayload;
  let header: BackupHeader;

  try {
    const bytes =
      fileContent instanceof Uint8Array ? fileContent : new Uint8Array(fileContent);

    const container = unpackContainer(bytes);
    header = container.header;
    validateHeader(header);

    const salt = base64ToBytes(header.pbkdf2Salt);
    const iv = base64ToBytes(header.aesIv);

    const decrypted = await decryptPayload(container.ciphertext, salt, iv, passphrase);

    const recomputed = await sha256Hex(container.ciphertext);
    if (recomputed !== header.checksum) {
      return {
        ok: false,
        code: 'CHECKSUM_MISMATCH',
        message: 'یکپارچگی فایل پشتیبان تأیید نشد',
      };
    }

    const payloadJson = utf8Decode(decrypted);
    parsedPayload = JSON.parse(payloadJson) as SerializedPayload;
  } catch (e) {
    return {
      ok: false,
      code: 'DECRYPT_FAILED',
      message: e instanceof Error ? e.message : 'رمزگشایی با خطا مواجه شد',
    };
  }

  try {
    const result =
      mode === 'replace'
        ? await applyReplaceMode(parsedPayload)
        : await applyMergeMode(parsedPayload);

    await writeBackupAuditEvent('backup_restore', {
      mode,
      counts: result.counts,
      backupCreatedAt: header.createdAt,
      workspaceId: header.workspaceId,
    });

    return {
      ok: true,
      value: {
        ...result,
        workspaceName: parsedPayload.workspace.name,
        backupCreatedAt: header.createdAt,
        backupTransactionCount: parsedPayload.transactions.length,
      },
    };
  } catch (e) {
    return {
      ok: false,
      code: 'RESTORE_FAILED',
      message: e instanceof Error ? e.message : 'بازیابی با خطا مواجه شد',
    };
  }
}

async function applyReplaceMode(payload: SerializedPayload): Promise<RestoreResult> {
  const conn = getDatabase();

  const counts = {
    imported: 0,
    skipped: 0,
    conflicts: 0,
  };

  await conn.transaction(async (tx) => {
    await tx.execute('DELETE FROM attachments');
    await tx.execute('DELETE FROM transactions');
    await tx.execute('DELETE FROM projects');
    await tx.execute('DELETE FROM parties');
    await tx.execute('DELETE FROM accounts');
    await tx.execute(`DELETE FROM categories WHERE is_custom = 1`);
    await tx.execute('DELETE FROM audit_events');
    await tx.execute('DELETE FROM backup_records');
    await tx.execute('DELETE FROM alerts');
    await tx.execute(
      `DELETE FROM app_settings WHERE key NOT IN (
        'theme', 'language', 'company_name', 'onboarding_done',
        'security_prompt_count', 'device_prefix',
        'privacy_hide_amounts', 'asset_cache_version'
      )`
    );

    const existingWorkspace = await tx.queryOne<{ id: string }>(
      'SELECT id FROM workspaces LIMIT 1'
    );

    if (existingWorkspace) {
      await tx.execute('UPDATE workspaces SET name = ? WHERE id = ?', [
        payload.workspace.name,
        existingWorkspace.id,
      ]);
    } else {
      await tx.execute('INSERT INTO workspaces (id, name, created_at) VALUES (?, ?, ?)', [
        payload.workspace.id,
        payload.workspace.name,
        payload.workspace.createdAt,
      ]);
    }

    for (const account of payload.accounts) {
      const a = deserializeAccount(account);
      await tx.execute(
        `INSERT INTO accounts
          (id, workspace_id, name, type, bank_name, account_number, card_number,
           description, opening_balance, opening_balance_date, status,
           sort_order, created_at, updated_at, created_by, updated_by)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          a.id,
          a.workspaceId,
          a.name,
          a.type,
          a.bankName,
          a.accountNumber,
          a.cardNumber,
          a.description,
          Number(a.openingBalance),
          a.openingBalanceDate,
          a.status,
          a.sortOrder,
          a.createdAt,
          a.updatedAt,
          a.createdBy,
          a.updatedBy,
        ]
      );
      counts.imported += 1;
    }

    for (const party of payload.parties) {
      await tx.execute(
        `INSERT INTO parties
          (id, workspace_id, name, normalized_name, type, phone, card_number,
           account_number, role, notes, status, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          party.id,
          party.workspaceId,
          party.name,
          party.normalizedName,
          party.type,
          party.phone,
          party.cardNumber,
          party.accountNumber,
          party.role,
          party.notes,
          party.status,
          party.createdAt,
          party.updatedAt,
        ]
      );
      counts.imported += 1;
    }

    for (const project of payload.projects) {
      const p = deserializeProject(project);
      await tx.execute(
        `INSERT INTO projects
          (id, workspace_id, name, code, status, budget_amount, description,
           created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
        [
          p.id,
          p.workspaceId,
          p.name,
          p.code,
          p.status,
          p.budgetAmount === null ? null : Number(p.budgetAmount),
          p.description,
          p.createdAt,
          p.updatedAt,
        ]
      );
      counts.imported += 1;
    }

    for (const category of payload.categories) {
      if (!category.isCustom) continue;
      await tx.execute(
        `INSERT OR IGNORE INTO categories
          (id, parent_id, name, type, is_custom, sort_order, status)
         VALUES (?, ?, ?, ?, ?, ?, ?)`,
        [
          category.id,
          category.parentId,
          category.name,
          category.type,
          category.isCustom ? 1 : 0,
          category.sortOrder,
          category.status,
        ]
      );
      counts.imported += 1;
    }

    for (const t of payload.transactions) {
      const tx2 = deserializeTransaction(t);
      try {
        await tx.execute(
          `INSERT INTO transactions
            (id, workspace_id, display_code, type, amount, account_id, party_id,
             category_id, custom_category_text, project_id, transaction_date,
             transaction_time, reference_code, description, status, version,
             device_id, created_at, updated_at, created_by, updated_by, deleted_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            tx2.id,
            tx2.workspaceId,
            tx2.displayCode,
            tx2.type,
            Number(tx2.amount),
            tx2.accountId,
            tx2.partyId,
            tx2.categoryId,
            tx2.customCategoryText,
            tx2.projectId,
            tx2.transactionDate,
            tx2.transactionTime,
            tx2.referenceCode,
            tx2.description,
            tx2.status,
            tx2.version,
            tx2.deviceId,
            tx2.createdAt,
            tx2.updatedAt,
            tx2.createdBy,
            tx2.updatedBy,
            tx2.deletedAt,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const event of payload.auditEvents) {
      try {
        await tx.execute(
          `INSERT INTO audit_events
            (id, workspace_id, entity_type, entity_id, action,
             before_json, after_json, actor_label, device_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            event.id,
            event.workspaceId,
            event.entityType,
            event.entityId,
            event.action,
            event.beforeJson,
            event.afterJson,
            event.actorLabel,
            event.deviceId,
            event.createdAt,
          ]
        );
      } catch {
        // ignore duplicated audit
      }
    }
  });

  return {
    success: true,
    mode: 'replace',
    counts,
    message: `بازیابی کامل انجام شد. ${counts.imported} رکورد بازیابی شد.`,
  };
}

async function applyMergeMode(payload: SerializedPayload): Promise<RestoreResult> {
  const conn = getDatabase();

  const counts = {
    imported: 0,
    skipped: 0,
    conflicts: 0,
  };

  const existingAccounts = new Set(
    (await conn.query<{ id: string }>('SELECT id FROM accounts')).map((r) => r.id)
  );
  const existingParties = new Set(
    (await conn.query<{ id: string }>('SELECT id FROM parties')).map((r) => r.id)
  );
  const existingProjects = new Set(
    (await conn.query<{ id: string }>('SELECT id FROM projects')).map((r) => r.id)
  );
  const existingTxDisplayCodes = new Set(
    (
      await conn.query<{ display_code: string }>('SELECT display_code FROM transactions')
    ).map((r) => r.display_code)
  );
  const existingTxIds = new Set(
    (await conn.query<{ id: string }>('SELECT id FROM transactions')).map((r) => r.id)
  );

  await conn.transaction(async (tx) => {
    for (const account of payload.accounts) {
      if (existingAccounts.has(account.id)) {
        counts.skipped += 1;
        continue;
      }
      const a = deserializeAccount(account);
      try {
        await tx.execute(
          `INSERT INTO accounts
            (id, workspace_id, name, type, bank_name, account_number, card_number,
             description, opening_balance, opening_balance_date, status,
             sort_order, created_at, updated_at, created_by, updated_by)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            a.id,
            a.workspaceId,
            a.name,
            a.type,
            a.bankName,
            a.accountNumber,
            a.cardNumber,
            a.description,
            Number(a.openingBalance),
            a.openingBalanceDate,
            a.status,
            a.sortOrder,
            a.createdAt,
            a.updatedAt,
            a.createdBy,
            a.updatedBy,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const party of payload.parties) {
      if (existingParties.has(party.id)) {
        counts.skipped += 1;
        continue;
      }
      try {
        await tx.execute(
          `INSERT INTO parties
            (id, workspace_id, name, normalized_name, type, phone, card_number,
             account_number, role, notes, status, created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            party.id,
            party.workspaceId,
            party.name,
            party.normalizedName,
            party.type,
            party.phone,
            party.cardNumber,
            party.accountNumber,
            party.role,
            party.notes,
            party.status,
            party.createdAt,
            party.updatedAt,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const project of payload.projects) {
      if (existingProjects.has(project.id)) {
        counts.skipped += 1;
        continue;
      }
      const p = deserializeProject(project);
      try {
        await tx.execute(
          `INSERT INTO projects
            (id, workspace_id, name, code, status, budget_amount, description,
             created_at, updated_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            p.id,
            p.workspaceId,
            p.name,
            p.code,
            p.status,
            p.budgetAmount === null ? null : Number(p.budgetAmount),
            p.description,
            p.createdAt,
            p.updatedAt,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const category of payload.categories) {
      if (!category.isCustom) continue;
      try {
        await tx.execute(
          `INSERT OR IGNORE INTO categories
            (id, parent_id, name, type, is_custom, sort_order, status)
           VALUES (?, ?, ?, ?, ?, ?, ?)`,
          [
            category.id,
            category.parentId,
            category.name,
            category.type,
            category.isCustom ? 1 : 0,
            category.sortOrder,
            category.status,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const t of payload.transactions) {
      const tx2 = deserializeTransaction(t);

      if (existingTxIds.has(tx2.id) || existingTxDisplayCodes.has(tx2.displayCode)) {
        counts.skipped += 1;
        continue;
      }

      try {
        await tx.execute(
          `INSERT INTO transactions
            (id, workspace_id, display_code, type, amount, account_id, party_id,
             category_id, custom_category_text, project_id, transaction_date,
             transaction_time, reference_code, description, status, version,
             device_id, created_at, updated_at, created_by, updated_by, deleted_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            tx2.id,
            tx2.workspaceId,
            tx2.displayCode,
            tx2.type,
            Number(tx2.amount),
            tx2.accountId,
            tx2.partyId,
            tx2.categoryId,
            tx2.customCategoryText,
            tx2.projectId,
            tx2.transactionDate,
            tx2.transactionTime,
            tx2.referenceCode,
            tx2.description,
            tx2.status,
            tx2.version,
            tx2.deviceId,
            tx2.createdAt,
            tx2.updatedAt,
            tx2.createdBy,
            tx2.updatedBy,
            tx2.deletedAt,
          ]
        );
        counts.imported += 1;
      } catch {
        counts.conflicts += 1;
      }
    }

    for (const event of payload.auditEvents) {
      try {
        await tx.execute(
          `INSERT OR IGNORE INTO audit_events
            (id, workspace_id, entity_type, entity_id, action,
             before_json, after_json, actor_label, device_id, created_at)
           VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
          [
            event.id,
            event.workspaceId,
            event.entityType,
            event.entityId,
            event.action,
            event.beforeJson,
            event.afterJson,
            event.actorLabel,
            event.deviceId,
            event.createdAt,
          ]
        );
      } catch {
        // ignore
      }
    }
  });

  return {
    success: true,
    mode: 'merge',
    counts,
    message: `ادغام انجام شد. ${counts.imported} رکورد اضافه و ${counts.skipped} رکورد تکراری نادیده گرفته شد.`,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Verify backup integrity
// ═══════════════════════════════════════════════════════════════════════════

export async function verifyBackup(
  data: Uint8Array | ArrayBuffer,
  passphrase: string
): Promise<Result<{ valid: boolean; transactionCount: number }>> {
  try {
    const bytes = data instanceof Uint8Array ? data : new Uint8Array(data);
    const container = unpackContainer(bytes);
    validateHeader(container.header);

    const recomputed = await sha256Hex(container.ciphertext);
    if (recomputed !== container.header.checksum) {
      return {
        ok: false,
        code: 'CHECKSUM_MISMATCH',
        message: 'یکپارچگی فایل تأیید نشد',
      };
    }

    const salt = base64ToBytes(container.header.pbkdf2Salt);
    const iv = base64ToBytes(container.header.aesIv);

    const decrypted = await decryptPayload(container.ciphertext, salt, iv, passphrase);

    const payloadJson = utf8Decode(decrypted);
    const payload = JSON.parse(payloadJson) as SerializedPayload;

    return {
      ok: true,
      value: {
        valid: true,
        transactionCount: payload.transactions.length,
      },
    };
  } catch (e) {
    return {
      ok: false,
      code: 'VERIFY_FAILED',
      message: e instanceof Error ? e.message : 'بررسی با خطا مواجه شد',
    };
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Helpers
// ═══════════════════════════════════════════════════════════════════════════

export function getBackupFileNameForDisplay(header: BackupHeader): string {
  const iso = header.createdAt.slice(0, 10);
  return `پشتیبان ${iso}`;
}

export async function getLatestBackupInfo(): Promise<BackupRecord | null> {
  const records = await backupRepo.list(1);
  return records[0] ?? null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Public facade
// ═══════════════════════════════════════════════════════════════════════════

export const backupService = {
  create: createBackup,
  inspect: inspectBackup,
  restore: restoreBackup,
  verify: verifyBackup,
  getLatestInfo: getLatestBackupInfo,
  list: backupRepo.list,
};

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
