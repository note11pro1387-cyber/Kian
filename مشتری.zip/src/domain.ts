// ============================================================================
//  src/domain.ts
//  قوانین مالی خالص — بدون هیچ وابستگی به React/Capacitor/SQL
// ============================================================================
//
//  ── تغییرات SPEC v2.0 ─────────────────────────────────────────────────
//
//   ۱. `validateTransactionRules` از `account.status === 'archived'` و
//      `party.status !== 'active'` استفاده می‌کند (نه boolean).
//   ۲. `TransactionStatus.DELETED` مقدار جدید `'soft_deleted'` را برمی‌گرداند
//      (تغییر از `'deleted'`).
//   ۳. `openingBalanceDate` حالا اجباری است (نه nullable).
//
//  ── قوانین حاکم ─────────────────────────────────────────────────────
//
//   - موجودی هرگز ذخیره نمی‌شود، فقط محاسبه.
//   - تراکنش‌های soft_deleted هرگز در محاسبات شرکت نمی‌کنند.
//   - گزارش بازه‌ای از فرمول Opening + Inflow - Outflow = Closing استفاده می‌کند.
// ============================================================================

import {
  TransactionStatus,
  TransactionType,
  AccountStatus,
  PartyStatus,
  ReportWarningCode,
  DuplicateLevel,
} from './types';

import type {
  Account,
  AccountBreakdown,
  AccountId,
  BalanceResult,
  Category,
  CategoryBreakdown,
  CategoryId,
  CreateTransactionInput,
  DisplayCode,
  DuplicateScore,
  ISODate,
  ISOTimestamp,
  Money,
  Party,
  PartyBreakdown,
  PartyId,
  PeriodReport,
  Project,
  ProjectBreakdown,
  ProjectId,
  ReportWarning,
  Transaction,
  TransactionFilter,
  TransactionId,
} from './types';

import { normalizePersianText } from './formatters';

// ═══════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════

const MAX_AMOUNT = 999_999_999_999_999n;
const MS_PER_DAY = 86_400_000;

// ═══════════════════════════════════════════════════════════════════════════
// Balance
// ═══════════════════════════════════════════════════════════════════════════

export function calculateBalance(
  account: Account,
  transactions: readonly Transaction[]
): BalanceResult {
  let totalInflow = 0n;
  let totalOutflow = 0n;
  let count = 0;

  for (const tx of transactions) {
    if (tx.accountId !== account.id) continue;
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    count += 1;
    if (tx.type === TransactionType.DEPOSIT) {
      totalInflow += tx.amount;
    } else {
      totalOutflow += tx.amount;
    }
  }

  const balance = account.openingBalance + totalInflow - totalOutflow;

  return {
    accountId: account.id,
    openingBalance: account.openingBalance,
    totalInflow,
    totalOutflow,
    balance,
    isNegative: balance < 0n,
    transactionCount: count,
  };
}

export function calculateBalances(
  accounts: readonly Account[],
  transactions: readonly Transaction[]
): Map<AccountId, BalanceResult> {
  const result = new Map<AccountId, BalanceResult>();
  for (const acc of accounts) {
    result.set(acc.id, calculateBalance(acc, transactions));
  }
  return result;
}

export function calculateTotalBalance(balances: Iterable<BalanceResult>): Money {
  let total = 0n;
  for (const b of balances) total += b.balance;
  return total;
}

export function calculateTotalInflow(balances: Iterable<BalanceResult>): Money {
  let total = 0n;
  for (const b of balances) total += b.totalInflow;
  return total;
}

export function calculateTotalOutflow(balances: Iterable<BalanceResult>): Money {
  let total = 0n;
  for (const b of balances) total += b.totalOutflow;
  return total;
}

// ═══════════════════════════════════════════════════════════════════════════
// Opening position
// ═══════════════════════════════════════════════════════════════════════════

export function computeOpeningPosition(
  account: Account,
  transactions: readonly Transaction[],
  beforeDate: ISODate
): Money {
  let total = account.openingBalance;
  for (const tx of transactions) {
    if (tx.accountId !== account.id) continue;
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.transactionDate >= beforeDate) continue;
    if (tx.type === TransactionType.DEPOSIT) total += tx.amount;
    else total -= tx.amount;
  }
  return total;
}

function computeOpeningPositionMulti(
  accounts: readonly Account[],
  transactions: readonly Transaction[],
  beforeDate: ISODate,
  accountFilter: Set<AccountId> | null
): Money {
  let total = 0n;
  const included = new Set<AccountId>();

  for (const acc of accounts) {
    if (accountFilter && !accountFilter.has(acc.id)) continue;
    included.add(acc.id);
    total += acc.openingBalance;
  }

  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (!included.has(tx.accountId)) continue;
    if (tx.transactionDate >= beforeDate) continue;
    if (tx.type === TransactionType.DEPOSIT) total += tx.amount;
    else total -= tx.amount;
  }

  return total;
}

function findLastDepositBefore(
  transactions: readonly Transaction[],
  beforeDate: ISODate,
  accountFilter: Set<AccountId> | null
): Transaction | null {
  let best: Transaction | null = null;
  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.type !== TransactionType.DEPOSIT) continue;
    if (tx.transactionDate >= beforeDate) continue;
    if (accountFilter && !accountFilter.has(tx.accountId)) continue;
    if (!best || tx.transactionDate > best.transactionDate) best = tx;
  }
  return best;
}

// ═══════════════════════════════════════════════════════════════════════════
// Reconciliation
// ═══════════════════════════════════════════════════════════════════════════

export interface ReconciliationResult {
  accountId: AccountId;
  stored: Money | null;
  calculated: Money;
  matches: boolean;
  difference: Money;
}

export function reconcileAccount(
  account: Account,
  transactions: readonly Transaction[],
  cachedBalance: Money | null
): ReconciliationResult {
  const { balance } = calculateBalance(account, transactions);
  return {
    accountId: account.id,
    stored: cachedBalance,
    calculated: balance,
    matches: cachedBalance === null || cachedBalance === balance,
    difference: cachedBalance === null ? 0n : cachedBalance - balance,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Validation rules (domain-level)
// ═══════════════════════════════════════════════════════════════════════════

export interface RuleViolation {
  field: string;
  message: string;
}

export function validateTransactionRules(
  input: CreateTransactionInput,
  account: Account | null,
  party: Party | null
): RuleViolation[] {
  const errors: RuleViolation[] = [];

  if (input.amount <= 0n) {
    errors.push({
      field: 'amount',
      message: 'مبلغ باید بزرگ‌تر از صفر باشد',
    });
  }

  if (input.amount > MAX_AMOUNT) {
    errors.push({
      field: 'amount',
      message: 'مبلغ از حد مجاز بیشتر است',
    });
  }

  if (!account) {
    errors.push({
      field: 'accountId',
      message: 'حساب انتخاب نشده است',
    });
  } else if (account.status === AccountStatus.ARCHIVED) {
    errors.push({
      field: 'accountId',
      message: 'حساب آرشیو شده است و تراکنش جدید نمی‌پذیرد',
    });
  }

  if (input.type === TransactionType.EXPENSE && !input.partyId) {
    errors.push({
      field: 'partyId',
      message: 'برای ثبت خرج، انتخاب طرف حساب الزامی است',
    });
  }

  if (input.partyId && !party) {
    errors.push({
      field: 'partyId',
      message: 'طرف حساب یافت نشد',
    });
  }

  if (party && party.status !== PartyStatus.ACTIVE) {
    errors.push({
      field: 'partyId',
      message: 'طرف حساب غیرفعال است',
    });
  }

  if (!input.transactionDate) {
    errors.push({
      field: 'transactionDate',
      message: 'تاریخ تراکنش الزامی است',
    });
  }

  if (input.customCategoryText && input.customCategoryText.length > 80) {
    errors.push({
      field: 'customCategoryText',
      message: 'متن بابت بیش از حد بلند است',
    });
  }

  if (input.description && input.description.length > 500) {
    errors.push({
      field: 'description',
      message: 'توضیحات بیش از حد بلند است',
    });
  }

  if (input.referenceCode && input.referenceCode.length > 50) {
    errors.push({
      field: 'referenceCode',
      message: 'کد پیگیری بیش از حد بلند است',
    });
  }

  return errors;
}

export function validateAccountInput(input: {
  name: string;
  openingBalance: Money;
}): RuleViolation[] {
  const errors: RuleViolation[] = [];

  if (!input.name.trim()) {
    errors.push({ field: 'name', message: 'نام حساب الزامی است' });
  }

  if (input.name.length > 100) {
    errors.push({ field: 'name', message: 'نام حساب بیش از حد بلند است' });
  }

  if (input.openingBalance < 0n) {
    errors.push({
      field: 'openingBalance',
      message: 'موجودی اولیه نمی‌تواند منفی باشد',
    });
  }

  if (input.openingBalance > MAX_AMOUNT) {
    errors.push({
      field: 'openingBalance',
      message: 'موجودی اولیه از حد مجاز بیشتر است',
    });
  }

  return errors;
}

export function validatePartyInput(input: { name: string }): RuleViolation[] {
  const errors: RuleViolation[] = [];

  if (!input.name.trim()) {
    errors.push({ field: 'name', message: 'نام طرف حساب الزامی است' });
  }

  if (input.name.length > 100) {
    errors.push({ field: 'name', message: 'نام طرف حساب بیش از حد بلند است' });
  }

  return errors;
}

export function validateProjectInput(input: {
  name: string;
  budgetAmount: Money | null;
}): RuleViolation[] {
  const errors: RuleViolation[] = [];

  if (!input.name.trim()) {
    errors.push({ field: 'name', message: 'نام پروژه الزامی است' });
  }

  if (input.name.length > 100) {
    errors.push({ field: 'name', message: 'نام پروژه بیش از حد بلند است' });
  }

  if (input.budgetAmount !== null && input.budgetAmount < 0n) {
    errors.push({
      field: 'budgetAmount',
      message: 'بودجه نمی‌تواند منفی باشد',
    });
  }

  if (input.budgetAmount !== null && input.budgetAmount > MAX_AMOUNT) {
    errors.push({
      field: 'budgetAmount',
      message: 'بودجه از حد مجاز بیشتر است',
    });
  }

  return errors;
}

export function isDuplicateName(
  name: string,
  existing: readonly { id: string; name: string }[],
  excludeId?: string
): boolean {
  const target = normalizePersianText(name);
  for (const item of existing) {
    if (excludeId && item.id === excludeId) continue;
    if (normalizePersianText(item.name) === target) return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════════════════════
// Duplicate detection
// ═══════════════════════════════════════════════════════════════════════════

function daysBetween(a: ISODate, b: ISODate): number {
  const da = new Date(a + 'T00:00:00Z').getTime();
  const db = new Date(b + 'T00:00:00Z').getTime();
  if (!Number.isFinite(da) || !Number.isFinite(db)) {
    return Number.MAX_SAFE_INTEGER;
  }
  return Math.round(Math.abs(da - db) / MS_PER_DAY);
}

export function checkDuplicate(
  candidate: CreateTransactionInput,
  existing: readonly Transaction[]
): DuplicateScore {
  let best: DuplicateScore = {
    level: DuplicateLevel.UNIQUE,
    score: 0,
    matchedTransactionId: null,
    reasons: [],
  };

  for (const tx of existing) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.type !== candidate.type) continue;
    if (tx.amount !== candidate.amount) continue;
    if (tx.accountId !== candidate.accountId) continue;

    const dayDelta = daysBetween(tx.transactionDate, candidate.transactionDate);
    if (dayDelta > 1) continue;

    const reasons: string[] = ['مبلغ یکسان', 'نوع یکسان', 'حساب یکسان'];

    if (dayDelta === 0) reasons.push('تاریخ یکسان');
    else reasons.push('تاریخ نزدیک');

    const sameParty =
      tx.partyId !== null &&
      candidate.partyId !== null &&
      tx.partyId === candidate.partyId;

    const bothNullParty = tx.partyId === null && candidate.partyId === null;

    if (sameParty) reasons.push('طرف حساب یکسان');

    const sameRef =
      tx.referenceCode !== null &&
      candidate.referenceCode !== null &&
      tx.referenceCode === candidate.referenceCode;

    if (sameRef) reasons.push('کد پیگیری یکسان');

    const sameCategory =
      tx.categoryId !== null &&
      candidate.categoryId !== null &&
      tx.categoryId === candidate.categoryId;

    let level: DuplicateLevel = DuplicateLevel.POSSIBLE;
    let score = 0.5;

    if (sameParty && dayDelta === 0) {
      level = DuplicateLevel.LIKELY;
      score = 0.75;
    }

    if (sameParty && dayDelta === 0 && sameRef) {
      level = DuplicateLevel.EXACT;
      score = 1;
    }

    if (sameParty && dayDelta === 0 && sameCategory && sameRef) {
      level = DuplicateLevel.EXACT;
      score = 1;
    }

    if (bothNullParty && dayDelta === 0 && sameRef) {
      level = DuplicateLevel.EXACT;
      score = 1;
    }

    if (score > best.score) {
      best = {
        level,
        score,
        matchedTransactionId: tx.id,
        reasons,
      };
    }
  }

  return best;
}

// ═══════════════════════════════════════════════════════════════════════════
// Delete impact
// ═══════════════════════════════════════════════════════════════════════════

export interface DeleteAccountImpact {
  transactionCount: number;
  currentBalance: Money;
  willCauseNegative: boolean;
}

export function computeDeleteAccountImpact(
  account: Account,
  transactions: readonly Transaction[]
): DeleteAccountImpact {
  const { balance, transactionCount } = calculateBalance(account, transactions);
  return {
    transactionCount,
    currentBalance: balance,
    willCauseNegative: balance < 0n,
  };
}

export interface DeleteTransactionImpact {
  currentBalance: Money;
  projectedBalance: Money;
  willCauseNegative: boolean;
}

export function computeDeleteTransactionImpact(
  transaction: Transaction,
  account: Account,
  transactions: readonly Transaction[]
): DeleteTransactionImpact {
  const current = calculateBalance(account, transactions).balance;

  const delta =
    transaction.type === TransactionType.DEPOSIT
      ? -transaction.amount
      : transaction.amount;

  const projected = current + delta;

  return {
    currentBalance: current,
    projectedBalance: projected,
    willCauseNegative: projected < 0n && current >= 0n,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Filtering
// ═══════════════════════════════════════════════════════════════════════════

export function filterTransactions(
  transactions: readonly Transaction[],
  filter: TransactionFilter,
  parties: readonly Party[]
): Transaction[] {
  const typeSet = filter.types.length ? new Set(filter.types) : null;
  const accountSet = filter.accountIds.length ? new Set(filter.accountIds) : null;
  const partySet = filter.partyIds.length ? new Set(filter.partyIds) : null;
  const projectSet = filter.projectIds.length ? new Set(filter.projectIds) : null;
  const categorySet = filter.categoryIds.length ? new Set(filter.categoryIds) : null;
  const statusSet = filter.statuses.length ? new Set(filter.statuses) : null;

  const partiesById = new Map<PartyId, Party>();
  for (const p of parties) partiesById.set(p.id, p);

  const search = filter.searchQuery ? normalizePersianText(filter.searchQuery) : '';

  const result: Transaction[] = [];

  for (const tx of transactions) {
    if (!statusSet) {
      if (tx.status !== TransactionStatus.ACTIVE) continue;
    } else if (!statusSet.has(tx.status)) {
      continue;
    }

    if (typeSet && !typeSet.has(tx.type)) continue;
    if (accountSet && !accountSet.has(tx.accountId)) continue;

    if (partySet) {
      if (tx.partyId === null || !partySet.has(tx.partyId)) continue;
    }

    if (projectSet) {
      if (tx.projectId === null || !projectSet.has(tx.projectId)) continue;
    }

    if (categorySet) {
      if (tx.categoryId === null || !categorySet.has(tx.categoryId)) continue;
    }

    if (filter.dateFrom && tx.transactionDate < filter.dateFrom) continue;
    if (filter.dateTo && tx.transactionDate > filter.dateTo) continue;

    if (filter.amountMin !== null && tx.amount < filter.amountMin) continue;
    if (filter.amountMax !== null && tx.amount > filter.amountMax) continue;

    if (search) {
      const partyName =
        tx.partyId !== null ? (partiesById.get(tx.partyId)?.normalizedName ?? '') : '';
      const haystack = normalizePersianText(
        [
          tx.description ?? '',
          tx.referenceCode ?? '',
          tx.displayCode,
          tx.customCategoryText ?? '',
          partyName,
        ].join(' ')
      );
      if (!haystack.includes(search)) continue;
    }

    result.push(tx);
  }

  return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// Sorting
// ═══════════════════════════════════════════════════════════════════════════

export function sortTransactionsDesc(
  transactions: readonly Transaction[]
): Transaction[] {
  const copy = [...transactions];
  copy.sort((a, b) => {
    if (a.transactionDate !== b.transactionDate) {
      return a.transactionDate > b.transactionDate ? -1 : 1;
    }
    const ta = a.transactionTime ?? '00:00';
    const tb = b.transactionTime ?? '00:00';
    if (ta !== tb) return ta > tb ? -1 : 1;
    if (a.createdAt !== b.createdAt) return a.createdAt > b.createdAt ? -1 : 1;
    return a.id > b.id ? -1 : 1;
  });
  return copy;
}

export function sortTransactionsAsc(transactions: readonly Transaction[]): Transaction[] {
  const copy = [...transactions];
  copy.sort((a, b) => {
    if (a.transactionDate !== b.transactionDate) {
      return a.transactionDate < b.transactionDate ? -1 : 1;
    }
    const ta = a.transactionTime ?? '00:00';
    const tb = b.transactionTime ?? '00:00';
    if (ta !== tb) return ta < tb ? -1 : 1;
    if (a.createdAt !== b.createdAt) return a.createdAt < b.createdAt ? -1 : 1;
    return a.id < b.id ? -1 : 1;
  });
  return copy;
}

// ═══════════════════════════════════════════════════════════════════════════
// Grouping
// ═══════════════════════════════════════════════════════════════════════════

export interface TransactionGroup {
  date: ISODate;
  transactions: Transaction[];
  totalInflow: Money;
  totalOutflow: Money;
}

export function groupTransactionsByDate(
  transactions: readonly Transaction[]
): TransactionGroup[] {
  const map = new Map<ISODate, Transaction[]>();

  for (const tx of transactions) {
    const list = map.get(tx.transactionDate);
    if (list) list.push(tx);
    else map.set(tx.transactionDate, [tx]);
  }

  const groups: TransactionGroup[] = [];

  for (const [date, txs] of map) {
    let inflow = 0n;
    let outflow = 0n;
    for (const tx of txs) {
      if (tx.type === TransactionType.DEPOSIT) inflow += tx.amount;
      else outflow += tx.amount;
    }
    groups.push({
      date,
      transactions: txs,
      totalInflow: inflow,
      totalOutflow: outflow,
    });
  }

  groups.sort((a, b) => (a.date > b.date ? -1 : a.date < b.date ? 1 : 0));

  return groups;
}

// ═══════════════════════════════════════════════════════════════════════════
// Sums
// ═══════════════════════════════════════════════════════════════════════════

export function sumTransactions(transactions: readonly Transaction[]): Money {
  let total = 0n;
  for (const tx of transactions) total += tx.amount;
  return total;
}

export function sumByType(
  transactions: readonly Transaction[],
  type: Transaction['type']
): Money {
  let total = 0n;
  for (const tx of transactions) {
    if (tx.type === type) total += tx.amount;
  }
  return total;
}

export function countByType(
  transactions: readonly Transaction[],
  type: Transaction['type']
): number {
  let count = 0;
  for (const tx of transactions) {
    if (tx.type === type) count += 1;
  }
  return count;
}

// ═══════════════════════════════════════════════════════════════════════════
// Report generation
// ═══════════════════════════════════════════════════════════════════════════

export interface GenerateReportParams {
  start: ISODate;
  end: ISODate;
  accounts: readonly Account[];
  parties: readonly Party[];
  projects: readonly Project[];
  categories: readonly Category[];
  transactions: readonly Transaction[];
  accountIds?: readonly AccountId[];
  partyIds?: readonly PartyId[];
  projectIds?: readonly ProjectId[];
  categoryIds?: readonly CategoryId[];
  types?: readonly Transaction['type'][];
}

function computeCategoryBreakdown(
  transactions: readonly Transaction[],
  categories: readonly Category[]
): CategoryBreakdown[] {
  const index = new Map<CategoryId, Category>();
  for (const c of categories) index.set(c.id, c);

  const map = new Map<CategoryId, { total: Money; count: number }>();

  for (const tx of transactions) {
    const cid = tx.categoryId;
    if (!cid) continue;
    const entry = map.get(cid) ?? { total: 0n, count: 0 };
    entry.total += tx.amount;
    entry.count += 1;
    map.set(cid, entry);
  }

  const result: CategoryBreakdown[] = [];

  for (const [id, { total, count }] of map) {
    const cat = index.get(id);
    result.push({
      id,
      name: cat?.name ?? 'نامشخص',
      total,
      count,
    });
  }

  result.sort((a, b) => (b.total > a.total ? 1 : b.total < a.total ? -1 : 0));
  return result;
}

function computePartyBreakdown(
  transactions: readonly Transaction[],
  parties: readonly Party[]
): PartyBreakdown[] {
  const index = new Map<PartyId, Party>();
  for (const p of parties) index.set(p.id, p);

  const map = new Map<PartyId, { total: Money; count: number }>();

  for (const tx of transactions) {
    const pid = tx.partyId;
    if (!pid) continue;
    const entry = map.get(pid) ?? { total: 0n, count: 0 };
    entry.total += tx.amount;
    entry.count += 1;
    map.set(pid, entry);
  }

  const result: PartyBreakdown[] = [];

  for (const [id, { total, count }] of map) {
    const party = index.get(id);
    result.push({
      id,
      name: party?.name ?? 'نامشخص',
      total,
      count,
    });
  }

  result.sort((a, b) => (b.total > a.total ? 1 : b.total < a.total ? -1 : 0));
  return result;
}

function computeProjectBreakdown(
  transactions: readonly Transaction[],
  projects: readonly Project[]
): ProjectBreakdown[] {
  const index = new Map<ProjectId, Project>();
  for (const p of projects) index.set(p.id, p);

  const map = new Map<ProjectId, { total: Money; count: number }>();

  for (const tx of transactions) {
    const pid = tx.projectId;
    if (!pid) continue;
    const entry = map.get(pid) ?? { total: 0n, count: 0 };
    entry.total += tx.amount;
    entry.count += 1;
    map.set(pid, entry);
  }

  const result: ProjectBreakdown[] = [];

  for (const [id, { total, count }] of map) {
    const project = index.get(id);
    result.push({
      id,
      name: project?.name ?? 'نامشخص',
      total,
      count,
    });
  }

  result.sort((a, b) => (b.total > a.total ? 1 : b.total < a.total ? -1 : 0));
  return result;
}

function computeAccountBreakdown(
  transactions: readonly Transaction[],
  accounts: readonly Account[]
): AccountBreakdown[] {
  const index = new Map<AccountId, Account>();
  for (const a of accounts) index.set(a.id, a);

  const map = new Map<AccountId, { total: Money; count: number }>();

  for (const tx of transactions) {
    const entry = map.get(tx.accountId) ?? { total: 0n, count: 0 };
    entry.total += tx.amount;
    entry.count += 1;
    map.set(tx.accountId, entry);
  }

  const result: AccountBreakdown[] = [];

  for (const [id, { total, count }] of map) {
    const acc = index.get(id);
    result.push({
      id,
      name: acc?.name ?? 'نامشخص',
      total,
      count,
    });
  }

  result.sort((a, b) => (b.total > a.total ? 1 : b.total < a.total ? -1 : 0));
  return result;
}

export function generateReport(params: GenerateReportParams): PeriodReport {
  const { start, end, accounts, parties, projects, categories, transactions } = params;

  const accountSet = params.accountIds?.length ? new Set(params.accountIds) : null;
  const partySet = params.partyIds?.length ? new Set(params.partyIds) : null;
  const projectSet = params.projectIds?.length ? new Set(params.projectIds) : null;
  const categorySet = params.categoryIds?.length ? new Set(params.categoryIds) : null;
  const typeSet = params.types?.length ? new Set(params.types) : null;

  const inRange: Transaction[] = [];

  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.transactionDate < start) continue;
    if (tx.transactionDate > end) continue;
    if (accountSet && !accountSet.has(tx.accountId)) continue;
    if (partySet) {
      if (tx.partyId === null || !partySet.has(tx.partyId)) continue;
    }
    if (projectSet) {
      if (tx.projectId === null || !projectSet.has(tx.projectId)) continue;
    }
    if (categorySet) {
      if (tx.categoryId === null || !categorySet.has(tx.categoryId)) continue;
    }
    if (typeSet && !typeSet.has(tx.type)) continue;
    inRange.push(tx);
  }

  inRange.sort((a, b) => {
    if (a.transactionDate !== b.transactionDate) {
      return a.transactionDate < b.transactionDate ? -1 : 1;
    }
    const ta = a.transactionTime ?? '00:00';
    const tb = b.transactionTime ?? '00:00';
    if (ta !== tb) return ta < tb ? -1 : 1;
    return a.createdAt < b.createdAt ? -1 : 1;
  });

  let periodInflow = 0n;
  let periodOutflow = 0n;

  for (const tx of inRange) {
    if (tx.type === TransactionType.DEPOSIT) periodInflow += tx.amount;
    else periodOutflow += tx.amount;
  }

  const openingPosition = computeOpeningPositionMulti(
    accounts,
    transactions,
    start,
    accountSet
  );

  const closingPosition = openingPosition + periodInflow - periodOutflow;
  const netChange = periodInflow - periodOutflow;

  const byCategory = computeCategoryBreakdown(inRange, categories);
  const byParty = computePartyBreakdown(inRange, parties);
  const byProject = computeProjectBreakdown(inRange, projects);
  const byAccount = computeAccountBreakdown(inRange, accounts);

  const warnings: ReportWarning[] = [];

  if (inRange.length > 0 && periodInflow === 0n) {
    warnings.push({
      code: ReportWarningCode.NO_INCOME,
      message: 'در این بازه هیچ ورودی ثبت نشده است',
      relatedId: null,
    });
  }

  if (inRange.length > 0 && periodOutflow === 0n) {
    warnings.push({
      code: ReportWarningCode.NO_EXPENSE,
      message: 'در این بازه هیچ خروجی ثبت نشده است',
      relatedId: null,
    });
  }

  if (closingPosition < 0n) {
    warnings.push({
      code: ReportWarningCode.NEGATIVE_BALANCE,
      message: 'موجودی پایان بازه منفی است',
      relatedId: null,
    });
  }

  const lastPreRange = findLastDepositBefore(transactions, start, accountSet);

  if (lastPreRange) {
    warnings.push({
      code: ReportWarningCode.OPENING_BEFORE_RANGE,
      message:
        'این ورودی پیش از آغاز بازه‌ی انتخاب‌شده ثبت شده و مبنای مالی این گزارش است؛ بخشی از هزینه‌های این بازه از همین منبع تأمین شده‌اند.',
      relatedId: lastPreRange.id,
    });
  }

  return {
    start,
    end,
    openingPosition,
    periodInflow,
    periodOutflow,
    closingPosition,
    netChange,
    transactions: inRange,
    byCategory,
    byParty,
    byProject,
    byAccount,
    warnings,
    generatedAt: new Date().toISOString() as ISOTimestamp,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Statistics
// ═══════════════════════════════════════════════════════════════════════════

export interface MonthlyStats {
  inflow: Money;
  outflow: Money;
  count: number;
}

export function getMonthlyStats(
  transactions: readonly Transaction[],
  from: ISODate,
  to: ISODate
): MonthlyStats {
  let inflow = 0n;
  let outflow = 0n;
  let count = 0;

  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.transactionDate < from) continue;
    if (tx.transactionDate > to) continue;
    count += 1;
    if (tx.type === TransactionType.DEPOSIT) inflow += tx.amount;
    else outflow += tx.amount;
  }

  return { inflow, outflow, count };
}

export function getPartyTransactionStats(
  partyId: PartyId,
  transactions: readonly Transaction[]
): { received: Money; paid: Money; count: number } {
  let received = 0n;
  let paid = 0n;
  let count = 0;

  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.partyId !== partyId) continue;
    count += 1;
    if (tx.type === TransactionType.DEPOSIT) received += tx.amount;
    else paid += tx.amount;
  }

  return { received, paid, count };
}

export function getProjectStats(
  projectId: ProjectId,
  transactions: readonly Transaction[]
): { spent: Money; received: Money; count: number } {
  let spent = 0n;
  let received = 0n;
  let count = 0;

  for (const tx of transactions) {
    if (tx.status !== TransactionStatus.ACTIVE) continue;
    if (tx.projectId !== projectId) continue;
    count += 1;
    if (tx.type === TransactionType.EXPENSE) spent += tx.amount;
    else received += tx.amount;
  }

  return { spent, received, count };
}

// ═══════════════════════════════════════════════════════════════════════════
// Predicates
// ═══════════════════════════════════════════════════════════════════════════

export function isIncome(tx: Transaction): boolean {
  return tx.type === TransactionType.DEPOSIT;
}

export function isExpense(tx: Transaction): boolean {
  return tx.type === TransactionType.EXPENSE;
}

export function isActive(tx: Transaction): boolean {
  return tx.status === TransactionStatus.ACTIVE;
}

export function isDeleted(tx: Transaction): boolean {
  return tx.status === TransactionStatus.DELETED;
}

export function hasAttachment(
  tx: Transaction,
  attachments: readonly { transactionId: TransactionId }[]
): boolean {
  for (const a of attachments) {
    if (a.transactionId === tx.id) return true;
  }
  return false;
}

// ═══════════════════════════════════════════════════════════════════════════
// Display code helpers (kept for backward compatibility within domain)
// ═══════════════════════════════════════════════════════════════════════════

export function displayCodeMatchesDate(
  code: DisplayCode,
  date: ISODate,
  devicePrefix: string
): boolean {
  return code.includes(date.replace(/-/g, '').slice(2)) && code.endsWith(devicePrefix);
}

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
