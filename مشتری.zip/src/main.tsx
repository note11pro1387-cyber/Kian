// src/main.tsx

import { StrictMode } from 'react';
import { createRoot } from 'react-dom/client';

import './styles.css';

import { App } from './App';

// ═══════════════════════════════════════════════════════════════════════════
// Mount
// ═══════════════════════════════════════════════════════════════════════════

function mount(): void {
  const container = document.getElementById('root');
  
  if (!container) {
    const fallback = document.createElement('div');
    fallback.id = 'root';
    document.body.appendChild(fallback);
    
    const root = createRoot(fallback);
    root.render(
      <StrictMode>
        <App />
      </StrictMode>
    );
    return;
  }
  
  const root = createRoot(container);
  
  root.render(
    <StrictMode>
      <App />
    </StrictMode>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// Fatal error fallback
// ═══════════════════════════════════════════════════════════════════════════

function renderFatalError(message: string, detail ? : string): void {
  const container = document.getElementById('root');
  if (!container) return;
  
  container.innerHTML = '';
  
  const wrap = document.createElement('div');
  wrap.style.cssText = [
    'min-height:100vh',
    'display:flex',
    'flex-direction:column',
    'align-items:center',
    'justify-content:center',
    'padding:24px',
    'font-family:system-ui,-apple-system,"Segoe UI",Roboto,sans-serif',
    'background:#0b1020',
    'color:#f8fafc',
    'text-align:center',
    'direction:rtl',
    'gap:16px',
  ].join(';');
  
  const title = document.createElement('div');
  title.textContent = message;
  title.style.cssText = 'font-size:20px;font-weight:700;';
  
  wrap.appendChild(title);
  
  if (detail) {
    const desc = document.createElement('div');
    desc.textContent = detail;
    desc.style.cssText =
      'font-size:13px;color:#a8b1c2;max-width:400px;word-break:break-word;';
    wrap.appendChild(desc);
  }
  
  const reload = document.createElement('button');
  reload.textContent = 'تلاش دوباره';
  reload.style.cssText = [
    'padding:12px 24px',
    'border-radius:12px',
    'border:none',
    'background:#8b7cff',
    'color:#fff',
    'font-size:15px',
    'font-weight:600',
    'cursor:pointer',
  ].join(';');
  reload.addEventListener('click', () => {
    window.location.reload();
  });
  
  wrap.appendChild(reload);
  container.appendChild(wrap);
}

window.addEventListener('error', (event) => {
  const root = document.getElementById('root');
  if (root && root.childElementCount === 0) {
    renderFatalError('خطا در راه‌اندازی برنامه', event.message);
  }
});

window.addEventListener('unhandledrejection', (event) => {
  const reason = event.reason;
  const message =
    reason instanceof Error ?
    reason.message :
    typeof reason === 'string' ?
    reason :
    'خطای نامشخص';
  
  console.error('[unhandledrejection]', reason);
  
  const root = document.getElementById('root');
  if (root && root.childElementCount === 0) {
    renderFatalError('خطای غیرمنتظره', message);
  }
});

// ═══════════════════════════════════════════════════════════════════════════
// Entry
// ═══════════════════════════════════════════════════════════════════════════

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', mount, { once: true });
} else {
  mount();
}

if (import.meta.hot) {
  import.meta.hot.accept();
}