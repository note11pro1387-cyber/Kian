// src/store.ts

import { create } from 'zustand';

import type {
  BootPhase,
  BootState,
  Language,
  PerformanceTier,
  ReportFilter,
  Theme,
  ToastKind,
  ToastMessage,
  TransactionFilter,
  ULID,
} from './types';

import {
  getSessionSnapshot,
  subscribeSession,
  requiresRecoveryReset as getRequiresRecoveryReset,
  isPrivacyOverlayActive as getPrivacyOverlayActive,
} from './security';

import { settingsService } from './services';

// ─── DOM helpers ───────────────────────────────────────────────────────

function applyThemeToDom(theme: Theme): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  root.setAttribute('data-theme', theme);
  root.style.colorScheme = theme;
}

function applyLanguageToDom(language: Language): void {
  if (typeof document === 'undefined') return;
  const root = document.documentElement;
  root.setAttribute('lang', language);
  root.setAttribute('dir', language === 'fa' ? 'rtl' : 'ltr');
}

function generateToastId(): ULID {
  const cryptoObj = globalThis.crypto;
  if (cryptoObj && typeof cryptoObj.randomUUID === 'function') {
    return cryptoObj.randomUUID();
  }

  if (cryptoObj && typeof cryptoObj.getRandomValues === 'function') {
    const bytes = new Uint8Array(16);
    cryptoObj.getRandomValues(bytes);
    const byte6 = bytes[6] ?? 0;
    const byte8 = bytes[8] ?? 0;
    bytes[6] = (byte6 & 0x0f) | 0x40;
    bytes[8] = (byte8 & 0x3f) | 0x80;

    return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).reduce(
      (out, byte, index) => {
        const separator = index === 4 || index === 6 || index === 8 || index === 10 ? '-' : '';
        return `${out}${separator}${byte}`;
      },
      ''
    );
  }

  throw new Error('Secure random generator unavailable');
}

// ─── Filters ───────────────────────────────────────────────────────────

export function createEmptyTransactionFilter(): TransactionFilter {
  return {
    types: [],
    accountIds: [],
    partyIds: [],
    projectIds: [],
    categoryIds: [],
    statuses: [],
    dateFrom: null,
    dateTo: null,
    amountMin: null,
    amountMax: null,
    searchQuery: '',
  };
}

// ─── AppStore ──────────────────────────────────────────────────────────

interface AppStoreState {
  theme: Theme;
  language: Language;
  companyName: string | null;
  performanceTier: PerformanceTier;
  onboardingDone: boolean;
  privacyHideAmounts: boolean;
  hydrated: boolean;
  bootState: BootState;
}

interface AppStoreActions {
  setTheme(theme: Theme): void;
  setLanguage(language: Language): void;
  setCompanyName(name: string | null): void;
  setPerformanceTier(tier: PerformanceTier): void;
  setOnboardingDone(done: boolean): void;
  setPrivacyHideAmounts(hide: boolean): void;
  setBootPhase(phase: BootPhase, progress?: number, error?: string | null): void;
  hydrate(): Promise<void>;
}

type AppStore = AppStoreState & AppStoreActions;

const initialBootState: BootState = {
  phase: 'starting',
  progress: 0,
  error: null,
};

export const useAppStore = create<AppStore>((set, get) => ({
  theme: 'dark',
  language: 'fa',
  companyName: null,
  performanceTier: 'P0',
  onboardingDone: false,
  privacyHideAmounts: false,
  hydrated: false,
  bootState: initialBootState,

  setTheme(theme) {
    set({ theme });
    applyThemeToDom(theme);
    void settingsService.setTheme(theme).catch(() => undefined);
  },

  setLanguage(language) {
    set({ language });
    applyLanguageToDom(language);
    void settingsService.setLanguage(language).catch(() => undefined);
  },

  setCompanyName(name) {
    const value = name && name.trim().length > 0 ? name.trim() : null;
    set({ companyName: value });
    if (value === null) return;
    void settingsService.setCompanyName(value).catch(() => undefined);
  },

  setPerformanceTier(tier) {
    set({ performanceTier: tier });
  },

  setOnboardingDone(done) {
    set({ onboardingDone: done });
    if (!done) return;
    void settingsService.setOnboardingDone().catch(() => undefined);
  },

  setPrivacyHideAmounts(hide) {
    set({ privacyHideAmounts: hide });
    void settingsService.setPrivacyHideAmounts(hide).catch(() => undefined);
  },

  setBootPhase(phase, progress, error) {
    const current = get().bootState;
    set({
      bootState: {
        phase,
        progress:
          typeof progress === 'number'
            ? Math.max(0, Math.min(1, progress))
            : current.progress,
        error: error === undefined ? current.error : error,
      },
    });
  },

  async hydrate() {
    try {
      set({ bootState: { phase: 'database', progress: 0.2, error: null } });

      const [theme, language, companyName, onboardingDone, privacyHideAmounts] =
        await Promise.all([
          settingsService.getTheme(),
          settingsService.getLanguage(),
          settingsService.getCompanyName(),
          settingsService.isOnboardingDone(),
          settingsService.getPrivacyHideAmounts(),
        ]);

      set({
        theme,
        language,
        companyName,
        onboardingDone,
        privacyHideAmounts,
        hydrated: true,
        bootState: { phase: 'settings', progress: 0.6, error: null },
      });

      applyThemeToDom(theme);
      applyLanguageToDom(language);
    } catch (e) {
      set({
        hydrated: false,
        bootState: {
          phase: 'failed',
          progress: 0,
          error: e instanceof Error ? e.message : 'خطای بارگذاری تنظیمات',
        },
      });
    }
  },
}));

// ─── UIStore ───────────────────────────────────────────────────────────

export const UI_SHEET = {
  ADD_TRANSACTION: 'add-transaction',
  FILTER_TRANSACTIONS: 'filter-transactions',
  SELECT_ACCOUNT: 'select-account',
  SELECT_PARTY: 'select-party',
  SELECT_CATEGORY: 'select-category',
  SELECT_PROJECT: 'select-project',
  SECURITY_PROMPT: 'security-prompt',
  SETUP_PIN: 'setup-pin',
  SETUP_PATTERN: 'setup-pattern',
  CONFIRM_DELETE: 'confirm-delete',
  CONFIRM_ARCHIVE: 'confirm-archive',
  RESTORE_BACKUP: 'restore-backup',
  ALERT_DETAIL: 'alert-detail',
  IMPORT_MAPPING: 'import-mapping',
  IMPORT_PREVIEW: 'import-preview',
} as const;
export type UISheetName = (typeof UI_SHEET)[keyof typeof UI_SHEET];

export const UI_MODAL = {
  ABOUT: 'about',
  DIAGNOSTICS: 'diagnostics',
  AUDIT_HISTORY: 'audit-history',
  HELP: 'help',
} as const;
export type UIModalName = (typeof UI_MODAL)[keyof typeof UI_MODAL];

interface UIStoreState {
  toasts: ToastMessage[];
  activeSheet: UISheetName | null;
  activeSheetPayload: unknown;
  activeModal: UIModalName | null;
  activeModalPayload: unknown;
}

interface UIStoreActions {
  addToast(input: {
    kind: ToastKind;
    message: string;
    actionLabel?: string | undefined;
    onAction?: (() => void) | undefined;
    durationMs?: number | undefined;
  }): ULID;
  removeToast(id: ULID): void;
  clearToasts(): void;
  openSheet(name: UISheetName, payload?: unknown): void;
  closeSheet(): void;
  openModal(name: UIModalName, payload?: unknown): void;
  closeModal(): void;
}

type UIStore = UIStoreState & UIStoreActions;

const toastTimers = new Map<ULID, ReturnType<typeof setTimeout>>();
const DEFAULT_TOAST_DURATION = 3500;

export const useUIStore = create<UIStore>((set, get) => ({
  toasts: [],
  activeSheet: null,
  activeSheetPayload: null,
  activeModal: null,
  activeModalPayload: null,

  addToast(input) {
    const id = generateToastId();
    const duration = input.durationMs ?? DEFAULT_TOAST_DURATION;

    const toast: ToastMessage = {
      id,
      kind: input.kind,
      message: input.message,
      actionLabel: input.actionLabel,
      onAction: input.onAction,
      durationMs: duration,
    };

    set({ toasts: [...get().toasts, toast] });

    if (duration > 0) {
      const timer = setTimeout(() => {
        toastTimers.delete(id);
        useUIStore.getState().removeToast(id);
      }, duration);
      toastTimers.set(id, timer);
    }

    return id;
  },

  removeToast(id) {
    const timer = toastTimers.get(id);
    if (timer) {
      clearTimeout(timer);
      toastTimers.delete(id);
    }
    set({ toasts: get().toasts.filter((t) => t.id !== id) });
  },

  clearToasts() {
    for (const timer of toastTimers.values()) clearTimeout(timer);
    toastTimers.clear();
    set({ toasts: [] });
  },

  openSheet(name, payload) {
    set({ activeSheet: name, activeSheetPayload: payload ?? null });
  },

  closeSheet() {
    set({ activeSheet: null, activeSheetPayload: null });
  },

  openModal(name, payload) {
    set({ activeModal: name, activeModalPayload: payload ?? null });
  },

  closeModal() {
    set({ activeModal: null, activeModalPayload: null });
  },
}));

// ─── FilterStore ───────────────────────────────────────────────────────

interface FilterStoreState {
  transactionsFilter: TransactionFilter;
  reportsFilter: ReportFilter | null;
}

interface FilterStoreActions {
  setTransactionsFilter(filter: TransactionFilter): void;
  patchTransactionsFilter(patch: Partial<TransactionFilter>): void;
  resetTransactionsFilter(): void;
  setReportsFilter(filter: ReportFilter | null): void;
  resetReportsFilter(): void;
}

type FilterStore = FilterStoreState & FilterStoreActions;

export const useFilterStore = create<FilterStore>((set, get) => ({
  transactionsFilter: createEmptyTransactionFilter(),
  reportsFilter: null,

  setTransactionsFilter(filter) {
    set({ transactionsFilter: filter });
  },

  patchTransactionsFilter(patch) {
    set({ transactionsFilter: { ...get().transactionsFilter, ...patch } });
  },

  resetTransactionsFilter() {
    set({ transactionsFilter: createEmptyTransactionFilter() });
  },

  setReportsFilter(filter) {
    set({ reportsFilter: filter });
  },

  resetReportsFilter() {
    set({ reportsFilter: null });
  },
}));

// ─── SecurityStore ─────────────────────────────────────────────────────

interface SecurityStoreState {
  configured: boolean;
  unlocked: boolean;
  privacyOverlayActive: boolean;
  requiresRecoveryReset: boolean;
  lastActivityAt: number;
}

interface SecurityStoreActions {
  syncFromSession(): void;
  setLocked(locked: boolean): void;
}

type SecurityStore = SecurityStoreState & SecurityStoreActions;

function readSessionSnapshot(): SecurityStoreState {
  const snapshot = getSessionSnapshot();
  return {
    configured: snapshot.configured,
    unlocked: snapshot.unlocked,
    privacyOverlayActive: getPrivacyOverlayActive(),
    requiresRecoveryReset: getRequiresRecoveryReset(),
    lastActivityAt: snapshot.lastActivityAt,
  };
}

export const useSecurityStore = create<SecurityStore>((set) => ({
  ...readSessionSnapshot(),

  syncFromSession() {
    set(readSessionSnapshot());
  },

  setLocked(locked) {
    void (async () => {
      const mod = await import('./security');
      if (locked) {
        await mod.lockApp();
      } else {
        await mod.unlockApp();
      }
    })();
  },
}));

let sessionUnsubscribe: (() => void) | null = null;

export function startSecuritySync(): void {
  if (sessionUnsubscribe) return;
  useSecurityStore.getState().syncFromSession();
  sessionUnsubscribe = subscribeSession(() => {
    useSecurityStore.getState().syncFromSession();
  });
}

export function stopSecuritySync(): void {
  if (!sessionUnsubscribe) return;
  sessionUnsubscribe();
  sessionUnsubscribe = null;
}

// ─── RefreshStore ──────────────────────────────────────────────────────

interface RefreshStoreState {
  dataVersion: number;
  lastMutationAt: number;
  lastMutationEntity: string | null;
}

interface RefreshStoreActions {
  bump(entity?: string): void;
}

type RefreshStore = RefreshStoreState & RefreshStoreActions;

export const useRefreshStore = create<RefreshStore>((set, get) => ({
  dataVersion: 0,
  lastMutationAt: 0,
  lastMutationEntity: null,

  bump(entity) {
    set({
      dataVersion: get().dataVersion + 1,
      lastMutationAt: Date.now(),
      lastMutationEntity: entity ?? null,
    });
  },
}));

// ─── Toast helpers ─────────────────────────────────────────────────────

export const toast = {
  success(
    message: string,
    options?: { actionLabel?: string; onAction?: () => void }
  ): ULID {
    return useUIStore.getState().addToast({
      kind: 'success',
      message,
      actionLabel: options?.actionLabel,
      onAction: options?.onAction,
    });
  },

  error(message: string, options?: { durationMs?: number }): ULID {
    return useUIStore.getState().addToast({
      kind: 'error',
      message,
      durationMs: options?.durationMs ?? 5000,
    });
  },

  info(message: string, options?: { actionLabel?: string; onAction?: () => void }): ULID {
    return useUIStore.getState().addToast({
      kind: 'info',
      message,
      actionLabel: options?.actionLabel,
      onAction: options?.onAction,
    });
  },

  warning(message: string, options?: { durationMs?: number }): ULID {
    return useUIStore.getState().addToast({
      kind: 'warning',
      message,
      durationMs: options?.durationMs ?? 4500,
    });
  },
};

// ─── Boot ──────────────────────────────────────────────────────────────

let bootPromise: Promise<void> | null = null;
let bootCompleted = false;

export function runBootSequence(): Promise<void> {
  if (bootCompleted) return Promise.resolve();
  if (bootPromise) return bootPromise;

  bootPromise = (async () => {
    const app = useAppStore.getState();

    try {
      app.setBootPhase('database', 0.15);

      const { initDatabase } = await import('./db');
      await initDatabase();

      app.setBootPhase('security', 0.5);

      const {
        getProfile,
        isConfigured,
        setSecurityConfigured,
        markUnlocked,
        startSecurityLifecycle,
      } = await import('./security');
      await getProfile();
      const configured = await isConfigured();

      // Establish the authoritative security mode before hydration can expose the UI.
      // A fresh install has no credential and therefore must never be treated as locked.
      setSecurityConfigured(configured);
      if (!configured) {
        markUnlocked();
      }

      // Sync the security store before hydration can publish the ready UI.
      // This prevents a configured database from rendering unlocked for one frame.
      startSecuritySync();

      app.setBootPhase('settings', 0.75);

      await app.hydrate();

      await startSecurityLifecycle();

      app.setBootPhase('ready', 1);

      bootCompleted = true;
    } catch (e) {
      bootCompleted = false;
      app.setBootPhase(
        'failed',
        0,
        e instanceof Error ? e.message : 'خطای راه‌اندازی برنامه'
      );
      throw e;
    }
  })().finally(() => {
    bootPromise = null;
  });

  return bootPromise;
}

export function shutdownStore(): void {
  // React StrictMode performs an extra development-only setup/cleanup cycle.
  // Do not tear down shared security state while the singleton boot is still running.
  if (bootPromise && !bootCompleted) return;

  stopSecuritySync();
  useUIStore.getState().clearToasts();
  void import('./security').then((mod) => {
    mod.stopSecurityLifecycle();
  });
}

// ─── Selectors ─────────────────────────────────────────────────────────

export const selectTheme = (s: AppStore): Theme => s.theme;
export const selectLanguage = (s: AppStore): Language => s.language;
export const selectCompanyName = (s: AppStore): string | null => s.companyName;
export const selectPerformanceTier = (s: AppStore): PerformanceTier => s.performanceTier;
export const selectBootState = (s: AppStore): BootState => s.bootState;
export const selectHydrated = (s: AppStore): boolean => s.hydrated;
export const selectPrivacyHideAmounts = (s: AppStore): boolean => s.privacyHideAmounts;

export const selectActiveSheet = (s: UIStore): UISheetName | null => s.activeSheet;
export const selectActiveSheetPayload = (s: UIStore): unknown => s.activeSheetPayload;
export const selectActiveModal = (s: UIStore): UIModalName | null => s.activeModal;
export const selectToasts = (s: UIStore): ToastMessage[] => s.toasts;

export const selectTransactionsFilter = (s: FilterStore): TransactionFilter =>
  s.transactionsFilter;
export const selectReportsFilter = (s: FilterStore): ReportFilter | null =>
  s.reportsFilter;

export const selectLocked = (s: SecurityStore): boolean => !s.unlocked;
export const selectPrivacyOverlay = (s: SecurityStore): boolean => s.privacyOverlayActive;
export const selectRequiresRecoveryReset = (s: SecurityStore): boolean =>
  s.requiresRecoveryReset;

export const selectDataVersion = (s: RefreshStore): number => s.dataVersion;
