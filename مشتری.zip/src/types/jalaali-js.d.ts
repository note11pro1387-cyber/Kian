// src/types/jalaali-js.d.ts

declare module 'jalaali-js' {
  export interface JalaliDate {
    jy: number;
    jm: number;
    jd: number;
  }

  export interface GregorianDate {
    gy: number;
    gm: number;
    gd: number;
  }

  export function toJalaali(gy: number, gm: number, gd: number): JalaliDate;

  export function toJalaali(date: Date): JalaliDate;

  export function toGregorian(jy: number, jm: number, jd: number): GregorianDate;

  export function isValidJalaaliDate(jy: number, jm: number, jd: number): boolean;

  export function isLeapJalaaliYear(jy: number): boolean;

  export function jalaaliMonthLength(jy: number, jm: number): number;

  export function jalaaliToDateObject(jy: number, jm: number, jd: number): Date;

  export function jalaaliWeek(
    jy: number,
    jm: number,
    jd: number
  ): {
    week: number;
    year: number;
  };

  const jalaali: {
    toJalaali: typeof toJalaali;
    toGregorian: typeof toGregorian;
    isValidJalaaliDate: typeof isValidJalaaliDate;
    isLeapJalaaliYear: typeof isLeapJalaaliYear;
    jalaaliMonthLength: typeof jalaaliMonthLength;
    jalaaliToDateObject: typeof jalaaliToDateObject;
    jalaaliWeek: typeof jalaaliWeek;
  };

  export default jalaali;
}
