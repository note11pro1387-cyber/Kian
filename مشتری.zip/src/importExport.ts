// ============================================================================
//  src/importExport.ts
//  Import از Excel + Export به Excel + Duplicate Engine
// ============================================================================
//
//  ── تغییرات SPEC v2.0 ─────────────────────────────────────────────────
//
//   ۱. `sha256Hex` جایگزین `cyrb53` شد (طبق Change Map #21).
//   ۲. Import از `transactionService.create()` استفاده می‌کند
//      (نه `transactionRepo.create()` مستقیم).
//   ۳. `moneyToExcelNumber` در صورت خارج بودن از Safe Integer خطا می‌دهد
//      (Fail-Fast، بدون truncate).
//   ۴. `AccountStatus.ARCHIVED` و `PartyStatus.ACTIVE` به‌جای boolean.
//   ۵. Audit Events با مقادیر canonical AuditAction.
//   ۶. `ImportRecord` با `rowNumber`, `duplicateScore`, `errorMessage`.
// ============================================================================

import * as XLSX from 'xlsx';
import type { WorkBook, WorkSheet, CellObject, ColInfo } from 'xlsx';

import {
  AccountStatus,
  PartyStatus,
  TransactionType,
  TransactionStatus,
  DuplicateLevel,
  ImportStatus,
  ImportDecision as ImportDecisionValue,
} from './types';

import type {
  Account,
  AccountId,
  Category,
  CategoryId,
  CreateTransactionInput,
  DuplicateScore,
  ImportDecision,
  ImportJobId,
  ISODate,
  Money,
  Party,
  PartyId,
  PeriodReport,
  Project,
  ProjectId,
  Transaction,
} from './types';

import {
  formatMoneyPlain,
  numberToPersianWords,
  normalizeDigits,
  normalizePersianText,
  parseDate,
  toJalali,
  todayISO,
} from './formatters';

import { checkDuplicate } from './domain';

import {
  accountRepo,
  categoryRepo,
  importRepo,
  partyRepo,
  projectRepo,
  transactionRepo,
} from './db';

import { transactionService } from './services';

// ═══════════════════════════════════════════════════════════════════════════
// Constants
// ═══════════════════════════════════════════════════════════════════════════

const SHEET_SUMMARY = 'خلاصه';
const SHEET_TRANSACTIONS = 'تراکنش‌ها';
const SHEET_ACCOUNTS = 'حساب‌ها';
const SHEET_PARTIES = 'اشخاص';
const SHEET_PROJECTS = 'پروژه‌ها';
const SHEET_ERRORS = 'ردیف‌های نامعتبر';
const SHEET_BREAKDOWN_CATEGORY = 'تفکیک بابت';
const SHEET_BREAKDOWN_PARTY = 'تفکیک اشخاص';
const SHEET_BREAKDOWN_PROJECT = 'تفکیک پروژه‌ها';

const AMOUNT_FORMAT = '#,##0 "تومان"';
const NUMBER_FORMAT = '#,##0';
const PERCENT_FORMAT = '0.0%';

const EXCEL_MAX_ROWS = 1_048_576;
const APP_VERSION = '1.0.0';

// ═══════════════════════════════════════════════════════════════════════════
// Column headers
// ═══════════════════════════════════════════════════════════════════════════

const TRANSACTION_HEADERS = [
  'ردیف',
  'کد تراکنش',
  'نوع',
  'مبلغ',
  'مبلغ به حروف',
  'تاریخ',
  'ساعت',
  'حساب',
  'طرف حساب',
  'بابت',
  'پروژه',
  'کد پیگیری',
  'توضیحات',
  'ثبت‌کننده',
  'وضعیت',
] as const;

const ACCOUNT_HEADERS = [
  'نام حساب',
  'نوع',
  'نام بانک',
  'شماره حساب',
  'شماره کارت',
  'موجودی اولیه',
  'ورودی کل',
  'خروجی کل',
  'موجودی فعلی',
  'تعداد تراکنش',
  'وضعیت',
] as const;

const PARTY_HEADERS = [
  'نام',
  'نوع',
  'نقش',
  'تلفن',
  'شماره کارت',
  'دریافت کل',
  'پرداخت کل',
  'تعداد تراکنش',
  'وضعیت',
] as const;

const PROJECT_HEADERS = [
  'نام پروژه',
  'کد',
  'وضعیت',
  'بودجه',
  'هزینه‌شده',
  'باقی‌مانده',
  'درصد مصرف',
  'تعداد تراکنش',
] as const;

const ERROR_HEADERS = ['شماره ردیف', 'خطا', 'ردیف خام'] as const;

// ═══════════════════════════════════════════════════════════════════════════
// SHA-256 hashing
// ═══════════════════════════════════════════════════════════════════════════

/**
 * SHA-256 هش به‌صورت hex.
 *
 * طبق SPEC v2.0 §۵: برای Row Hash از SHA-256 استفاده می‌شود، نه hash سبک.
 */
async function sha256Hex(input: string): Promise<string> {
  const cryptoObj = globalThis.crypto;
  if (!cryptoObj?.subtle) {
    throw new Error('Web Crypto API unavailable for SHA-256');
  }

  const data = new TextEncoder().encode(input);
  const digest = await cryptoObj.subtle.digest('SHA-256', data);
  const bytes = new Uint8Array(digest);

  return Array.from(bytes, (byte) => byte.toString(16).padStart(2, '0')).join('');
}

async function computeRowHash(
  parts: readonly (string | null | undefined)[]
): Promise<string> {
  const normalized = parts
    .map((p) => (p === null || p === undefined ? '' : normalizePersianText(String(p))))
    .join('\u0001');
  return sha256Hex(normalized);
}

// ═══════════════════════════════════════════════════════════════════════════
// Money conversion for Excel — Fail-Fast
// ═══════════════════════════════════════════════════════════════════════════

/**
 * تبدیل Money به number برای سلول Excel.
 *
 * طبق SPEC v2.0 §۶ و Change Map #23: اگر مبلغ از Safe Integer خارج باشد،
 * باید خطا داده شود، نه truncate خاموش.
 */
function moneyToExcelNumber(m: Money): number {
  const n = Number(m);
  if (!Number.isSafeInteger(n)) {
    throw new Error(
      `مبلغ ${formatMoneyPlain(m)} تومان از محدوده‌ی عددی امن Excel خارج است و نمی‌تواند به‌صورت عددی خروجی داده شود.`
    );
  }
  return n;
}

function parseMoneyFromCell(value: unknown): Money | null {
  if (value === null || value === undefined) return null;

  if (typeof value === 'number') {
    if (!Number.isFinite(value)) return null;
    const rounded = Math.round(value);
    if (!Number.isSafeInteger(rounded)) return null;
    return BigInt(rounded);
  }

  if (typeof value === 'bigint') return value;

  if (typeof value === 'string') {
    const cleaned = normalizeDigits(value)
      .replace(/[تومانریال,،\s]/g, '')
      .trim();
    if (!cleaned) return null;
    if (!/^-?\d+$/.test(cleaned)) return null;
    try {
      return BigInt(cleaned);
    } catch {
      return null;
    }
  }

  return null;
}

function parseDateFromCell(value: unknown): ISODate | null {
  if (value === null || value === undefined) return null;

  if (typeof value === 'string') {
    return parseDate(value.trim());
  }

  if (typeof value === 'number') {
    const parsed = XLSX.SSF.parse_date_code(value);
    if (!parsed) return null;
    const y = parsed.y;
    const m = parsed.m < 10 ? `0${parsed.m}` : String(parsed.m);
    const d = parsed.d < 10 ? `0${parsed.d}` : String(parsed.d);
    return `${y}-${m}-${d}`;
  }

  if (value instanceof Date) {
    const y = value.getUTCFullYear();
    const m = value.getUTCMonth() + 1;
    const d = value.getUTCDate();
    const mm = m < 10 ? `0${m}` : String(m);
    const dd = d < 10 ? `0${d}` : String(d);
    return `${y}-${mm}-${dd}`;
  }

  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Column widths + header styling
// ═══════════════════════════════════════════════════════════════════════════

function buildColumnWidths(widths: readonly number[]): ColInfo[] {
  return widths.map((wch) => ({ wch }));
}

function applyHeaderRow(ws: WorkSheet, headers: readonly string[]): void {
  for (let c = 0; c < headers.length; c++) {
    const addr = XLSX.utils.encode_cell({ r: 0, c });
    const cell = ws[addr] as CellObject | undefined;
    if (cell) {
      cell.s = {
        font: { bold: true },
        fill: { fgColor: { rgb: 'EEF2FF' } },
        alignment: { horizontal: 'center', vertical: 'center' },
      };
    }
  }
}

function applyAmountFormat(ws: WorkSheet, columnIndex: number, rowCount: number): void {
  for (let r = 1; r <= rowCount; r++) {
    const addr = XLSX.utils.encode_cell({ r, c: columnIndex });
    const cell = ws[addr] as CellObject | undefined;
    if (cell && typeof cell.v === 'number') {
      cell.z = AMOUNT_FORMAT;
    }
  }
}

function applyNumberFormat(
  ws: WorkSheet,
  columnIndex: number,
  rowCount: number,
  format: string = NUMBER_FORMAT
): void {
  for (let r = 1; r <= rowCount; r++) {
    const addr = XLSX.utils.encode_cell({ r, c: columnIndex });
    const cell = ws[addr] as CellObject | undefined;
    if (cell && typeof cell.v === 'number') {
      cell.z = format;
    }
  }
}

// ═══════════════════════════════════════════════════════════════════════════
// Export context
// ═══════════════════════════════════════════════════════════════════════════

export interface ExportContext {
  accounts: readonly Account[];
  parties: readonly Party[];
  projects: readonly Project[];
  categories: readonly Category[];
}

// ═══════════════════════════════════════════════════════════════════════════
// Export: Transactions sheet
// ═══════════════════════════════════════════════════════════════════════════

function buildTransactionRows(
  transactions: readonly Transaction[],
  context: ExportContext
): (string | number)[][] {
  const accountIndex = new Map<AccountId, Account>();
  for (const a of context.accounts) accountIndex.set(a.id, a);

  const partyIndex = new Map<PartyId, Party>();
  for (const p of context.parties) partyIndex.set(p.id, p);

  const projectIndex = new Map<ProjectId, Project>();
  for (const p of context.projects) projectIndex.set(p.id, p);

  const categoryIndex = new Map<CategoryId, Category>();
  for (const c of context.categories) categoryIndex.set(c.id, c);

  const rows: (string | number)[][] = [];

  for (let i = 0; i < transactions.length; i++) {
    const tx = transactions[i]!;
    const account = accountIndex.get(tx.accountId);
    const party = tx.partyId ? partyIndex.get(tx.partyId) : null;
    const project = tx.projectId ? projectIndex.get(tx.projectId) : null;
    const category = tx.categoryId ? categoryIndex.get(tx.categoryId) : null;

    const categoryLabel = tx.customCategoryText ?? (category ? category.name : '');
    const jalaliDate = toJalali(tx.transactionDate);

    rows.push([
      i + 1,
      tx.displayCode,
      tx.type === TransactionType.DEPOSIT ? 'دریافت' : 'پرداخت',
      moneyToExcelNumber(tx.amount),
      numberToPersianWords(tx.amount),
      jalaliDate,
      tx.transactionTime ?? '',
      account?.name ?? '',
      party?.name ?? '',
      categoryLabel,
      project?.name ?? '',
      tx.referenceCode ?? '',
      tx.description ?? '',
      tx.createdBy ?? '',
      tx.status === TransactionStatus.ACTIVE ? 'فعال' : 'حذف‌شده',
    ]);
  }

  return rows;
}

export function buildTransactionsSheet(
  transactions: readonly Transaction[],
  context: ExportContext
): WorkSheet {
  const aoa: (string | number)[][] = [
    [...TRANSACTION_HEADERS],
    ...buildTransactionRows(transactions, context),
  ];

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([
    6, 26, 10, 16, 30, 14, 8, 18, 20, 18, 18, 16, 40, 14, 10,
  ]);

  applyHeaderRow(ws, TRANSACTION_HEADERS);
  applyAmountFormat(ws, 3, transactions.length);
  applyNumberFormat(ws, 0, transactions.length);

  const lastRow = transactions.length + 1;
  const lastCol = TRANSACTION_HEADERS.length - 1;
  const ref = `${XLSX.utils.encode_cell({ r: 0, c: 0 })}:${XLSX.utils.encode_cell({
    r: lastRow,
    c: lastCol,
  })}`;
  ws['!autofilter'] = { ref };

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════════
// Export: Accounts sheet
// ═══════════════════════════════════════════════════════════════════════════

export interface AccountExportRow {
  account: Account;
  totalInflow: Money;
  totalOutflow: Money;
  balance: Money;
  transactionCount: number;
}

function translateAccountType(type: string): string {
  switch (type) {
    case 'bank':
      return 'بانکی';
    case 'cash':
      return 'صندوق نقدی';
    case 'card':
      return 'کارت';
    case 'treasury':
      return 'تنخواه';
    default:
      return type;
  }
}

function buildAccountsSheet(rows: readonly AccountExportRow[]): WorkSheet {
  const aoa: (string | number)[][] = [[...ACCOUNT_HEADERS]];

  for (const row of rows) {
    aoa.push([
      row.account.name,
      translateAccountType(row.account.type),
      row.account.bankName ?? '',
      row.account.accountNumber ?? '',
      row.account.cardNumber ?? '',
      moneyToExcelNumber(row.account.openingBalance),
      moneyToExcelNumber(row.totalInflow),
      moneyToExcelNumber(row.totalOutflow),
      moneyToExcelNumber(row.balance),
      row.transactionCount,
      row.account.status === AccountStatus.ACTIVE ? 'فعال' : 'آرشیو',
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([22, 12, 16, 20, 20, 18, 18, 18, 20, 14, 10]);

  applyHeaderRow(ws, ACCOUNT_HEADERS);
  applyAmountFormat(ws, 5, rows.length);
  applyAmountFormat(ws, 6, rows.length);
  applyAmountFormat(ws, 7, rows.length);
  applyAmountFormat(ws, 8, rows.length);
  applyNumberFormat(ws, 9, rows.length);

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════════
// Export: Parties sheet
// ═══════════════════════════════════════════════════════════════════════════

export interface PartyExportRow {
  party: Party;
  received: Money;
  paid: Money;
  transactionCount: number;
}

function translatePartyRole(role: string | null): string {
  if (!role) return '';
  switch (role) {
    case 'contractor':
      return 'پیمانکار';
    case 'employee':
      return 'کارمند';
    case 'customer':
      return 'مشتری';
    case 'supplier':
      return 'تأمین‌کننده';
    case 'other':
      return 'سایر';
    default:
      return role;
  }
}

function buildPartiesSheet(rows: readonly PartyExportRow[]): WorkSheet {
  const aoa: (string | number)[][] = [[...PARTY_HEADERS]];

  for (const row of rows) {
    aoa.push([
      row.party.name,
      row.party.type === 'person' ? 'شخص' : 'شرکت',
      translatePartyRole(row.party.role),
      row.party.phone ?? '',
      row.party.cardNumber ?? '',
      moneyToExcelNumber(row.received),
      moneyToExcelNumber(row.paid),
      row.transactionCount,
      row.party.status === PartyStatus.ACTIVE ? 'فعال' : 'غیرفعال',
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([24, 10, 14, 18, 20, 18, 18, 14, 10]);

  applyHeaderRow(ws, PARTY_HEADERS);
  applyAmountFormat(ws, 5, rows.length);
  applyAmountFormat(ws, 6, rows.length);
  applyNumberFormat(ws, 7, rows.length);

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════════
// Export: Projects sheet
// ═══════════════════════════════════════════════════════════════════════════

export interface ProjectExportRow {
  project: Project;
  spent: Money;
  received: Money;
  remainingBudget: Money | null;
  utilization: number | null;
  transactionCount: number;
}

function translateProjectStatus(status: string): string {
  switch (status) {
    case 'active':
      return 'فعال';
    case 'done':
      return 'پایان‌یافته';
    case 'paused':
      return 'متوقف';
    case 'archived':
      return 'آرشیو';
    default:
      return status;
  }
}

function buildProjectsSheet(rows: readonly ProjectExportRow[]): WorkSheet {
  const aoa: (string | number)[][] = [[...PROJECT_HEADERS]];

  for (const row of rows) {
    aoa.push([
      row.project.name,
      row.project.code ?? '',
      translateProjectStatus(row.project.status),
      row.project.budgetAmount === null
        ? ''
        : moneyToExcelNumber(row.project.budgetAmount),
      moneyToExcelNumber(row.spent),
      row.remainingBudget === null ? '' : moneyToExcelNumber(row.remainingBudget),
      row.utilization === null ? '' : row.utilization,
      row.transactionCount,
    ]);
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([24, 12, 12, 18, 18, 18, 12, 14]);

  applyHeaderRow(ws, PROJECT_HEADERS);
  applyAmountFormat(ws, 3, rows.length);
  applyAmountFormat(ws, 4, rows.length);
  applyAmountFormat(ws, 5, rows.length);
  applyNumberFormat(ws, 6, rows.length, PERCENT_FORMAT);
  applyNumberFormat(ws, 7, rows.length);

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════════
// Export: Summary sheet
// ═══════════════════════════════════════════════════════════════════════════

function buildSummarySheet(report: PeriodReport): WorkSheet {
  const aoa: (string | number)[][] = [
    ['گزارش مالی'],
    [],
    ['از تاریخ', toJalali(report.start)],
    ['تا تاریخ', toJalali(report.end)],
    ['تولید گزارش در', report.generatedAt],
    [],
    ['موجودی ابتدای دوره', moneyToExcelNumber(report.openingPosition)],
    ['مجموع ورودی‌ها', moneyToExcelNumber(report.periodInflow)],
    ['مجموع خروجی‌ها', moneyToExcelNumber(report.periodOutflow)],
    ['خالص تغییر', moneyToExcelNumber(report.netChange)],
    ['موجودی پایان دوره', moneyToExcelNumber(report.closingPosition)],
    [],
  ];

  if (report.warnings.length > 0) {
    aoa.push(['هشدارها']);
    for (const w of report.warnings) {
      aoa.push(['', w.message]);
    }
    aoa.push([]);
  }

  if (report.byCategory.length > 0) {
    aoa.push(['تفکیک بابت', 'مجموع', 'تعداد']);
    for (const c of report.byCategory) {
      aoa.push([c.name, moneyToExcelNumber(c.total), c.count]);
    }
    aoa.push([]);
  }

  if (report.byParty.length > 0) {
    aoa.push(['تفکیک اشخاص', 'مجموع', 'تعداد']);
    for (const p of report.byParty) {
      aoa.push([p.name, moneyToExcelNumber(p.total), p.count]);
    }
    aoa.push([]);
  }

  if (report.byProject.length > 0) {
    aoa.push(['تفکیک پروژه‌ها', 'مجموع', 'تعداد']);
    for (const p of report.byProject) {
      aoa.push([p.name, moneyToExcelNumber(p.total), p.count]);
    }
    aoa.push([]);
  }

  if (report.byAccount.length > 0) {
    aoa.push(['تفکیک حساب‌ها', 'مجموع', 'تعداد']);
    for (const a of report.byAccount) {
      aoa.push([a.name, moneyToExcelNumber(a.total), a.count]);
    }
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([26, 24, 14]);

  for (let r = 0; r < aoa.length; r++) {
    const row = aoa[r];
    if (!row) continue;
    if (row.length >= 2 && typeof row[1] === 'number' && r >= 6 && r <= 10) {
      const addr = XLSX.utils.encode_cell({ r, c: 1 });
      const cell = ws[addr] as CellObject | undefined;
      if (cell) cell.z = AMOUNT_FORMAT;
    }
  }

  return ws;
}

// ═══════════════════════════════════════════════════════════════════════════
// Public: exportReport
// ═══════════════════════════════════════════════════════════════════════════

export interface ExportOptions {
  includeAccounts?: boolean;
  includeParties?: boolean;
  includeProjects?: boolean;
  includeBreakdowns?: boolean;
}

export interface ExportResult {
  data: Uint8Array;
  fileName: string;
  mimeType: string;
  rowCount: number;
}

export async function exportReport(
  report: PeriodReport,
  context: ExportContext,
  options: ExportOptions = {}
): Promise<ExportResult> {
  const wb: WorkBook = XLSX.utils.book_new();

  const summaryWs = buildSummarySheet(report);
  XLSX.utils.book_append_sheet(wb, summaryWs, SHEET_SUMMARY);

  const txWs = buildTransactionsSheet(report.transactions, context);
  XLSX.utils.book_append_sheet(wb, txWs, SHEET_TRANSACTIONS);

  if (options.includeBreakdowns) {
    if (report.byCategory.length > 0) {
      const aoa: (string | number)[][] = [['بابت', 'مجموع', 'تعداد']];
      for (const c of report.byCategory) {
        aoa.push([c.name, moneyToExcelNumber(c.total), c.count]);
      }
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      ws['!cols'] = buildColumnWidths([30, 20, 10]);
      applyHeaderRow(ws, ['بابت', 'مجموع', 'تعداد']);
      applyAmountFormat(ws, 1, report.byCategory.length);
      XLSX.utils.book_append_sheet(wb, ws, SHEET_BREAKDOWN_CATEGORY);
    }

    if (report.byParty.length > 0) {
      const aoa: (string | number)[][] = [['طرف حساب', 'مجموع', 'تعداد']];
      for (const p of report.byParty) {
        aoa.push([p.name, moneyToExcelNumber(p.total), p.count]);
      }
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      ws['!cols'] = buildColumnWidths([30, 20, 10]);
      applyHeaderRow(ws, ['طرف حساب', 'مجموع', 'تعداد']);
      applyAmountFormat(ws, 1, report.byParty.length);
      XLSX.utils.book_append_sheet(wb, ws, SHEET_BREAKDOWN_PARTY);
    }

    if (report.byProject.length > 0) {
      const aoa: (string | number)[][] = [['پروژه', 'مجموع', 'تعداد']];
      for (const p of report.byProject) {
        aoa.push([p.name, moneyToExcelNumber(p.total), p.count]);
      }
      const ws = XLSX.utils.aoa_to_sheet(aoa);
      ws['!cols'] = buildColumnWidths([30, 20, 10]);
      applyHeaderRow(ws, ['پروژه', 'مجموع', 'تعداد']);
      applyAmountFormat(ws, 1, report.byProject.length);
      XLSX.utils.book_append_sheet(wb, ws, SHEET_BREAKDOWN_PROJECT);
    }
  }

  const data = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });

  const fileName = `Financial_Report_${report.start}_to_${report.end}.xlsx`;

  return {
    data: data instanceof Uint8Array ? data : new Uint8Array(data),
    fileName,
    mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    rowCount: report.transactions.length,
  };
}

export async function exportFullWorkbook(
  context: ExportContext,
  accountRows: readonly AccountExportRow[],
  partyRows: readonly PartyExportRow[],
  projectRows: readonly ProjectExportRow[],
  transactions: readonly Transaction[]
): Promise<ExportResult> {
  const wb: WorkBook = XLSX.utils.book_new();

  XLSX.utils.book_append_sheet(wb, buildAccountsSheet(accountRows), SHEET_ACCOUNTS);
  XLSX.utils.book_append_sheet(wb, buildPartiesSheet(partyRows), SHEET_PARTIES);
  XLSX.utils.book_append_sheet(wb, buildProjectsSheet(projectRows), SHEET_PROJECTS);
  XLSX.utils.book_append_sheet(
    wb,
    buildTransactionsSheet(transactions, context),
    SHEET_TRANSACTIONS
  );

  const data = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });

  const today = todayISO().replace(/-/g, '-');
  const fileName = `Financial_Full_${today}.xlsx`;

  return {
    data: data instanceof Uint8Array ? data : new Uint8Array(data),
    fileName,
    mimeType: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    rowCount: transactions.length,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Parsing
// ═══════════════════════════════════════════════════════════════════════════

export interface ParsedSheet {
  sheetName: string;
  headers: string[];
  rows: unknown[][];
  totalRows: number;
}

export async function parseExcelFile(
  fileContent: ArrayBuffer | Uint8Array
): Promise<ParsedSheet> {
  const data =
    fileContent instanceof Uint8Array ? fileContent : new Uint8Array(fileContent);

  const wb = XLSX.read(data, { type: 'array', cellDates: true, cellNF: false });

  if (wb.SheetNames.length === 0) {
    throw new Error('فایل اکسل خالی است');
  }

  const firstSheetName = wb.SheetNames[0]!;
  const ws = wb.Sheets[firstSheetName];

  if (!ws) {
    throw new Error('شیت اصلی فایل خوانده نشد');
  }

  const aoa = XLSX.utils.sheet_to_json<unknown[]>(ws, {
    header: 1,
    raw: true,
    defval: null,
    blankrows: false,
  });

  if (aoa.length === 0) {
    throw new Error('فایل شامل هیچ ردیفی نیست');
  }

  let headerRowIndex = -1;
  for (let i = 0; i < Math.min(aoa.length, 10); i++) {
    const row = aoa[i];
    if (!row) continue;
    const nonEmpty = row.filter(
      (c) => c !== null && c !== undefined && String(c).trim() !== ''
    );
    if (nonEmpty.length >= 2) {
      headerRowIndex = i;
      break;
    }
  }

  if (headerRowIndex < 0) {
    throw new Error('ردیف سرستون پیدا نشد');
  }

  const rawHeaders = aoa[headerRowIndex] ?? [];
  const headers = rawHeaders.map((h, i) => {
    if (h === null || h === undefined) return `ستون ${i + 1}`;
    const s = String(h).trim();
    return s.length > 0 ? s : `ستون ${i + 1}`;
  });

  const rows = aoa.slice(headerRowIndex + 1).filter((row) => {
    if (!row) return false;
    return row.some((c) => c !== null && c !== undefined && String(c).trim() !== '');
  });

  return {
    sheetName: firstSheetName,
    headers,
    rows,
    totalRows: rows.length,
  };
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Column mapping
// ═══════════════════════════════════════════════════════════════════════════

export const IMPORT_FIELD = {
  AMOUNT: 'amount',
  TYPE: 'type',
  DATE: 'date',
  TIME: 'time',
  ACCOUNT: 'account',
  PARTY: 'party',
  CATEGORY: 'category',
  PROJECT: 'project',
  REFERENCE: 'reference',
  DESCRIPTION: 'description',
  IGNORE: '__ignore__',
} as const;

export type ImportField = (typeof IMPORT_FIELD)[keyof typeof IMPORT_FIELD];

const FIELD_LABELS: Record<ImportField, string> = {
  amount: 'مبلغ',
  type: 'نوع (دریافت/پرداخت)',
  date: 'تاریخ',
  time: 'ساعت',
  account: 'حساب',
  party: 'طرف حساب',
  category: 'بابت',
  project: 'پروژه',
  reference: 'کد پیگیری',
  description: 'توضیحات',
  __ignore__: 'نادیده بگیر',
};

const FIELD_SYNONYMS: Record<ImportField, string[]> = {
  amount: ['مبلغ', 'amount', 'مقدار', 'value', 'price', 'قیمت', 'مبلغ تراکنش'],
  type: ['نوع', 'type', 'نوع تراکنش', 'دریافت یا پرداخت', 'واریز یا خرج'],
  date: ['تاریخ', 'date', 'روز', 'تاریخ تراکنش'],
  time: ['ساعت', 'time', 'زمان'],
  account: ['حساب', 'account', 'بانک', 'bank', 'شماره حساب'],
  party: [
    'طرف حساب',
    'شخص',
    'party',
    'name',
    'نام',
    'دریافت‌کننده',
    'پرداخت‌کننده',
    'گیرنده',
  ],
  category: ['بابت', 'دسته', 'category', 'نوع هزینه', 'شرح'],
  project: ['پروژه', 'project', 'کار'],
  reference: ['کد پیگیری', 'reference', 'شماره پیگیری', 'پیگیری', 'شماره سند'],
  description: ['توضیحات', 'description', 'شرح', 'توضیح', 'note', 'یادداشت'],
  __ignore__: [],
};

function normalizeHeader(header: string): string {
  return normalizePersianText(header)
    .replace(/[()\[\]{}:،,]/g, '')
    .trim();
}

export function suggestColumnMapping(
  headers: readonly string[]
): Record<number, ImportField> {
  const mapping: Record<number, ImportField> = {};
  const usedFields = new Set<ImportField>();

  for (let i = 0; i < headers.length; i++) {
    const normalized = normalizeHeader(headers[i]!);
    let bestMatch: ImportField = IMPORT_FIELD.IGNORE;
    let bestScore = 0;

    for (const field of Object.keys(FIELD_SYNONYMS) as ImportField[]) {
      if (field === IMPORT_FIELD.IGNORE) continue;
      if (usedFields.has(field)) continue;

      for (const syn of FIELD_SYNONYMS[field]) {
        const normalizedSyn = normalizePersianText(syn);
        if (normalized === normalizedSyn) {
          bestMatch = field;
          bestScore = 100;
          break;
        }
        if (normalized.includes(normalizedSyn) || normalizedSyn.includes(normalized)) {
          const score =
            (Math.min(normalized.length, normalizedSyn.length) /
              Math.max(normalized.length, normalizedSyn.length)) *
            80;
          if (score > bestScore) {
            bestScore = score;
            bestMatch = field;
          }
        }
      }
    }

    if (bestScore >= 40) {
      mapping[i] = bestMatch;
      usedFields.add(bestMatch);
    } else {
      mapping[i] = IMPORT_FIELD.IGNORE;
    }
  }

  return mapping;
}

export function getFieldLabel(field: ImportField): string {
  return FIELD_LABELS[field];
}

export function getAllFields(): ImportField[] {
  return [
    IMPORT_FIELD.AMOUNT,
    IMPORT_FIELD.TYPE,
    IMPORT_FIELD.DATE,
    IMPORT_FIELD.TIME,
    IMPORT_FIELD.ACCOUNT,
    IMPORT_FIELD.PARTY,
    IMPORT_FIELD.CATEGORY,
    IMPORT_FIELD.PROJECT,
    IMPORT_FIELD.REFERENCE,
    IMPORT_FIELD.DESCRIPTION,
    IMPORT_FIELD.IGNORE,
  ];
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Type detection
// ═══════════════════════════════════════════════════════════════════════════

const DEPOSIT_KEYWORDS = ['دریافت', 'واریز', 'deposit', 'credit', 'income', 'ورودی', '+'];
const EXPENSE_KEYWORDS = [
  'پرداخت',
  'خرج',
  'expense',
  'debit',
  'outcome',
  'خروجی',
  'هزینه',
  '-',
];

function detectTransactionType(raw: unknown): TransactionType | null {
  if (raw === null || raw === undefined) return null;
  const text = normalizePersianText(String(raw));

  for (const kw of DEPOSIT_KEYWORDS) {
    if (text.includes(normalizePersianText(kw))) return TransactionType.DEPOSIT;
  }
  for (const kw of EXPENSE_KEYWORDS) {
    if (text.includes(normalizePersianText(kw))) return TransactionType.EXPENSE;
  }

  const num = Number(normalizeDigits(String(raw)));
  if (Number.isFinite(num)) {
    if (num > 0) return TransactionType.DEPOSIT;
    if (num < 0) return TransactionType.EXPENSE;
  }

  return null;
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Entity resolution
// ═══════════════════════════════════════════════════════════════════════════

interface ResolverIndex {
  accountsByName: Map<string, Account>;
  partiesByName: Map<string, Party>;
  projectsByName: Map<string, Project>;
  categoriesByName: Map<string, Category>;
}

function buildResolverIndex(
  accounts: readonly Account[],
  parties: readonly Party[],
  projects: readonly Project[],
  categories: readonly Category[]
): ResolverIndex {
  const accountsByName = new Map<string, Account>();
  for (const a of accounts) {
    accountsByName.set(normalizePersianText(a.name), a);
  }

  const partiesByName = new Map<string, Party>();
  for (const p of parties) {
    partiesByName.set(normalizePersianText(p.name), p);
  }

  const projectsByName = new Map<string, Project>();
  for (const p of projects) {
    projectsByName.set(normalizePersianText(p.name), p);
  }

  const categoriesByName = new Map<string, Category>();
  for (const c of categories) {
    categoriesByName.set(normalizePersianText(c.name), c);
  }

  return { accountsByName, partiesByName, projectsByName, categoriesByName };
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Preview
// ═══════════════════════════════════════════════════════════════════════════

export interface ImportPreviewRow {
  rowIndex: number;
  rawRow: unknown[];
  parsed: {
    type: TransactionType | null;
    amount: Money | null;
    date: ISODate | null;
    time: string | null;
    accountId: AccountId | null;
    accountName: string | null;
    partyId: PartyId | null;
    partyName: string | null;
    categoryId: CategoryId | null;
    categoryName: string | null;
    projectId: ProjectId | null;
    projectName: string | null;
    referenceCode: string | null;
    description: string | null;
  };
  decision: ImportDecision;
  duplicate: DuplicateScore | null;
  errors: string[];
  rowHash: string;
}

export interface ImportPreviewResult {
  rows: ImportPreviewRow[];
  stats: {
    total: number;
    valid: number;
    invalid: number;
    exact: number;
    likely: number;
    possible: number;
    unique: number;
  };
}

export async function buildPreview(
  sheet: ParsedSheet,
  mapping: Record<number, ImportField>
): Promise<ImportPreviewResult> {
  const [accounts, parties, projects, categories, existingTransactions] =
    await Promise.all([
      accountRepo.list(true),
      partyRepo.list(true),
      projectRepo.list(),
      categoryRepo.list(true),
      transactionRepo.listActive(),
    ]);

  const resolver = buildResolverIndex(accounts, parties, projects, categories);

  const headerIndexByField = new Map<ImportField, number>();
  for (const [colIdxStr, field] of Object.entries(mapping)) {
    if (field === IMPORT_FIELD.IGNORE) continue;
    if (headerIndexByField.has(field)) continue;
    headerIndexByField.set(field, Number(colIdxStr));
  }

  const rows: ImportPreviewRow[] = [];
  const stats = {
    total: 0,
    valid: 0,
    invalid: 0,
    exact: 0,
    likely: 0,
    possible: 0,
    unique: 0,
  };

  for (let i = 0; i < sheet.rows.length && i < EXCEL_MAX_ROWS; i++) {
    const raw = sheet.rows[i] ?? [];
    const errors: string[] = [];

    const amountCol = headerIndexByField.get(IMPORT_FIELD.AMOUNT);
    const typeCol = headerIndexByField.get(IMPORT_FIELD.TYPE);
    const dateCol = headerIndexByField.get(IMPORT_FIELD.DATE);
    const timeCol = headerIndexByField.get(IMPORT_FIELD.TIME);
    const accountCol = headerIndexByField.get(IMPORT_FIELD.ACCOUNT);
    const partyCol = headerIndexByField.get(IMPORT_FIELD.PARTY);
    const categoryCol = headerIndexByField.get(IMPORT_FIELD.CATEGORY);
    const projectCol = headerIndexByField.get(IMPORT_FIELD.PROJECT);
    const referenceCol = headerIndexByField.get(IMPORT_FIELD.REFERENCE);
    const descriptionCol = headerIndexByField.get(IMPORT_FIELD.DESCRIPTION);

    let amount: Money | null = null;
    if (amountCol !== undefined) {
      amount = parseMoneyFromCell(raw[amountCol]);
      if (amount === null) {
        errors.push('مبلغ نامعتبر یا خالی');
      } else if (amount < 0n) {
        amount = -amount;
      } else if (amount === 0n) {
        errors.push('مبلغ صفر');
      }
    } else {
      errors.push('ستون مبلغ در نگاشت تعیین نشده');
    }

    let type: TransactionType | null = null;
    if (typeCol !== undefined) {
      type = detectTransactionType(raw[typeCol]);
      if (type === null) {
        errors.push('نوع تراکنش مشخص نشد');
      }
    } else {
      const rawAmount = amountCol !== undefined ? raw[amountCol] : null;
      if (typeof rawAmount === 'number' && rawAmount < 0) {
        type = TransactionType.EXPENSE;
      } else {
        type = TransactionType.DEPOSIT;
      }
    }

    let date: ISODate | null = null;
    if (dateCol !== undefined) {
      date = parseDateFromCell(raw[dateCol]);
      if (date === null) {
        errors.push('تاریخ نامعتبر');
      }
    } else {
      errors.push('ستون تاریخ در نگاشت تعیین نشده');
    }

    let time: string | null = null;
    if (timeCol !== undefined) {
      const rawTime = raw[timeCol];
      if (rawTime !== null && rawTime !== undefined) {
        const cleanedTime = normalizeDigits(String(rawTime)).trim();
        if (/^([01][0-9]|2[0-3]):[0-5][0-9]$/.test(cleanedTime)) {
          time = cleanedTime;
        } else if (/^\d{1,2}:\d{2}/.test(cleanedTime)) {
          const parts = cleanedTime.split(':');
          const h = parts[0]!.padStart(2, '0');
          const m = parts[1]!.slice(0, 2);
          if (/^([01][0-9]|2[0-3])$/.test(h) && /^[0-5][0-9]$/.test(m)) {
            time = `${h}:${m}`;
          }
        }
      }
    }

    let accountId: AccountId | null = null;
    let accountName: string | null = null;
    if (accountCol !== undefined) {
      const rawAccount = raw[accountCol];
      if (rawAccount !== null && rawAccount !== undefined) {
        const name = String(rawAccount).trim();
        accountName = name;
        const found = resolver.accountsByName.get(normalizePersianText(name));
        if (found) accountId = found.id;
        else errors.push(`حساب «${name}» یافت نشد`);
      }
    }

    let partyId: PartyId | null = null;
    let partyName: string | null = null;
    if (partyCol !== undefined) {
      const rawParty = raw[partyCol];
      if (rawParty !== null && rawParty !== undefined) {
        const name = String(rawParty).trim();
        if (name) {
          partyName = name;
          const found = resolver.partiesByName.get(normalizePersianText(name));
          if (found) partyId = found.id;
        }
      }
    }

    if (type === TransactionType.EXPENSE && !partyId) {
      if (partyName) {
        errors.push(`طرف حساب «${partyName}» یافت نشد`);
      } else {
        errors.push('برای پرداخت، طرف حساب الزامی است');
      }
    }

    let categoryId: CategoryId | null = null;
    let categoryName: string | null = null;
    if (categoryCol !== undefined) {
      const rawCategory = raw[categoryCol];
      if (rawCategory !== null && rawCategory !== undefined) {
        const name = String(rawCategory).trim();
        if (name) {
          categoryName = name;
          const found = resolver.categoriesByName.get(normalizePersianText(name));
          if (found) categoryId = found.id;
        }
      }
    }

    let projectId: ProjectId | null = null;
    let projectName: string | null = null;
    if (projectCol !== undefined) {
      const rawProject = raw[projectCol];
      if (rawProject !== null && rawProject !== undefined) {
        const name = String(rawProject).trim();
        if (name) {
          projectName = name;
          const found = resolver.projectsByName.get(normalizePersianText(name));
          if (found) projectId = found.id;
        }
      }
    }

    const referenceCode =
      referenceCol !== undefined &&
      raw[referenceCol] !== null &&
      raw[referenceCol] !== undefined
        ? String(raw[referenceCol]).trim() || null
        : null;

    const description =
      descriptionCol !== undefined &&
      raw[descriptionCol] !== null &&
      raw[descriptionCol] !== undefined
        ? String(raw[descriptionCol]).trim() || null
        : null;

    const rowHash = await computeRowHash([
      type ?? '',
      amount?.toString() ?? '',
      date ?? '',
      accountId ?? accountName ?? '',
      partyId ?? partyName ?? '',
      referenceCode ?? '',
    ]);

    let duplicate: DuplicateScore | null = null;
    let decision: ImportDecision = ImportDecisionValue.IMPORTED;

    if (errors.length === 0 && amount !== null && type !== null && date !== null) {
      const candidate: CreateTransactionInput = {
        type,
        amount,
        accountId: accountId!,
        partyId,
        categoryId,
        customCategoryText: null,
        projectId,
        transactionDate: date,
        transactionTime: time,
        referenceCode,
        description,
        createdBy: null,
      };

      const dup = checkDuplicate(candidate, existingTransactions);

      if (dup.level !== DuplicateLevel.UNIQUE) {
        duplicate = dup;
        decision = ImportDecisionValue.SKIPPED;
      }

      switch (dup.level) {
        case DuplicateLevel.EXACT:
          stats.exact += 1;
          break;
        case DuplicateLevel.LIKELY:
          stats.likely += 1;
          break;
        case DuplicateLevel.POSSIBLE:
          stats.possible += 1;
          break;
        case DuplicateLevel.UNIQUE:
          stats.unique += 1;
          break;
      }
    }

    if (errors.length > 0) {
      decision = ImportDecisionValue.CONFLICT;
      stats.invalid += 1;
    } else {
      stats.valid += 1;
    }

    stats.total += 1;

    rows.push({
      rowIndex: i,
      rawRow: raw,
      parsed: {
        type,
        amount,
        date,
        time,
        accountId,
        accountName,
        partyId,
        partyName,
        categoryId,
        categoryName,
        projectId,
        projectName,
        referenceCode,
        description,
      },
      decision,
      duplicate,
      errors,
      rowHash,
    });
  }

  return { rows, stats };
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Commit
// ═══════════════════════════════════════════════════════════════════════════

export interface CommitOptions {
  jobId: ImportJobId;
  decisions: Map<number, ImportDecision>;
  autoCreateMissingParties?: boolean;
  defaultAccountId: AccountId | null;
}

export interface CommitResult {
  imported: number;
  skipped: number;
  failed: number;
  errors: { rowIndex: number; message: string }[];
}

export async function commitImport(
  preview: ImportPreviewResult,
  options: CommitOptions
): Promise<CommitResult> {
  const result: CommitResult = {
    imported: 0,
    skipped: 0,
    failed: 0,
    errors: [],
  };

  await importRepo.updateJobStatus(options.jobId, ImportStatus.PREVIEWING, null);

  for (const row of preview.rows) {
    const decision = options.decisions.get(row.rowIndex) ?? row.decision;

    if (decision === ImportDecisionValue.SKIPPED) {
      result.skipped += 1;
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.SKIPPED,
        matchedTransactionId: row.duplicate?.matchedTransactionId ?? null,
        duplicateScore: row.duplicate?.level ?? null,
        errorMessage: null,
      });
      continue;
    }

    if (decision === ImportDecisionValue.CONFLICT) {
      result.failed += 1;
      const message = row.errors.join(' • ') || 'ردیف نامعتبر';
      result.errors.push({
        rowIndex: row.rowIndex,
        message,
      });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.CONFLICT,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
      continue;
    }

    if (row.errors.length > 0) {
      result.failed += 1;
      const message = row.errors.join(' • ');
      result.errors.push({
        rowIndex: row.rowIndex,
        message,
      });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.ERROR,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
      continue;
    }

    if (
      row.parsed.amount === null ||
      row.parsed.type === null ||
      row.parsed.date === null
    ) {
      result.failed += 1;
      const message = 'فیلدهای الزامی ناقص';
      result.errors.push({
        rowIndex: row.rowIndex,
        message,
      });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.ERROR,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
      continue;
    }

    let accountId = row.parsed.accountId;
    if (!accountId && options.defaultAccountId) {
      accountId = options.defaultAccountId;
    }

    if (!accountId) {
      result.failed += 1;
      const message = 'حساب مشخص نشده';
      result.errors.push({ rowIndex: row.rowIndex, message });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.ERROR,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
      continue;
    }

    let partyId = row.parsed.partyId;
    if (!partyId && row.parsed.partyName && options.autoCreateMissingParties) {
      try {
        const newParty = await partyRepo.create({
          name: row.parsed.partyName,
          type: 'person',
          phone: null,
          cardNumber: null,
          accountNumber: null,
          role: null,
          notes: 'ایجاد شده در Import',
        });
        partyId = newParty.id;
      } catch {
        // ignore — will be reported as failed below
      }
    }

    if (row.parsed.type === TransactionType.EXPENSE && !partyId) {
      result.failed += 1;
      const message = 'طرف حساب برای پرداخت الزامی است';
      result.errors.push({ rowIndex: row.rowIndex, message });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.ERROR,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
      continue;
    }

    try {
      const existingByHash = await importRepo.findRecordByHash(row.rowHash);
      if (existingByHash && existingByHash.decision === ImportDecisionValue.IMPORTED) {
        result.skipped += 1;
        await importRepo.addRecord({
          jobId: options.jobId,
          rowNumber: row.rowIndex + 2,
          rowHash: row.rowHash,
          decision: ImportDecisionValue.SKIPPED,
          matchedTransactionId: null,
          duplicateScore: null,
          errorMessage: null,
        });
        continue;
      }

      const input: CreateTransactionInput = {
        type: row.parsed.type,
        amount: row.parsed.amount,
        accountId,
        partyId,
        categoryId: row.parsed.categoryId,
        customCategoryText: null,
        projectId: row.parsed.projectId,
        transactionDate: row.parsed.date,
        transactionTime: row.parsed.time,
        referenceCode: row.parsed.referenceCode,
        description: row.parsed.description,
        createdBy: 'Import',
      };

      // ⚠️ Service Path — نه Repository Bypass (طبق SPEC v2.0 §۵)
      const result2 = await transactionService.create(input);

      if (!result2.ok) {
        throw new Error(result2.message);
      }

      const created = result2.value.transaction;

      result.imported += 1;
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.IMPORTED,
        matchedTransactionId: created.id,
        duplicateScore: null,
        errorMessage: null,
      });
    } catch (e) {
      result.failed += 1;
      const message = e instanceof Error ? e.message : 'خطای نامشخص';
      result.errors.push({ rowIndex: row.rowIndex, message });
      await importRepo.addRecord({
        jobId: options.jobId,
        rowNumber: row.rowIndex + 2,
        rowHash: row.rowHash,
        decision: ImportDecisionValue.ERROR,
        matchedTransactionId: null,
        duplicateScore: null,
        errorMessage: message,
      });
    }
  }

  const statsJson = JSON.stringify({
    imported: result.imported,
    skipped: result.skipped,
    failed: result.failed,
    total: preview.rows.length,
  });

  await importRepo.updateJobStatus(
    options.jobId,
    result.failed > 0 && result.imported === 0
      ? ImportStatus.FAILED
      : ImportStatus.COMMITTED,
    statsJson
  );

  return result;
}

// ═══════════════════════════════════════════════════════════════════════════
// Import: Error sheet
// ═══════════════════════════════════════════════════════════════════════════

export function buildErrorSheet(
  rows: readonly ImportPreviewRow[],
  _headers: readonly string[]
): WorkSheet {
  const aoa: (string | number)[][] = [[...ERROR_HEADERS]];

  for (const row of rows) {
    const rawJoined = row.rawRow
      .map((c) => (c === null || c === undefined ? '' : String(c)))
      .join(' | ');

    aoa.push([row.rowIndex + 2, row.errors.join(' • ') || 'نامشخص', rawJoined]);
  }

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([12, 50, 80]);
  applyHeaderRow(ws, ERROR_HEADERS);

  return ws;
}

export function exportErrorRows(
  rows: readonly ImportPreviewRow[],
  headers: readonly string[]
): Uint8Array {
  const wb = XLSX.utils.book_new();
  const ws = buildErrorSheet(rows, headers);
  XLSX.utils.book_append_sheet(wb, ws, SHEET_ERRORS);
  const data = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  return data instanceof Uint8Array ? data : new Uint8Array(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Templates
// ═══════════════════════════════════════════════════════════════════════════

export function exportTemplate(): Uint8Array {
  const aoa: (string | number | null)[][] = [
    [
      'ردیف',
      'نوع',
      'مبلغ',
      'تاریخ',
      'ساعت',
      'حساب',
      'طرف حساب',
      'بابت',
      'پروژه',
      'کد پیگیری',
      'توضیحات',
    ],
    [
      1,
      'دریافت',
      50000000,
      '1405/06/25',
      '10:30',
      'بانک ملت',
      '',
      'فروش',
      'پروژه A',
      '123456',
      'مثال',
    ],
    [
      2,
      'پرداخت',
      8000000,
      '1405/06/26',
      '14:15',
      'بانک ملت',
      'علی رضایی',
      'خرید مصالح',
      'پروژه A',
      '',
      '',
    ],
  ];

  const ws = XLSX.utils.aoa_to_sheet(aoa);
  ws['!cols'] = buildColumnWidths([6, 10, 16, 14, 8, 18, 20, 18, 18, 16, 30]);
  applyHeaderRow(
    ws,
    aoa[0]!.map((c) => String(c))
  );

  for (let r = 1; r < aoa.length; r++) {
    const addr = XLSX.utils.encode_cell({ r, c: 2 });
    const cell = ws[addr] as CellObject | undefined;
    if (cell && typeof cell.v === 'number') cell.z = AMOUNT_FORMAT;
  }

  const wb = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(wb, ws, 'قالب');
  const data = XLSX.write(wb, { type: 'array', bookType: 'xlsx' });
  return data instanceof Uint8Array ? data : new Uint8Array(data);
}

// ═══════════════════════════════════════════════════════════════════════════
// Public API facade
// ═══════════════════════════════════════════════════════════════════════════

export const importExportService = {
  exportReport,
  exportFullWorkbook,
  exportTemplate,
  exportErrorRows,
  parseExcelFile,
  suggestColumnMapping,
  buildPreview,
  commitImport,
  getFieldLabel,
  getAllFields,
};

// ═══════════════════════════════════════════════════════════════════════════
// APP_VERSION constant export (used by other modules)
// ═══════════════════════════════════════════════════════════════════════════

export const IMPORT_EXPORT_APP_VERSION = APP_VERSION;

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
