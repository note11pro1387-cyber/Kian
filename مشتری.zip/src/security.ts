// ============================================================================
//  src/security.ts
//  امنیت برنامه — PIN / Pattern / Biometric / Recovery / Auto-Lock
// ============================================================================
//
//  ── قوانین این فایل ────────────────────────────────────────────────────
//
//   ۱. تمام Secretها با PBKDF2 (۱۰۰k iteration, SHA-256) هش می‌شوند.
//   ۲. هرگز PIN/Pattern/RecoveryCode خام در حافظه‌ی پایدار ذخیره نمی‌شود.
//   ۳. `randomBytes` Fail-Closed است (بدون Math.random).
//   ۴. Auto-Lock با Timer واقعی + Lifecycle listener کار می‌کند.
//   ۵. Biometric فقط اگر هم دستگاه پشتیبانی کند و هم کاربر فعال کرده باشد.
//   ۶. Recovery `0000` پس از موفقیت کاربر را مجبور به ساخت PIN جدید می‌کند.
//   ۷. هیچ‌گاه کد امنیتی کلید/Secret را در Audit خام ثبت نمی‌کند.
// ============================================================================

import { AuditAction, AuditEntityType, PrimarySecurityMethod } from './types';

import type {
  PrimarySecurityMethod as PrimarySecurityMethodValue,
  ISOTimestamp,
  RecoveryResult,
  SecurityProfile,
  VerifyResult,
} from './types';

import { securityRepo, dbUtils, getWorkspaceId, getDatabase } from './db';
import { nowISO } from './formatters';

// ============================================================================
//  Constants
// ============================================================================

/**
 * کد بازیابی سازندگان — طبق تصمیم قطعی پروژه.
 *
 * ⚠️ هشدار مهندسی صادقانه (طبق SPEC v2.0 §۹.۳):
 * این کد ثابت است و در همه‌ی نصب‌ها یکسان. محافظ‌های سه‌گانه
 * (اجبار Reset + Audit + هشدار) ریسک را کنترل می‌کنند، ولی صفر نمی‌کنند.
 * اگر در آینده تصمیم به Per-installation recovery گرفتید، فقط
 * تابع `useRecoveryCode` را تغییر دهید.
 */
export const RECOVERY_CODE = '0000';

const PBKDF2_ITERATIONS = 100_000;
const SALT_BYTES = 16;
const HASH_BITS = 256;

/**
 * طول PIN — طبق SPEC v2.0 §۹.۲: بین ۴ تا ۶ رقم.
 */
export const PIN_MIN_LENGTH = 4;
export const PIN_MAX_LENGTH = 6;

export const PATTERN_MIN_POINTS = 4;

/**
 * گزینه‌های معتبر Timeout قفل خودکار (ثانیه).
 *  0 = فوری
 */
export const LOCK_TIMEOUT_OPTIONS = [0, 30, 60, 300, 900] as const;

export function isSupportedLockTimeout(value: number): boolean {
  return (LOCK_TIMEOUT_OPTIONS as readonly number[]).includes(value);
}

/**
 * سطوح Lockout با Exponential Backoff — طبق SPEC v2.0 §۹.۴.
 *
 * ترتیب: پس از N تلاش ناموفق، قفل به مدت S ثانیه اعمال می‌شود.
 * مقادیر بالاترین سطح معتبر، برای تلاش‌های بعدی اعمال می‌شود.
 */
interface LockoutTier {
  attempts: number;
  seconds: number;
}

const LOCKOUT_TIERS: readonly LockoutTier[] = [
  { attempts: 5, seconds: 30 },
  { attempts: 10, seconds: 120 },
  { attempts: 15, seconds: 600 },
];

const MAX_FAILED_ATTEMPTS = 15;

// ============================================================================
//  Encoding helpers
// ============================================================================

function bytesToBase64(bytes: Uint8Array): string {
  let binary = '';
  for (let i = 0; i < bytes.length; i++) {
    binary += String.fromCharCode(bytes[i]!);
  }
  if (typeof btoa === 'function') return btoa(binary);
  return Buffer.from(bytes).toString('base64');
}

function base64ToBytes(b64: string): Uint8Array {
  let binary: string;
  if (typeof atob === 'function') {
    binary = atob(b64);
  } else {
    binary = Buffer.from(b64, 'base64').toString('binary');
  }
  const out = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) out[i] = binary.charCodeAt(i);
  return out;
}

// ============================================================================
//  Secure random — Fail-Closed
// ============================================================================

/**
 * تولید بایت تصادفی امن.
 *
 * طبق SPEC v2.0 §۹.۸: هیچ fallback به Math.random مجاز نیست.
 * اگر Web Crypto در دسترس نباشد، این تابع throw می‌کند.
 */
function randomBytes(n: number): Uint8Array {
  if (!Number.isInteger(n) || n <= 0) {
    throw new Error('Secure random byte length must be a positive integer');
  }

  const cryptoObj = globalThis.crypto;
  if (!cryptoObj || typeof cryptoObj.getRandomValues !== 'function') {
    throw new Error(
      'Secure random generator is unavailable. Cannot proceed with security-sensitive operation.'
    );
  }

  const arr = new Uint8Array(n);
  cryptoObj.getRandomValues(arr);
  return arr;
}

// ============================================================================
//  Constant-time comparison
// ============================================================================

function constantTimeEqual(a: string, b: string): boolean {
  if (a.length !== b.length) return false;
  let result = 0;
  for (let i = 0; i < a.length; i++) {
    result |= a.charCodeAt(i) ^ b.charCodeAt(i);
  }
  return result === 0;
}

// ============================================================================
//  PBKDF2
// ============================================================================

async function deriveKey(
  secret: string,
  saltBytes: Uint8Array,
  iterations: number
): Promise<Uint8Array> {
  const cryptoObj = (globalThis as { crypto?: Crypto }).crypto;
  if (!cryptoObj || !cryptoObj.subtle) {
    throw new Error('Web Crypto API unavailable for PBKDF2');
  }

  const enc = new TextEncoder();
  const keyMaterial = await cryptoObj.subtle.importKey(
    'raw',
    enc.encode(secret),
    { name: 'PBKDF2' },
    false,
    ['deriveBits']
  );

  const saltBuffer = saltBytes.slice().buffer;
  const derived = await cryptoObj.subtle.deriveBits(
    {
      name: 'PBKDF2',
      salt: saltBuffer,
      iterations,
      hash: 'SHA-256',
    },
    keyMaterial,
    HASH_BITS
  );

  return new Uint8Array(derived);
}

async function hashSecret(secret: string, existingSalt?: Uint8Array): Promise<string> {
  const salt = existingSalt ?? randomBytes(SALT_BYTES);
  const derived = await deriveKey(secret, salt, PBKDF2_ITERATIONS);
  const saltB64 = bytesToBase64(salt);
  const hashB64 = bytesToBase64(derived);
  return `pbkdf2$${PBKDF2_ITERATIONS}$${saltB64}$${hashB64}`;
}

interface ParsedHash {
  iterations: number;
  salt: Uint8Array;
  hash: string;
}

function parseHash(stored: string): ParsedHash | null {
  const parts = stored.split('$');
  if (parts.length !== 4) return null;
  if (parts[0] !== 'pbkdf2') return null;
  const iterations = Number(parts[1]);
  if (!Number.isFinite(iterations) || iterations <= 0) return null;
  try {
    return {
      iterations,
      salt: base64ToBytes(parts[2]!),
      hash: parts[3]!,
    };
  } catch {
    return null;
  }
}

async function verifySecret(secret: string, stored: string): Promise<boolean> {
  const parsed = parseHash(stored);
  if (!parsed) return false;
  try {
    const derived = await deriveKey(secret, parsed.salt, parsed.iterations);
    const derivedB64 = bytesToBase64(derived);
    return constantTimeEqual(derivedB64, parsed.hash);
  } catch {
    return false;
  }
}

// ============================================================================
//  Native bridge
// ============================================================================

export type BiometricType = 'fingerprint' | 'face' | 'iris' | 'none';

export interface BiometricAvailability {
  available: boolean;
  type: BiometricType;
}

export interface BiometricAuthOptions {
  title: string;
  subtitle: string;
  cancel: string;
}

export interface BiometricAuthResult {
  success: boolean;
  error?: string;
}

interface NativeSecurityPlugin {
  isBiometricAvailable(): Promise<BiometricAvailability>;
  authenticateBiometric(options: BiometricAuthOptions): Promise<BiometricAuthResult>;
  secureStore(options: { key: string; value: string }): Promise<void>;
  secureRetrieve(options: { key: string }): Promise<{ value: string | null }>;
  secureDelete(options: { key: string }): Promise<void>;
  setSecureFlag(options: { enabled: boolean }): Promise<void>;
}

interface CapacitorWindow {
  Capacitor?: {
    isNativePlatform?: () => boolean;
    Plugins?: Record<string, unknown>;
  };
}

function getCapacitor(): CapacitorWindow['Capacitor'] | null {
  if (typeof window === 'undefined') return null;
  return (window as unknown as CapacitorWindow).Capacitor ?? null;
}

export function isNativePlatform(): boolean {
  const cap = getCapacitor();
  return cap?.isNativePlatform?.() === true;
}

function getNativePlugin(): NativeSecurityPlugin | null {
  const cap = getCapacitor();
  if (!cap?.isNativePlatform?.()) return null;
  const plugins = cap.Plugins;
  if (!plugins) return null;
  const plugin = plugins['SecurityPlugin'];
  if (!plugin) return null;
  return plugin as NativeSecurityPlugin;
}

// ============================================================================
//  Session state (in-memory only)
// ============================================================================

interface SessionState {
  configured: boolean;
  unlocked: boolean;
  lastActivityAt: number;
  requiresRecoveryReset: boolean;
  privacyOverlayActive: boolean;
}

const session: SessionState = {
  configured: false,
  unlocked: false,
  lastActivityAt: Date.now(),
  requiresRecoveryReset: false,
  privacyOverlayActive: false,
};

const sessionListeners = new Set<() => void>();
let autoLockTimer: ReturnType<typeof setTimeout> | null = null;
let lifecycleStarted = false;
let lifecycleActivityHandler: (() => void) | null = null;
let lifecycleVisibilityHandler: (() => void) | null = null;

function notifySessionListeners(): void {
  for (const fn of sessionListeners) {
    try {
      fn();
    } catch {
      // silent — a broken listener must not break others
    }
  }
}

export function subscribeSession(listener: () => void): () => void {
  sessionListeners.add(listener);
  return () => {
    sessionListeners.delete(listener);
  };
}

export function getSessionSnapshot(): Readonly<SessionState> {
  return { ...session };
}

function clearAutoLockTimer(): void {
  if (autoLockTimer !== null) {
    clearTimeout(autoLockTimer);
    autoLockTimer = null;
  }
}

async function scheduleAutoLock(): Promise<void> {
  clearAutoLockTimer();

  if (!session.configured || !session.unlocked) return;

  const timeoutSeconds = await getLockTimeout();
  if (timeoutSeconds <= 0) return;

  const elapsedMs = Date.now() - session.lastActivityAt;
  const remainingMs = Math.max(250, timeoutSeconds * 1000 - elapsedMs);

  autoLockTimer = setTimeout(() => {
    autoLockTimer = null;
    void lockApp();
  }, remainingMs);
}

export function setSecurityConfigured(configured: boolean): void {
  session.configured = configured;
  if (!configured) {
    clearAutoLockTimer();
  }
  notifySessionListeners();
}

export function isSecurityConfiguredInSession(): boolean {
  return session.configured;
}

export function markUnlocked(): void {
  session.unlocked = true;
  session.lastActivityAt = Date.now();
  notifySessionListeners();
  if (session.configured) {
    void scheduleAutoLock();
  }
}

export function markLocked(): void {
  clearAutoLockTimer();
  session.unlocked = false;
  notifySessionListeners();
}

export function touchActivity(): void {
  if (!session.configured || !session.unlocked) return;
  session.lastActivityAt = Date.now();
  void scheduleAutoLock();
}

export function requiresRecoveryReset(): boolean {
  return session.requiresRecoveryReset;
}

export function setRequiresRecoveryReset(value: boolean): void {
  session.requiresRecoveryReset = value;
  notifySessionListeners();
}

// ============================================================================
//  Lifecycle — auto-lock + privacy overlay
// ============================================================================

/**
 * شروع Lifecycle امنیتی — یک‌بار در Boot فراخوانی می‌شود.
 *
 * این تابع:
 *   ۱. رویدادهای فعالیت کاربر را رصد می‌کند تا `lastActivityAt` را
 *      به‌روز نگه دارد.
 *   ۲. رویداد visibilitychange را برای قفل خودکار و Privacy Overlay
 *      مدیریت می‌کند.
 *   ۳. Timer خودکار قفل را زمان‌بندی می‌کند.
 */
export async function startSecurityLifecycle(): Promise<void> {
  if (lifecycleStarted || typeof document === 'undefined') return;
  lifecycleStarted = true;

  const activityEvents = ['pointerdown', 'keydown', 'touchstart', 'input'] as const;

  lifecycleActivityHandler = () => {
    touchActivity();
  };

  for (const eventName of activityEvents) {
    document.addEventListener(eventName, lifecycleActivityHandler, {
      passive: true,
      capture: true,
    });
  }

  lifecycleVisibilityHandler = () => {
    if (document.visibilityState === 'hidden') {
      void enablePrivacyOverlay();

      void (async () => {
        if (!session.configured || !session.unlocked) return;
        const timeout = await getLockTimeout();
        if (timeout <= 0) {
          await lockApp();
          return;
        }
        await scheduleAutoLock();
      })();
      return;
    }

    void (async () => {
      // The soft privacy overlay is a visibility safeguard, not the lock state.
      // A fresh/unconfigured session must never remain covered after returning to the tab.
      if (!session.configured) {
        await disablePrivacyOverlay();
        return;
      }

      if (!session.unlocked) return;

      const timeout = await getLockTimeout();
      const elapsedSeconds = (Date.now() - session.lastActivityAt) / 1000;

      if (timeout <= 0 || elapsedSeconds >= timeout) {
        await lockApp();
        return;
      }

      await disablePrivacyOverlay();
      await scheduleAutoLock();
    })();
  };

  document.addEventListener('visibilitychange', lifecycleVisibilityHandler);

  await scheduleAutoLock();
}

export function stopSecurityLifecycle(): void {
  if (!lifecycleStarted || typeof document === 'undefined') return;
  lifecycleStarted = false;
  clearAutoLockTimer();

  const activityEvents = ['pointerdown', 'keydown', 'touchstart', 'input'] as const;

  if (lifecycleActivityHandler) {
    for (const eventName of activityEvents) {
      document.removeEventListener(eventName, lifecycleActivityHandler, true);
    }
    lifecycleActivityHandler = null;
  }

  if (lifecycleVisibilityHandler) {
    document.removeEventListener('visibilitychange', lifecycleVisibilityHandler);
    lifecycleVisibilityHandler = null;
  }
}

// ============================================================================
//  Privacy overlay
// ============================================================================

export function isPrivacyOverlayActive(): boolean {
  return session.privacyOverlayActive;
}

export async function enablePrivacyOverlay(): Promise<void> {
  if (session.privacyOverlayActive) return;
  session.privacyOverlayActive = true;
  notifySessionListeners();

  const plugin = getNativePlugin();
  if (plugin) {
    try {
      await plugin.setSecureFlag({ enabled: true });
    } catch {
      // silent — overlay is a soft layer
    }
  }
}

export async function disablePrivacyOverlay(): Promise<void> {
  if (!session.privacyOverlayActive) return;
  session.privacyOverlayActive = false;
  notifySessionListeners();

  const plugin = getNativePlugin();
  if (plugin) {
    try {
      await plugin.setSecureFlag({ enabled: false });
    } catch {
      // silent
    }
  }
}

// ============================================================================
//  Security audit helper
// ============================================================================

async function writeSecurityAudit(
  action: typeof AuditAction.SECURITY_CHANGE | typeof AuditAction.MASTER_RECOVERY_USED,
  actorLabel: string | null,
  detail: Record<string, unknown> | null
): Promise<void> {
  try {
    const conn = getDatabase();
    await conn.transaction(async (tx) => {
      const workspaceId = await getWorkspaceId(tx);
      await tx.execute(
        `INSERT INTO audit_events
          (id, workspace_id, entity_type, entity_id, action,
           before_json, after_json, actor_label, device_id, created_at)
         VALUES (?, ?, ?, NULL, ?, NULL, ?, ?, NULL, ?)`,
        [
          dbUtils.generateULID(),
          workspaceId,
          AuditEntityType.SECURITY,
          action,
          detail === null ? null : JSON.stringify(detail),
          actorLabel,
          nowISO(),
        ]
      );
    });
  } catch {
    // silent — audit failure must not block security flow
  }
}

// ============================================================================
//  Profile access
// ============================================================================

export async function getProfile(): Promise<SecurityProfile> {
  const existing = await securityRepo.get();
  if (existing) return existing;
  return securityRepo.ensureInitialized();
}

export async function isConfigured(): Promise<boolean> {
  const profile = await getProfile();
  return (
    profile.pinHash !== null || profile.patternHash !== null || profile.biometricEnabled
  );
}

export async function isBiometricEnabled(): Promise<boolean> {
  const profile = await getProfile();
  return profile.biometricEnabled;
}

export async function getLockTimeout(): Promise<number> {
  const profile = await getProfile();
  return profile.lockTimeoutSeconds;
}

export async function setLockTimeout(seconds: number): Promise<void> {
  if (!isSupportedLockTimeout(seconds)) {
    throw new Error('Unsupported lock timeout value');
  }
  await securityRepo.update({ lockTimeoutSeconds: seconds });
  await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
    field: 'lock_timeout_seconds',
    newValue: seconds,
  });
}

// ============================================================================
//  Setup
// ============================================================================

export interface SetupInput {
  pin?: string | null;
  pattern?: string | null;
  biometricEnabled?: boolean;
}

export interface SetupResult {
  success: boolean;
  error?: string;
}

function validatePin(pin: string): string | null {
  if (!/^\d+$/.test(pin)) return 'پین باید فقط شامل رقم باشد';
  if (pin.length < PIN_MIN_LENGTH) {
    return `پین باید حداقل ${PIN_MIN_LENGTH} رقم باشد`;
  }
  if (pin.length > PIN_MAX_LENGTH) {
    return `پین باید حداکثر ${PIN_MAX_LENGTH} رقم باشد`;
  }
  return null;
}

function validatePattern(pattern: string): string | null {
  if (!/^\d+(-\d+)+$/.test(pattern)) return 'الگو نامعتبر است';
  const points = pattern.split('-');
  if (points.length < PATTERN_MIN_POINTS) {
    return `الگو باید حداقل ${PATTERN_MIN_POINTS} نقطه داشته باشد`;
  }
  for (const p of points) {
    const n = Number(p);
    if (!Number.isInteger(n) || n < 0 || n > 8) {
      return 'الگو شامل نقطه نامعتبر است';
    }
  }
  const unique = new Set(points);
  if (unique.size < PATTERN_MIN_POINTS) {
    return 'الگو نباید نقطه تکراری داشته باشد';
  }
  return null;
}

export async function setupSecurity(input: SetupInput): Promise<SetupResult> {
  const hasPin = typeof input.pin === 'string' && input.pin.length > 0;
  const hasPattern = typeof input.pattern === 'string' && input.pattern.length > 0;

  if (!hasPin && !hasPattern) {
    return {
      success: false,
      error: 'حداقل یکی از پین یا الگو باید تعیین شود',
    };
  }
  if (hasPin && hasPattern) {
    return {
      success: false,
      error: 'فقط یکی از پین یا الگو باید تعیین شود',
    };
  }

  if (hasPin) {
    const err = validatePin(input.pin!);
    if (err) return { success: false, error: err };
  }

  if (hasPattern) {
    const err = validatePattern(input.pattern!);
    if (err) return { success: false, error: err };
  }

  try {
    await securityRepo.ensureInitialized();

    let pinHash: string | null = null;
    let patternHash: string | null = null;
    let primaryMethod: PrimarySecurityMethodValue;

    if (hasPin) {
      pinHash = await hashSecret(input.pin!);
      primaryMethod = PrimarySecurityMethod.PIN;
    } else {
      patternHash = await hashSecret(input.pattern!);
      primaryMethod = PrimarySecurityMethod.PATTERN;
    }

    const biometricEnabled = input.biometricEnabled === true;

    const now = nowISO();
    const existing = await securityRepo.get();

    await securityRepo.update({
      pinHash,
      patternHash,
      biometricEnabled,
      primaryMethod,
      failedAttempts: 0,
      lockoutUntil: null,
      configuredAt: existing?.configuredAt ?? now,
    });

    await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
      event: 'SECURITY_SETUP',
      hasPin,
      hasPattern,
      biometric: biometricEnabled,
    });

    setSecurityConfigured(true);
    markUnlocked();

    return { success: true };
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'ثبت امنیت با خطا مواجه شد',
    };
  }
}

// ============================================================================
//  Verify
// ============================================================================

function getTierForAttempts(attempts: number): {
  seconds: number;
  active: boolean;
} {
  let tier = { seconds: 0, active: false };
  for (const t of LOCKOUT_TIERS) {
    if (attempts >= t.attempts) {
      tier = { seconds: t.seconds, active: true };
    } else {
      break;
    }
  }
  return tier;
}

async function applyFailedAttempt(): Promise<VerifyResult> {
  const profile = await getProfile();
  const nextAttempts = Math.min(profile.failedAttempts + 1, MAX_FAILED_ATTEMPTS);

  const tier = getTierForAttempts(nextAttempts);
  let lockoutUntil: string | null = null;
  if (tier.active && tier.seconds > 0) {
    lockoutUntil = new Date(Date.now() + tier.seconds * 1000).toISOString();
  }

  await securityRepo.update({
    failedAttempts: nextAttempts,
    lockoutUntil,
  });

  return {
    success: false,
    remainingAttempts: Math.max(0, MAX_FAILED_ATTEMPTS - nextAttempts),
    lockedUntil: lockoutUntil,
  };
}

async function resetFailedAttempts(): Promise<void> {
  const profile = await getProfile();
  if (profile.failedAttempts > 0 || profile.lockoutUntil !== null) {
    await securityRepo.update({
      failedAttempts: 0,
      lockoutUntil: null,
    });
  }
}

function isLockedOut(profile: SecurityProfile): boolean {
  if (!profile.lockoutUntil) return false;
  const until = new Date(profile.lockoutUntil).getTime();
  return Number.isFinite(until) && until > Date.now();
}

export async function verifyPIN(pin: string): Promise<VerifyResult> {
  const profile = await getProfile();

  if (isLockedOut(profile)) {
    return {
      success: false,
      remainingAttempts: 0,
      lockedUntil: profile.lockoutUntil,
    };
  }

  if (!profile.pinHash) {
    return {
      success: false,
      remainingAttempts: 0,
      lockedUntil: null,
    };
  }

  if (pin.length < PIN_MIN_LENGTH || pin.length > PIN_MAX_LENGTH) {
    return applyFailedAttempt();
  }

  const match = await verifySecret(pin, profile.pinHash);

  if (match) {
    await resetFailedAttempts();
    return {
      success: true,
      remainingAttempts: MAX_FAILED_ATTEMPTS,
      lockedUntil: null,
    };
  }

  return applyFailedAttempt();
}

export async function verifyPattern(pattern: string): Promise<VerifyResult> {
  const profile = await getProfile();

  if (isLockedOut(profile)) {
    return {
      success: false,
      remainingAttempts: 0,
      lockedUntil: profile.lockoutUntil,
    };
  }

  if (!profile.patternHash) {
    return {
      success: false,
      remainingAttempts: 0,
      lockedUntil: null,
    };
  }

  const match = await verifySecret(pattern, profile.patternHash);

  if (match) {
    await resetFailedAttempts();
    return {
      success: true,
      remainingAttempts: MAX_FAILED_ATTEMPTS,
      lockedUntil: null,
    };
  }

  return applyFailedAttempt();
}

export async function isCurrentlyLockedOut(): Promise<ISOTimestamp | null> {
  const profile = await getProfile();
  if (isLockedOut(profile)) return profile.lockoutUntil;
  return null;
}

export async function getLockoutRemaining(): Promise<number> {
  const profile = await getProfile();
  if (!profile.lockoutUntil) return 0;
  const remaining = new Date(profile.lockoutUntil).getTime() - Date.now();
  return remaining > 0 ? Math.ceil(remaining / 1000) : 0;
}

// ============================================================================
//  Biometric
// ============================================================================

export async function checkBiometricAvailability(): Promise<BiometricAvailability> {
  const plugin = getNativePlugin();
  if (!plugin) return { available: false, type: 'none' };

  try {
    return await plugin.isBiometricAvailable();
  } catch {
    return { available: false, type: 'none' };
  }
}

/**
 * احراز هویت بیومتریک.
 *
 * طبق SPEC v2.0 §۹.۶: باید هم دستگاه پشتیبانی کند و هم کاربر
 * بیومتریک را فعال کرده باشد.
 */
async function authenticateBiometricDirect(
  title: string,
  subtitle: string
): Promise<BiometricAuthResult> {
  const plugin = getNativePlugin();
  if (!plugin) {
    return {
      success: false,
      error: 'بیومتریک در محیط فعلی پشتیبانی نمی‌شود',
    };
  }

  try {
    return await plugin.authenticateBiometric({
      title,
      subtitle,
      cancel: 'انصراف',
    });
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'خطای بیومتریک',
    };
  }
}

export async function authenticateBiometric(): Promise<BiometricAuthResult> {
  const enabled = await isBiometricEnabled();
  if (!enabled) {
    return {
      success: false,
      error: 'بیومتریک توسط کاربر فعال نشده است',
    };
  }

  const availability = await checkBiometricAvailability();
  if (!availability.available) {
    return {
      success: false,
      error: 'بیومتریک در این دستگاه در دسترس نیست',
    };
  }

  return authenticateBiometricDirect(
    'ورود به برنامه',
    'برای ورود، هویت خود را تأیید کنید'
  );
}

export async function enableBiometric(): Promise<SetupResult> {
  const availability = await checkBiometricAvailability();
  if (!availability.available) {
    return {
      success: false,
      error: 'بیومتریک در این دستگاه در دسترس نیست',
    };
  }

  const profile = await getProfile();
  if (!profile.pinHash && !profile.patternHash) {
    return {
      success: false,
      error: 'ابتدا باید پین یا الگو تعیین شود',
    };
  }

  const result = await authenticateBiometricDirect(
    'فعال‌سازی بیومتریک',
    'برای فعال‌سازی، هویت خود را تأیید کنید'
  );
  if (!result.success) {
    return {
      success: false,
      error: result.error ?? 'تأیید هویت انجام نشد',
    };
  }

  await securityRepo.update({
    biometricEnabled: true,
  });

  await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
    event: 'BIOMETRIC_ENABLED',
    type: availability.type,
  });

  return { success: true };
}

export async function disableBiometric(): Promise<void> {
  await securityRepo.update({
    biometricEnabled: false,
  });

  await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
    event: 'BIOMETRIC_DISABLED',
  });
}

// ============================================================================
//  Change PIN / Pattern
// ============================================================================

export async function changePIN(
  currentPin: string,
  newPin: string
): Promise<SetupResult> {
  const err = validatePin(newPin);
  if (err) return { success: false, error: err };

  const verify = await verifyPIN(currentPin);
  if (!verify.success) {
    return { success: false, error: 'پین فعلی نادرست است' };
  }

  try {
    const hash = await hashSecret(newPin);
    await securityRepo.update({
      pinHash: hash,
      failedAttempts: 0,
      lockoutUntil: null,
    });

    await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
      event: 'PIN_CHANGED',
    });

    return { success: true };
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'تغییر پین با خطا مواجه شد',
    };
  }
}

export async function changePattern(
  currentPattern: string,
  newPattern: string
): Promise<SetupResult> {
  const err = validatePattern(newPattern);
  if (err) return { success: false, error: err };

  const verify = await verifyPattern(currentPattern);
  if (!verify.success) {
    return { success: false, error: 'الگوی فعلی نادرست است' };
  }

  try {
    const hash = await hashSecret(newPattern);
    await securityRepo.update({
      patternHash: hash,
      failedAttempts: 0,
      lockoutUntil: null,
    });

    await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
      event: 'PATTERN_CHANGED',
    });

    return { success: true };
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'تغییر الگو با خطا مواجه شد',
    };
  }
}

// ============================================================================
//  Recovery
// ============================================================================

/**
 * استفاده از کد بازیابی سازندگان.
 *
 * طبق SPEC v2.0 §۹.۳:
 *   - پس از موفقیت، کاربر به Reset اجباری PIN هدایت می‌شود.
 *   - در Audit با `master_recovery_used` ثبت می‌شود.
 *   - `recoveryUsedCount` افزایش می‌یابد.
 */
export async function applyRecoveryCode(code: string): Promise<RecoveryResult> {
  if (!constantTimeEqual(code, RECOVERY_CODE)) {
    return {
      success: false,
      mustReset: false,
      message: 'کد بازیابی نادرست است',
    };
  }

  try {
    const profile = await getProfile();
    const nextCount = profile.recoveryUsedCount + 1;

    await securityRepo.update({
      recoveryUsedCount: nextCount,
      failedAttempts: 0,
      lockoutUntil: null,
    });

    setRequiresRecoveryReset(true);

    await writeSecurityAudit(AuditAction.MASTER_RECOVERY_USED, null, {
      previousCount: profile.recoveryUsedCount,
      newCount: nextCount,
      timestamp: nowISO(),
    });

    return {
      success: true,
      mustReset: true,
      message: 'دسترسی بازیابی شد. لطفاً رمز جدید تعیین کنید.',
    };
  } catch (e) {
    return {
      success: false,
      mustReset: false,
      message: e instanceof Error ? e.message : 'خطا در بازیابی',
    };
  }
}

/**
 * تکمیل جریان Recovery Reset با PIN جدید.
 *
 * طبق SPEC v2.0 §۹.۳: پس از موفقیت، کاربر Unlock می‌شود.
 * `patternHash` پاک می‌شود چون کاربر پین جدید تعیین کرده.
 * `biometricEnabled` هم برای امنیت خاموش می‌شود.
 */
export async function completeRecoveryReset(newPin: string): Promise<SetupResult> {
  if (!session.requiresRecoveryReset) {
    return { success: false, error: 'جریان بازیابی فعال نیست' };
  }

  const validationError = validatePin(newPin);
  if (validationError) {
    return { success: false, error: validationError };
  }

  try {
    const hash = await hashSecret(newPin);

    await securityRepo.update({
      pinHash: hash,
      patternHash: null,
      primaryMethod: PrimarySecurityMethod.PIN,
      biometricEnabled: false,
      failedAttempts: 0,
      lockoutUntil: null,
    });

    session.requiresRecoveryReset = false;
    setSecurityConfigured(true);
    session.unlocked = true;
    session.lastActivityAt = Date.now();

    await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
      event: 'RECOVERY_PIN_RESET',
    });

    notifySessionListeners();
    void scheduleAutoLock();

    return { success: true };
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'تعیین پین جدید با خطا مواجه شد',
    };
  }
}

export async function getRecoveryUsedCount(): Promise<number> {
  const profile = await getProfile();
  return profile.recoveryUsedCount;
}

// ============================================================================
//  Lock policy
// ============================================================================

export async function shouldLock(): Promise<boolean> {
  if (!(await isConfigured())) return false;
  if (!session.unlocked) return true;

  const timeout = await getLockTimeout();
  if (timeout <= 0) return false;

  const elapsedSeconds = (Date.now() - session.lastActivityAt) / 1000;
  return elapsedSeconds >= timeout;
}

export async function lockApp(): Promise<void> {
  clearAutoLockTimer();
  session.unlocked = false;
  await enablePrivacyOverlay();
  notifySessionListeners();
}

export async function unlockApp(): Promise<void> {
  session.unlocked = true;
  session.lastActivityAt = Date.now();
  await disablePrivacyOverlay();
  notifySessionListeners();
  await scheduleAutoLock();
}

// ============================================================================
//  Remove all security (dangerous)
// ============================================================================

export async function removeAllSecurity(currentPin: string): Promise<SetupResult> {
  const verify = await verifyPIN(currentPin);
  if (!verify.success) {
    return { success: false, error: 'پین فعلی نادرست است' };
  }

  try {
    await securityRepo.update({
      pinHash: null,
      patternHash: null,
      biometricEnabled: false,
      primaryMethod: null,
      failedAttempts: 0,
      lockoutUntil: null,
      configuredAt: null,
    });

    await writeSecurityAudit(AuditAction.SECURITY_CHANGE, null, {
      event: 'SECURITY_REMOVED',
    });

    setRequiresRecoveryReset(false);
    setSecurityConfigured(false);
    await unlockApp();
    return { success: true };
  } catch (e) {
    return {
      success: false,
      error: e instanceof Error ? e.message : 'حذف امنیت با خطا مواجه شد',
    };
  }
}

// ============================================================================
//  Utility exports (for tests and external consumers)
// ============================================================================

export const securityUtils = {
  validatePin,
  validatePattern,
  hashSecret,
  verifySecret,
  constantTimeEqual,
  isNativePlatform,
  isSupportedLockTimeout,
};

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
