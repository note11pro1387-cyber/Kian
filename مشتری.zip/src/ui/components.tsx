// src/ui/components.tsx

import {
  forwardRef,
  memo,
  useCallback,
  useEffect,
  useId,
  useLayoutEffect,
  useMemo,
  useRef,
  useState,
  type CSSProperties,
  type ChangeEvent,
  type KeyboardEvent,
  type MouseEvent,
  type PointerEvent as ReactPointerEvent,
  type ReactNode,
  type RefObject,
  type TextareaHTMLAttributes,
  type ButtonHTMLAttributes,
  type InputHTMLAttributes,
  type HTMLAttributes,
} from 'react';
import { createPortal } from 'react-dom';

import {
  AlertTriangle,
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  Check,
  ChevronDown,
  ChevronLeft,
  CircleAlert,
  CircleCheck,
  CircleDollarSign,
  Coins,
  FolderKanban,
  House,
  Info,
  Landmark,
  LockKeyhole,
  MoreHorizontal,
  Plus,
  ReceiptText,
  Search,
  Settings2,
  UserRound,
  Wallet,
  X,
} from 'lucide-react';

import { useTranslation } from '../i18n';
import { translate, type TranslationKey } from '../i18n';

import {
  formatMoneyPlain,
  normalizeDigits,
  numberToPersianWords,
  parseAmountExpression,
  parseMoney,
} from '../formatters';

import { useUIStore, type UISheetName, type UIModalName } from '../store';
import type { ToastMessage } from '../types';

// ─── Hooks ─────────────────────────────────────────────────────────────

export function useMediaQuery(query: string): boolean {
  const [matches, setMatches] = useState<boolean>(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return false;
    }
    try {
      return window.matchMedia(query).matches;
    } catch {
      return false;
    }
  });

  useEffect(() => {
    if (typeof window === 'undefined' || typeof window.matchMedia !== 'function') {
      return;
    }
    let mql: MediaQueryList;
    try {
      mql = window.matchMedia(query);
    } catch {
      return;
    }
    const handler = (e: MediaQueryListEvent) => setMatches(e.matches);
    setMatches(mql.matches);
    mql.addEventListener('change', handler);
    return () => mql.removeEventListener('change', handler);
  }, [query]);

  return matches;
}

export function useReducedMotion(): boolean {
  return useMediaQuery('(prefers-reduced-motion: reduce)');
}

export function useEscapeKey(handler: () => void, enabled: boolean): void {
  useEffect(() => {
    if (!enabled) return;
    const onKey = (e: globalThis.KeyboardEvent) => {
      if (e.key === 'Escape') {
        e.stopPropagation();
        handler();
      }
    };
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, [handler, enabled]);
}

export function useClickOutside<T extends HTMLElement>(
  ref: RefObject<T | null>,
  handler: () => void,
  enabled: boolean = true
): void {
  useEffect(() => {
    if (!enabled) return;
    const onPointerDown = (e: PointerEvent) => {
      const el = ref.current;
      if (!el) return;
      if (!el.contains(e.target as Node)) handler();
    };
    document.addEventListener('pointerdown', onPointerDown);
    return () => document.removeEventListener('pointerdown', onPointerDown);
  }, [handler, enabled, ref]);
}

export function useFocusTrap<T extends HTMLElement>(
  ref: RefObject<T | null>,
  enabled: boolean
): void {
  useEffect(() => {
    if (!enabled) return;
    const el = ref.current;
    if (!el) return;

    const previouslyFocused = document.activeElement as HTMLElement | null;

    const focusFirst = () => {
      const focusable = el.querySelectorAll<HTMLElement>(
        'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
      );
      if (focusable.length > 0) focusable[0]!.focus();
      else el.focus();
    };

    const onKeyDown = (e: globalThis.KeyboardEvent) => {
      if (e.key !== 'Tab') return;
      const focusable = Array.from(
        el.querySelectorAll<HTMLElement>(
          'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
        )
      ).filter((node) => node.offsetParent !== null || node === document.activeElement);

      if (focusable.length === 0) {
        e.preventDefault();
        return;
      }

      const first = focusable[0]!;
      const last = focusable[focusable.length - 1]!;
      const active = document.activeElement as HTMLElement | null;

      if (!e.shiftKey && active === last) {
        e.preventDefault();
        first.focus();
      } else if (e.shiftKey && active === first) {
        e.preventDefault();
        last.focus();
      }
    };

    const raf = requestAnimationFrame(focusFirst);
    el.addEventListener('keydown', onKeyDown);

    return () => {
      cancelAnimationFrame(raf);
      el.removeEventListener('keydown', onKeyDown);
      if (previouslyFocused && previouslyFocused.focus) previouslyFocused.focus();
    };
  }, [enabled, ref]);
}

export function useBodyScrollLock(enabled: boolean): void {
  useLayoutEffect(() => {
    if (!enabled) return;
    const original = document.body.style.overflow;
    const originalPadding = document.body.style.paddingInlineEnd;
    const scrollbarWidth = window.innerWidth - document.documentElement.clientWidth;
    document.body.style.overflow = 'hidden';
    if (scrollbarWidth > 0) {
      document.body.style.paddingInlineEnd = `${scrollbarWidth}px`;
    }
    return () => {
      document.body.style.overflow = original;
      document.body.style.paddingInlineEnd = originalPadding;
    };
  }, [enabled]);
}

// ─── Icon map ──────────────────────────────────────────────────────────

const ACCOUNT_ICONS = {
  bank: Landmark,
  cash: Banknote,
  card: Wallet,
  treasury: Coins,
} as const;

// ─── Button ────────────────────────────────────────────────────────────

export type ButtonVariant =
  | 'primary'
  | 'secondary'
  | 'ghost'
  | 'danger'
  | 'success'
  | 'income'
  | 'expense';

export type ButtonSize = 'sm' | 'md' | 'lg';

export interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: ButtonVariant;
  size?: ButtonSize;
  block?: boolean;
  loading?: boolean;
  success?: boolean;
  leadingIcon?: ReactNode;
  trailingIcon?: ReactNode;
}

export const Button = forwardRef<HTMLButtonElement, ButtonProps>(function Button(
  {
    variant = 'secondary',
    size = 'md',
    block = false,
    loading = false,
    success = false,
    leadingIcon,
    trailingIcon,
    className,
    children,
    disabled,
    type = 'button',
    ...rest
  },
  ref
) {
  const classes = [
    'btn',
    `btn--${variant}`,
    size !== 'md' ? `btn--${size}` : '',
    block ? 'btn--block' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <button
      ref={ref}
      type={type}
      className={classes}
      disabled={disabled || loading || success}
      aria-busy={loading || undefined}
      {...rest}
    >
      {leadingIcon && !loading && !success ? (
        <span className="btn__leading" aria-hidden="true">
          {leadingIcon}
        </span>
      ) : null}
      <span className="btn__label">{children}</span>
      {trailingIcon && !loading && !success ? (
        <span className="btn__trailing" aria-hidden="true">
          {trailingIcon}
        </span>
      ) : null}
      {loading ? <span className="spinner spinner--sm" aria-hidden="true" /> : null}
      {success ? <Check size={18} aria-hidden="true" /> : null}
    </button>
  );
});

export interface StatefulButtonProps extends Omit<ButtonProps, 'loading' | 'success'> {
  state: 'idle' | 'loading' | 'success';
}

export const StatefulButton = forwardRef<HTMLButtonElement, StatefulButtonProps>(
  function StatefulButton(
    { state, variant = 'primary', size = 'lg', className, children, ...rest },
    ref
  ) {
    const isLoading = state === 'loading';
    const isSuccess = state === 'success';
    const classes = [
      'btn',
      `btn--${variant}`,
      `btn--${size}`,
      'btn-submit',
      isLoading ? 'is-loading' : '',
      isSuccess ? 'is-success' : '',
      className ?? '',
    ]
      .filter(Boolean)
      .join(' ');

    return (
      <button
        ref={ref}
        type="submit"
        className={classes}
        disabled={isLoading || isSuccess}
        aria-busy={isLoading || undefined}
        aria-live="polite"
        {...rest}
      >
        <span className="btn-submit__text">{children}</span>
        <span className="btn-submit__spinner" aria-hidden="true" />
        <svg
          className="btn-submit__check"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={3.5}
          strokeLinecap="round"
          strokeLinejoin="round"
          aria-hidden="true"
        >
          <polyline points="20 6 9 17 4 12" />
        </svg>
      </button>
    );
  }
);

// ─── IconButton ────────────────────────────────────────────────────────

export interface IconButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  'aria-label': string;
  size?: 'sm' | 'md';
  variant?: 'default' | 'danger';
  children: ReactNode;
}

export const IconButton = forwardRef<HTMLButtonElement, IconButtonProps>(
  function IconButton(
    {
      'aria-label': ariaLabel,
      size = 'md',
      variant = 'default',
      className,
      children,
      type = 'button',
      ...rest
    },
    ref
  ) {
    const classes = [
      'icon-btn',
      size === 'sm' ? 'icon-btn--sm' : '',
      variant === 'danger' ? 'icon-btn--danger' : '',
      className ?? '',
    ]
      .filter(Boolean)
      .join(' ');

    return (
      <button
        ref={ref}
        type={type}
        className={classes}
        aria-label={ariaLabel}
        title={ariaLabel}
        {...rest}
      >
        {children}
      </button>
    );
  }
);

// ─── FAB ───────────────────────────────────────────────────────────────

export interface FABProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  ariaLabel?: string;
}

export const FAB = forwardRef<HTMLButtonElement, FABProps>(function FAB(
  { ariaLabel, className, children, type = 'button', ...rest },
  ref
) {
  const { t } = useTranslation();
  const label = ariaLabel ?? t('tx.new' as TranslationKey);
  return (
    <button
      ref={ref}
      type={type}
      className={['fab', className ?? ''].filter(Boolean).join(' ')}
      aria-label={label}
      title={label}
      {...rest}
    >
      {children ?? <Plus aria-hidden="true" />}
    </button>
  );
});

// ─── Field ─────────────────────────────────────────────────────────────

export interface FieldProps {
  label?: ReactNode;
  required?: boolean;
  error?: string | null | undefined;
  hint?: ReactNode;
  htmlFor?: string;
  children: ReactNode;
  className?: string;
}

export function Field({
  label,
  required,
  error,
  hint,
  htmlFor,
  children,
  className,
}: FieldProps) {
  return (
    <div className={['field', className ?? ''].filter(Boolean).join(' ')}>
      {label ? (
        <label
          htmlFor={htmlFor}
          className={['field__label', required ? 'field__label--required' : '']
            .filter(Boolean)
            .join(' ')}
        >
          {label}
        </label>
      ) : null}
      {children}
      {error ? (
        <span className="field__error" role="alert">
          <CircleAlert aria-hidden="true" />
          {error}
        </span>
      ) : hint ? (
        <span className="field__hint">{hint}</span>
      ) : null}
    </div>
  );
}

// ─── Input ─────────────────────────────────────────────────────────────

export interface InputProps extends InputHTMLAttributes<HTMLInputElement> {
  invalid?: boolean;
  suffix?: ReactNode;
}

export const Input = forwardRef<HTMLInputElement, InputProps>(function Input(
  { invalid, suffix, className, type = 'text', ...rest },
  ref
) {
  if (suffix) {
    return (
      <div className="input-wrapper">
        <input
          ref={ref}
          type={type}
          className={['input', invalid ? 'input--invalid' : '', className ?? '']
            .filter(Boolean)
            .join(' ')}
          aria-invalid={invalid || undefined}
          {...rest}
        />
        <span className="input-wrapper__suffix">{suffix}</span>
      </div>
    );
  }

  return (
    <input
      ref={ref}
      type={type}
      className={['input', invalid ? 'input--invalid' : '', className ?? '']
        .filter(Boolean)
        .join(' ')}
      aria-invalid={invalid || undefined}
      {...rest}
    />
  );
});

export interface TextareaProps extends TextareaHTMLAttributes<HTMLTextAreaElement> {
  invalid?: boolean;
}

export const Textarea = forwardRef<HTMLTextAreaElement, TextareaProps>(function Textarea(
  { invalid, className, ...rest },
  ref
) {
  return (
    <textarea
      ref={ref}
      className={['textarea', invalid ? 'textarea--invalid' : '', className ?? '']
        .filter(Boolean)
        .join(' ')}
      aria-invalid={invalid || undefined}
      {...rest}
    />
  );
});

// ─── AmountInput ───────────────────────────────────────────────────────

export interface AmountInputProps {
  value: string;
  onChange: (raw: string, amount: bigint | null) => void;
  onBlur?: () => void;
  invalid?: boolean;
  autoFocus?: boolean;
  placeholder?: string;
  ariaLabel?: string;
  id?: string;
  disabled?: boolean;
}

export function AmountInput({
  value,
  onChange,
  onBlur,
  invalid,
  autoFocus,
  placeholder,
  ariaLabel,
  id,
  disabled,
}: AmountInputProps) {
  const localId = useId();
  const finalId = id ?? localId;
  const { t } = useTranslation();

  const formatted = useMemo(() => formatAmountForDisplay(value), [value]);

  const parsed = useMemo<bigint | null>(() => {
    if (!value || value.trim().length === 0) return null;
    const cleaned = normalizeDigits(value).replace(/[,\s،]/g, '');
    if (cleaned.length === 0) return null;

    if (/[+\-]/.test(cleaned)) {
      return parseAmountExpression(cleaned);
    }
    const direct = parseMoney(cleaned);
    return direct && direct > 0n ? direct : null;
  }, [value]);

  const words = useMemo(() => {
    if (!parsed || parsed <= 0n) return '';
    try {
      return numberToPersianWords(parsed);
    } catch {
      return '';
    }
  }, [parsed]);

  const handleChange = useCallback(
    (e: ChangeEvent<HTMLInputElement>) => {
      const raw = e.target.value;
      const normalized = normalizeDigits(raw).replace(/[^\d+\-,\s]/g, '');
      onChange(normalized, parseAmountExpression(normalized) ?? parseMoney(normalized));
    },
    [onChange]
  );

  return (
    <div className="amount-input">
      <div
        className={['amount-input__field', invalid ? 'input--invalid' : '']
          .filter(Boolean)
          .join(' ')}
      >
        <input
          id={finalId}
          type="text"
          inputMode="numeric"
          autoComplete="off"
          autoFocus={autoFocus}
          disabled={disabled}
          value={formatted}
          onChange={handleChange}
          onBlur={onBlur}
          placeholder={placeholder ?? '0'}
          aria-label={ariaLabel ?? t('app.amount' as TranslationKey)}
          aria-invalid={invalid || undefined}
          className="amount-input__input"
          dir="ltr"
        />
        <span className="amount-input__unit" aria-hidden="true">
          {t('app.toman' as TranslationKey)}
        </span>
      </div>
      {words ? (
        <div className="amount-input__words" aria-live="polite">
          {words}
        </div>
      ) : null}
    </div>
  );
}

function formatAmountForDisplay(raw: string): string {
  if (!raw) return '';
  const cleaned = normalizeDigits(raw);

  if (/[+\-]/.test(cleaned)) {
    return cleaned
      .split(/([+\-])/)
      .map((part) => {
        if (part === '+' || part === '-') return ` ${part} `;
        const digits = part.replace(/[^\d]/g, '');
        if (!digits) return part;
        return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
      })
      .join('');
  }

  const digits = cleaned.replace(/[^\d]/g, '');
  if (!digits) return '';
  return digits.replace(/\B(?=(\d{3})+(?!\d))/g, ',');
}

// ─── Select ────────────────────────────────────────────────────────────

export interface SelectOption<T extends string = string> {
  value: T;
  label: string;
  disabled?: boolean;
}

export interface SelectProps<T extends string = string> {
  value: T | null;
  options: ReadonlyArray<SelectOption<T>>;
  onChange: (value: T | null) => void;
  placeholder?: string;
  disabled?: boolean;
  invalid?: boolean;
  id?: string;
  ariaLabel?: string;
}

export function Select<T extends string = string>({
  value,
  options,
  onChange,
  placeholder,
  disabled,
  invalid,
  id,
  ariaLabel,
}: SelectProps<T>) {
  const localId = useId();
  const finalId = id ?? localId;
  const [open, setOpen] = useState(false);
  const wrapperRef = useRef<HTMLDivElement | null>(null);

  useClickOutside(wrapperRef, () => setOpen(false), open);
  useEscapeKey(() => setOpen(false), open);

  const selected = options.find((o) => o.value === value) ?? null;

  return (
    <div
      ref={wrapperRef}
      className={['select', open ? 'select--open' : ''].filter(Boolean).join(' ')}
    >
      <button
        id={finalId}
        type="button"
        className="select__trigger"
        disabled={disabled}
        aria-haspopup="listbox"
        aria-expanded={open}
        aria-label={ariaLabel}
        aria-invalid={invalid || undefined}
        onClick={() => setOpen((v) => !v)}
      >
        <span className={[selected ? 'select__value' : 'select__placeholder'].join(' ')}>
          {selected?.label ?? placeholder ?? '—'}
        </span>
        <ChevronDown className="select__chevron" aria-hidden="true" />
      </button>

      {open ? (
        <ul
          role="listbox"
          aria-labelledby={finalId}
          className="select__list"
          style={{
            position: 'absolute',
            zIndex: 50,
            insetInline: 0,
            marginTop: 4,
            background: 'var(--surface)',
            border: '1px solid var(--border)',
            borderRadius: 'var(--radius-md)',
            boxShadow: 'var(--shadow-lg)',
            maxHeight: 280,
            overflowY: 'auto',
            padding: 4,
          }}
        >
          {options.map((opt) => {
            const isActive = opt.value === value;
            return (
              <li
                key={opt.value}
                role="option"
                aria-selected={isActive}
                aria-disabled={opt.disabled || undefined}
                className="select__option"
                style={{
                  padding: '10px 12px',
                  borderRadius: 'var(--radius-sm)',
                  background: isActive ? 'var(--primary-soft)' : 'transparent',
                  color: isActive ? 'var(--primary)' : 'var(--text)',
                  cursor: opt.disabled ? 'not-allowed' : 'pointer',
                  opacity: opt.disabled ? 0.5 : 1,
                  fontSize: 'var(--text-body-size)',
                }}
                onClick={() => {
                  if (opt.disabled) return;
                  onChange(opt.value);
                  setOpen(false);
                }}
                onKeyDown={(e: KeyboardEvent<HTMLLIElement>) => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    if (opt.disabled) return;
                    onChange(opt.value);
                    setOpen(false);
                  }
                }}
                tabIndex={0}
              >
                {opt.label}
              </li>
            );
          })}
        </ul>
      ) : null}
    </div>
  );
}

// ─── Checkbox ──────────────────────────────────────────────────────────

export interface CheckboxProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  label?: ReactNode;
  disabled?: boolean;
  id?: string;
  ariaLabel?: string;
}

export function Checkbox({
  checked,
  onChange,
  label,
  disabled,
  id,
  ariaLabel,
}: CheckboxProps) {
  const localId = useId();
  const finalId = id ?? localId;

  return (
    <label
      htmlFor={finalId}
      className="checkbox"
      style={disabled ? { opacity: 0.5, cursor: 'not-allowed' } : undefined}
    >
      <input
        id={finalId}
        type="checkbox"
        className="checkbox__input"
        checked={checked}
        disabled={disabled}
        aria-label={ariaLabel}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span className="checkbox__box" aria-hidden="true">
        <svg
          className="checkbox__check"
          viewBox="0 0 24 24"
          fill="none"
          stroke="currentColor"
          strokeWidth={3}
          strokeLinecap="round"
          strokeLinejoin="round"
        >
          <polyline points="20 6 9 17 4 12" />
        </svg>
      </span>
      {label ? <span className="checkbox__label">{label}</span> : null}
    </label>
  );
}

// ─── Switch ────────────────────────────────────────────────────────────

export interface SwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
  disabled?: boolean;
  id?: string;
  ariaLabel: string;
}

export function Switch({ checked, onChange, disabled, id, ariaLabel }: SwitchProps) {
  const localId = useId();
  const finalId = id ?? localId;

  return (
    <label htmlFor={finalId} className="switch">
      <input
        id={finalId}
        type="checkbox"
        className="switch__input"
        checked={checked}
        disabled={disabled}
        aria-label={ariaLabel}
        onChange={(e) => onChange(e.target.checked)}
      />
      <span className="switch__track" aria-hidden="true">
        <span className="switch__thumb" />
      </span>
    </label>
  );
}

// ─── Card ──────────────────────────────────────────────────────────────

export interface CardProps extends HTMLAttributes<HTMLDivElement> {
  elevated?: boolean;
  flat?: boolean;
  interactive?: boolean;
}

export const Card = forwardRef<HTMLDivElement, CardProps>(function Card(
  { elevated, flat, interactive, className, children, onClick, ...rest },
  ref
) {
  const classes = [
    'card',
    elevated ? 'card--elevated' : '',
    flat ? 'card--flat' : '',
    interactive ? 'card--interactive' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  const isInteractive = interactive || Boolean(onClick);

  return (
    <div
      ref={ref}
      className={classes}
      onClick={onClick}
      role={isInteractive ? 'button' : undefined}
      tabIndex={isInteractive ? 0 : undefined}
      onKeyDown={
        isInteractive && onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick(e as unknown as MouseEvent<HTMLDivElement>);
              }
            }
          : undefined
      }
      {...rest}
    >
      {children}
    </div>
  );
});

// ─── HeroCard ──────────────────────────────────────────────────────────

export interface HeroCardProps {
  label: string;
  amount: bigint;
  delta?: bigint;
  deltaLabel?: string;
  hidden?: boolean;
  onToggleHidden?: () => void;
  sparklineData?: ReadonlyArray<bigint>;
  className?: string;
}

export const HeroCard = memo(function HeroCard({
  label,
  amount,
  delta,
  deltaLabel,
  hidden,
  onToggleHidden,
  sparklineData,
  className,
}: HeroCardProps) {
  const { t } = useTranslation();
  const isNegative = amount < 0n;
  const deltaSign = delta === undefined ? 0 : delta > 0n ? 1 : delta < 0n ? -1 : 0;

  return (
    <div className={['hero-card', className ?? ''].filter(Boolean).join(' ')}>
      <div className="hero-card__top">
        <span className="hero-card__label">{label}</span>
        {onToggleHidden ? (
          <button
            type="button"
            className="icon-btn icon-btn--sm"
            aria-label={
              hidden
                ? t('dashboard.showAmount' as TranslationKey)
                : t('dashboard.hideAmount' as TranslationKey)
            }
            onClick={onToggleHidden}
          >
            {hidden ? (
              <svg
                viewBox="0 0 24 24"
                width={16}
                height={16}
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24" />
                <line x1="1" y1="1" x2="23" y2="23" />
              </svg>
            ) : (
              <svg
                viewBox="0 0 24 24"
                width={16}
                height={16}
                fill="none"
                stroke="currentColor"
                strokeWidth={2}
                strokeLinecap="round"
                strokeLinejoin="round"
                aria-hidden="true"
              >
                <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z" />
                <circle cx="12" cy="12" r="3" />
              </svg>
            )}
          </button>
        ) : null}
      </div>

      <div
        className={['hero-card__amount', isNegative ? 'amount-negative' : '']
          .filter(Boolean)
          .join(' ')}
      >
        <span className="amount-value" dir="ltr">
          {hidden ? '•••••••' : formatMoneyPlain(amount)}
        </span>
        <span className="amount-unit">{t('app.toman' as TranslationKey)}</span>
      </div>

      {delta !== undefined && deltaLabel ? (
        <div
          className={[
            'hero-card__delta',
            deltaSign > 0 ? 'hero-card__delta--positive' : '',
            deltaSign < 0 ? 'hero-card__delta--negative' : '',
          ]
            .filter(Boolean)
            .join(' ')}
        >
          {deltaSign > 0 ? '+' : deltaSign < 0 ? '−' : ''}
          {hidden ? '•••••' : formatMoneyPlain(delta < 0n ? -delta : delta)} {deltaLabel}
        </div>
      ) : null}

      {sparklineData && sparklineData.length > 1 ? (
        <div className="hero-card__sparkline">
          <Sparkline
            data={sparklineData}
            variant={isNegative ? 'warning' : 'primary'}
            height={40}
          />
        </div>
      ) : null}
    </div>
  );
});

// ─── AccountCard ───────────────────────────────────────────────────────

export interface AccountCardProps {
  name: string;
  type: 'bank' | 'cash' | 'card' | 'treasury';
  balance: bigint;
  totalInflow: bigint;
  totalOutflow: bigint;
  transactionCount: number;
  isArchived?: boolean;
  isNegative?: boolean;
  hidden?: boolean;
  onClick?: () => void;
  className?: string;
}

export const AccountCard = memo(function AccountCard({
  name,
  type,
  balance,
  totalInflow,
  totalOutflow,
  transactionCount,
  isArchived,
  isNegative,
  hidden,
  onClick,
  className,
}: AccountCardProps) {
  const { t } = useTranslation();
  const Icon = ACCOUNT_ICONS[type] ?? Landmark;

  return (
    <div
      className={[
        'account-card',
        isArchived ? 'account-card--archived' : '',
        isNegative ? 'account-card--negative' : '',
        className ?? '',
      ]
        .filter(Boolean)
        .join(' ')}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
    >
      <div className="account-card__header">
        <div className="account-card__icon">
          <Icon aria-hidden="true" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="account-card__name">{name}</div>
          <div className="account-card__type">
            {t(`account.type.${type}` as TranslationKey)}
          </div>
        </div>
      </div>

      <div className="account-card__balance">
        <span className="amount-value" dir="ltr">
          {hidden ? '•••••••' : formatMoneyPlain(balance)}
        </span>
        <span className="amount-unit">{t('app.toman' as TranslationKey)}</span>
      </div>

      <div className="account-card__meta">
        <span className="account-card__meta-item account-card__meta-item--income">
          <ArrowDownLeft size={12} aria-hidden="true" />
          {hidden ? '••••' : formatMoneyPlain(totalInflow)}
        </span>
        <span className="account-card__meta-item account-card__meta-item--expense">
          <ArrowUpRight size={12} aria-hidden="true" />
          {hidden ? '••••' : formatMoneyPlain(totalOutflow)}
        </span>
        <span className="account-card__meta-item">
          {t('account.transactionCount' as TranslationKey)}: {transactionCount}
        </span>
      </div>
    </div>
  );
});

// ─── TransactionRow ────────────────────────────────────────────────────

export interface TransactionRowProps {
  type: 'deposit' | 'expense';
  amount: bigint;
  title: string;
  subtitle?: string;
  time?: string;
  displayCode?: string;
  isDeleted?: boolean;
  onClick?: () => void;
  className?: string;
}

export const TransactionRow = memo(function TransactionRow({
  type,
  amount,
  title,
  subtitle,
  time,
  displayCode,
  isDeleted,
  onClick,
  className,
}: TransactionRowProps) {
  const isDeposit = type === 'deposit';

  return (
    <div
      className={[
        'tx-row',
        isDeposit ? 'tx-row--deposit' : 'tx-row--expense',
        isDeleted ? 'tx-row--deleted' : '',
        className ?? '',
      ]
        .filter(Boolean)
        .join(' ')}
      onClick={onClick}
      role={onClick ? 'button' : undefined}
      tabIndex={onClick ? 0 : undefined}
      onKeyDown={
        onClick
          ? (e) => {
              if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onClick();
              }
            }
          : undefined
      }
    >
      <div className="tx-row__icon">
        {isDeposit ? (
          <ArrowDownLeft aria-hidden="true" />
        ) : (
          <ArrowUpRight aria-hidden="true" />
        )}
      </div>

      <div className="tx-row__body">
        <div className="tx-row__title">{title}</div>
        <div className="tx-row__subtitle">
          {subtitle ? <span>{subtitle}</span> : null}
          {subtitle && (time || displayCode) ? (
            <span className="tx-row__subtitle-sep">•</span>
          ) : null}
          {time ? <span dir="ltr">{time}</span> : null}
          {time && displayCode ? <span className="tx-row__subtitle-sep">•</span> : null}
          {displayCode ? <span dir="ltr">{displayCode}</span> : null}
        </div>
      </div>

      <div className="tx-row__amount">
        <span className="amount-value" dir="ltr">
          {isDeposit ? '+' : '−'}
          {formatMoneyPlain(amount)}
        </span>
        {isDeleted ? (
          <div className="tx-row__status-badge">
            {translate('audit.action.delete' as TranslationKey)}
          </div>
        ) : null}
      </div>
    </div>
  );
});

export interface TransactionDayHeaderProps {
  dateLabel: string;
  inflow: bigint;
  outflow: bigint;
  hidden?: boolean;
}

export const TransactionDayHeader = memo(function TransactionDayHeader({
  dateLabel,
  inflow,
  outflow,
  hidden,
}: TransactionDayHeaderProps) {
  return (
    <div className="tx-day-header">
      <span>{dateLabel}</span>
      <div className="tx-day-header__totals">
        {inflow > 0n ? (
          <span className="tx-day-header__inflow" dir="ltr">
            +{hidden ? '•••' : formatMoneyPlain(inflow)}
          </span>
        ) : null}
        {outflow > 0n ? (
          <span className="tx-day-header__outflow" dir="ltr">
            −{hidden ? '•••' : formatMoneyPlain(outflow)}
          </span>
        ) : null}
      </div>
    </div>
  );
});

// ─── MenuRow ───────────────────────────────────────────────────────────

export interface MenuRowProps {
  icon?: ReactNode;
  title: ReactNode;
  description?: ReactNode;
  trailing?: ReactNode;
  onClick?: (() => void) | undefined;
  className?: string;
}

export function MenuRow({
  icon,
  title,
  description,
  trailing,
  onClick,
  className,
}: MenuRowProps) {
  return (
    <button
      type="button"
      className={['menu-row', className ?? ''].filter(Boolean).join(' ')}
      onClick={onClick}
    >
      {icon ? (
        <span className="menu-row__icon" aria-hidden="true">
          {icon}
        </span>
      ) : null}
      <span className="menu-row__body">
        <span className="menu-row__title">{title}</span>
        {description ? (
          <span className="menu-row__description">{description}</span>
        ) : null}
      </span>
      {trailing ?? <ChevronLeft className="menu-row__chevron" aria-hidden="true" />}
    </button>
  );
}

// ─── Badge / Alert ─────────────────────────────────────────────────────

export type BadgeVariant =
  | 'default'
  | 'primary'
  | 'success'
  | 'warning'
  | 'danger'
  | 'info';

export interface BadgeProps {
  variant?: BadgeVariant;
  children?: ReactNode;
  className?: string;
  dot?: boolean;
}

export function Badge({ variant = 'default', children, className, dot }: BadgeProps) {
  return (
    <span
      className={['badge', `badge--${variant}`, className ?? '']
        .filter(Boolean)
        .join(' ')}
    >
      {dot ? <span className="badge__dot" aria-hidden="true" /> : null}
      {children}
    </span>
  );
}

export type AlertVariant = 'info' | 'success' | 'warning' | 'danger';

export interface AlertProps {
  variant: AlertVariant;
  title?: ReactNode;
  children: ReactNode;
  className?: string;
}

export function Alert({ variant, title, children, className }: AlertProps) {
  const Icon =
    variant === 'danger' || variant === 'warning'
      ? AlertTriangle
      : variant === 'success'
        ? CircleCheck
        : Info;

  return (
    <div
      className={['alert', `alert--${variant}`, className ?? '']
        .filter(Boolean)
        .join(' ')}
      role={variant === 'danger' ? 'alert' : 'status'}
    >
      <Icon className="alert__icon" aria-hidden="true" />
      <div className="alert__body">
        {title ? <div className="alert__title">{title}</div> : null}
        <div className="alert__message">{children}</div>
      </div>
    </div>
  );
}

// ─── Spinner / Skeleton ────────────────────────────────────────────────

export interface SpinnerProps {
  size?: 'sm' | 'md' | 'lg';
  className?: string;
}

export function Spinner({ size = 'md', className }: SpinnerProps) {
  const classes = [
    'spinner',
    size === 'sm' ? 'spinner--sm' : '',
    size === 'lg' ? 'spinner--lg' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');
  return (
    <span
      className={classes}
      role="status"
      aria-label={translate('app.loading.short' as TranslationKey)}
    />
  );
}

export function OrbitLoader({ label }: { label?: string }) {
  const { t } = useTranslation();
  return (
    <div className="spinner-container">
      <div
        className="orbit-loader"
        role="status"
        aria-label={label ?? t('app.loading.short' as TranslationKey)}
      >
        <span className="orbit-loader__ring" />
        <span className="orbit-loader__core" />
      </div>
      {label ? <span>{label}</span> : null}
    </div>
  );
}

export interface SkeletonProps {
  variant?: 'text' | 'title' | 'circle' | 'card' | 'row';
  width?: number | string;
  height?: number | string;
  className?: string;
  style?: CSSProperties;
}

export function Skeleton({
  variant = 'text',
  width,
  height,
  className,
  style,
}: SkeletonProps) {
  const classes = [
    'skeleton',
    variant === 'text' ? 'skeleton--text' : '',
    variant === 'title' ? 'skeleton--title' : '',
    variant === 'circle' ? 'skeleton--circle' : '',
    variant === 'card' ? 'skeleton--card' : '',
    variant === 'row' ? 'skeleton--row' : '',
    className ?? '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div
      className={classes}
      style={{
        width: width ?? undefined,
        height: height ?? undefined,
        ...style,
      }}
      aria-hidden="true"
    />
  );
}

export function SkeletonStack({ count = 3 }: { count?: number }) {
  return (
    <div className="skeleton-stack" aria-hidden="true">
      {Array.from({ length: count }).map((_, i) => (
        <Skeleton key={i} variant="row" />
      ))}
    </div>
  );
}

// ─── Progress ──────────────────────────────────────────────────────────

export interface ProgressBarProps {
  value: number;
  max?: number;
  variant?: 'primary' | 'income' | 'warning' | 'danger';
  size?: 'sm' | 'md' | 'lg';
  ariaLabel?: string;
}

export function ProgressBar({
  value,
  max = 1,
  variant = 'primary',
  size = 'md',
  ariaLabel,
}: ProgressBarProps) {
  const ratio = max > 0 ? Math.max(0, Math.min(1, value / max)) : 0;
  const classes = [
    'progress',
    size === 'sm' ? 'progress--sm' : '',
    size === 'lg' ? 'progress--lg' : '',
  ]
    .filter(Boolean)
    .join(' ');
  const fillClasses = [
    'progress__fill',
    variant !== 'primary' ? `progress__fill--${variant}` : '',
  ]
    .filter(Boolean)
    .join(' ');

  return (
    <div
      className={classes}
      role="progressbar"
      aria-valuemin={0}
      aria-valuemax={max}
      aria-valuenow={value}
      aria-label={ariaLabel}
    >
      <div className={fillClasses} style={{ width: `${ratio * 100}%` }} />
    </div>
  );
}

// ─── Empty / Error state ───────────────────────────────────────────────

export interface EmptyStateProps {
  icon?: ReactNode;
  title: string;
  message?: string;
  action?: ReactNode;
}

export function EmptyState({ icon, title, message, action }: EmptyStateProps) {
  return (
    <div className="empty-state">
      {icon ? (
        <div className="empty-state__icon" aria-hidden="true">
          {icon}
        </div>
      ) : (
        <div className="empty-state__icon" aria-hidden="true">
          <ReceiptText strokeWidth={1.2} />
        </div>
      )}
      <div className="empty-state__title">{title}</div>
      {message ? <div className="empty-state__message">{message}</div> : null}
      {action ? <div className="empty-state__action">{action}</div> : null}
    </div>
  );
}

export interface ErrorStateProps {
  title?: string;
  message?: string;
  actions?: ReactNode;
}

export function ErrorState({ title, message, actions }: ErrorStateProps) {
  const { t } = useTranslation();
  return (
    <div className="error-state">
      <div className="error-state__icon" aria-hidden="true">
        <CircleAlert strokeWidth={1.5} />
      </div>
      <div className="error-state__title">
        {title ?? t('error.generic' as TranslationKey)}
      </div>
      {message ? <div className="error-state__message">{message}</div> : null}
      {actions ? <div className="error-state__actions">{actions}</div> : null}
    </div>
  );
}

// ─── Toast ─────────────────────────────────────────────────────────────

function ToastItem({ toast }: { toast: ToastMessage }) {
  const [exiting, setExiting] = useState(false);
  const removeToast = useUIStore((s) => s.removeToast);
  const duration = toast.durationMs ?? 3500;

  useEffect(() => {
    if (duration <= 0) return;
    const timer = setTimeout(() => setExiting(true), Math.max(0, duration - 200));
    return () => clearTimeout(timer);
  }, [duration]);

  useEffect(() => {
    if (!exiting) return;
    const timer = setTimeout(() => removeToast(toast.id), 200);
    return () => clearTimeout(timer);
  }, [exiting, removeToast, toast.id]);

  const Icon =
    toast.kind === 'success'
      ? CircleCheck
      : toast.kind === 'error'
        ? CircleAlert
        : toast.kind === 'warning'
          ? AlertTriangle
          : Info;

  return (
    <div
      className={['toast', `toast--${toast.kind}`, exiting ? 'toast--exiting' : '']
        .filter(Boolean)
        .join(' ')}
      role={toast.kind === 'error' ? 'alert' : 'status'}
    >
      <Icon className="toast__icon" aria-hidden="true" />
      <span className="toast__message">{toast.message}</span>
      {toast.actionLabel && toast.onAction ? (
        <button
          type="button"
          className="toast__action"
          onClick={() => {
            toast.onAction?.();
            setExiting(true);
          }}
        >
          {toast.actionLabel}
        </button>
      ) : null}
      <button
        type="button"
        className="icon-btn icon-btn--sm"
        aria-label={translate('app.close' as TranslationKey)}
        onClick={() => setExiting(true)}
      >
        <X size={14} aria-hidden="true" />
      </button>
    </div>
  );
}

export function ToastContainer() {
  const toasts = useUIStore((s) => s.toasts);
  const containerRef = useRef<HTMLDivElement | null>(null);

  if (typeof document === 'undefined') return null;

  return createPortal(
    <div
      ref={containerRef}
      className="toast-container"
      role="region"
      aria-live="polite"
      aria-atomic="false"
    >
      {toasts.map((t) => (
        <ToastItem key={t.id} toast={t} />
      ))}
    </div>,
    document.body
  );
}

// ─── Header ────────────────────────────────────────────────────────────

export interface HeaderProps {
  title: ReactNode;
  onBack?: (() => void) | undefined;
  actions?: ReactNode;
  className?: string;
}

export function Header({ title, onBack, actions, className }: HeaderProps) {
  return (
    <header
      className={['header-shell', className ?? ''].filter(Boolean).join(' ')}
      role="banner"
    >
      {onBack ? (
        <IconButton aria-label={translate('app.back' as TranslationKey)} onClick={onBack}>
          <span className="header-back-icon">
            <ChevronRightChevron aria-hidden={true} />
          </span>
        </IconButton>
      ) : null}
      <h1 className="header-title">{title}</h1>
      {actions ? <div className="header-actions">{actions}</div> : null}
    </header>
  );
}

function ChevronRightChevron({ ...rest }: { 'aria-hidden'?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={20}
      height={20}
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...rest}
    >
      <polyline points="9 18 15 12 9 6" />
    </svg>
  );
}

// ─── BottomNav ─────────────────────────────────────────────────────────

export type BottomNavKey = 'home' | 'transactions' | 'accounts' | 'more';

export interface BottomNavProps {
  active: BottomNavKey;
  onNavigate: (key: BottomNavKey) => void;
  onFabClick?: () => void;
}

export const BottomNav = memo(function BottomNav({
  active,
  onNavigate,
  onFabClick,
}: BottomNavProps) {
  const { t } = useTranslation();

  const items: Array<{ key: BottomNavKey; label: string; icon: ReactNode }> = [
    {
      key: 'home',
      label: t('nav.home' as TranslationKey),
      icon: <House aria-hidden="true" />,
    },
    {
      key: 'transactions',
      label: t('nav.transactions' as TranslationKey),
      icon: <ReceiptText aria-hidden="true" />,
    },
    {
      key: 'accounts',
      label: t('nav.accounts' as TranslationKey),
      icon: <Landmark aria-hidden="true" />,
    },
    {
      key: 'more',
      label: t('nav.more' as TranslationKey),
      icon: <MoreHorizontal aria-hidden="true" />,
    },
  ];

  return (
    <nav className="bottom-nav" aria-label={t('nav.home' as TranslationKey)}>
      <div className="bottom-nav__inner">
        {items.map((item) => (
          <button
            key={item.key}
            type="button"
            className={['nav-item', active === item.key ? 'nav-item--active' : '']
              .filter(Boolean)
              .join(' ')}
            onClick={() => onNavigate(item.key)}
            aria-current={active === item.key ? 'page' : undefined}
          >
            <span className="nav-item__icon" aria-hidden="true">
              {item.icon}
            </span>
            <span className="nav-item__label">{item.label}</span>
          </button>
        ))}
      </div>
      {onFabClick ? (
        <FAB onClick={onFabClick} ariaLabel={t('tx.new' as TranslationKey)} />
      ) : null}
    </nav>
  );
});

// ─── Sidebar ───────────────────────────────────────────────────────────

export type SidebarKey =
  | 'dashboard'
  | 'transactions'
  | 'accounts'
  | 'parties'
  | 'projects'
  | 'reports'
  | 'importExport'
  | 'backup'
  | 'settings'
  | 'about';

export interface SidebarProps {
  active: SidebarKey;
  onNavigate: (key: SidebarKey) => void;
}

export const Sidebar = memo(function Sidebar({ active, onNavigate }: SidebarProps) {
  const { t } = useTranslation();

  const main: Array<{ key: SidebarKey; label: string; icon: ReactNode }> = [
    {
      key: 'dashboard',
      label: t('nav.dashboard' as TranslationKey),
      icon: <House aria-hidden="true" />,
    },
    {
      key: 'transactions',
      label: t('nav.transactions' as TranslationKey),
      icon: <ReceiptText aria-hidden="true" />,
    },
    {
      key: 'accounts',
      label: t('nav.accounts' as TranslationKey),
      icon: <Landmark aria-hidden="true" />,
    },
    {
      key: 'parties',
      label: t('nav.parties' as TranslationKey),
      icon: <UserRound aria-hidden="true" />,
    },
    {
      key: 'projects',
      label: t('nav.projects' as TranslationKey),
      icon: <FolderKanban aria-hidden="true" />,
    },
    {
      key: 'reports',
      label: t('nav.reports' as TranslationKey),
      icon: <CircleDollarSign aria-hidden="true" />,
    },
  ];

  const secondary: Array<{ key: SidebarKey; label: string; icon: ReactNode }> = [
    {
      key: 'importExport',
      label: t('nav.importExport' as TranslationKey),
      icon: <ArrowDownLeft aria-hidden="true" />,
    },
    {
      key: 'backup',
      label: t('nav.backup' as TranslationKey),
      icon: <DatabaseBackupIcon aria-hidden={true} />,
    },
    {
      key: 'settings',
      label: t('nav.settings' as TranslationKey),
      icon: <Settings2 aria-hidden="true" />,
    },
    {
      key: 'about',
      label: t('nav.about' as TranslationKey),
      icon: <Info aria-hidden="true" />,
    },
  ];

  return (
    <aside className="sidebar" aria-label={t('nav.more' as TranslationKey)}>
      <div className="sidebar__header">
        <div className="sidebar__brand">
          <span className="sidebar__brand-logo" aria-hidden="true">
            <img
              src="./assets/svg/logo-mark.svg"
              alt=""
              width={32}
              height={32}
              decoding="async"
            />
          </span>
          {t('app.name' as TranslationKey)}
        </div>
      </div>
      <nav className="sidebar__nav">
        {main.map((item) => (
          <button
            key={item.key}
            type="button"
            className={[
              'sidebar__item',
              active === item.key ? 'sidebar__item--active' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            onClick={() => onNavigate(item.key)}
            aria-current={active === item.key ? 'page' : undefined}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
        <div className="sidebar__divider" role="presentation" />
        {secondary.map((item) => (
          <button
            key={item.key}
            type="button"
            className={[
              'sidebar__item',
              active === item.key ? 'sidebar__item--active' : '',
            ]
              .filter(Boolean)
              .join(' ')}
            onClick={() => onNavigate(item.key)}
            aria-current={active === item.key ? 'page' : undefined}
          >
            {item.icon}
            <span>{item.label}</span>
          </button>
        ))}
      </nav>
    </aside>
  );
});

function DatabaseBackupIcon({ ...rest }: { 'aria-hidden'?: boolean }) {
  return (
    <svg
      viewBox="0 0 24 24"
      width={20}
      height={20}
      fill="none"
      stroke="currentColor"
      strokeWidth={2}
      strokeLinecap="round"
      strokeLinejoin="round"
      {...rest}
    >
      <ellipse cx="12" cy="5" rx="9" ry="3" />
      <path d="M21 12c0 1.66-4 3-9 3s-9-1.34-9-3" />
      <path d="M3 5v14c0 1.66 4 3 9 3s9-1.34 9-3V5" />
    </svg>
  );
}

// ─── Tabs ──────────────────────────────────────────────────────────────

export interface TabItem<T extends string = string> {
  key: T;
  label: string;
  variant?: 'income' | 'expense';
}

export interface TabsProps<T extends string = string> {
  value: T;
  items: ReadonlyArray<TabItem<T>>;
  onChange: (key: T) => void;
  ariaLabel?: string;
}

export function Tabs<T extends string = string>({
  value,
  items,
  onChange,
  ariaLabel,
}: TabsProps<T>) {
  return (
    <div className="tabs" role="tablist" aria-label={ariaLabel}>
      {items.map((item) => (
        <button
          key={item.key}
          type="button"
          role="tab"
          aria-selected={value === item.key}
          className={[
            'tab',
            value === item.key ? 'tab--active' : '',
            item.variant === 'income' ? 'tab--income' : '',
            item.variant === 'expense' ? 'tab--expense' : '',
          ]
            .filter(Boolean)
            .join(' ')}
          onClick={() => onChange(item.key)}
        >
          {item.label}
        </button>
      ))}
    </div>
  );
}

// ─── Divider ───────────────────────────────────────────────────────────

export interface DividerProps {
  label?: string;
  vertical?: boolean;
  className?: string;
}

export function Divider({ label, vertical, className }: DividerProps) {
  if (vertical) {
    return (
      <div
        className={['divider divider--vertical', className ?? '']
          .filter(Boolean)
          .join(' ')}
        role="separator"
        aria-orientation="vertical"
      />
    );
  }
  if (label) {
    return (
      <div
        className={['divider divider--label', className ?? ''].filter(Boolean).join(' ')}
        role="separator"
      >
        {label}
      </div>
    );
  }
  return (
    <div
      className={['divider', className ?? ''].filter(Boolean).join(' ')}
      role="separator"
    />
  );
}

// ─── BottomSheet ───────────────────────────────────────────────────────

export interface BottomSheetProps {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  size?: 'auto' | 'md' | 'lg';
  footer?: ReactNode;
  children: ReactNode;
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;
  closeOnSwipe?: boolean;
  showHandle?: boolean;
  showCloseButton?: boolean;
  ariaLabel?: string;
}

export function BottomSheet({
  open,
  onClose,
  title,
  size = 'md',
  footer,
  children,
  closeOnBackdrop = true,
  closeOnEscape = true,
  closeOnSwipe = true,
  showHandle = true,
  showCloseButton = true,
  ariaLabel,
}: BottomSheetProps) {
  const sheetRef = useRef<HTMLDivElement | null>(null);
  const dragStartY = useRef<number | null>(null);
  const [dragOffset, setDragOffset] = useState(0);
  const [exiting, setExiting] = useState(false);

  useFocusTrap(sheetRef, open);
  useBodyScrollLock(open);

  const requestClose = useCallback(() => {
    setExiting(true);
    setTimeout(() => {
      onClose();
      setExiting(false);
      setDragOffset(0);
    }, 220);
  }, [onClose]);

  useEscapeKey(() => {
    if (closeOnEscape) requestClose();
  }, open);

  const onBackdropClick = useCallback(() => {
    if (closeOnBackdrop) requestClose();
  }, [closeOnBackdrop, requestClose]);

  const onPointerDown = useCallback(
    (e: ReactPointerEvent<HTMLDivElement>) => {
      if (!closeOnSwipe) return;
      dragStartY.current = e.clientY;
    },
    [closeOnSwipe]
  );

  const onPointerMove = useCallback((e: ReactPointerEvent<HTMLDivElement>) => {
    if (dragStartY.current === null) return;
    const delta = e.clientY - dragStartY.current;
    if (delta > 0) setDragOffset(delta);
  }, []);

  const onPointerUp = useCallback(() => {
    if (dragStartY.current === null) return;
    const finalOffset = dragOffset;
    dragStartY.current = null;
    if (finalOffset > 120) {
      requestClose();
    } else {
      setDragOffset(0);
    }
  }, [dragOffset, requestClose]);

  if (!open || typeof document === 'undefined') return null;

  const sizeClass =
    size === 'lg'
      ? 'bottom-sheet--lg'
      : size === 'auto'
        ? 'bottom-sheet--auto'
        : 'bottom-sheet--md';

  const style: CSSProperties =
    dragOffset > 0
      ? { transform: `translateY(${dragOffset}px)`, transition: 'none' }
      : {};

  return createPortal(
    <>
      <div
        className={['sheet-backdrop', exiting ? 'sheet-backdrop--exiting' : '']
          .filter(Boolean)
          .join(' ')}
        onClick={onBackdropClick}
        aria-hidden="true"
      />
      <div
        ref={sheetRef}
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel ?? (typeof title === 'string' ? title : undefined)}
        className={['bottom-sheet', sizeClass, exiting ? 'bottom-sheet--exiting' : '']
          .filter(Boolean)
          .join(' ')}
        style={style}
      >
        {showHandle ? (
          <div
            className="bottom-sheet__handle"
            onPointerDown={onPointerDown}
            onPointerMove={onPointerMove}
            onPointerUp={onPointerUp}
            onPointerCancel={onPointerUp}
            role="separator"
            aria-hidden="true"
          />
        ) : null}
        {title ? (
          <div className="bottom-sheet__header">
            <div className="bottom-sheet__title">{title}</div>
            {showCloseButton ? (
              <IconButton
                aria-label={translate('app.close' as TranslationKey)}
                onClick={requestClose}
              >
                <X aria-hidden="true" />
              </IconButton>
            ) : null}
          </div>
        ) : null}
        <div className="bottom-sheet__body">{children}</div>
        {footer ? <div className="bottom-sheet__footer">{footer}</div> : null}
      </div>
    </>,
    document.body
  );
}

// ─── Modal ─────────────────────────────────────────────────────────────

export interface ModalProps {
  open: boolean;
  onClose: () => void;
  title?: ReactNode;
  footer?: ReactNode;
  children: ReactNode;
  closeOnBackdrop?: boolean;
  closeOnEscape?: boolean;
  ariaLabel?: string;
}

export function Modal({
  open,
  onClose,
  title,
  footer,
  children,
  closeOnBackdrop = true,
  closeOnEscape = true,
  ariaLabel,
}: ModalProps) {
  const modalRef = useRef<HTMLDivElement | null>(null);

  useFocusTrap(modalRef, open);
  useBodyScrollLock(open);
  useEscapeKey(() => {
    if (closeOnEscape) onClose();
  }, open);

  if (!open || typeof document === 'undefined') return null;

  return createPortal(
    <div
      className="modal-backdrop"
      onClick={() => {
        if (closeOnBackdrop) onClose();
      }}
      role="presentation"
    >
      <div
        ref={modalRef}
        role="dialog"
        aria-modal="true"
        aria-label={ariaLabel ?? (typeof title === 'string' ? title : undefined)}
        className="modal"
        onClick={(e) => e.stopPropagation()}
      >
        {title ? (
          <div className="modal__header">
            <div className="modal__title">{title}</div>
            <IconButton
              aria-label={translate('app.close' as TranslationKey)}
              onClick={onClose}
            >
              <X aria-hidden="true" />
            </IconButton>
          </div>
        ) : null}
        <div className="modal__body">{children}</div>
        {footer ? <div className="modal__footer">{footer}</div> : null}
      </div>
    </div>,
    document.body
  );
}

// ─── ConfirmDialog ─────────────────────────────────────────────────────

export interface ConfirmDialogProps {
  open: boolean;
  onClose: () => void;
  onConfirm: () => void;
  title: string;
  message: ReactNode;
  warning?: ReactNode;
  confirmLabel?: string;
  cancelLabel?: string;
  danger?: boolean;
  requireText?: string;
}

export function ConfirmDialog({
  open,
  onClose,
  onConfirm,
  title,
  message,
  warning,
  confirmLabel,
  cancelLabel,
  danger,
  requireText,
}: ConfirmDialogProps) {
  const { t } = useTranslation();
  const [typed, setTyped] = useState('');
  const requireValid = !requireText || typed.trim() === requireText;

  useEffect(() => {
    if (!open) setTyped('');
  }, [open]);

  const finalConfirmLabel = confirmLabel ?? t('app.confirm' as TranslationKey);
  const finalCancelLabel = cancelLabel ?? t('app.cancel' as TranslationKey);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={title}
      ariaLabel={title}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {finalCancelLabel}
          </Button>
          <Button
            variant={danger ? 'danger' : 'primary'}
            onClick={onConfirm}
            disabled={!requireValid}
          >
            {finalConfirmLabel}
          </Button>
        </>
      }
    >
      <div className="confirm-dialog">
        <div className="confirm-dialog__message">{message}</div>
        {warning ? (
          <div className="confirm-dialog__warning" role="alert">
            <AlertTriangle size={18} aria-hidden="true" />
            <div>{warning}</div>
          </div>
        ) : null}
        {requireText ? (
          <div className="confirm-dialog__danger-input">
            <Field
              label={t('settings.resetAllConfirm' as TranslationKey)}
              hint={requireText}
            >
              <Input
                value={typed}
                onChange={(e) => setTyped(e.target.value)}
                invalid={typed.length > 0 && !requireValid}
                autoComplete="off"
              />
            </Field>
          </div>
        ) : null}
      </div>
    </Modal>
  );
}

// ─── PrivacyOverlay ────────────────────────────────────────────────────

export interface PrivacyOverlayProps {
  open: boolean;
}

export function PrivacyOverlay({ open }: PrivacyOverlayProps) {
  const { t } = useTranslation();
  if (!open || typeof document === 'undefined') return null;
  return createPortal(
    <div className="privacy-overlay" aria-hidden="true">
      <div className="privacy-overlay__icon">
        <LockKeyhole strokeWidth={1.5} />
      </div>
      <div className="privacy-overlay__message">
        {t('security.privacy.overlayMessage' as TranslationKey)}
      </div>
    </div>,
    document.body
  );
}

// ─── ReceiptCard ───────────────────────────────────────────────────────

export interface ReceiptRow {
  label: string;
  value: ReactNode;
}

export interface ReceiptCardProps {
  type: 'deposit' | 'expense';
  amount: bigint;
  amountWords: string;
  rows: ReadonlyArray<ReceiptRow>;
  className?: string;
}

export function ReceiptCard({
  type,
  amount,
  amountWords,
  rows,
  className,
}: ReceiptCardProps) {
  const { t } = useTranslation();
  return (
    <div
      className={[
        'receipt',
        type === 'deposit' ? 'receipt--deposit' : 'receipt--expense',
        className ?? '',
      ]
        .filter(Boolean)
        .join(' ')}
    >
      <div className="receipt__header">
        <div className="receipt__amount">
          <span className="amount-value">
            {type === 'deposit' ? '+' : '−'}
            {formatMoneyPlain(amount)}
          </span>
          <span className="amount-unit">{t('app.toman' as TranslationKey)}</span>
        </div>
        <div className="receipt__words">{amountWords}</div>
      </div>
      <div className="receipt__rows">
        {rows.map((row, i) => (
          <div className="receipt__row" key={i}>
            <span className="receipt__row-label">{row.label}</span>
            <span className="receipt__row-value">{row.value}</span>
          </div>
        ))}
      </div>
      <div className="receipt__footer">
        <div className="receipt__stamp" aria-hidden="true">
          {t('app.done' as TranslationKey)}
        </div>
      </div>
    </div>
  );
}

// ─── Sparkline ─────────────────────────────────────────────────────────

export interface SparklineProps {
  data: ReadonlyArray<bigint>;
  variant?: 'primary' | 'income' | 'warning';
  height?: number;
  showArea?: boolean;
  showDots?: boolean;
  className?: string;
}

export function Sparkline({
  data,
  variant = 'primary',
  height = 40,
  showArea = true,
  showDots = false,
  className,
}: SparklineProps) {
  const id = useId();

  const { points, areaPath } = useMemo(() => {
    if (data.length < 2) {
      return { points: '', areaPath: '' };
    }

    const numeric = data.map((v) => Number(v));
    const min = Math.min(...numeric);
    const max = Math.max(...numeric);
    const range = max - min || 1;
    const width = 100;
    const h = 100;

    const pointsArray = numeric.map((value, i) => {
      const x = (i / (numeric.length - 1)) * width;
      const y = h - ((value - min) / range) * h;
      return { x, y };
    });

    const pts = pointsArray.map((p) => `${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' ');

    const area =
      `M0,${h} ` +
      pointsArray.map((p) => `L${p.x.toFixed(2)},${p.y.toFixed(2)}`).join(' ') +
      ` L${width},${h} Z`;

    return { points: pts, areaPath: area };
  }, [data]);

  if (!points) return null;

  const strokeClass = `sparkline__line sparkline__line--${variant}`;
  const areaClass = `sparkline__area sparkline__area--${variant}`;

  return (
    <svg
      className={['sparkline', className ?? ''].filter(Boolean).join(' ')}
      viewBox="0 0 100 100"
      preserveAspectRatio="none"
      style={{ height, width: '100%' }}
      aria-hidden="true"
    >
      <defs>
        <linearGradient id={`spark-${id}`} x1="0" x2="0" y1="0" y2="1">
          <stop offset="0%" stopColor="currentColor" stopOpacity="0.2" />
          <stop offset="100%" stopColor="currentColor" stopOpacity="0" />
        </linearGradient>
      </defs>
      {showArea ? <path d={areaPath} className={areaClass} /> : null}
      <polyline
        points={points}
        className={strokeClass}
        vectorEffect="non-scaling-stroke"
      />
      {showDots ? (
        <circle
          cx="0"
          cy={points.split(' ')[0]?.split(',')[1] ?? '0'}
          r="2"
          className={`sparkline__dot sparkline__dot--${variant}`}
          vectorEffect="non-scaling-stroke"
        />
      ) : null}
    </svg>
  );
}

// ─── DonutChart ────────────────────────────────────────────────────────

export interface DonutSlice {
  id: string;
  label: string;
  value: bigint;
  color: string;
}

export interface DonutChartProps {
  slices: ReadonlyArray<DonutSlice>;
  totalLabel: string;
  formatTotal?: (total: bigint) => string;
  className?: string;
}

export function DonutChart({
  slices,
  totalLabel,
  formatTotal,
  className,
}: DonutChartProps) {
  const total = useMemo(() => slices.reduce((acc, s) => acc + s.value, 0n), [slices]);

  const circumference = 2 * Math.PI * 40;

  let accumulated = 0;
  const arcs = slices.map((slice) => {
    const ratio = total > 0n ? Number(slice.value) / Number(total) : 0;
    const dash = ratio * circumference;
    const offset = accumulated;
    accumulated += dash;
    return { slice, dash, offset };
  });

  const totalLabelText = formatTotal ? formatTotal(total) : formatMoneyPlain(total);

  return (
    <div className={['donut', className ?? ''].filter(Boolean).join(' ')}>
      <div className="donut__chart">
        <svg className="donut__svg" viewBox="0 0 100 100">
          <circle
            cx="50"
            cy="50"
            r="40"
            fill="none"
            stroke="var(--surface-3)"
            strokeWidth={24}
          />
          {arcs.map(({ slice, dash, offset }) => (
            <circle
              key={slice.id}
              cx="50"
              cy="50"
              r="40"
              fill="none"
              stroke={slice.color}
              strokeWidth={24}
              strokeDasharray={`${dash} ${circumference - dash}`}
              strokeDashoffset={-offset}
              className="donut__slice"
              aria-label={`${slice.label}: ${slice.value}`}
            />
          ))}
        </svg>
        <div className="donut__center">
          <div className="donut__total" dir="ltr">
            {totalLabelText}
          </div>
          <div className="donut__total-label">{totalLabel}</div>
        </div>
      </div>
      <div className="donut__legend">
        {slices.map((slice) => (
          <div className="donut__legend-item" key={slice.id}>
            <span
              className="donut__legend-dot"
              style={{ background: slice.color }}
              aria-hidden="true"
            />
            <span>{slice.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Sheet / Modal helpers ─────────────────────────────────────────────

export function useSheet(): {
  openSheet: (name: UISheetName, payload?: unknown) => void;
  closeSheet: () => void;
  activeSheet: UISheetName | null;
  payload: unknown;
} {
  const activeSheet = useUIStore((s) => s.activeSheet);
  const payload = useUIStore((s) => s.activeSheetPayload);
  const openSheet = useUIStore((s) => s.openSheet);
  const closeSheet = useUIStore((s) => s.closeSheet);
  return { openSheet, closeSheet, activeSheet, payload };
}

export function useModal(): {
  openModal: (name: UIModalName, payload?: unknown) => void;
  closeModal: () => void;
  activeModal: UIModalName | null;
  payload: unknown;
} {
  const activeModal = useUIStore((s) => s.activeModal);
  const payload = useUIStore((s) => s.activeModalPayload);
  const openModal = useUIStore((s) => s.openModal);
  const closeModal = useUIStore((s) => s.closeModal);
  return { openModal, closeModal, activeModal, payload };
}

// ─── SearchBar ─────────────────────────────────────────────────────────

export interface SearchBarProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  ariaLabel?: string;
  autoFocus?: boolean;
}

export function SearchBar({
  value,
  onChange,
  placeholder,
  ariaLabel,
  autoFocus,
}: SearchBarProps) {
  const { t } = useTranslation();
  const finalPlaceholder = placeholder ?? t('search.placeholder' as TranslationKey);
  return (
    <div className="search-bar">
      <Search className="search-bar__icon" aria-hidden="true" />
      <input
        type="search"
        className="search-bar__input"
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={finalPlaceholder}
        aria-label={ariaLabel ?? finalPlaceholder}
        autoFocus={autoFocus}
      />
      {value ? (
        <button
          type="button"
          className="search-bar__clear"
          onClick={() => onChange('')}
          aria-label={t('app.clear' as TranslationKey)}
        >
          <X size={16} aria-hidden="true" />
        </button>
      ) : null}
    </div>
  );
}

// ─── Chip ──────────────────────────────────────────────────────────────

export interface ChipProps {
  active?: boolean;
  onClick?: () => void;
  onRemove?: () => void;
  children: ReactNode;
  className?: string;
}

export function Chip({ active, onClick, onRemove, children, className }: ChipProps) {
  return (
    <button
      type="button"
      className={['chip', active ? 'chip--active' : '', className ?? '']
        .filter(Boolean)
        .join(' ')}
      onClick={onClick}
    >
      {children}
      {onRemove ? (
        <span
          role="button"
          tabIndex={0}
          className="chip__close"
          aria-label={translate('app.remove' as TranslationKey)}
          onClick={(e) => {
            e.stopPropagation();
            onRemove();
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              e.stopPropagation();
              onRemove();
            }
          }}
        >
          <X size={12} aria-hidden="true" />
        </span>
      ) : null}
    </button>
  );
}

// ─── DateInput ─────────────────────────────────────────────────────────

export interface DateInputProps {
  value: string;
  onChange: (value: string) => void;
  invalid?: boolean;
  id?: string;
  ariaLabel?: string;
  disabled?: boolean;
  autoFocus?: boolean;
}

export const DateInput = forwardRef<HTMLInputElement, DateInputProps>(function DateInput(
  { value, onChange, invalid, id, ariaLabel, disabled, autoFocus },
  ref
) {
  return (
    <input
      ref={ref}
      id={id}
      type="text"
      inputMode="numeric"
      placeholder="۱۴۰۵/۰۶/۲۵"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      disabled={disabled}
      autoFocus={autoFocus}
      aria-label={ariaLabel}
      aria-invalid={invalid || undefined}
      className={['input', invalid ? 'input--invalid' : ''].filter(Boolean).join(' ')}
      dir="ltr"
    />
  );
});

// ─── Re-exports ────────────────────────────────────────────────────────

export { ChevronLeft };
