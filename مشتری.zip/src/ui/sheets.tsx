// src/ui/sheets.tsx

import {
  useCallback,
  useEffect,
  useMemo,
  useState,
  type ChangeEvent,
  type FormEvent,
  type ReactNode,
} from 'react';

import {
  CircleAlert,
  DatabaseBackup,
  FileSpreadsheet,
  FolderKanban,
  Landmark,
  LockKeyhole,
  Plus,
  UserRound,
} from 'lucide-react';

import { useTranslation, translate, type TranslationKey } from '../i18n';

import {
  formatMoneyPlain,
  fromJalali,
  normalizeDigits,
  parseAmountExpression,
  parseMoney,
  toJalali,
  todayISO,
} from '../formatters';

import type {
  Account,
  AccountId,
  Category,
  CategoryId,
  CreateAccountInput,
  CreatePartyInput,
  CreateProjectInput,
  CreateTransactionInput,
  ImportDecision,
  ImportJobId,
  ISODate,
  Money,
  Party,
  PartyId,
  Project,
  ProjectId,
  RestoreMode,
  Transaction,
  TransactionFilter,
  TransactionId,
} from '../types';

import {
  TransactionType,
  AccountType,
  PartyType,
  PartyRole,
  ProjectStatus,
  DuplicateLevel,
  DraftKey,
} from '../types';

import {
  accountService,
  categoryService,
  partyService,
  projectService,
  transactionService,
  draftService,
  settingsService,
} from '../services';

import type { AccountWithBalance, PartyWithStats, CategoryTree } from '../services';

import {
  Alert,
  AmountInput,
  Badge,
  BottomSheet,
  Button,
  Checkbox,
  Chip,
  DateInput,
  Divider,
  EmptyState,
  Field,
  Input,
  Modal,
  OrbitLoader,
  ProgressBar,
  SearchBar,
  Select,
  Spinner,
  Tabs,
  Textarea,
} from './components';

import {
  useFilterStore,
  useRefreshStore,
  useUIStore,
  toast,
  UI_SHEET,
  createEmptyTransactionFilter,
} from '../store';

import {
  changePIN,
  checkBiometricAvailability,
  completeRecoveryReset,
  isBiometricEnabled,
  isCurrentlyLockedOut,
  setupSecurity,
  applyRecoveryCode,
  verifyPIN,
  PIN_MIN_LENGTH,
  PIN_MAX_LENGTH,
  type BiometricAvailability,
  type SetupResult,
} from '../security';

import {
  buildPreview,
  commitImport,
  exportErrorRows,
  parseExcelFile,
  suggestColumnMapping,
  getFieldLabel,
  getAllFields,
  IMPORT_FIELD,
  type ImportField,
  type ImportPreviewResult,
  type ImportPreviewRow,
  type ParsedSheet,
} from '../importExport';

import {
  createBackup,
  restoreBackup,
  verifyBackup,
  inspectBackup,
  type BackupInspection,
} from '../backup';

// ═══════════════════════════════════════════════════════════════════════════
// Local helpers
// ═══════════════════════════════════════════════════════════════════════════

function parseJalaliToISO(jalali: string): ISODate | null {
  const cleaned = normalizeDigits(jalali).replace(/[^\d/]/g, '');
  const parts = cleaned.split('/');
  if (parts.length !== 3) return null;

  const jy = Number(parts[0]);
  const jm = Number(parts[1]);
  const jd = Number(parts[2]);

  if (!Number.isFinite(jy) || !Number.isFinite(jm) || !Number.isFinite(jd)) {
    return null;
  }
  if (jm < 1 || jm > 12 || jd < 1 || jd > 31) return null;

  const result = fromJalali(jy, jm, jd);
  if (!result) return null;

  const mm = result.gm < 10 ? `0${result.gm}` : String(result.gm);
  const dd = result.gd < 10 ? `0${result.gd}` : String(result.gd);
  return `${result.gy}-${mm}-${dd}`;
}

function accountTypeLabel(type: AccountType): string {
  return translate(`account.type.${type}` as TranslationKey);
}

function partyRoleLabel(role: PartyRole | null): string {
  if (!role) return '';
  return translate(`party.role.${role}` as TranslationKey);
}

function projectStatusLabel(status: ProjectStatus): string {
  return translate(`project.status.${status}` as TranslationKey);
}

// ═══════════════════════════════════════════════════════════════════════════
// Data hooks
// ═══════════════════════════════════════════════════════════════════════════

function useAccounts(): Account[] {
  const [accounts, setAccounts] = useState<Account[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await accountService.list(false);
      if (!cancelled) setAccounts(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return accounts;
}

function useAccountsWithBalance(): AccountWithBalance[] {
  const [rows, setRows] = useState<AccountWithBalance[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await accountService.listWithBalances(false);
      if (!cancelled) setRows(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return rows;
}

function useParties(): Party[] {
  const [parties, setParties] = useState<Party[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await partyService.list(false);
      if (!cancelled) setParties(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return parties;
}

function usePartiesWithStats(): PartyWithStats[] {
  const [rows, setRows] = useState<PartyWithStats[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await partyService.listWithStats(false);
      if (!cancelled) setRows(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return rows;
}

function useProjects(): Project[] {
  const [projects, setProjects] = useState<Project[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await projectService.list();
      if (!cancelled) setProjects(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return projects;
}

function useCategoryTree(): CategoryTree[] {
  const [tree, setTree] = useState<CategoryTree[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await categoryService.listTree(false);
      if (!cancelled) setTree(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return tree;
}

// ═══════════════════════════════════════════════════════════════════════════
// SelectAccountSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SelectAccountSheetProps {
  open: boolean;
  onClose: () => void;
  onSelect: (accountId: AccountId) => void;
  selectedId?: AccountId | null;
}

export function SelectAccountSheet({
  open,
  onClose,
  onSelect,
  selectedId,
}: SelectAccountSheetProps) {
  const { t } = useTranslation();
  const rows = useAccountsWithBalance();

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('tx.selectAccount' as TranslationKey)}
      size="md"
    >
      {rows.length === 0 ? (
        <EmptyState
          icon={<Landmark />}
          title={t('empty.accounts.title' as TranslationKey)}
          message={t('empty.accounts.message' as TranslationKey)}
        />
      ) : (
        <div className="stack--sm">
          {rows.map(({ account, balance }) => (
            <button
              key={account.id}
              type="button"
              className={[
                'card',
                'card--interactive',
                account.id === selectedId ? 'card--elevated' : '',
              ]
                .filter(Boolean)
                .join(' ')}
              style={{
                textAlign: 'start',
                width: '100%',
                borderColor: account.id === selectedId ? 'var(--primary)' : undefined,
              }}
              onClick={() => {
                onSelect(account.id);
                onClose();
              }}
            >
              <div className="flex-row items-center gap-3">
                <div className="account-card__icon">
                  <Landmark aria-hidden="true" />
                </div>
                <div className="flex-1" style={{ minWidth: 0 }}>
                  <div className="t-body t-semibold">{account.name}</div>
                  <div className="t-caption t-muted">
                    {accountTypeLabel(account.type)}
                  </div>
                </div>
                <div className="t-end">
                  <div className="amount">
                    <span className="amount-value" dir="ltr">
                      {formatMoneyPlain(balance.balance)}
                    </span>
                    <span className="amount-unit">
                      {t('app.toman' as TranslationKey)}
                    </span>
                  </div>
                  {balance.isNegative ? (
                    <Badge variant="warning" dot>
                      {t('account.negativeBalance' as TranslationKey)}
                    </Badge>
                  ) : null}
                </div>
              </div>
            </button>
          ))}
        </div>
      )}
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SelectPartySheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SelectPartySheetProps {
  open: boolean;
  onClose: () => void;
  onSelect: (partyId: PartyId) => void;
  selectedId?: PartyId | null;
}

export function SelectPartySheet({
  open,
  onClose,
  onSelect,
  selectedId,
}: SelectPartySheetProps) {
  const { t } = useTranslation();
  const rows = usePartiesWithStats();
  const [query, setQuery] = useState('');
  const [createOpen, setCreateOpen] = useState(false);

  const filtered = useMemo(() => {
    if (!query.trim()) return rows;
    const q = query.trim().toLowerCase();
    return rows.filter((r) => r.party.normalizedName.includes(q));
  }, [rows, query]);

  const handleCreate = (partyId: PartyId): void => {
    onSelect(partyId);
    setCreateOpen(false);
    onClose();
  };

  return (
    <>
      <BottomSheet
        open={open}
        onClose={onClose}
        title={t('party.selectParty' as TranslationKey)}
        size="lg"
      >
        <div className="stack--sm">
          <SearchBar value={query} onChange={setQuery} autoFocus />

          <Button
            variant="secondary"
            leadingIcon={<Plus size={16} />}
            block
            onClick={() => setCreateOpen(true)}
          >
            {t('party.new' as TranslationKey)}
          </Button>

          {filtered.length === 0 ? (
            <EmptyState
              icon={<UserRound />}
              title={t('empty.search.title' as TranslationKey)}
              message={t('empty.search.message' as TranslationKey)}
            />
          ) : (
            <div className="list list--bordered">
              {filtered.map(({ party, received, paid, transactionCount }) => (
                <button
                  key={party.id}
                  type="button"
                  className="tx-row"
                  style={{
                    textAlign: 'start',
                    width: '100%',
                    borderBottom: '1px solid var(--border)',
                    background:
                      party.id === selectedId ? 'var(--primary-soft)' : undefined,
                  }}
                  onClick={() => {
                    onSelect(party.id);
                    onClose();
                  }}
                >
                  <div
                    className="tx-row__icon"
                    style={{ background: 'var(--surface-2)' }}
                  >
                    <UserRound aria-hidden="true" />
                  </div>
                  <div className="tx-row__body">
                    <div className="tx-row__title">{party.name}</div>
                    <div className="tx-row__subtitle">
                      {party.role
                        ? partyRoleLabel(party.role)
                        : party.type === 'company'
                          ? t('party.type.company' as TranslationKey)
                          : t('party.type.person' as TranslationKey)}
                      <span className="tx-row__subtitle-sep">•</span>
                      <span>
                        {transactionCount}{' '}
                        {t('account.transactionCount' as TranslationKey)}
                      </span>
                    </div>
                  </div>
                  <div className="tx-row__amount t-end">
                    {received > 0n ? (
                      <div className="amount" style={{ color: 'var(--income)' }}>
                        <span className="amount-value" dir="ltr">
                          +{formatMoneyPlain(received)}
                        </span>
                      </div>
                    ) : null}
                    {paid > 0n ? (
                      <div className="amount" style={{ color: 'var(--expense)' }}>
                        <span className="amount-value" dir="ltr">
                          −{formatMoneyPlain(paid)}
                        </span>
                      </div>
                    ) : null}
                  </div>
                </button>
              ))}
            </div>
          )}
        </div>
      </BottomSheet>

      <CreatePartySheet
        open={createOpen}
        onClose={() => setCreateOpen(false)}
        onCreated={handleCreate}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SelectCategorySheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SelectCategorySheetProps {
  open: boolean;
  onClose: () => void;
  transactionType: Transaction['type'];
  onSelect: (categoryId: CategoryId | null, customText: string | null) => void;
  selectedId?: CategoryId | null;
}

export function SelectCategorySheet({
  open,
  onClose,
  transactionType,
  onSelect,
  selectedId,
}: SelectCategorySheetProps) {
  const { t } = useTranslation();
  const tree = useCategoryTree();
  const [customMode, setCustomMode] = useState(false);
  const [customText, setCustomText] = useState('');

  const filtered = useMemo(() => {
    return tree.filter(({ category }) => {
      if (category.type === 'both') return true;
      if (transactionType === TransactionType.DEPOSIT) {
        return category.type === 'income';
      }
      return category.type === 'expense';
    });
  }, [tree, transactionType]);

  const handleSelect = (id: CategoryId): void => {
    onSelect(id, null);
    onClose();
  };

  const handleCustom = (): void => {
    const trimmed = customText.trim();
    if (!trimmed) return;
    onSelect(null, trimmed);
    setCustomText('');
    setCustomMode(false);
    onClose();
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('tx.selectCategory' as TranslationKey)}
      size="md"
    >
      {customMode ? (
        <div className="stack--sm">
          <Field label={t('tx.customCategory' as TranslationKey)} required>
            <Input
              value={customText}
              onChange={(e) => setCustomText(e.target.value)}
              placeholder={t('tx.customCategory' as TranslationKey)}
              maxLength={80}
              autoFocus
            />
          </Field>
          <div className="form__actions">
            <Button variant="ghost" onClick={() => setCustomMode(false)}>
              {t('app.cancel' as TranslationKey)}
            </Button>
            <Button
              variant="primary"
              onClick={handleCustom}
              disabled={!customText.trim()}
            >
              {t('app.confirm' as TranslationKey)}
            </Button>
          </div>
        </div>
      ) : (
        <div className="stack--sm">
          <Button
            variant="secondary"
            leadingIcon={<Plus size={16} />}
            block
            onClick={() => setCustomMode(true)}
          >
            {t('category.custom' as TranslationKey)}
          </Button>

          {filtered.length === 0 ? (
            <EmptyState title={t('empty.search.title' as TranslationKey)} />
          ) : (
            <div className="category-picker">
              {filtered.map(({ category, children }) => (
                <div className="category-picker__group" key={category.id}>
                  <div className="category-picker__title">{category.name}</div>
                  <div className="category-picker__items">
                    <Chip
                      active={category.id === selectedId}
                      onClick={() => handleSelect(category.id)}
                    >
                      {category.name}
                    </Chip>
                    {children.map((child) => (
                      <Chip
                        key={child.id}
                        active={child.id === selectedId}
                        onClick={() => handleSelect(child.id)}
                      >
                        {child.name}
                      </Chip>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SelectProjectSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SelectProjectSheetProps {
  open: boolean;
  onClose: () => void;
  onSelect: (projectId: ProjectId | null) => void;
  selectedId?: ProjectId | null;
  projects?: Project[];
}

export function SelectProjectSheet({
  open,
  onClose,
  onSelect,
  selectedId,
  projects: providedProjects,
}: SelectProjectSheetProps) {
  const { t } = useTranslation();
  const loadedProjects = useProjects();
  const projects = providedProjects ?? loadedProjects;
  const [query, setQuery] = useState('');

  const filteredProjects = useMemo(() => {
    const normalized = query.trim().toLocaleLowerCase();
    return [...projects]
      .filter((project) =>
        normalized.length === 0
          ? true
          : `${project.name} ${project.code ?? ''}`.toLocaleLowerCase().includes(normalized)
      )
      .sort((a, b) => {
        const statusRank = (status: Project['status']): number =>
          status === ProjectStatus.ACTIVE ? 0 : status === ProjectStatus.PAUSED ? 1 : 2;
        return statusRank(a.status) - statusRank(b.status) || a.name.localeCompare(b.name, 'fa');
      });
  }, [projects, query]);

  useEffect(() => {
    if (!open) setQuery('');
  }, [open]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('tx.selectProject' as TranslationKey)}
      size="md"
    >
      <div className="stack--sm">
        <button
          type="button"
          className={[
            'card',
            'card--interactive',
            !selectedId ? 'card--elevated' : '',
          ].join(' ')}
          style={{ width: '100%', textAlign: 'start' }}
          onClick={() => {
            onSelect(null);
            onClose();
          }}
        >
          <div className="t-body">{t('tx.chooseProject' as TranslationKey)}</div>
        </button>

        {projects.length > 0 ? (
          <SearchBar
            value={query}
            onChange={setQuery}
            placeholder={t('tx.searchProject' as TranslationKey)}
          />
        ) : null}

        {projects.length === 0 ? (
          <EmptyState
            icon={<FolderKanban />}
            title={t('empty.projects.title' as TranslationKey)}
          />
        ) : filteredProjects.length === 0 ? (
          <EmptyState
            icon={<FolderKanban />}
            title={t('empty.search.title' as TranslationKey)}
          />
        ) : (
          <div className="project-picker">
            {filteredProjects.map((project) => (
              <button
                key={project.id}
                type="button"
                className={[
                  'card',
                  'card--interactive',
                  'project-picker__item',
                  project.id === selectedId ? 'card--elevated' : '',
                ].join(' ')}
                onClick={() => {
                  onSelect(project.id);
                  onClose();
                }}
              >
                <div className="flex-row items-center gap-3">
                  <FolderKanban size={20} aria-hidden="true" />
                  <div className="flex-1 project-picker__body">
                    <div className="t-body t-semibold">{project.name}</div>
                    <div className="t-caption t-muted">
                      {projectStatusLabel(project.status)}
                      {project.code ? <> {'•'} {project.code}</> : null}
                    </div>
                  </div>
                </div>
              </button>
            ))}
          </div>
        )}
      </div>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// AddTransactionSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface AddTransactionSheetProps {
  open: boolean;
  onClose: () => void;
  editTransaction?: Transaction | null;
  initialType?: Transaction['type'];
}

export function AddTransactionSheet({
  open,
  onClose,
  editTransaction,
  initialType = TransactionType.EXPENSE,
}: AddTransactionSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);

  const isEdit = Boolean(editTransaction);

  const [type, setType] = useState<Transaction['type']>(
    editTransaction?.type ?? initialType
  );
  const [amountRaw, setAmountRaw] = useState<string>(
    editTransaction ? editTransaction.amount.toString() : ''
  );
  const [accountId, setAccountId] = useState<AccountId | null>(
    editTransaction?.accountId ?? null
  );
  const [partyId, setPartyId] = useState<PartyId | null>(
    editTransaction?.partyId ?? null
  );
  const [categoryId, setCategoryId] = useState<CategoryId | null>(
    editTransaction?.categoryId ?? null
  );
  const [customCategoryText, setCustomCategoryText] = useState<string | null>(
    editTransaction?.customCategoryText ?? null
  );
  const [projectId, setProjectId] = useState<ProjectId | null>(
    editTransaction?.projectId ?? null
  );
  const [transactionDate, setTransactionDate] = useState<string>(
    editTransaction ? toJalali(editTransaction.transactionDate) : toJalali(todayISO())
  );
  const [transactionTime, setTransactionTime] = useState<string>(
    editTransaction?.transactionTime ?? ''
  );
  const [referenceCode, setReferenceCode] = useState<string>(
    editTransaction?.referenceCode ?? ''
  );
  const [description, setDescription] = useState<string>(
    editTransaction?.description ?? ''
  );

  const [showDetails, setShowDetails] = useState(false);
  const [submitting, setSubmitting] = useState(false);
  const [submitState, setSubmitState] = useState<'idle' | 'loading' | 'success'>('idle');
  const [errors, setErrors] = useState<Record<string, string>>({});

  const [accountSheetOpen, setAccountSheetOpen] = useState(false);
  const [partySheetOpen, setPartySheetOpen] = useState(false);
  const [categorySheetOpen, setCategorySheetOpen] = useState(false);
  const [projectSheetOpen, setProjectSheetOpen] = useState(false);

  const [duplicateWarning, setDuplicateWarning] = useState<{
    level: DuplicateLevel;
    reasons: string[];
    matchedId: TransactionId | null;
  } | null>(null);

  const [accounts, setAccounts] = useState<Account[]>([]);
  const [parties, setParties] = useState<Party[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);

  useEffect(() => {
    if (!open) return;
    void (async () => {
      const [a, p, c, pr] = await Promise.all([
        accountService.list(false),
        partyService.list(false),
        categoryService.listByTransactionType(type),
        projectService.list(),
      ]);
      setAccounts(a);
      setParties(p);
      setCategories(c);
      setProjects(pr);
    })();
  }, [open, type]);

  useEffect(() => {
    if (!open) {
      setDuplicateWarning(null);
      setErrors({});
      setSubmitState('idle');
    }
  }, [open]);

  const account = accounts.find((a) => a.id === accountId) ?? null;
  const party = parties.find((p) => p.id === partyId) ?? null;
  const category = categories.find((c) => c.id === categoryId) ?? null;
  const project = projects.find((p) => p.id === projectId) ?? null;

  const amountBigInt = useMemo<Money | null>(() => {
    if (!amountRaw.trim()) return null;
    const cleaned = amountRaw.replace(/[,\s،]/g, '');
    const parsed = parseAmountExpression(cleaned) ?? parseMoney(cleaned);
    return parsed && parsed > 0n ? parsed : null;
  }, [amountRaw]);

  const resetForm = useCallback((): void => {
    setAmountRaw('');
    setAccountId(null);
    setPartyId(null);
    setCategoryId(null);
    setCustomCategoryText(null);
    setProjectId(null);
    setTransactionDate(toJalali(todayISO()));
    setTransactionTime('');
    setReferenceCode('');
    setDescription('');
    setShowDetails(false);
    setErrors({});
    setDuplicateWarning(null);
    setSubmitState('idle');
    setSubmitting(false);
  }, []);

  const validate = useCallback((): boolean => {
    const newErrors: Record<string, string> = {};

    if (!amountBigInt) {
      newErrors.amount = t('validation.amount.required' as TranslationKey);
    }
    if (!accountId) {
      newErrors.accountId = t('validation.account.required' as TranslationKey);
    }
    if (type === TransactionType.EXPENSE && !partyId) {
      newErrors.partyId = t('validation.party.expenseRequired' as TranslationKey);
    }
    if (!transactionDate) {
      newErrors.transactionDate = t('validation.date.required' as TranslationKey);
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  }, [amountBigInt, accountId, partyId, transactionDate, type, t]);

  const buildInput = useCallback((): CreateTransactionInput | null => {
    if (!amountBigInt || !accountId) return null;

    const isoDate = parseJalaliToISO(transactionDate);
    if (!isoDate) return null;

    return {
      type,
      amount: amountBigInt,
      accountId,
      partyId,
      categoryId,
      customCategoryText,
      projectId,
      transactionDate: isoDate,
      transactionTime: transactionTime.trim() || null,
      referenceCode: referenceCode.trim() || null,
      description: description.trim() || null,
      createdBy: null,
    };
  }, [
    amountBigInt,
    accountId,
    partyId,
    categoryId,
    customCategoryText,
    projectId,
    transactionDate,
    transactionTime,
    referenceCode,
    description,
    type,
  ]);

  const performSubmit = useCallback(async (): Promise<void> => {
    const input = buildInput();
    if (!input) {
      setErrors({ amount: t('validation.amount.invalid' as TranslationKey) });
      return;
    }

    setSubmitting(true);
    setSubmitState('loading');

    try {
      if (isEdit && editTransaction) {
        const result = await transactionService.update(editTransaction.id, {
          amount: input.amount,
          accountId: input.accountId,
          partyId: input.partyId,
          categoryId: input.categoryId,
          customCategoryText: input.customCategoryText,
          projectId: input.projectId,
          transactionDate: input.transactionDate,
          transactionTime: input.transactionTime,
          referenceCode: input.referenceCode,
          description: input.description,
        });

        if (!result.ok) {
          setErrors({ form: result.message });
          setSubmitState('idle');
          setSubmitting(false);
          return;
        }

        await draftService.clear(DraftKey.NEW_TRANSACTION);
        setSubmitState('success');
        toast.success(t('toast.transaction.updated' as TranslationKey));
        bump('transaction');
        setTimeout(() => {
          onClose();
          resetForm();
        }, 500);
      } else {
        const result = await transactionService.create(input);

        if (!result.ok) {
          setErrors({ form: result.message });
          setSubmitState('idle');
          setSubmitting(false);
          return;
        }

        await draftService.clear(DraftKey.NEW_TRANSACTION);
        setSubmitState('success');
        toast.success(t('toast.transaction.created' as TranslationKey));
        bump('transaction');
        setTimeout(() => {
          onClose();
          resetForm();
        }, 500);
      }
    } catch (err) {
      setErrors({
        form: err instanceof Error ? err.message : t('error.generic' as TranslationKey),
      });
      setSubmitState('idle');
      setSubmitting(false);
    }
  }, [buildInput, isEdit, editTransaction, onClose, resetForm, bump, t]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting || submitState !== 'idle') return;

      if (!validate()) return;

      const input = buildInput();
      if (!input) {
        setErrors({ amount: t('validation.amount.invalid' as TranslationKey) });
        return;
      }

      if (!isEdit && !duplicateWarning) {
        const dup = await transactionService.checkDuplicateOnly(input);
        if (
          dup.level !== DuplicateLevel.UNIQUE &&
          dup.level !== DuplicateLevel.POSSIBLE
        ) {
          setDuplicateWarning({
            level: dup.level,
            reasons: dup.reasons,
            matchedId: dup.matchedTransactionId,
          });
          return;
        }
      }

      await performSubmit();
    },
    [
      submitting,
      submitState,
      validate,
      buildInput,
      isEdit,
      duplicateWarning,
      performSubmit,
      t,
    ]
  );

  const handleSaveDraft = useCallback(async (): Promise<void> => {
    try {
      await draftService.save(DraftKey.NEW_TRANSACTION, {
        type,
        amountRaw,
        accountId,
        partyId,
        categoryId,
        customCategoryText,
        projectId,
        transactionDate,
        transactionTime,
        referenceCode,
        description,
      });
    } catch {
      // silent
    }
  }, [
    type,
    amountRaw,
    accountId,
    partyId,
    categoryId,
    customCategoryText,
    projectId,
    transactionDate,
    transactionTime,
    referenceCode,
    description,
  ]);

  useEffect(() => {
    if (!open || isEdit) return;
    const timer = setTimeout(() => {
      void handleSaveDraft();
    }, 800);
    return () => clearTimeout(timer);
  }, [open, isEdit, handleSaveDraft]);

  return (
    <>
      <BottomSheet
        open={open}
        onClose={() => {
          if (submitting) return;
          void handleSaveDraft();
          onClose();
        }}
        title={isEdit ? t('tx.edit' as TranslationKey) : t('tx.new' as TranslationKey)}
        size="lg"
        footer={
          <Button
            variant={type === TransactionType.DEPOSIT ? 'income' : 'expense'}
            size="lg"
            block
            loading={submitting}
            onClick={(e) => {
              void handleSubmit(e as unknown as FormEvent);
            }}
            disabled={submitting}
            type="submit"
          >
            {submitting
              ? t('app.loading.short' as TranslationKey)
              : t('tx.save' as TranslationKey)}
          </Button>
        }
      >
        {!isEdit ? (
          <Tabs<Transaction['type']>
            value={type}
            items={[
              {
                key: TransactionType.DEPOSIT,
                label: t('tx.type.deposit' as TranslationKey),
                variant: 'income',
              },
              {
                key: TransactionType.EXPENSE,
                label: t('tx.type.expense' as TranslationKey),
                variant: 'expense',
              },
            ]}
            onChange={(k) => {
              setType(k);
              setCategoryId(null);
              setCustomCategoryText(null);
            }}
          />
        ) : null}

        <form onSubmit={handleSubmit} className="form" style={{ marginTop: 16 }}>
          <Field error={errors.amount} required label={t('app.amount' as TranslationKey)}>
            <AmountInput
              value={amountRaw}
              onChange={(raw) => setAmountRaw(raw)}
              invalid={Boolean(errors.amount)}
              autoFocus
            />
          </Field>

          <Field
            error={errors.accountId}
            required
            label={t('tx.account' as TranslationKey)}
          >
            <button
              type="button"
              className="select__trigger"
              onClick={() => setAccountSheetOpen(true)}
            >
              <span className={account ? 'select__value' : 'select__placeholder'}>
                {account ? account.name : t('tx.selectAccount' as TranslationKey)}
              </span>
              <Landmark size={18} aria-hidden="true" />
            </button>
          </Field>

          <Field
            error={errors.partyId}
            required={type === TransactionType.EXPENSE}
            label={t('tx.party' as TranslationKey)}
          >
            <button
              type="button"
              className="select__trigger"
              onClick={() => setPartySheetOpen(true)}
            >
              <span className={party ? 'select__value' : 'select__placeholder'}>
                {party ? party.name : t('tx.selectParty' as TranslationKey)}
              </span>
              <UserRound size={18} aria-hidden="true" />
            </button>
          </Field>

          <Field label={t('tx.category' as TranslationKey)}>
            <button
              type="button"
              className="select__trigger"
              onClick={() => setCategorySheetOpen(true)}
            >
              <span
                className={
                  category || customCategoryText ? 'select__value' : 'select__placeholder'
                }
              >
                {customCategoryText ??
                  category?.name ??
                  t('tx.selectCategory' as TranslationKey)}
              </span>
              <FolderKanban size={18} aria-hidden="true" />
            </button>
          </Field>

          <Field label={t('tx.project' as TranslationKey)}>
            <button
              type="button"
              className="select__trigger"
              onClick={() => setProjectSheetOpen(true)}
            >
              <span className={project ? 'select__value' : 'select__placeholder'}>
                {project?.name ?? t('tx.selectProject' as TranslationKey)}
              </span>
              <FolderKanban size={18} aria-hidden="true" />
            </button>
          </Field>

          <Field
            error={errors.transactionDate}
            required
            label={t('tx.date' as TranslationKey)}
          >
            <DateInput
              value={transactionDate}
              onChange={setTransactionDate}
              invalid={Boolean(errors.transactionDate)}
            />
          </Field>

          <button
            type="button"
            className="flex-row items-center gap-2 t-primary t-small"
            style={{
              background: 'transparent',
              border: 'none',
              padding: '8px 0',
              cursor: 'pointer',
            }}
            onClick={() => setShowDetails((v) => !v)}
          >
            <span>
              {showDetails
                ? t('tx.hideDetails' as TranslationKey)
                : t('tx.showDetails' as TranslationKey)}
            </span>
            <Plus
              size={16}
              style={{
                transform: showDetails ? 'rotate(45deg)' : 'rotate(0deg)',
                transition: 'transform 200ms',
              }}
              aria-hidden="true"
            />
          </button>

          {showDetails ? (
            <div className="stack--sm">
              <Field label={t('tx.time' as TranslationKey)}>
                <Input
                  type="time"
                  value={transactionTime}
                  onChange={(e) => setTransactionTime(e.target.value)}
                  dir="ltr"
                />
              </Field>

              <Field label={t('tx.referenceCode' as TranslationKey)}>
                <Input
                  value={referenceCode}
                  onChange={(e) => setReferenceCode(e.target.value)}
                  maxLength={50}
                  dir="ltr"
                />
              </Field>

              <Field label={t('tx.description' as TranslationKey)}>
                <Textarea
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  maxLength={500}
                  rows={3}
                />
              </Field>
            </div>
          ) : null}

          {errors.form ? <Alert variant="danger">{errors.form}</Alert> : null}

          {duplicateWarning ? (
            <Alert variant="warning" title={t('alert.duplicate.title' as TranslationKey)}>
              <div>{t('alert.duplicate.message' as TranslationKey)}</div>
              <ul style={{ marginTop: 6, paddingInlineStart: 16 }}>
                {duplicateWarning.reasons.map((r, i) => (
                  <li key={i} className="t-small">
                    • {r}
                  </li>
                ))}
              </ul>
              <div className="flex-row gap-2 mt-3">
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={() => setDuplicateWarning(null)}
                >
                  {t('confirm.discard' as TranslationKey)}
                </Button>
                <Button
                  variant="primary"
                  size="sm"
                  onClick={() => {
                    setDuplicateWarning(null);
                    void performSubmit();
                  }}
                >
                  {t('app.confirm' as TranslationKey)}
                </Button>
              </div>
            </Alert>
          ) : null}
        </form>
      </BottomSheet>

      <SelectAccountSheet
        open={accountSheetOpen}
        onClose={() => setAccountSheetOpen(false)}
        onSelect={setAccountId}
        selectedId={accountId}
      />

      <SelectPartySheet
        open={partySheetOpen}
        onClose={() => setPartySheetOpen(false)}
        onSelect={setPartyId}
        selectedId={partyId}
      />

      <SelectCategorySheet
        open={categorySheetOpen}
        onClose={() => setCategorySheetOpen(false)}
        transactionType={type}
        onSelect={(id, custom) => {
          setCategoryId(id);
          setCustomCategoryText(custom);
        }}
        selectedId={categoryId}
      />

      <SelectProjectSheet
        open={projectSheetOpen}
        onClose={() => setProjectSheetOpen(false)}
        onSelect={setProjectId}
        selectedId={projectId}
        projects={projects}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CreateAccountSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface CreateAccountSheetProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (accountId: AccountId) => void;
  editAccount?: Account | null;
}

export function CreateAccountSheet({
  open,
  onClose,
  onCreated,
  editAccount,
}: CreateAccountSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);

  const [name, setName] = useState(editAccount?.name ?? '');
  const [type, setType] = useState<AccountType>(editAccount?.type ?? AccountType.BANK);
  const [bankName, setBankName] = useState(editAccount?.bankName ?? '');
  const [accountNumber, setAccountNumber] = useState(editAccount?.accountNumber ?? '');
  const [cardNumber, setCardNumber] = useState(editAccount?.cardNumber ?? '');
  const [description, setDescription] = useState(editAccount?.description ?? '');
  const [openingBalanceRaw, setOpeningBalanceRaw] = useState(
    editAccount ? editAccount.openingBalance.toString() : ''
  );
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) {
      setName(editAccount?.name ?? '');
      setType(editAccount?.type ?? AccountType.BANK);
      setBankName(editAccount?.bankName ?? '');
      setAccountNumber(editAccount?.accountNumber ?? '');
      setCardNumber(editAccount?.cardNumber ?? '');
      setDescription(editAccount?.description ?? '');
      setOpeningBalanceRaw(editAccount ? editAccount.openingBalance.toString() : '');
      setErrors({});
      setSubmitting(false);
    }
  }, [open, editAccount]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting) return;

      const newErrors: Record<string, string> = {};
      if (!name.trim()) {
        newErrors.name = t('validation.name.required' as TranslationKey);
      }
      setErrors(newErrors);
      if (Object.keys(newErrors).length > 0) return;

      const openingBalance = openingBalanceRaw
        ? (parseMoney(openingBalanceRaw.replace(/,/g, '')) ?? 0n)
        : 0n;

      setSubmitting(true);

      const input: CreateAccountInput = {
        name: name.trim(),
        type,
        bankName: bankName.trim() || null,
        accountNumber: accountNumber.trim() || null,
        cardNumber: cardNumber.trim() || null,
        description: description.trim() || null,
        openingBalance,
        openingBalanceDate: null,
        sortOrder: 0,
      };

      const result = editAccount
        ? await accountService.update(editAccount.id, input)
        : await accountService.create(input);

      if (!result.ok) {
        setErrors({ form: result.message });
        setSubmitting(false);
        return;
      }

      toast.success(
        t(
          editAccount
            ? ('toast.account.updated' as TranslationKey)
            : ('toast.account.created' as TranslationKey)
        )
      );
      bump('account');
      onCreated?.(result.value.id);
      onClose();
    },
    [
      submitting,
      name,
      type,
      bankName,
      accountNumber,
      cardNumber,
      description,
      openingBalanceRaw,
      editAccount,
      onClose,
      onCreated,
      bump,
      t,
    ]
  );

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={
        editAccount
          ? t('account.edit' as TranslationKey)
          : t('account.new' as TranslationKey)
      }
      size="md"
      footer={
        <Button
          variant="primary"
          size="lg"
          block
          loading={submitting}
          onClick={(e) => void handleSubmit(e as unknown as FormEvent)}
        >
          {t('app.save' as TranslationKey)}
        </Button>
      }
    >
      <form onSubmit={handleSubmit} className="form">
        <Field error={errors.name} required label={t('account.name' as TranslationKey)}>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={100}
            autoFocus
          />
        </Field>

        <Field label={t('account.type' as TranslationKey)}>
          <Select<AccountType>
            value={type}
            onChange={(v) => v && setType(v)}
            options={[
              {
                value: AccountType.BANK,
                label: t('account.type.bank' as TranslationKey),
              },
              {
                value: AccountType.CASH,
                label: t('account.type.cash' as TranslationKey),
              },
              {
                value: AccountType.CARD,
                label: t('account.type.card' as TranslationKey),
              },
              {
                value: AccountType.TREASURY,
                label: t('account.type.treasury' as TranslationKey),
              },
            ]}
          />
        </Field>

        {type === AccountType.BANK ? (
          <Field label={t('account.bankName' as TranslationKey)}>
            <Input
              value={bankName}
              onChange={(e) => setBankName(e.target.value)}
              maxLength={80}
            />
          </Field>
        ) : null}

        <Field label={t('account.accountNumber' as TranslationKey)}>
          <Input
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            dir="ltr"
            maxLength={30}
          />
        </Field>

        <Field label={t('account.cardNumber' as TranslationKey)}>
          <Input
            value={cardNumber}
            onChange={(e) =>
              setCardNumber(e.target.value.replace(/\D/g, '').slice(0, 16))
            }
            dir="ltr"
            inputMode="numeric"
          />
        </Field>

        {!editAccount ? (
          <Field label={t('account.openingBalance' as TranslationKey)}>
            <AmountInput
              value={openingBalanceRaw}
              onChange={(raw) => setOpeningBalanceRaw(raw)}
            />
          </Field>
        ) : null}

        <Field label={t('account.description' as TranslationKey)}>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={300}
            rows={2}
          />
        </Field>

        {errors.form ? <Alert variant="danger">{errors.form}</Alert> : null}
      </form>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CreatePartySheet
// ═══════════════════════════════════════════════════════════════════════════

export interface CreatePartySheetProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (partyId: PartyId) => void;
  editParty?: Party | null;
  presetName?: string;
}

export function CreatePartySheet({
  open,
  onClose,
  onCreated,
  editParty,
  presetName,
}: CreatePartySheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);

  const [name, setName] = useState(editParty?.name ?? presetName ?? '');
  const [type, setType] = useState<PartyType>(editParty?.type ?? PartyType.PERSON);
  const [role, setRole] = useState<PartyRole | null>(editParty?.role ?? null);
  const [phone, setPhone] = useState(editParty?.phone ?? '');
  const [cardNumber, setCardNumber] = useState(editParty?.cardNumber ?? '');
  const [accountNumber, setAccountNumber] = useState(editParty?.accountNumber ?? '');
  const [notes, setNotes] = useState(editParty?.notes ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) {
      setName(editParty?.name ?? presetName ?? '');
      setType(editParty?.type ?? PartyType.PERSON);
      setRole(editParty?.role ?? null);
      setPhone(editParty?.phone ?? '');
      setCardNumber(editParty?.cardNumber ?? '');
      setAccountNumber(editParty?.accountNumber ?? '');
      setNotes(editParty?.notes ?? '');
      setErrors({});
      setSubmitting(false);
    }
  }, [open, editParty, presetName]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting) return;

      const newErrors: Record<string, string> = {};
      if (!name.trim()) {
        newErrors.name = t('validation.name.required' as TranslationKey);
      }
      setErrors(newErrors);
      if (Object.keys(newErrors).length > 0) return;

      setSubmitting(true);

      const input: CreatePartyInput = {
        name: name.trim(),
        type,
        phone: phone.trim() || null,
        cardNumber: cardNumber.trim() || null,
        accountNumber: accountNumber.trim() || null,
        role,
        notes: notes.trim() || null,
      };

      const result = editParty
        ? await partyService.update(editParty.id, input)
        : await partyService.create(input);

      if (!result.ok) {
        setErrors({ form: result.message });
        setSubmitting(false);
        return;
      }

      toast.success(
        t(
          editParty
            ? ('toast.party.updated' as TranslationKey)
            : ('toast.party.created' as TranslationKey)
        )
      );
      bump('party');
      onCreated?.(result.value.id);
      onClose();
    },
    [
      submitting,
      name,
      type,
      role,
      phone,
      cardNumber,
      accountNumber,
      notes,
      editParty,
      onClose,
      onCreated,
      bump,
      t,
    ]
  );

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={
        editParty ? t('party.edit' as TranslationKey) : t('party.new' as TranslationKey)
      }
      size="md"
      footer={
        <Button
          variant="primary"
          size="lg"
          block
          loading={submitting}
          onClick={(e) => void handleSubmit(e as unknown as FormEvent)}
        >
          {t('app.save' as TranslationKey)}
        </Button>
      }
    >
      <form onSubmit={handleSubmit} className="form">
        <Field error={errors.name} required label={t('party.name' as TranslationKey)}>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={100}
            autoFocus
          />
        </Field>

        <Field label={t('party.type' as TranslationKey)}>
          <Select<PartyType>
            value={type}
            onChange={(v) => v && setType(v)}
            options={[
              {
                value: PartyType.PERSON,
                label: t('party.type.person' as TranslationKey),
              },
              {
                value: PartyType.COMPANY,
                label: t('party.type.company' as TranslationKey),
              },
            ]}
          />
        </Field>

        <Field label={t('party.role' as TranslationKey)}>
          <Select<PartyRole>
            value={role}
            onChange={setRole}
            placeholder={t('app.none' as TranslationKey)}
            options={[
              {
                value: PartyRole.CONTRACTOR,
                label: t('party.role.contractor' as TranslationKey),
              },
              {
                value: PartyRole.EMPLOYEE,
                label: t('party.role.employee' as TranslationKey),
              },
              {
                value: PartyRole.CUSTOMER,
                label: t('party.role.customer' as TranslationKey),
              },
              {
                value: PartyRole.SUPPLIER,
                label: t('party.role.supplier' as TranslationKey),
              },
              {
                value: PartyRole.OTHER,
                label: t('party.role.other' as TranslationKey),
              },
            ]}
          />
        </Field>

        <Field label={t('party.phone' as TranslationKey)}>
          <Input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            dir="ltr"
            inputMode="tel"
            maxLength={20}
          />
        </Field>

        <Field label={t('party.cardNumber' as TranslationKey)}>
          <Input
            value={cardNumber}
            onChange={(e) =>
              setCardNumber(e.target.value.replace(/\D/g, '').slice(0, 16))
            }
            dir="ltr"
            inputMode="numeric"
          />
        </Field>

        <Field label={t('party.accountNumber' as TranslationKey)}>
          <Input
            value={accountNumber}
            onChange={(e) => setAccountNumber(e.target.value)}
            dir="ltr"
            maxLength={30}
          />
        </Field>

        <Field label={t('party.notes' as TranslationKey)}>
          <Textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            maxLength={500}
            rows={2}
          />
        </Field>

        {errors.form ? <Alert variant="danger">{errors.form}</Alert> : null}
      </form>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CreateProjectSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface CreateProjectSheetProps {
  open: boolean;
  onClose: () => void;
  onCreated?: (projectId: ProjectId) => void;
  editProject?: Project | null;
}

export function CreateProjectSheet({
  open,
  onClose,
  onCreated,
  editProject,
}: CreateProjectSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);

  const [name, setName] = useState(editProject?.name ?? '');
  const [code, setCode] = useState(editProject?.code ?? '');
  const [status, setStatus] = useState<ProjectStatus>(
    editProject?.status ?? ProjectStatus.ACTIVE
  );
  const [budgetRaw, setBudgetRaw] = useState(
    editProject?.budgetAmount !== null && editProject?.budgetAmount !== undefined
      ? editProject.budgetAmount.toString()
      : ''
  );
  const [description, setDescription] = useState(editProject?.description ?? '');
  const [submitting, setSubmitting] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (!open) {
      setName(editProject?.name ?? '');
      setCode(editProject?.code ?? '');
      setStatus(editProject?.status ?? ProjectStatus.ACTIVE);
      setBudgetRaw(
        editProject?.budgetAmount !== null && editProject?.budgetAmount !== undefined
          ? editProject.budgetAmount.toString()
          : ''
      );
      setDescription(editProject?.description ?? '');
      setErrors({});
      setSubmitting(false);
    }
  }, [open, editProject]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting) return;

      const newErrors: Record<string, string> = {};
      if (!name.trim()) {
        newErrors.name = t('validation.name.required' as TranslationKey);
      }
      setErrors(newErrors);
      if (Object.keys(newErrors).length > 0) return;

      setSubmitting(true);

      const budgetAmount = budgetRaw.trim()
        ? (parseMoney(budgetRaw.replace(/,/g, '')) ?? null)
        : null;

      const input: CreateProjectInput = {
        name: name.trim(),
        code: code.trim() || null,
        status,
        budgetAmount,
        description: description.trim() || null,
      };

      const result = editProject
        ? await projectService.update(editProject.id, input)
        : await projectService.create(input);

      if (!result.ok) {
        setErrors({ form: result.message });
        setSubmitting(false);
        return;
      }

      toast.success(
        t(
          editProject
            ? ('toast.project.updated' as TranslationKey)
            : ('toast.project.created' as TranslationKey)
        )
      );
      bump('project');
      onCreated?.(result.value.id);
      onClose();
    },
    [
      submitting,
      name,
      code,
      status,
      budgetRaw,
      description,
      editProject,
      onClose,
      onCreated,
      bump,
      t,
    ]
  );

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={
        editProject
          ? t('project.edit' as TranslationKey)
          : t('project.new' as TranslationKey)
      }
      size="md"
      footer={
        <Button
          variant="primary"
          size="lg"
          block
          loading={submitting}
          onClick={(e) => void handleSubmit(e as unknown as FormEvent)}
        >
          {t('app.save' as TranslationKey)}
        </Button>
      }
    >
      <form onSubmit={handleSubmit} className="form">
        <Field error={errors.name} required label={t('project.name' as TranslationKey)}>
          <Input
            value={name}
            onChange={(e) => setName(e.target.value)}
            maxLength={100}
            autoFocus
          />
        </Field>

        <Field label={t('project.code' as TranslationKey)}>
          <Input
            value={code}
            onChange={(e) => setCode(e.target.value)}
            maxLength={40}
            dir="ltr"
          />
        </Field>

        <Field label={t('project.status' as TranslationKey)}>
          <Select<ProjectStatus>
            value={status}
            onChange={(v) => v && setStatus(v)}
            options={[
              {
                value: ProjectStatus.ACTIVE,
                label: t('project.status.active' as TranslationKey),
              },
              {
                value: ProjectStatus.DONE,
                label: t('project.status.done' as TranslationKey),
              },
              {
                value: ProjectStatus.PAUSED,
                label: t('project.status.paused' as TranslationKey),
              },
            ]}
          />
        </Field>

        <Field label={t('project.budgetOptional' as TranslationKey)}>
          <AmountInput value={budgetRaw} onChange={(raw) => setBudgetRaw(raw)} />
        </Field>

        <Field label={t('project.description' as TranslationKey)}>
          <Textarea
            value={description}
            onChange={(e) => setDescription(e.target.value)}
            maxLength={500}
            rows={3}
          />
        </Field>

        {errors.form ? <Alert variant="danger">{errors.form}</Alert> : null}
      </form>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// DeleteTransactionDialog
// ═══════════════════════════════════════════════════════════════════════════

export interface DeleteTransactionDialogProps {
  open: boolean;
  onClose: () => void;
  transactionId: TransactionId | null;
  onDeleted?: () => void;
}

export function DeleteTransactionDialog({
  open,
  onClose,
  transactionId,
  onDeleted,
}: DeleteTransactionDialogProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);
  const [impact, setImpact] = useState<{
    currentBalance: Money;
    projectedBalance: Money;
    willCauseNegative: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(false);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (!open || !transactionId) return;
    setLoading(true);
    void (async () => {
      const result = await transactionService.getDeleteImpact(transactionId);
      if (result.ok) setImpact(result.value);
      setLoading(false);
    })();
  }, [open, transactionId]);

  const handleDelete = useCallback(async (): Promise<void> => {
    if (!transactionId || deleting) return;
    setDeleting(true);

    const result = await transactionService.softDelete(transactionId, null);

    setDeleting(false);

    if (!result.ok) {
      toast.error(result.message);
      return;
    }

    toast.success(t('toast.transaction.deleted' as TranslationKey), {
      actionLabel: t('toast.transaction.undo' as TranslationKey),
      onAction: async () => {
        const restoreResult = await transactionService.restore(transactionId, null);
        if (restoreResult.ok) {
          toast.success(t('toast.transaction.restored' as TranslationKey));
          bump('transaction');
        }
      },
    });

    bump('transaction');
    onDeleted?.();
    onClose();
  }, [transactionId, deleting, onClose, onDeleted, bump, t]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t('confirm.deleteTransaction.title' as TranslationKey)}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('app.cancel' as TranslationKey)}
          </Button>
          <Button variant="danger" onClick={handleDelete} disabled={deleting}>
            {t('app.delete' as TranslationKey)}
          </Button>
        </>
      }
    >
      <div className="confirm-dialog">
        {loading ? (
          <Spinner />
        ) : (
          <div>
            <div className="confirm-dialog__message">
              {t('confirm.deleteTransaction.message' as TranslationKey)}
            </div>
            {impact?.willCauseNegative ? (
              <div
                className="confirm-dialog__warning"
                role="alert"
                style={{ marginTop: 12 }}
              >
                <CircleAlert size={18} aria-hidden="true" />
                <div>
                  {t('confirm.deleteTransaction.willGoNegative' as TranslationKey)}
                </div>
              </div>
            ) : null}
          </div>
        )}
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// ArchiveAccountDialog
// ═══════════════════════════════════════════════════════════════════════════

export interface ArchiveAccountDialogProps {
  open: boolean;
  onClose: () => void;
  accountId: AccountId | null;
  onArchived?: () => void;
}

export function ArchiveAccountDialog({
  open,
  onClose,
  accountId,
  onArchived,
}: ArchiveAccountDialogProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);
  const [processing, setProcessing] = useState(false);

  const handleConfirm = useCallback(async (): Promise<void> => {
    if (!accountId || processing) return;
    setProcessing(true);
    const result = await accountService.archive(accountId);
    setProcessing(false);
    if (!result.ok) {
      toast.error(result.message);
      return;
    }
    toast.success(t('toast.account.archived' as TranslationKey));
    bump('account');
    onArchived?.();
    onClose();
  }, [accountId, processing, onClose, onArchived, bump, t]);

  return (
    <Modal
      open={open}
      onClose={onClose}
      title={t('confirm.archiveAccount.title' as TranslationKey)}
      footer={
        <>
          <Button variant="ghost" onClick={onClose}>
            {t('app.cancel' as TranslationKey)}
          </Button>
          <Button variant="primary" onClick={handleConfirm} disabled={processing}>
            {t('account.archive' as TranslationKey)}
          </Button>
        </>
      }
    >
      <div className="confirm-dialog">
        <div className="confirm-dialog__message">
          {t('confirm.archiveAccount.message' as TranslationKey)}
        </div>
      </div>
    </Modal>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SecurityPromptSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SecurityPromptSheetProps {
  open: boolean;
  onClose: () => void;
  onEnable: () => void;
}

export function SecurityPromptSheet({
  open,
  onClose,
  onEnable,
}: SecurityPromptSheetProps) {
  const { t } = useTranslation();
  const [count, setCount] = useState(0);

  useEffect(() => {
    if (!open) return;
    void (async () => {
      const c = await settingsService.getSecurityPromptCount();
      setCount(c);
    })();
  }, [open]);

  const handleLater = useCallback(async (): Promise<void> => {
    await settingsService.incrementSecurityPromptCount();
    onClose();
  }, [onClose]);

  return (
    <BottomSheet
      open={open}
      onClose={handleLater}
      size="auto"
      title={t('security.setupPrompt.title' as TranslationKey)}
    >
      <div className="stack">
        <div className="flex-row items-center justify-center" style={{ padding: 12 }}>
          <LockKeyhole size={48} color="var(--primary)" aria-hidden="true" />
        </div>
        <p className="t-body t-center">
          {t('security.setupPrompt.message' as TranslationKey)}
        </p>
        {count > 0 ? (
          <p className="t-caption t-dim t-center">{count}/۳ بار یادآوری</p>
        ) : null}
        <Divider />
        <Button variant="primary" size="lg" block onClick={onEnable}>
          {t('security.enable' as TranslationKey)}
        </Button>
        <Button variant="ghost" block onClick={handleLater}>
          {t('security.setupPrompt.later' as TranslationKey)}
        </Button>
      </div>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SetupPinSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface SetupPinSheetProps {
  open: boolean;
  onClose: () => void;
  onSuccess?: () => void;
  mode: 'setup' | 'change' | 'recovery';
}

export function SetupPinSheet({ open, onClose, onSuccess, mode }: SetupPinSheetProps) {
  const { t } = useTranslation();
  const [step, setStep] = useState<'current' | 'enter' | 'confirm'>(
    mode === 'change' ? 'current' : 'enter'
  );
  const [currentPin, setCurrentPin] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  const forcedRecovery = mode === 'recovery';

  useEffect(() => {
    if (!open) {
      setStep(mode === 'change' ? 'current' : 'enter');
      setCurrentPin('');
      setPin('');
      setConfirmPin('');
      setError(null);
      setSubmitting(false);
    }
  }, [open, mode]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting) return;
      setError(null);

      if (step === 'current') {
        if (currentPin.length < PIN_MIN_LENGTH || currentPin.length > PIN_MAX_LENGTH) {
          setError(
            t('validation.pin.length' as TranslationKey, {
              min: PIN_MIN_LENGTH,
              max: PIN_MAX_LENGTH,
            }) as string
          );
          return;
        }

        const result = await verifyPIN(currentPin);
        if (!result.success) {
          setError(t('security.wrongPIN' as TranslationKey));
          return;
        }

        setCurrentPin('');
        setStep('enter');
        return;
      }

      if (step === 'enter') {
        if (pin.length < PIN_MIN_LENGTH || pin.length > PIN_MAX_LENGTH) {
          setError(
            t('validation.pin.length' as TranslationKey, {
              min: PIN_MIN_LENGTH,
              max: PIN_MAX_LENGTH,
            }) as string
          );
          return;
        }
        setStep('confirm');
        return;
      }

      if (pin !== confirmPin) {
        setError(t('backup.passphraseMismatch' as TranslationKey));
        return;
      }

      setSubmitting(true);

      let result: SetupResult;
      if (mode === 'change') {
        result = await changePIN(currentPin, pin);
      } else if (mode === 'recovery') {
        result = await completeRecoveryReset(pin);
      } else {
        result = await setupSecurity({
          pin,
          pattern: null,
          biometricEnabled: false,
        });
      }

      setSubmitting(false);

      if (!result.success) {
        setError(result.error ?? t('error.generic' as TranslationKey));
        return;
      }

      toast.success(t('toast.security.enabled' as TranslationKey));
      onSuccess?.();
      onClose();
    },
    [step, currentPin, pin, confirmPin, mode, onClose, onSuccess, submitting, t]
  );

  const getTitle = (): string => {
    if (mode === 'change') return t('security.changePIN' as TranslationKey);
    if (mode === 'recovery') return t('security.recovery.setNewPIN' as TranslationKey);
    return t('security.setPIN' as TranslationKey);
  };

  const getLabel = (): string => {
    if (step === 'current') return t('security.currentPIN' as TranslationKey);
    if (step === 'enter') return t('security.newPIN' as TranslationKey);
    return t('security.confirmPIN' as TranslationKey);
  };

  const value = step === 'current' ? currentPin : step === 'enter' ? pin : confirmPin;
  const setValue =
    step === 'current' ? setCurrentPin : step === 'enter' ? setPin : setConfirmPin;

  return (
    <BottomSheet
      open={open}
      onClose={forcedRecovery ? () => undefined : onClose}
      title={getTitle()}
      size="auto"
      closeOnBackdrop={!forcedRecovery}
      closeOnEscape={!forcedRecovery}
      closeOnSwipe={!forcedRecovery}
      showCloseButton={!forcedRecovery}
    >
      <form onSubmit={handleSubmit} className="form">
        {forcedRecovery ? (
          <Alert variant="warning">
            {t('security.recovery.forced' as TranslationKey)}
          </Alert>
        ) : null}

        <Field label={getLabel()} error={error} required>
          <Input
            type="password"
            inputMode="numeric"
            value={value}
            onChange={(e) =>
              setValue(e.target.value.replace(/\D/g, '').slice(0, PIN_MAX_LENGTH))
            }
            placeholder={t('security.pinPlaceholder' as TranslationKey)}
            dir="ltr"
            autoFocus
            minLength={PIN_MIN_LENGTH}
            maxLength={PIN_MAX_LENGTH}
          />
        </Field>

        <Button type="submit" variant="primary" size="lg" block loading={submitting}>
          {step === 'confirm'
            ? t('app.confirm' as TranslationKey)
            : t('app.next' as TranslationKey)}
        </Button>
      </form>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// RecoverySheet
// ═══════════════════════════════════════════════════════════════════════════

export interface RecoverySheetProps {
  open: boolean;
  onClose: () => void;
  onSuccess: () => void;
}

export function RecoverySheet({ open, onClose, onSuccess }: RecoverySheetProps) {
  const { t } = useTranslation();
  const [code, setCode] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setCode('');
      setError(null);
      setSubmitting(false);
    }
  }, [open]);

  const handleSubmit = useCallback(
    async (e: FormEvent): Promise<void> => {
      e.preventDefault();
      if (submitting) return;

      if (code.length !== 4) {
        setError(t('security.recovery.wrongCode' as TranslationKey));
        return;
      }

      setSubmitting(true);
      const result = await applyRecoveryCode(code);
      setSubmitting(false);

      if (!result.success) {
        setError(t('security.recovery.wrongCode' as TranslationKey));
        return;
      }

      toast.warning(t('security.recovery.success' as TranslationKey));
      onSuccess();
    },
    [code, submitting, onSuccess, t]
  );

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('security.recovery.title' as TranslationKey)}
      size="auto"
    >
      <form onSubmit={handleSubmit} className="form">
        <Alert variant="warning">
          {t('security.recovery.warning' as TranslationKey)}
        </Alert>

        <Field label={t('security.recovery.message' as TranslationKey)} error={error}>
          <Input
            type="password"
            inputMode="numeric"
            value={code}
            onChange={(e) => setCode(e.target.value.replace(/\D/g, '').slice(0, 4))}
            placeholder={t('security.recovery.placeholder' as TranslationKey)}
            dir="ltr"
            autoFocus
          />
        </Field>

        <Button type="submit" variant="primary" size="lg" block loading={submitting}>
          {t('app.confirm' as TranslationKey)}
        </Button>
      </form>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// LockScreenOverlay
// ═══════════════════════════════════════════════════════════════════════════

export interface LockScreenOverlayProps {
  open: boolean;
  onUnlocked: () => void;
}

export function LockScreenOverlay({ open, onUnlocked }: LockScreenOverlayProps) {
  const { t } = useTranslation();
  const [pin, setPin] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [lockoutUntil, setLockoutUntil] = useState<string | null>(null);
  const [remainingSeconds, setRemainingSeconds] = useState(0);
  const [shake, setShake] = useState(false);
  const [biometric, setBiometric] = useState<BiometricAvailability>({
    available: false,
    type: 'none',
  });
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [recoveryOpen, setRecoveryOpen] = useState(false);
  const [pinSetupOpen, setPinSetupOpen] = useState(false);

  useEffect(() => {
    if (!open) return;
    void (async () => {
      const [availability, enabled, locked] = await Promise.all([
        checkBiometricAvailability(),
        isBiometricEnabled(),
        isCurrentlyLockedOut(),
      ]);
      setBiometric(availability);
      setBiometricEnabled(enabled);
      setLockoutUntil(locked);
    })();
  }, [open]);

  useEffect(() => {
    if (!lockoutUntil) return;
    const tick = (): void => {
      const remaining = Math.max(
        0,
        Math.ceil((new Date(lockoutUntil).getTime() - Date.now()) / 1000)
      );
      setRemainingSeconds(remaining);
      if (remaining === 0) setLockoutUntil(null);
    };
    tick();
    const timer = setInterval(tick, 1000);
    return () => clearInterval(timer);
  }, [lockoutUntil]);

  const handleBiometric = useCallback(async (): Promise<void> => {
    const mod = await import('../security');
    const result = await mod.authenticateBiometric();
    if (result.success) {
      onUnlocked();
    }
  }, [onUnlocked]);

  useEffect(() => {
    if (open && biometric.available && biometricEnabled) {
      void handleBiometric();
    }
  }, [open, biometric.available, biometricEnabled, handleBiometric]);

  const handleDigit = useCallback(
    (digit: string): void => {
      if (pin.length >= PIN_MAX_LENGTH) return;
      setPin((v) => v + digit);
      setError(null);
    },
    [pin.length]
  );

  const handleBackspace = useCallback((): void => {
    setPin((v) => v.slice(0, -1));
  }, []);

  const handleSubmit = useCallback(async (): Promise<void> => {
    if (pin.length < PIN_MIN_LENGTH || pin.length > PIN_MAX_LENGTH) return;

    const result = await verifyPIN(pin);

    if (result.success) {
      setPin('');
      onUnlocked();
      return;
    }

    if (result.lockedUntil) {
      setLockoutUntil(result.lockedUntil);
      setPin('');
      return;
    }

    setShake(true);
    setTimeout(() => setShake(false), 400);
    setError(t('security.wrongPIN' as TranslationKey));
    setPin('');
  }, [pin, onUnlocked, t]);

  if (!open) return null;

  const isLockedOut = remainingSeconds > 0;
  const canSubmit = pin.length >= PIN_MIN_LENGTH && pin.length <= PIN_MAX_LENGTH;

  return (
    <>
      <div
        className={['lock-screen', shake ? 'lock-screen--shake' : '']
          .filter(Boolean)
          .join(' ')}
      >
        <img
          className="lock-screen__logo lock-screen__brand"
          src="./assets/svg/logo-mark.svg"
          alt=""
          width={72}
          height={72}
          decoding="async"
        />

        <div className="lock-screen__title">
          {t('security.lockScreen.title' as TranslationKey)}
        </div>
        <div className="lock-screen__subtitle">
          {t('security.lockScreen.enterPIN' as TranslationKey)}
        </div>

        <div className="lock-screen__pin-dots" aria-hidden="true">
          {Array.from({ length: Math.max(PIN_MIN_LENGTH, pin.length) }).map((_, i) => (
            <span
              key={i}
              className={[
                'lock-screen__dot',
                i < pin.length ? 'lock-screen__dot--filled' : '',
              ]
                .filter(Boolean)
                .join(' ')}
            />
          ))}
        </div>

        {error ? <div className="lock-screen__error">{error}</div> : null}
        {isLockedOut ? (
          <div className="lock-screen__lockout">
            {t('security.lockedOut' as TranslationKey)} — {remainingSeconds}s
          </div>
        ) : null}

        <div
          className="lock-screen__keypad"
          role="group"
          aria-label={t('security.lockScreen.enterPIN' as TranslationKey)}
        >
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map((d) => (
            <button
              key={d}
              type="button"
              className="lock-screen__key"
              onClick={() => handleDigit(d)}
              disabled={isLockedOut}
            >
              {d}
            </button>
          ))}
          <button
            type="button"
            className="lock-screen__key lock-screen__key--empty"
            tabIndex={-1}
            aria-hidden="true"
          />
          <button
            type="button"
            className="lock-screen__key"
            onClick={() => handleDigit('0')}
            disabled={isLockedOut}
          >
            0
          </button>
          <button
            type="button"
            className="lock-screen__key"
            onClick={handleBackspace}
            disabled={isLockedOut}
            aria-label={t('app.delete' as TranslationKey)}
          >
            ⌫
          </button>
        </div>

        <Button
          variant="primary"
          size="lg"
          onClick={handleSubmit}
          disabled={!canSubmit || isLockedOut}
          style={{ minWidth: 200 }}
        >
          {t('app.confirm' as TranslationKey)}
        </Button>

        <div className="lock-screen__actions">
          {biometric.available && biometricEnabled ? (
            <button
              type="button"
              className="lock-screen__biometric"
              onClick={handleBiometric}
            >
              <LockKeyhole size={20} aria-hidden="true" />
              {t('security.lockScreen.unlockBiometric' as TranslationKey)}
            </button>
          ) : null}
          <button
            type="button"
            className="lock-screen__link"
            onClick={() => setRecoveryOpen(true)}
          >
            {t('security.lockScreen.forgot' as TranslationKey)}
          </button>
        </div>
      </div>

      <RecoverySheet
        open={recoveryOpen}
        onClose={() => setRecoveryOpen(false)}
        onSuccess={() => {
          setRecoveryOpen(false);
          setPinSetupOpen(true);
        }}
      />

      <SetupPinSheet
        open={pinSetupOpen}
        onClose={() => {
          // Forced recovery must never unlock on cancel/close.
          setPinSetupOpen(false);
        }}
        onSuccess={() => {
          setPinSetupOpen(false);
          onUnlocked();
        }}
        mode="recovery"
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// FilterTransactionsSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface FilterTransactionsSheetProps {
  open: boolean;
  onClose: () => void;
}

export function FilterTransactionsSheet({ open, onClose }: FilterTransactionsSheetProps) {
  const { t } = useTranslation();
  const transactionsFilter = useFilterStore((s) => s.transactionsFilter);
  const setTransactionsFilter = useFilterStore((s) => s.setTransactionsFilter);
  const resetTransactionsFilter = useFilterStore((s) => s.resetTransactionsFilter);
  const [draft, setDraft] = useState<TransactionFilter>(transactionsFilter);

  const accounts = useAccounts();
  const parties = useParties();
  const projects = useProjects();
  const tree = useCategoryTree();

  useEffect(() => {
    if (open) setDraft(transactionsFilter);
  }, [open, transactionsFilter]);

  const categories = useMemo(() => {
    const flat: Category[] = [];
    for (const { category, children } of tree) {
      flat.push(category);
      flat.push(...children);
    }
    return flat;
  }, [tree]);

  const handleApply = useCallback((): void => {
    setTransactionsFilter(draft);
    onClose();
  }, [draft, setTransactionsFilter, onClose]);

  const handleReset = useCallback((): void => {
    resetTransactionsFilter();
    setDraft(createEmptyTransactionFilter());
  }, [resetTransactionsFilter]);

  const toggleInArray = <T,>(arr: T[], item: T): T[] => {
    const index = arr.indexOf(item);
    if (index >= 0) return arr.filter((_, i) => i !== index);
    return [...arr, item];
  };

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('filter.title' as TranslationKey)}
      size="lg"
      footer={
        <div className="flex-row gap-2 w-full">
          <Button variant="ghost" onClick={handleReset} style={{ flex: 1 }}>
            {t('filter.reset' as TranslationKey)}
          </Button>
          <Button variant="primary" onClick={handleApply} style={{ flex: 2 }}>
            {t('filter.apply' as TranslationKey)}
          </Button>
        </div>
      }
    >
      <div className="stack">
        <Field label={t('filter.types' as TranslationKey)}>
          <div className="flex-row flex-wrap gap-2">
            <Chip
              active={draft.types.includes(TransactionType.DEPOSIT)}
              onClick={() =>
                setDraft((d) => ({
                  ...d,
                  types: toggleInArray(d.types, TransactionType.DEPOSIT),
                }))
              }
            >
              {t('tx.type.deposit' as TranslationKey)}
            </Chip>
            <Chip
              active={draft.types.includes(TransactionType.EXPENSE)}
              onClick={() =>
                setDraft((d) => ({
                  ...d,
                  types: toggleInArray(d.types, TransactionType.EXPENSE),
                }))
              }
            >
              {t('tx.type.expense' as TranslationKey)}
            </Chip>
          </div>
        </Field>

        <Field label={t('filter.accounts' as TranslationKey)}>
          <div className="flex-row flex-wrap gap-2">
            {accounts.map((a) => (
              <Chip
                key={a.id}
                active={draft.accountIds.includes(a.id)}
                onClick={() =>
                  setDraft((d) => ({
                    ...d,
                    accountIds: toggleInArray(d.accountIds, a.id),
                  }))
                }
              >
                {a.name}
              </Chip>
            ))}
          </div>
        </Field>

        <Field label={t('filter.parties' as TranslationKey)}>
          <div className="flex-row flex-wrap gap-2">
            {parties.slice(0, 20).map((p) => (
              <Chip
                key={p.id}
                active={draft.partyIds.includes(p.id)}
                onClick={() =>
                  setDraft((d) => ({
                    ...d,
                    partyIds: toggleInArray(d.partyIds, p.id),
                  }))
                }
              >
                {p.name}
              </Chip>
            ))}
          </div>
        </Field>

        <Field label={t('filter.projects' as TranslationKey)}>
          <div className="flex-row flex-wrap gap-2">
            {projects.map((p) => (
              <Chip
                key={p.id}
                active={draft.projectIds.includes(p.id)}
                onClick={() =>
                  setDraft((d) => ({
                    ...d,
                    projectIds: toggleInArray(d.projectIds, p.id),
                  }))
                }
              >
                {p.name}
              </Chip>
            ))}
          </div>
        </Field>

        <Field label={t('filter.categories' as TranslationKey)}>
          <div className="flex-row flex-wrap gap-2">
            {categories.slice(0, 24).map((c) => (
              <Chip
                key={c.id}
                active={draft.categoryIds.includes(c.id)}
                onClick={() =>
                  setDraft((d) => ({
                    ...d,
                    categoryIds: toggleInArray(d.categoryIds, c.id),
                  }))
                }
              >
                {c.name}
              </Chip>
            ))}
          </div>
        </Field>

        <Field label={t('filter.dateRange' as TranslationKey)}>
          <div className="grid-2">
            <DateInput
              value={draft.dateFrom ? toJalali(draft.dateFrom) : ''}
              onChange={(v) =>
                setDraft((d) => ({
                  ...d,
                  dateFrom: v ? parseJalaliToISO(v) : null,
                }))
              }
              ariaLabel={t('report.dateFrom' as TranslationKey)}
            />
            <DateInput
              value={draft.dateTo ? toJalali(draft.dateTo) : ''}
              onChange={(v) =>
                setDraft((d) => ({
                  ...d,
                  dateTo: v ? parseJalaliToISO(v) : null,
                }))
              }
              ariaLabel={t('report.dateTo' as TranslationKey)}
            />
          </div>
        </Field>

        <Field label={t('filter.amountRange' as TranslationKey)}>
          <div className="grid-2">
            <AmountInput
              value={draft.amountMin?.toString() ?? ''}
              onChange={(_, amt) => setDraft((d) => ({ ...d, amountMin: amt }))}
              placeholder={t('filter.amountMin' as TranslationKey)}
            />
            <AmountInput
              value={draft.amountMax?.toString() ?? ''}
              onChange={(_, amt) => setDraft((d) => ({ ...d, amountMax: amt }))}
              placeholder={t('filter.amountMax' as TranslationKey)}
            />
          </div>
        </Field>
      </div>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// CreateBackupSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface CreateBackupSheetProps {
  open: boolean;
  onClose: () => void;
  onCreated?: () => void;
}

export function CreateBackupSheet({ open, onClose, onCreated }: CreateBackupSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);
  const [passphrase, setPassphrase] = useState('');
  const [confirm, setConfirm] = useState('');
  const [error, setError] = useState<string | null>(null);
  const [progress, setProgress] = useState(0);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setPassphrase('');
      setConfirm('');
      setError(null);
      setProgress(0);
      setSubmitting(false);
    }
  }, [open]);

  const handleCreate = useCallback(async (): Promise<void> => {
    setError(null);

    if (passphrase.length < 8) {
      setError(t('validation.passphrase.min' as TranslationKey, { min: 8 }) as string);
      return;
    }
    if (passphrase !== confirm) {
      setError(t('backup.passphraseMismatch' as TranslationKey));
      return;
    }

    setSubmitting(true);
    setProgress(0.1);

    const result = await createBackup({ passphrase });

    setProgress(0.9);
    setSubmitting(false);

    if (!result.ok) {
      setError(result.message);
      setProgress(0);
      return;
    }

    setProgress(1);

    try {
      const buffer = new ArrayBuffer(result.value.data.byteLength);
      new Uint8Array(buffer).set(result.value.data);
      const blob = new Blob([buffer], {
        type: 'application/octet-stream',
      });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = result.value.fileName;
      a.click();
      setTimeout(() => URL.revokeObjectURL(url), 5000);
    } catch {
      // silent
    }

    toast.success(t('backup.created' as TranslationKey));
    bump('backup');
    onCreated?.();
    setTimeout(onClose, 800);
  }, [passphrase, confirm, onClose, onCreated, bump, t]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('backup.create' as TranslationKey)}
      size="md"
    >
      <div className="form">
        <Alert variant="info">{t('backup.passphraseHelp' as TranslationKey)}</Alert>

        <Field
          label={t('backup.passphrase' as TranslationKey)}
          hint={t('backup.passphraseMin' as TranslationKey)}
          required
        >
          <Input
            type="password"
            value={passphrase}
            onChange={(e) => setPassphrase(e.target.value)}
            autoComplete="new-password"
            disabled={submitting}
          />
        </Field>

        <Field label={t('backup.passphraseConfirm' as TranslationKey)} required>
          <Input
            type="password"
            value={confirm}
            onChange={(e) => setConfirm(e.target.value)}
            autoComplete="new-password"
            disabled={submitting}
          />
        </Field>

        {error ? <Alert variant="danger">{error}</Alert> : null}

        {submitting ? (
          <ProgressBar
            value={progress}
            max={1}
            ariaLabel={t('backup.creating' as TranslationKey)}
          />
        ) : null}

        <Button
          variant="primary"
          size="lg"
          block
          loading={submitting}
          onClick={handleCreate}
        >
          {submitting
            ? t('backup.creating' as TranslationKey)
            : t('backup.create' as TranslationKey)}
        </Button>
      </div>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// RestoreBackupSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface RestoreBackupSheetProps {
  open: boolean;
  onClose: () => void;
  onRestored?: () => void;
}

export function RestoreBackupSheet({
  open,
  onClose,
  onRestored,
}: RestoreBackupSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);
  const [step, setStep] = useState<'select' | 'inspect' | 'passphrase' | 'mode'>(
    'select'
  );
  const [fileContent, setFileContent] = useState<Uint8Array | null>(null);
  const [, setFileName] = useState<string>('');
  const [inspection, setInspection] = useState<BackupInspection | null>(null);
  const [passphrase, setPassphrase] = useState('');
  const [mode, setMode] = useState<RestoreMode>('merge');
  const [error, setError] = useState<string | null>(null);
  const [submitting, setSubmitting] = useState(false);

  useEffect(() => {
    if (!open) {
      setStep('select');
      setFileContent(null);
      setFileName('');
      setInspection(null);
      setPassphrase('');
      setMode('merge');
      setError(null);
      setSubmitting(false);
    }
  }, [open]);

  const handleFileSelect = useCallback(
    async (e: ChangeEvent<HTMLInputElement>): Promise<void> => {
      const file = e.target.files?.[0];
      if (!file) return;

      setFileName(file.name);
      setError(null);

      try {
        const buffer = await file.arrayBuffer();
        const bytes = new Uint8Array(buffer);
        setFileContent(bytes);

        const result = inspectBackup(bytes);
        if (!result.ok) {
          setError(result.message);
          return;
        }

        setInspection(result.value);
        setStep('passphrase');
      } catch (err) {
        setError(
          err instanceof Error ? err.message : t('backup.invalidFile' as TranslationKey)
        );
      }
    },
    [t]
  );

  const handleRestore = useCallback(async (): Promise<void> => {
    if (!fileContent) return;
    setError(null);
    setSubmitting(true);

    const verifyResult = await verifyBackup(fileContent, passphrase);
    if (!verifyResult.ok) {
      setError(t('backup.wrongPassphrase' as TranslationKey));
      setSubmitting(false);
      return;
    }

    const result = await restoreBackup({
      fileContent,
      passphrase,
      mode,
    });

    setSubmitting(false);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    toast.success(result.value.message);
    bump('transaction');
    onRestored?.();
    onClose();
  }, [fileContent, passphrase, mode, onClose, onRestored, bump, t]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('backup.restore' as TranslationKey)}
      size="md"
    >
      <div className="form">
        {step === 'select' ? (
          <>
            <Field label={t('backup.selectFile' as TranslationKey)}>
              <input
                type="file"
                accept=".finbackup,.bin,.dat,application/octet-stream"
                onChange={handleFileSelect}
                style={{ display: 'none' }}
                id="backup-file-input"
              />
              <label
                htmlFor="backup-file-input"
                className="btn btn--secondary btn--block"
                style={{ cursor: 'pointer', display: 'flex' }}
              >
                <DatabaseBackup size={18} aria-hidden="true" />
                {t('backup.selectFile' as TranslationKey)}
              </label>
            </Field>
            {error ? <Alert variant="danger">{error}</Alert> : null}
          </>
        ) : null}

        {step === 'passphrase' && inspection ? (
          <>
            <Alert variant="info">
              {inspection.warnings.length > 0
                ? inspection.warnings.join(' • ')
                : t('backup.verified' as TranslationKey)}
            </Alert>

            <Field label={t('backup.passphrase' as TranslationKey)} required>
              <Input
                type="password"
                value={passphrase}
                onChange={(e) => setPassphrase(e.target.value)}
                autoFocus
              />
            </Field>

            <Field label={t('backup.mode.title' as TranslationKey)}>
              <div className="stack--sm">
                <button
                  type="button"
                  className={[
                    'card',
                    'card--interactive',
                    mode === 'merge' ? 'card--elevated' : '',
                  ].join(' ')}
                  style={{ width: '100%', textAlign: 'start' }}
                  onClick={() => setMode('merge')}
                >
                  <div className="t-body t-semibold">
                    {t('backup.mode.merge' as TranslationKey)}
                  </div>
                  <div className="t-caption t-muted">
                    {t('backup.mode.mergeDesc' as TranslationKey)}
                  </div>
                </button>
                <button
                  type="button"
                  className={[
                    'card',
                    'card--interactive',
                    mode === 'replace' ? 'card--elevated' : '',
                  ].join(' ')}
                  style={{ width: '100%', textAlign: 'start' }}
                  onClick={() => setMode('replace')}
                >
                  <div className="t-body t-semibold">
                    {t('backup.mode.replace' as TranslationKey)}
                  </div>
                  <div className="t-caption t-muted">
                    {t('backup.mode.replaceDesc' as TranslationKey)}
                  </div>
                </button>
              </div>
            </Field>

            {error ? <Alert variant="danger">{error}</Alert> : null}

            <Button
              variant={mode === 'replace' ? 'danger' : 'primary'}
              size="lg"
              block
              loading={submitting}
              onClick={handleRestore}
            >
              {submitting
                ? t('backup.restoring' as TranslationKey)
                : t('backup.restore' as TranslationKey)}
            </Button>
          </>
        ) : null}
      </div>
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// ImportMappingSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface ImportMappingSheetProps {
  open: boolean;
  onClose: () => void;
  onConfirmed: (sheet: ParsedSheet, mapping: Record<number, ImportField>) => void;
}

export function ImportMappingSheet({
  open,
  onClose,
  onConfirmed,
}: ImportMappingSheetProps) {
  const { t } = useTranslation();
  const [sheet, setSheet] = useState<ParsedSheet | null>(null);
  const [mapping, setMapping] = useState<Record<number, ImportField>>({});
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    if (!open) {
      setSheet(null);
      setMapping({});
      setError(null);
      setLoading(false);
    }
  }, [open]);

  const handleFile = useCallback(
    async (e: ChangeEvent<HTMLInputElement>): Promise<void> => {
      const file = e.target.files?.[0];
      if (!file) return;

      setLoading(true);
      setError(null);

      try {
        const buffer = await file.arrayBuffer();
        const parsed = await parseExcelFile(buffer);
        setSheet(parsed);
        setMapping(suggestColumnMapping(parsed.headers));
      } catch (err) {
        setError(
          err instanceof Error ? err.message : t('error.import' as TranslationKey)
        );
      } finally {
        setLoading(false);
      }
    },
    [t]
  );

  const handleConfirm = useCallback((): void => {
    if (!sheet) return;
    onConfirmed(sheet, mapping);
  }, [sheet, mapping, onConfirmed]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('import.title' as TranslationKey)}
      size="lg"
      footer={
        sheet ? (
          <Button variant="primary" size="lg" block onClick={handleConfirm}>
            {t('app.next' as TranslationKey)}
          </Button>
        ) : null
      }
    >
      {loading ? (
        <OrbitLoader label={t('import.step.analyzing' as TranslationKey)} />
      ) : !sheet ? (
        <>
          <Field>
            <input
              type="file"
              accept=".xlsx,.xls"
              onChange={handleFile}
              style={{ display: 'none' }}
              id="import-file-input"
            />
            <label
              htmlFor="import-file-input"
              className="btn btn--primary btn--block"
              style={{ cursor: 'pointer', display: 'flex' }}
            >
              <FileSpreadsheet size={18} aria-hidden="true" />
              {t('import.selectFile' as TranslationKey)}
            </label>
          </Field>
          {error ? <Alert variant="danger">{error}</Alert> : null}
        </>
      ) : (
        <div className="stack">
          <Alert variant="info">
            {sheet.sheetName} • {sheet.totalRows} {t('app.count' as TranslationKey)}
          </Alert>

          <div className="stack--sm">
            {sheet.headers.map((header, idx) => (
              <div key={idx} className="card" style={{ padding: 12 }}>
                <div className="flex-row items-center gap-3">
                  <div className="flex-1" style={{ minWidth: 0 }}>
                    <div className="t-caption t-muted">
                      {t('import.column.excelHeader' as TranslationKey)}
                    </div>
                    <div className="t-small t-semibold truncate">{header}</div>
                  </div>
                  <div className="flex-1" style={{ minWidth: 0 }}>
                    <div className="t-caption t-muted">
                      {t('import.column.systemField' as TranslationKey)}
                    </div>
                    <Select<ImportField>
                      value={mapping[idx] ?? IMPORT_FIELD.IGNORE}
                      onChange={(v) => v && setMapping((m) => ({ ...m, [idx]: v }))}
                      options={getAllFields().map((f) => ({
                        value: f,
                        label: getFieldLabel(f),
                      }))}
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </BottomSheet>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// ImportPreviewSheet
// ═══════════════════════════════════════════════════════════════════════════

export interface ImportPreviewSheetProps {
  open: boolean;
  onClose: () => void;
  sheet: ParsedSheet | null;
  mapping: Record<number, ImportField>;
  onCommitted?: () => void;
}

export function ImportPreviewSheet({
  open,
  onClose,
  sheet,
  mapping,
  onCommitted,
}: ImportPreviewSheetProps) {
  const { t } = useTranslation();
  const bump = useRefreshStore((s) => s.bump);
  const [preview, setPreview] = useState<ImportPreviewResult | null>(null);
  const [decisions, setDecisions] = useState<Map<number, ImportDecision>>(new Map());
  const [loading, setLoading] = useState(false);
  const [committing, setCommitting] = useState(false);
  const [jobId, setJobId] = useState<ImportJobId | null>(null);
  const [autoCreateParties, setAutoCreateParties] = useState(true);

  useEffect(() => {
    if (!open || !sheet) {
      setPreview(null);
      setDecisions(new Map());
      setJobId(null);
      return;
    }

    setLoading(true);
    void (async () => {
      try {
        const result = await buildPreview(sheet, mapping);
        setPreview(result);

        const map = new Map<number, ImportDecision>();
        for (const row of result.rows) {
          map.set(row.rowIndex, row.decision);
        }
        setDecisions(map);

        const { importRepo } = await import('../db');
        const job = await importRepo.createJob('import.xlsx');
        setJobId(job.id);
      } catch (err) {
        toast.error(
          err instanceof Error ? err.message : t('error.import' as TranslationKey)
        );
      } finally {
        setLoading(false);
      }
    })();
  }, [open, sheet, mapping, t]);

  const handleCommit = useCallback(async (): Promise<void> => {
    if (!preview || !jobId || committing) return;
    setCommitting(true);

    try {
      const result = await commitImport(preview, {
        jobId,
        decisions,
        autoCreateMissingParties: autoCreateParties,
        defaultAccountId: null,
      });

      if (result.failed > 0) {
        toast.warning(
          t('import.commit.failed' as TranslationKey, {
            failed: result.failed,
          }) as string
        );
      }
      if (result.imported > 0) {
        toast.success(
          t('import.commit.success' as TranslationKey, {
            imported: result.imported,
          }) as string
        );
      }
      if (result.skipped > 0) {
        toast.info(
          t('import.commit.skipped' as TranslationKey, {
            skipped: result.skipped,
          }) as string
        );
      }

      bump('transaction');
      onCommitted?.();
      onClose();
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : t('error.import' as TranslationKey)
      );
    } finally {
      setCommitting(false);
    }
  }, [preview, jobId, decisions, autoCreateParties, onClose, onCommitted, bump, t]);

  const handleDownloadErrors = useCallback((): void => {
    if (!preview || !sheet) return;

    const errorRows = preview.rows.filter((r) => r.errors.length > 0);
    if (errorRows.length === 0) return;

    const data = exportErrorRows(errorRows, sheet.headers);
    const buffer = new ArrayBuffer(data.byteLength);
    new Uint8Array(buffer).set(data);
    const blob = new Blob([buffer], {
      type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `import-errors-${Date.now()}.xlsx`;
    a.click();
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  }, [preview, sheet]);

  return (
    <BottomSheet
      open={open}
      onClose={onClose}
      title={t('import.step.preview' as TranslationKey)}
      size="lg"
      footer={
        preview ? (
          <div className="flex-col gap-2 w-full">
            {preview.stats.invalid > 0 ? (
              <Button variant="ghost" size="sm" onClick={handleDownloadErrors} block>
                {t('import.commit.downloadErrors' as TranslationKey)}
              </Button>
            ) : null}
            <Button
              variant="primary"
              size="lg"
              block
              loading={committing}
              onClick={handleCommit}
            >
              {committing
                ? t('import.step.committing' as TranslationKey)
                : `${t('import.step.commit' as TranslationKey)} (${preview.stats.valid})`}
            </Button>
          </div>
        ) : null
      }
    >
      {loading ? (
        <OrbitLoader label={t('import.step.previewing' as TranslationKey)} />
      ) : preview ? (
        <div className="stack">
          <div className="grid-2">
            <div className="card">
              <div className="t-caption t-muted">{t('app.total' as TranslationKey)}</div>
              <div className="t-h3">{preview.stats.total}</div>
            </div>
            <div className="card">
              <div className="t-caption t-muted">{t('app.count' as TranslationKey)}</div>
              <div className="t-h3" style={{ color: 'var(--income)' }}>
                {preview.stats.valid}
              </div>
            </div>
          </div>

          <div className="flex-row flex-wrap gap-2">
            <Badge variant="success">
              {t('import.preview.exact' as TranslationKey)}: {preview.stats.exact}
            </Badge>
            <Badge variant="warning">
              {t('import.preview.likely' as TranslationKey)}: {preview.stats.likely}
            </Badge>
            <Badge variant="default">
              {t('import.preview.possible' as TranslationKey)}: {preview.stats.possible}
            </Badge>
            <Badge variant="primary">
              {t('import.preview.unique' as TranslationKey)}: {preview.stats.unique}
            </Badge>
          </div>

          <Divider />

          <div style={{ maxHeight: 320, overflowY: 'auto' }}>
            <div className="list list--bordered">
              {preview.rows.slice(0, 50).map((row) => (
                <ImportPreviewRowItem
                  key={row.rowIndex}
                  row={row}
                  decision={decisions.get(row.rowIndex) ?? row.decision}
                  onDecision={(d) =>
                    setDecisions((m) => {
                      const next = new Map(m);
                      next.set(row.rowIndex, d);
                      return next;
                    })
                  }
                />
              ))}
              {preview.rows.length > 50 ? (
                <div className="t-small t-muted p-3 t-center">
                  ... {preview.rows.length - 50} {t('app.more' as TranslationKey)}
                </div>
              ) : null}
            </div>
          </div>

          <Checkbox
            checked={autoCreateParties}
            onChange={setAutoCreateParties}
            label={t('import.autoCreateParties' as TranslationKey)}
          />
        </div>
      ) : null}
    </BottomSheet>
  );
}

function ImportPreviewRowItem({
  row,
  decision,
  onDecision,
}: {
  row: ImportPreviewRow;
  decision: ImportDecision;
  onDecision: (d: ImportDecision) => void;
}) {
  const { t } = useTranslation();

  const info: {
    variant: 'success' | 'warning' | 'default' | 'danger';
    label: string;
  } = (() => {
    if (!row.duplicate) {
      return {
        variant: 'success',
        label: t('import.preview.unique' as TranslationKey),
      };
    }
    switch (row.duplicate.level) {
      case DuplicateLevel.EXACT:
        return {
          variant: 'danger',
          label: t('import.preview.exact' as TranslationKey),
        };
      case DuplicateLevel.LIKELY:
        return {
          variant: 'warning',
          label: t('import.preview.likely' as TranslationKey),
        };
      case DuplicateLevel.POSSIBLE:
        return {
          variant: 'default',
          label: t('import.preview.possible' as TranslationKey),
        };
      case DuplicateLevel.UNIQUE:
      default:
        return {
          variant: 'success',
          label: t('import.preview.unique' as TranslationKey),
        };
    }
  })();

  return (
    <div className="card" style={{ padding: 12 }}>
      <div className="flex-row items-center gap-3">
        <div className="flex-1" style={{ minWidth: 0 }}>
          <div className="flex-row items-center gap-2">
            <Badge variant={info.variant}>{info.label}</Badge>
            {row.errors.length > 0 ? (
              <Badge variant="danger" dot>
                {row.errors.length}
              </Badge>
            ) : null}
          </div>
          <div className="t-small t-semibold" style={{ marginTop: 4 }}>
            {row.parsed.type === 'deposit' ? '↓' : '↑'}{' '}
            {row.parsed.amount ? formatMoneyPlain(row.parsed.amount) : '—'}
            {row.parsed.date ? ` • ${toJalali(row.parsed.date)}` : ''}
          </div>
          <div className="t-caption t-muted truncate">
            {row.parsed.partyName ?? '—'}
            {row.parsed.projectName ? ` • ${row.parsed.projectName}` : ''}
          </div>
        </div>
        {row.errors.length === 0 ? (
          <Checkbox
            checked={decision === 'imported'}
            onChange={(v) => onDecision(v ? 'imported' : 'skipped')}
            ariaLabel={t('app.select' as TranslationKey)}
          />
        ) : (
          <Badge variant="danger">{t('import.preview.unique' as TranslationKey)}</Badge>
        )}
      </div>
      {row.errors.length > 0 ? (
        <div className="t-caption" style={{ color: 'var(--danger)', marginTop: 6 }}>
          {row.errors.join(' • ')}
        </div>
      ) : null}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// SheetsHost
// ═══════════════════════════════════════════════════════════════════════════

export function SheetsHost(): ReactNode {
  const activeSheet = useUIStore((s) => s.activeSheet);
  const closeSheet = useUIStore((s) => s.closeSheet);
  const openSheet = useUIStore((s) => s.openSheet);

  const addTransactionSheetOpen = activeSheet === UI_SHEET.ADD_TRANSACTION;
  const filterSheetOpen = activeSheet === UI_SHEET.FILTER_TRANSACTIONS;
  const securityPromptOpen = activeSheet === UI_SHEET.SECURITY_PROMPT;
  const setupPinOpen = activeSheet === UI_SHEET.SETUP_PIN;

  return (
    <>
      <AddTransactionSheet
        open={addTransactionSheetOpen}
        onClose={() => {
          if (addTransactionSheetOpen) closeSheet();
        }}
      />
      <FilterTransactionsSheet
        open={filterSheetOpen}
        onClose={() => {
          if (filterSheetOpen) closeSheet();
        }}
      />
      <SecurityPromptSheet
        open={securityPromptOpen}
        onClose={() => {
          if (securityPromptOpen) closeSheet();
        }}
        onEnable={() => {
          closeSheet();
          openSheet(UI_SHEET.SETUP_PIN);
        }}
      />
      <SetupPinSheet open={setupPinOpen} onClose={closeSheet} mode="setup" />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// Re-exports
// ═══════════════════════════════════════════════════════════════════════════

export { accountTypeLabel, partyRoleLabel, projectStatusLabel, parseJalaliToISO };
