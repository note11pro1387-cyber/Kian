// src/ui/screens.tsx

import { useCallback, useEffect, useMemo, useState, type ReactNode } from 'react';

import {
  Activity,
  BookOpen,
  ArrowDownLeft,
  ArrowUpRight,
  Banknote,
  Bell,
  ChevronLeft,
  CircleAlert,
  CircleCheck,
  CircleDollarSign,
  Coins,
  DatabaseBackup,
  Download,
  FileSpreadsheet,
  Fingerprint,
  FolderKanban,
  History,
  Info,
  Landmark,
  Languages,
  LockKeyhole,
  Palette,
  Pencil,
  Plus,
  RefreshCw,
  Share2,
  Settings,
  ShieldCheck,
  Trash2,
  Upload,
  UserRound,
  UsersRound,
} from 'lucide-react';

import { useTranslation, translate, changeLanguage, type TranslationKey } from '../i18n';
import { Capacitor } from '@capacitor/core';
import { Share } from '@capacitor/share';

import {
  formatMoneyPlain,
  fromJalali,
  getJalaliParts,
  normalizeDigits,
  numberToPersianWords,
  toJalali,
  todayISO,
} from '../formatters';

import {
  TransactionType,
  TransactionStatus,
  AccountType,
  AccountStatus,
  PartyType,
  AuditAction,
} from '../types';

import type {
  Account,
  AccountId,
  AlertItem,
  AuditEvent,
  Category,
  ISODate,
  Money,
  Party,
  PartyId,
  PeriodReport,
  Project,
  ProjectId,
  ReportFilter,
  Transaction,
  TransactionId,
} from '../types';

import {
  accountService,
  alertsService,
  auditService,
  categoryService,
  dashboardService,
  partyService,
  projectService,
  reportService,
  settingsService,
  transactionService,
} from '../services';

import type {
  AccountWithBalance,
  DashboardSummary,
  PartyWithStats,
  ProjectWithStats,
} from '../services';

import {
  exportReport,
  exportFullWorkbook,
  exportTemplate,
  type ExportContext,
} from '../importExport';

async function shareTextContent(
  text: string,
  title: string,
): Promise<'shared' | 'copied' | 'failed'> {
  try {
    if (Capacitor.isNativePlatform()) {
      await Share.share({ title, text, dialogTitle: title });
      return 'shared';
    }

    if (typeof navigator !== 'undefined' && typeof navigator.share === 'function') {
      await navigator.share({ title, text });
      return 'shared';
    }

    if (
      typeof navigator !== 'undefined' &&
      navigator.clipboard &&
      typeof navigator.clipboard.writeText === 'function'
    ) {
      await navigator.clipboard.writeText(text);
      return 'copied';
    }

    if (typeof document !== 'undefined') {
      const textarea = document.createElement('textarea');
      textarea.value = text;
      textarea.setAttribute('readonly', '');
      textarea.style.position = 'fixed';
      textarea.style.opacity = '0';
      document.body.appendChild(textarea);
      textarea.select();
      const copied = document.execCommand('copy');
      textarea.remove();
      return copied ? 'copied' : 'failed';
    }
  } catch {
    return 'failed';
  }

  return 'failed';
}

import {
  Alert,
  Badge,
  Button,
  Card,
  Chip,
  Divider,
  DonutChart,
  EmptyState,
  ErrorState,
  Field,
  Header,
  HeroCard,
  IconButton,
  Input,
  MenuRow,
  Modal,
  ProgressBar,
  ReceiptCard,
  SearchBar,
  Select,
  Skeleton,
  SkeletonStack,
  Sparkline,
  Switch,
  Tabs,
} from './components';

import {
  CreateAccountSheet,
  CreatePartySheet,
  CreateProjectSheet,
  DeleteTransactionDialog,
  RestoreBackupSheet,
  CreateBackupSheet,
  ImportMappingSheet,
  ImportPreviewSheet,
  SetupPinSheet,
  accountTypeLabel,
  partyRoleLabel,
  projectStatusLabel,
} from './sheets';

import { useAppStore, useRefreshStore, useUIStore, toast, UI_SHEET } from '../store';

import {
  beginPerformanceWindow,
  endPerformanceWindow,
  getEffectivePerformanceTier,
  getGlobalPerformanceTier,
  getPerformanceDiagnostics,
  registerPerformanceSection,
  resetPerformanceProfile,
  unregisterPerformanceSection,
  type Diagnostics as PerfDiagnostics,
} from '../performance';

import {
  isBiometricEnabled,
  isConfigured,
  getLockTimeout,
  setLockTimeout,
  enableBiometric,
  disableBiometric,
  removeAllSecurity,
  isSupportedLockTimeout,
} from '../security';

import type { ParsedSheet, ImportField } from '../importExport';

// ═══════════════════════════════════════════════════════════════════════════
// Hooks
// ═══════════════════════════════════════════════════════════════════════════

function useDashboard(): {
  summary: DashboardSummary | null;
  sparkline: ReadonlyArray<{ date: ISODate; balance: Money }>;
  loading: boolean;
} {
  const [summary, setSummary] = useState<DashboardSummary | null>(null);
  const [sparkline, setSparkline] = useState<Array<{ date: ISODate; balance: Money }>>(
    []
  );
  const [loading, setLoading] = useState(true);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const [s, sp] = await Promise.all([
        dashboardService.getSummary(),
        dashboardService.getSparkline(30),
      ]);
      if (cancelled) return;
      setSummary(s);
      setSparkline(sp);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return { summary, sparkline, loading };
}

function useAlertsCount(): number {
  const [count, setCount] = useState(0);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const n = await alertsService.getUnreadCount();
      if (!cancelled) setCount(n);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return count;
}

function downloadBlob(data: Uint8Array, fileName: string, mimeType: string): void {
  try {
    const buffer = new ArrayBuffer(data.byteLength);
    new Uint8Array(buffer).set(data);
    const blob = new Blob([buffer], { type: mimeType });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = fileName;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(() => URL.revokeObjectURL(url), 5000);
  } catch {
    // silent
  }
}

const EMPTY_TRANSACTION_FILTER: TransactionFilter = Object.freeze({
  types: [],
  accountIds: [],
  partyIds: [],
  projectIds: [],
  categoryIds: [],
  statuses: [],
  dateFrom: null,
  dateTo: null,
  amountMin: null,
  amountMax: null,
  searchQuery: '',
}) as TransactionFilter;

function createEmptyTransactionFilter(): TransactionFilter {
  return EMPTY_TRANSACTION_FILTER;
}

// ═══════════════════════════════════════════════════════════════════════════
// S1 — SplashScreen
// ═══════════════════════════════════════════════════════════════════════════

export function SplashScreen() {
  const boot = useAppStore((s) => s.bootState);
  const { t } = useTranslation();

  const phaseLabel: Record<typeof boot.phase, string> = {
    starting: t('app.loading' as TranslationKey),
    database: t('app.loading' as TranslationKey),
    security: t('security.title' as TranslationKey),
    settings: t('app.loading' as TranslationKey),
    ready: t('app.ready' as TranslationKey),
    failed: t('error.databaseInit' as TranslationKey),
  };

  return (
    <div className="splash">
      <div className="splash__logo">
        <div className="splash__logo-ring" aria-hidden="true" />
        <div className="splash__logo-inner">
          <img
            src="./assets/svg/logo-mark.svg"
            alt=""
            width={56}
            height={56}
            decoding="async"
          />
        </div>
      </div>
      <div className="splash__brand">{t('app.name' as TranslationKey)}</div>
      <div className="splash__tagline">{t('app.tagline' as TranslationKey)}</div>
      <div
        className="splash__progress"
        role="progressbar"
        aria-valuemin={0}
        aria-valuemax={1}
        aria-valuenow={boot.progress}
      >
        <div
          className="splash__progress-fill"
          style={{ width: `${Math.max(0.05, boot.progress) * 100}%` }}
        />
      </div>
      <div className="splash__status">
        {boot.error ? (
          <span style={{ color: 'var(--danger)' }}>{boot.error}</span>
        ) : (
          phaseLabel[boot.phase]
        )}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S2 — OnboardingScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface OnboardingScreenProps {
  onComplete: () => void;
}

export function OnboardingScreen({ onComplete }: OnboardingScreenProps) {
  const { t } = useTranslation();
  const [step, setStep] = useState(0);
  const [createAccountOpen, setCreateAccountOpen] = useState(false);
  const bump = useRefreshStore((s) => s.bump);

  const steps: ReactNode[] = [
    <div className="empty-state" key="welcome">
      <div className="empty-state__icon" style={{ color: 'var(--primary)', opacity: 1 }}>
        <Coins strokeWidth={1.5} />
      </div>
      <div className="empty-state__title">
        {t('onboarding.welcome.title' as TranslationKey)}
      </div>
      <div className="empty-state__message">
        {t('onboarding.welcome.message' as TranslationKey)}
      </div>
      <div className="empty-state__action" style={{ width: '100%', maxWidth: 320 }}>
        <Button variant="primary" size="lg" block onClick={() => setStep(1)}>
          {t('onboarding.welcome.start' as TranslationKey)}
        </Button>
      </div>
    </div>,

    <div className="empty-state" key="account">
      <div className="empty-state__icon" style={{ color: 'var(--primary)', opacity: 1 }}>
        <Landmark strokeWidth={1.5} />
      </div>
      <div className="empty-state__title">
        {t('onboarding.firstAccount.title' as TranslationKey)}
      </div>
      <div className="empty-state__message">
        {t('onboarding.firstAccount.message' as TranslationKey)}
      </div>
      <div
        className="empty-state__action"
        style={{
          width: '100%',
          maxWidth: 320,
          display: 'flex',
          flexDirection: 'column',
          gap: 8,
        }}
      >
        <Button
          variant="primary"
          size="lg"
          block
          onClick={() => setCreateAccountOpen(true)}
        >
          {t('empty.accounts.action' as TranslationKey)}
        </Button>
        <Button variant="ghost" block onClick={() => setStep(2)}>
          {t('onboarding.firstAccount.skip' as TranslationKey)}
        </Button>
      </div>
    </div>,

    <div className="empty-state" key="ready">
      <div className="empty-state__icon" style={{ color: 'var(--income)', opacity: 1 }}>
        <CircleCheck strokeWidth={1.5} />
      </div>
      <div className="empty-state__title">
        {t('onboarding.ready.title' as TranslationKey)}
      </div>
      <div className="empty-state__message">
        {t('onboarding.ready.message' as TranslationKey)}
      </div>
      <div className="empty-state__action" style={{ width: '100%', maxWidth: 320 }}>
        <Button variant="primary" size="lg" block onClick={onComplete}>
          {t('onboarding.ready.enter' as TranslationKey)}
        </Button>
      </div>
    </div>,
  ];

  return (
    <>
      <div className="app-shell">
        <div className="app-shell__main flex flex-col justify-center">{steps[step]}</div>
      </div>
      <CreateAccountSheet
        open={createAccountOpen}
        onClose={() => setCreateAccountOpen(false)}
        onCreated={() => {
          bump('account');
          setCreateAccountOpen(false);
          setStep(2);
        }}
      />
    </>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S3 — DashboardScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface DashboardScreenProps {
  onNavigateTransactions: () => void;
  onNavigateAccounts: () => void;
  onNavigateAlerts: () => void;
  onNavigateSettings: () => void;
  onOpenTransaction: (id: TransactionId) => void;
}

export function DashboardScreen({
  onNavigateTransactions,
  onNavigateAccounts,
  onNavigateAlerts,
  onNavigateSettings,
  onOpenTransaction,
}: DashboardScreenProps) {
  const { t } = useTranslation();
  const { summary, sparkline, loading } = useDashboard();
  const alertsCount = useAlertsCount();
  const [hidden, setHidden] = useState(false);
  const openSheet = useUIStore((s) => s.openSheet);

  const [accounts, setAccounts] = useState<AccountWithBalance[]>([]);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await accountService.listWithBalances(false);
      if (!cancelled) setAccounts(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  const greeting = useMemo(() => {
    const h = new Date().getHours();
    if (h >= 4 && h < 12) return t('dashboard.greetingMorning' as TranslationKey);
    if (h >= 12 && h < 17) return t('dashboard.greetingAfternoon' as TranslationKey);
    if (h >= 17 && h < 19) return t('dashboard.greetingEvening' as TranslationKey);
    return t('dashboard.greetingNight' as TranslationKey);
  }, [t]);

  const todayLabel = useMemo(() => toJalali(todayISO()), []);

  if (loading) {
    return (
      <div className="page">
        <Skeleton variant="card" height={140} />
        <SkeletonStack count={3} />
      </div>
    );
  }

  if (!summary) {
    return (
      <ErrorState
        title={t('error.generic' as TranslationKey)}
        message={t('error.database' as TranslationKey)}
      />
    );
  }

  const sparklineData = sparkline.map((p) => p.balance);

  return (
    <div className="page">
      <div className="flex-row items-center justify-between gap-3">
        <div>
          <div className="t-h2">{greeting} 👋</div>
          <div className="t-caption t-muted">{todayLabel}</div>
        </div>
        <div className="flex-row gap-1">
          <IconButton
            aria-label={t('nav.alerts' as TranslationKey)}
            onClick={onNavigateAlerts}
            style={{ position: 'relative' }}
          >
            <Bell aria-hidden="true" />
            {alertsCount > 0 ? (
              <span
                style={{
                  position: 'absolute',
                  top: 6,
                  insetInlineEnd: 6,
                  minWidth: 16,
                  height: 16,
                  padding: '0 4px',
                  borderRadius: 8,
                  background: 'var(--danger)',
                  color: '#fff',
                  fontSize: 10,
                  fontWeight: 700,
                  display: 'flex',
                  alignItems: 'center',
                  justifyContent: 'center',
                }}
              >
                {alertsCount > 9 ? '۹+' : alertsCount}
              </span>
            ) : null}
          </IconButton>
          <IconButton
            aria-label={t('nav.settings' as TranslationKey)}
            onClick={onNavigateSettings}
          >
            <Settings aria-hidden="true" />
          </IconButton>
        </div>
      </div>

      <HeroCard
        label={t('dashboard.totalBalance' as TranslationKey)}
        amount={summary.totalBalance}
        delta={summary.currentMonth.inflow - summary.currentMonth.outflow}
        deltaLabel={t('dashboard.thisMonth' as TranslationKey)}
        hidden={hidden}
        onToggleHidden={() => setHidden((v) => !v)}
        {...(sparklineData.length > 1 ? { sparklineData } : {})}
      />

      <div className="grid-2">
        <Button
          variant="income"
          size="lg"
          block
          leadingIcon={<ArrowDownLeft size={18} />}
          onClick={() => openSheet(UI_SHEET.ADD_TRANSACTION)}
        >
          {t('tx.type.deposit' as TranslationKey)}
        </Button>
        <Button
          variant="expense"
          size="lg"
          block
          leadingIcon={<ArrowUpRight size={18} />}
          onClick={() => openSheet(UI_SHEET.ADD_TRANSACTION)}
        >
          {t('tx.type.expense' as TranslationKey)}
        </Button>
      </div>

      <Card>
        <div className="card__header">
          <div className="card__title">
            {t('dashboard.currentMonthFlow' as TranslationKey)}
          </div>
        </div>
        <div className="grid-2">
          <div>
            <div className="t-caption t-muted">
              {t('dashboard.inflow' as TranslationKey)}
            </div>
            <div className="amount mt-1" style={{ color: 'var(--income)' }}>
              <span className="amount-value" dir="ltr">
                {hidden ? '••••••' : `+${formatMoneyPlain(summary.currentMonth.inflow)}`}
              </span>
            </div>
          </div>
          <div>
            <div className="t-caption t-muted">
              {t('dashboard.outflow' as TranslationKey)}
            </div>
            <div className="amount mt-1" style={{ color: 'var(--expense)' }}>
              <span className="amount-value" dir="ltr">
                {hidden ? '••••••' : `−${formatMoneyPlain(summary.currentMonth.outflow)}`}
              </span>
            </div>
          </div>
        </div>
      </Card>

      {accounts.length > 0 ? (
        <div className="page__section">
          <div className="page__section-header">
            <div className="page__section-title">
              {t('nav.accounts' as TranslationKey)}
            </div>
            <button
              type="button"
              className="page__section-action"
              onClick={onNavigateAccounts}
            >
              {t('dashboard.viewAll' as TranslationKey)} →
            </button>
          </div>
          <div className="horizontal-scroll">
            {accounts.map(({ account, balance }) => (
              <AccountCardInline
                key={account.id}
                account={account}
                balance={balance}
                hidden={hidden}
                onClick={onNavigateAccounts}
              />
            ))}
          </div>
        </div>
      ) : null}

      <div className="page__section">
        <div className="page__section-header">
          <div className="page__section-title">
            {t('dashboard.recentTransactions' as TranslationKey)}
          </div>
          <button
            type="button"
            className="page__section-action"
            onClick={onNavigateTransactions}
          >
            {t('dashboard.viewAll' as TranslationKey)} →
          </button>
        </div>

        {summary.recentTransactions.length === 0 ? (
          <EmptyState
            icon={<CircleDollarSign />}
            title={t('empty.transactions.title' as TranslationKey)}
            message={t('empty.transactions.message' as TranslationKey)}
            action={
              <Button
                variant="primary"
                onClick={() => openSheet(UI_SHEET.ADD_TRANSACTION)}
              >
                {t('empty.transactions.action' as TranslationKey)}
              </Button>
            }
          />
        ) : (
          <div className="list list--bordered">
            {summary.recentTransactions.map((tx) => (
              <TransactionRowInline
                key={tx.id}
                tx={tx}
                onClick={() => onOpenTransaction(tx.id)}
              />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

function AccountCardInline({
  account,
  balance,
  hidden,
  onClick,
}: {
  account: Account;
  balance: {
    balance: Money;
    totalInflow: Money;
    totalOutflow: Money;
    transactionCount: number;
    isNegative: boolean;
  };
  hidden: boolean;
  onClick: () => void;
}) {
  const { t } = useTranslation();
  const Icon =
    account.type === AccountType.BANK
      ? Landmark
      : account.type === AccountType.CASH
        ? Banknote
        : account.type === AccountType.CARD
          ? Coins
          : Coins;

  return (
    <div
      className={[
        'account-card',
        account.status === AccountStatus.ARCHIVED ? 'account-card--archived' : '',
        balance.isNegative ? 'account-card--negative' : '',
      ]
        .filter(Boolean)
        .join(' ')}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <div className="account-card__header">
        <div className="account-card__icon">
          <Icon aria-hidden="true" />
        </div>
        <div style={{ flex: 1, minWidth: 0 }}>
          <div className="account-card__name">{account.name}</div>
          <div className="account-card__type">{accountTypeLabel(account.type)}</div>
        </div>
      </div>

      <div className="account-card__balance">
        <span className="amount-value" dir="ltr">
          {hidden ? '•••••••' : formatMoneyPlain(balance.balance)}
        </span>
        <span className="amount-unit">{t('app.toman' as TranslationKey)}</span>
      </div>

      <div className="account-card__meta">
        <span className="account-card__meta-item account-card__meta-item--income">
          <ArrowDownLeft size={12} aria-hidden="true" />
          {hidden ? '••••' : formatMoneyPlain(balance.totalInflow)}
        </span>
        <span className="account-card__meta-item account-card__meta-item--expense">
          <ArrowUpRight size={12} aria-hidden="true" />
          {hidden ? '••••' : formatMoneyPlain(balance.totalOutflow)}
        </span>
        <span className="account-card__meta-item">
          {t('account.transactionCount' as TranslationKey)}: {balance.transactionCount}
        </span>
      </div>
    </div>
  );
}

function TransactionRowInline({ tx, onClick }: { tx: Transaction; onClick: () => void }) {
  const isDeposit = tx.type === TransactionType.DEPOSIT;
  const isDeleted = tx.status === TransactionStatus.DELETED;

  return (
    <div
      className={[
        'tx-row',
        isDeposit ? 'tx-row--deposit' : 'tx-row--expense',
        isDeleted ? 'tx-row--deleted' : '',
      ]
        .filter(Boolean)
        .join(' ')}
      onClick={onClick}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => {
        if (e.key === 'Enter' || e.key === ' ') {
          e.preventDefault();
          onClick();
        }
      }}
    >
      <div className="tx-row__icon">
        {isDeposit ? (
          <ArrowDownLeft aria-hidden="true" />
        ) : (
          <ArrowUpRight aria-hidden="true" />
        )}
      </div>

      <div className="tx-row__body">
        <div className="tx-row__title">
          {tx.customCategoryText ?? (isDeposit ? 'دریافت' : 'پرداخت')}
        </div>
        <div className="tx-row__subtitle">
          {tx.transactionTime ? <span dir="ltr">{tx.transactionTime}</span> : null}
          {tx.transactionTime ? <span className="tx-row__subtitle-sep">•</span> : null}
          <span dir="ltr">{tx.displayCode}</span>
        </div>
      </div>

      <div className="tx-row__amount">
        <span className="amount-value" dir="ltr">
          {isDeposit ? '+' : '−'}
          {formatMoneyPlain(tx.amount)}
        </span>
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S4 — TransactionsListScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface TransactionsListScreenProps {
  onOpenTransaction: (id: TransactionId) => void;
  filter?: TransactionFilter;
}

import type { TransactionFilter } from '../types';

export function TransactionsListScreen({
  onOpenTransaction,
  filter = EMPTY_TRANSACTION_FILTER,
}: TransactionsListScreenProps) {
  const { t } = useTranslation();
  const openSheet = useUIStore((s) => s.openSheet);
  const bump = useRefreshStore((s) => s.bump);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    registerPerformanceSection('transactions-list');
    beginPerformanceWindow('transactions-list');
    return () => {
      endPerformanceWindow('transactions-list');
      unregisterPerformanceSection('transactions-list');
    };
  }, []);

  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [loading, setLoading] = useState(true);
  const [search, setSearch] = useState('');
  const [typeFilter, setTypeFilter] = useState<'all' | TransactionType>('all');
  const [deleteOpen, setDeleteOpen] = useState(false);
  const [deleteTargetId, setDeleteTargetId] = useState<TransactionId | null>(null);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const list = await transactionService.list(filter);
      if (cancelled) return;
      setTransactions(list);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion, filter]);

  const filtered = useMemo(() => {
    return transactions.filter((tx) => {
      if (typeFilter !== 'all' && tx.type !== typeFilter) return false;
      if (search) {
        const q = search.trim().toLowerCase();
        if (
          !tx.displayCode.toLowerCase().includes(q) &&
          !(tx.description ?? '').toLowerCase().includes(q) &&
          !(tx.referenceCode ?? '').toLowerCase().includes(q)
        ) {
          return false;
        }
      }
      return true;
    });
  }, [transactions, typeFilter, search]);

  const grouped = useMemo(() => {
    const map = new Map<ISODate, Transaction[]>();
    for (const tx of filtered) {
      const list = map.get(tx.transactionDate) ?? [];
      list.push(tx);
      map.set(tx.transactionDate, list);
    }
    return Array.from(map.entries())
      .map(([date, txs]) => {
        let inflow = 0n;
        let outflow = 0n;
        for (const tx of txs) {
          if (tx.type === TransactionType.DEPOSIT) inflow += tx.amount;
          else outflow += tx.amount;
        }
        return { date, transactions: txs, inflow, outflow };
      })
      .sort((a, b) => (a.date > b.date ? -1 : a.date < b.date ? 1 : 0));
  }, [filtered]);

  const hasActiveFilter = filter.types.length > 0 || filter.accountIds.length > 0;

  return (
    <div className="page">
      <SearchBar value={search} onChange={setSearch} />

      <div className="flex-row items-center gap-2">
        <Tabs<string>
          value={typeFilter}
          items={[
            { key: 'all', label: t('app.all' as TranslationKey) },
            {
              key: TransactionType.DEPOSIT,
              label: t('tx.type.deposit' as TranslationKey),
              variant: 'income',
            },
            {
              key: TransactionType.EXPENSE,
              label: t('tx.type.expense' as TranslationKey),
              variant: 'expense',
            },
          ]}
          onChange={(k) => {
            if (k === 'all') setTypeFilter('all');
            else setTypeFilter(k as TransactionType);
          }}
          ariaLabel={t('filter.types' as TranslationKey)}
        />
        <IconButton
          aria-label={t('filter.title' as TranslationKey)}
          onClick={() => openSheet(UI_SHEET.FILTER_TRANSACTIONS)}
          style={{
            background: hasActiveFilter ? 'var(--primary-soft)' : undefined,
            color: hasActiveFilter ? 'var(--primary)' : undefined,
          }}
        >
          <svg
            viewBox="0 0 24 24"
            width="20"
            height="20"
            fill="none"
            stroke="currentColor"
            strokeWidth="2"
            strokeLinecap="round"
            strokeLinejoin="round"
            aria-hidden="true"
          >
            <line x1="4" y1="6" x2="20" y2="6" />
            <line x1="7" y1="12" x2="17" y2="12" />
            <line x1="10" y1="18" x2="14" y2="18" />
          </svg>
        </IconButton>
      </div>

      {loading ? (
        <SkeletonStack count={4} />
      ) : grouped.length === 0 ? (
        <EmptyState
          icon={<CircleDollarSign />}
          title={t('empty.transactions.title' as TranslationKey)}
          message={t('empty.transactions.message' as TranslationKey)}
          action={
            <Button variant="primary" onClick={() => openSheet(UI_SHEET.ADD_TRANSACTION)}>
              {t('empty.transactions.action' as TranslationKey)}
            </Button>
          }
        />
      ) : (
        <div className="list list--bordered">
          {grouped.map((group) => (
            <div key={group.date}>
              <div className="tx-day-header">
                <span>{formatGroupDate(group.date)}</span>
                <div className="tx-day-header__totals">
                  {group.inflow > 0n ? (
                    <span className="tx-day-header__inflow" dir="ltr">
                      +{formatMoneyPlain(group.inflow)}
                    </span>
                  ) : null}
                  {group.outflow > 0n ? (
                    <span className="tx-day-header__outflow" dir="ltr">
                      −{formatMoneyPlain(group.outflow)}
                    </span>
                  ) : null}
                </div>
              </div>
              {group.transactions.map((tx) => (
                <TransactionRowInline
                  key={tx.id}
                  tx={tx}
                  onClick={() => onOpenTransaction(tx.id)}
                />
              ))}
            </div>
          ))}
        </div>
      )}

      <DeleteTransactionDialog
        open={deleteOpen}
        onClose={() => {
          setDeleteOpen(false);
          setDeleteTargetId(null);
        }}
        transactionId={deleteTargetId}
        onDeleted={() => bump('transaction')}
      />
    </div>
  );
}

function formatGroupDate(date: ISODate): string {
  const today = todayISO();
  if (date === today) return translate('time.today' as TranslationKey);

  const yesterday = new Date();
  yesterday.setDate(yesterday.getDate() - 1);
  const y = yesterday.toISOString().slice(0, 10);
  if (date === y) return translate('time.yesterday' as TranslationKey);

  const parts = getJalaliParts(date);
  if (!parts) return date;

  const monthsFa = [
    'فروردین',
    'اردیبهشت',
    'خرداد',
    'تیر',
    'مرداد',
    'شهریور',
    'مهر',
    'آبان',
    'آذر',
    'دی',
    'بهمن',
    'اسفند',
  ];

  return `${parts.jd} ${monthsFa[parts.jm - 1]} ${parts.jy}`;
}

// ═══════════════════════════════════════════════════════════════════════════
// S5 — TransactionDetailScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface TransactionDetailScreenProps {
  transactionId: TransactionId;
  onBack: () => void;
  onEdit?: (tx: Transaction) => void;
}

export function TransactionDetailScreen({
  transactionId,
  onBack,
  onEdit,
}: TransactionDetailScreenProps) {
  const { t } = useTranslation();
  const [transaction, setTransaction] = useState<Transaction | null>(null);
  const [account, setAccount] = useState<Account | null>(null);
  const [party, setParty] = useState<Party | null>(null);
  const [category, setCategory] = useState<Category | null>(null);
  const [project, setProject] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [deleteOpen, setDeleteOpen] = useState(false);
  const bump = useRefreshStore((s) => s.bump);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const tx = await transactionService.findById(transactionId);
      if (!tx || cancelled) {
        setLoading(false);
        return;
      }
      setTransaction(tx);

      const [acc, pt, ct, pr] = await Promise.all([
        accountService.findById(tx.accountId),
        tx.partyId ? partyService.findById(tx.partyId) : Promise.resolve(null),
        tx.categoryId ? categoryService.findById(tx.categoryId) : Promise.resolve(null),
        tx.projectId ? projectService.findById(tx.projectId) : Promise.resolve(null),
      ]);

      if (cancelled) return;
      setAccount(acc);
      setParty(pt);
      setCategory(ct);
      setProject(pr);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [transactionId, dataVersion]);

  const handleShareText = useCallback(async (): Promise<void> => {
    if (!transaction) return;
    const lines = [
      `${transaction.type === 'deposit' ? 'دریافت' : 'پرداخت'}: ${formatMoneyPlain(transaction.amount)} تومان`,
      numberToPersianWords(transaction.amount),
      `حساب: ${account?.name ?? '—'}`,
      party ? `طرف حساب: ${party.name}` : '',
      `تاریخ: ${toJalali(transaction.transactionDate)}`,
      `کد: ${transaction.displayCode}`,
    ].filter(Boolean);

    const text = lines.join('\n');

    const result = await shareTextContent(
      text,
      transaction.type === 'deposit'
        ? t('tx.newDeposit' as TranslationKey)
        : t('tx.newExpense' as TranslationKey)
    );
    if (result === 'copied') toast.success(t('toast.copied' as TranslationKey));
    if (result === 'failed') toast.error(t('error.share' as TranslationKey));
  }, [transaction, account, party, t]);

  if (loading) {
    return (
      <div className="page">
        <Skeleton variant="card" height={200} />
        <SkeletonStack count={3} />
      </div>
    );
  }

  if (!transaction) {
    return (
      <ErrorState
        title={t('error.notFound' as TranslationKey)}
        message={t('error.generic' as TranslationKey)}
        actions={
          <Button variant="secondary" onClick={onBack}>
            {t('app.back' as TranslationKey)}
          </Button>
        }
      />
    );
  }

  return (
    <div className="page">
      <Header
        title={t('tx.detail' as TranslationKey)}
        onBack={onBack}
        actions={
          onEdit ? (
            <IconButton
              aria-label={t('app.edit' as TranslationKey)}
              onClick={() => onEdit(transaction)}
            >
              <Pencil aria-hidden="true" />
            </IconButton>
          ) : null
        }
      />

      <ReceiptCard
        type={transaction.type}
        amount={transaction.amount}
        amountWords={numberToPersianWords(transaction.amount)}
        rows={[
          {
            label: t('tx.displayCode' as TranslationKey),
            value: <span dir="ltr">{transaction.displayCode}</span>,
          },
          {
            label: t('tx.account' as TranslationKey),
            value: account?.name ?? '—',
          },
          ...(party
            ? [{ label: t('tx.party' as TranslationKey), value: party.name }]
            : []),
          ...(category || transaction.customCategoryText
            ? [
                {
                  label: t('tx.category' as TranslationKey),
                  value: transaction.customCategoryText ?? category?.name ?? '—',
                },
              ]
            : []),
          ...(project
            ? [
                {
                  label: t('tx.project' as TranslationKey),
                  value: project.name,
                },
              ]
            : []),
          {
            label: t('tx.date' as TranslationKey),
            value: toJalali(transaction.transactionDate),
          },
          ...(transaction.transactionTime
            ? [
                {
                  label: t('tx.time' as TranslationKey),
                  value: <span dir="ltr">{transaction.transactionTime}</span>,
                },
              ]
            : []),
          ...(transaction.referenceCode
            ? [
                {
                  label: t('tx.referenceCode' as TranslationKey),
                  value: <span dir="ltr">{transaction.referenceCode}</span>,
                },
              ]
            : []),
          ...(transaction.description
            ? [
                {
                  label: t('tx.description' as TranslationKey),
                  value: transaction.description,
                },
              ]
            : []),
        ]}
      />

      <div className="grid-2">
        <Button
          variant="secondary"
          block
          leadingIcon={<Share2 size={16} />}
          onClick={handleShareText}
        >
          {t('app.share' as TranslationKey)}
        </Button>
        <Button
          variant="ghost"
          block
          leadingIcon={<Trash2 size={16} />}
          onClick={() => setDeleteOpen(true)}
          style={{ color: 'var(--danger)' }}
          disabled={transaction.status === TransactionStatus.DELETED}
        >
          {t('app.delete' as TranslationKey)}
        </Button>
      </div>

      {transaction.status === TransactionStatus.DELETED ? (
        <div className="flex-col gap-2">
          <Alert variant="warning">
            {t('tx.status' as TranslationKey)}:{' '}
            {translate('audit.action.delete' as TranslationKey)}
          </Alert>
          <Button
            variant="secondary"
            block
            onClick={async () => {
              const result = await transactionService.restore(transaction.id, null);
              if (result.ok) {
                toast.success(t('toast.transaction.restored' as TranslationKey));
                bump('transaction');
              } else {
                toast.error(result.message);
              }
            }}
          >
            {translate('audit.action.restore' as TranslationKey)}
          </Button>
        </div>
      ) : null}

      <DeleteTransactionDialog
        open={deleteOpen}
        onClose={() => setDeleteOpen(false)}
        transactionId={transaction.id}
        onDeleted={onBack}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S6 — AccountsListScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface AccountsListScreenProps {
  onOpenAccount: (id: AccountId) => void;
}

export function AccountsListScreen({ onOpenAccount }: AccountsListScreenProps) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<AccountWithBalance[]>([]);
  const [includeArchived, setIncludeArchived] = useState(false);
  const [createOpen, setCreateOpen] = useState(false);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await accountService.listWithBalances(includeArchived);
      if (!cancelled) setRows(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion, includeArchived]);

  return (
    <div className="page">
      <div className="flex-row items-center justify-between gap-2">
        <div className="t-h2">{t('nav.accounts' as TranslationKey)}</div>
        <Button
          variant="primary"
          size="sm"
          leadingIcon={<Plus size={16} />}
          onClick={() => setCreateOpen(true)}
        >
          {t('account.new' as TranslationKey)}
        </Button>
      </div>

      <label className="checkbox">
        <input
          type="checkbox"
          className="checkbox__input"
          checked={includeArchived}
          onChange={(e) => setIncludeArchived(e.target.checked)}
        />
        <span className="checkbox__box" aria-hidden="true">
          <svg
            className="checkbox__check"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            strokeWidth={3}
            strokeLinecap="round"
            strokeLinejoin="round"
          >
            <polyline points="20 6 9 17 4 12" />
          </svg>
        </span>
        <span className="checkbox__label">{t('app.archived' as TranslationKey)}</span>
      </label>

      {rows.length === 0 ? (
        <EmptyState
          icon={<Landmark />}
          title={t('empty.accounts.title' as TranslationKey)}
          message={t('empty.accounts.message' as TranslationKey)}
          action={
            <Button variant="primary" onClick={() => setCreateOpen(true)}>
              {t('empty.accounts.action' as TranslationKey)}
            </Button>
          }
        />
      ) : (
        <div className="stack--sm">
          {rows.map(({ account, balance }) => (
            <AccountCardInline
              key={account.id}
              account={account}
              balance={balance}
              hidden={false}
              onClick={() => onOpenAccount(account.id)}
            />
          ))}
        </div>
      )}

      <CreateAccountSheet open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S7 — AccountDetailScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface AccountDetailScreenProps {
  accountId: AccountId;
  onBack: () => void;
  onOpenTransaction: (id: TransactionId) => void;
}

export function AccountDetailScreen({
  accountId,
  onBack,
  onOpenTransaction,
}: AccountDetailScreenProps) {
  const { t } = useTranslation();
  const [account, setAccount] = useState<Account | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [balance, setBalance] = useState<{
    balance: Money;
    totalInflow: Money;
    totalOutflow: Money;
    transactionCount: number;
    isNegative: boolean;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [editOpen, setEditOpen] = useState(false);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const acc = await accountService.findById(accountId);
      if (!acc || cancelled) {
        setLoading(false);
        return;
      }
      const [txs, bal] = await Promise.all([
        transactionService.listByAccount(accountId),
        accountService.getBalance(accountId),
      ]);
      if (cancelled) return;
      setAccount(acc);
      setTransactions(txs);
      setBalance(bal);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [accountId, dataVersion]);

  if (loading) {
    return (
      <div className="page">
        <Skeleton variant="card" height={180} />
        <SkeletonStack count={4} />
      </div>
    );
  }

  if (!account || !balance) {
    return (
      <ErrorState
        title={t('error.notFound' as TranslationKey)}
        actions={
          <Button variant="secondary" onClick={onBack}>
            {t('app.back' as TranslationKey)}
          </Button>
        }
      />
    );
  }

  return (
    <div className="page">
      <Header
        title={account.name}
        onBack={onBack}
        actions={
          <IconButton
            aria-label={t('app.edit' as TranslationKey)}
            onClick={() => setEditOpen(true)}
          >
            <Pencil aria-hidden="true" />
          </IconButton>
        }
      />

      <HeroCard
        label={t('account.currentBalance' as TranslationKey)}
        amount={balance.balance}
      />

      {balance.isNegative ? (
        <Alert variant="warning" title={t('account.negativeBalance' as TranslationKey)}>
          {t('alert.negativeBalance.detail' as TranslationKey)}
        </Alert>
      ) : null}

      <div className="grid-2">
        <Card>
          <div className="t-caption t-muted">
            {t('account.totalInflow' as TranslationKey)}
          </div>
          <div className="amount mt-1" style={{ color: 'var(--income)' }}>
            <span className="amount-value" dir="ltr">
              +{formatMoneyPlain(balance.totalInflow)}
            </span>
          </div>
        </Card>
        <Card>
          <div className="t-caption t-muted">
            {t('account.totalOutflow' as TranslationKey)}
          </div>
          <div className="amount mt-1" style={{ color: 'var(--expense)' }}>
            <span className="amount-value" dir="ltr">
              −{formatMoneyPlain(balance.totalOutflow)}
            </span>
          </div>
        </Card>
      </div>

      <div className="page__section">
        <div className="page__section-title">
          {t('nav.transactions' as TranslationKey)}
        </div>

        {transactions.length === 0 ? (
          <EmptyState
            title={t('empty.transactions.title' as TranslationKey)}
            message={t('empty.transactions.message' as TranslationKey)}
          />
        ) : (
          <div className="list list--bordered">
            {transactions.slice(0, 100).map((tx) => (
              <TransactionRowInline
                key={tx.id}
                tx={tx}
                onClick={() => onOpenTransaction(tx.id)}
              />
            ))}
          </div>
        )}
      </div>

      <CreateAccountSheet
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editAccount={account}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S8 — PartiesListScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface PartiesListScreenProps {
  onOpenParty: (id: PartyId) => void;
}

export function PartiesListScreen({ onOpenParty }: PartiesListScreenProps) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<PartyWithStats[]>([]);
  const [query, setQuery] = useState('');
  const [createOpen, setCreateOpen] = useState(false);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await partyService.listWithStats(false);
      if (!cancelled) setRows(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  const filtered = useMemo(() => {
    if (!query.trim()) return rows;
    const q = query.trim().toLowerCase();
    return rows.filter((r) => r.party.normalizedName.includes(q));
  }, [rows, query]);

  return (
    <div className="page">
      <div className="flex-row items-center justify-between gap-2">
        <div className="t-h2">{t('nav.parties' as TranslationKey)}</div>
        <Button
          variant="primary"
          size="sm"
          leadingIcon={<Plus size={16} />}
          onClick={() => setCreateOpen(true)}
        >
          {t('party.new' as TranslationKey)}
        </Button>
      </div>

      <SearchBar value={query} onChange={setQuery} />

      {filtered.length === 0 ? (
        <EmptyState
          icon={<UsersRound />}
          title={t('empty.parties.title' as TranslationKey)}
          message={t('empty.parties.message' as TranslationKey)}
          action={
            <Button variant="primary" onClick={() => setCreateOpen(true)}>
              {t('empty.parties.action' as TranslationKey)}
            </Button>
          }
        />
      ) : (
        <div className="list list--bordered">
          {filtered.map(({ party, received, paid, transactionCount }) => (
            <button
              key={party.id}
              type="button"
              className="tx-row"
              style={{ textAlign: 'start', width: '100%' }}
              onClick={() => onOpenParty(party.id)}
            >
              <div
                className="tx-row__icon"
                style={{
                  background: 'var(--surface-2)',
                  color: 'var(--text-muted)',
                }}
              >
                {party.type === PartyType.COMPANY ? (
                  <FolderKanban aria-hidden="true" />
                ) : (
                  <UserRound aria-hidden="true" />
                )}
              </div>
              <div className="tx-row__body">
                <div className="tx-row__title">{party.name}</div>
                <div className="tx-row__subtitle">
                  {party.role
                    ? partyRoleLabel(party.role)
                    : party.type === PartyType.COMPANY
                      ? t('party.type.company' as TranslationKey)
                      : t('party.type.person' as TranslationKey)}
                  <span className="tx-row__subtitle-sep">•</span>
                  <span>
                    {transactionCount} {t('account.transactionCount' as TranslationKey)}
                  </span>
                </div>
              </div>
              <div className="tx-row__amount t-end">
                {received > 0n ? (
                  <div style={{ color: 'var(--income)' }}>
                    <span className="amount-value" dir="ltr">
                      +{formatMoneyPlain(received)}
                    </span>
                  </div>
                ) : null}
                {paid > 0n ? (
                  <div style={{ color: 'var(--expense)' }}>
                    <span className="amount-value" dir="ltr">
                      −{formatMoneyPlain(paid)}
                    </span>
                  </div>
                ) : null}
              </div>
            </button>
          ))}
        </div>
      )}

      <CreatePartySheet open={createOpen} onClose={() => setCreateOpen(false)} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S9 — PartyDetailScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface PartyDetailScreenProps {
  partyId: PartyId;
  onBack: () => void;
  onOpenTransaction: (id: TransactionId) => void;
}

export function PartyDetailScreen({
  partyId,
  onBack,
  onOpenTransaction,
}: PartyDetailScreenProps) {
  const { t } = useTranslation();
  const [party, setParty] = useState<Party | null>(null);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [stats, setStats] = useState<{
    received: Money;
    paid: Money;
    count: number;
    lastTransactionDate: ISODate | null;
  } | null>(null);
  const [loading, setLoading] = useState(true);
  const [editOpen, setEditOpen] = useState(false);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const p = await partyService.findById(partyId);
      if (!p || cancelled) {
        setLoading(false);
        return;
      }
      const [txs, st] = await Promise.all([
        transactionService.listByParty(partyId),
        partyService.getStats(partyId),
      ]);
      if (cancelled) return;
      setParty(p);
      setTransactions(txs);
      setStats(st);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [partyId, dataVersion]);

  const handleShareSummary = useCallback(async (): Promise<void> => {
    if (!party || !stats) return;
    const lines = [
      `گزارش ${party.name}`,
      `دریافت کل: ${formatMoneyPlain(stats.received)} تومان`,
      `پرداخت کل: ${formatMoneyPlain(stats.paid)} تومان`,
      `تعداد تراکنش: ${stats.count}`,
    ];
    const text = lines.join('\n');
    const result = await shareTextContent(text, party.name);
    if (result === 'copied') toast.success(t('toast.copied' as TranslationKey));
    if (result === 'failed') toast.error(t('error.share' as TranslationKey));
  }, [party, stats, t]);

  if (loading) {
    return (
      <div className="page">
        <Skeleton variant="card" height={140} />
        <SkeletonStack count={4} />
      </div>
    );
  }

  if (!party || !stats) {
    return (
      <ErrorState
        title={t('error.notFound' as TranslationKey)}
        actions={
          <Button variant="secondary" onClick={onBack}>
            {t('app.back' as TranslationKey)}
          </Button>
        }
      />
    );
  }

  return (
    <div className="page">
      <Header
        title={party.name}
        onBack={onBack}
        actions={
          <>
            <IconButton
              aria-label={t('app.share' as TranslationKey)}
              onClick={handleShareSummary}
            >
              <Share2 aria-hidden="true" />
            </IconButton>
            <IconButton
              aria-label={t('app.edit' as TranslationKey)}
              onClick={() => setEditOpen(true)}
            >
              <Pencil aria-hidden="true" />
            </IconButton>
          </>
        }
      />

      <div className="grid-3">
        <Card>
          <div className="t-caption t-muted">
            {t('party.totalReceived' as TranslationKey)}
          </div>
          <div className="amount mt-1" style={{ color: 'var(--income)' }}>
            <span className="amount-value" dir="ltr">
              +{formatMoneyPlain(stats.received)}
            </span>
          </div>
        </Card>
        <Card>
          <div className="t-caption t-muted">
            {t('party.totalPaid' as TranslationKey)}
          </div>
          <div className="amount mt-1" style={{ color: 'var(--expense)' }}>
            <span className="amount-value" dir="ltr">
              −{formatMoneyPlain(stats.paid)}
            </span>
          </div>
        </Card>
        <Card>
          <div className="t-caption t-muted">
            {t('party.transactionCount' as TranslationKey)}
          </div>
          <div className="t-h3 mt-1">{stats.count}</div>
        </Card>
      </div>

      {party.phone || party.cardNumber || party.accountNumber ? (
        <Card>
          <div className="stack--sm">
            {party.phone ? (
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('party.phone' as TranslationKey)}
                </span>
                <span className="t-small t-semibold" dir="ltr">
                  {party.phone}
                </span>
              </div>
            ) : null}
            {party.cardNumber ? (
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('party.cardNumber' as TranslationKey)}
                </span>
                <span className="t-small t-semibold" dir="ltr">
                  {party.cardNumber}
                </span>
              </div>
            ) : null}
            {party.accountNumber ? (
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('party.accountNumber' as TranslationKey)}
                </span>
                <span className="t-small t-semibold" dir="ltr">
                  {party.accountNumber}
                </span>
              </div>
            ) : null}
          </div>
        </Card>
      ) : null}

      <div className="page__section">
        <div className="page__section-title">
          {t('nav.transactions' as TranslationKey)}
        </div>
        {transactions.length === 0 ? (
          <EmptyState title={t('empty.transactions.title' as TranslationKey)} />
        ) : (
          <div className="list list--bordered">
            {transactions.slice(0, 100).map((tx) => (
              <TransactionRowInline
                key={tx.id}
                tx={tx}
                onClick={() => onOpenTransaction(tx.id)}
              />
            ))}
          </div>
        )}
      </div>

      <CreatePartySheet
        open={editOpen}
        onClose={() => setEditOpen(false)}
        editParty={party}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S10 — ProjectsListScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface ProjectsListScreenProps {
  onOpenProject?: (id: ProjectId) => void;
}

export function ProjectsListScreen({ onOpenProject }: ProjectsListScreenProps) {
  const { t } = useTranslation();
  const [rows, setRows] = useState<ProjectWithStats[]>([]);
  const [createOpen, setCreateOpen] = useState(false);
  const [editProject, setEditProject] = useState<Project | null>(null);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    void (async () => {
      const list = await projectService.listWithStats();
      if (!cancelled) setRows(list);
    })();
    return () => {
      cancelled = true;
    };
  }, [dataVersion]);

  return (
    <div className="page">
      <div className="flex-row items-center justify-between gap-2">
        <div className="t-h2">{t('nav.projects' as TranslationKey)}</div>
        <Button
          variant="primary"
          size="sm"
          leadingIcon={<Plus size={16} />}
          onClick={() => {
            setEditProject(null);
            setCreateOpen(true);
          }}
        >
          {t('project.new' as TranslationKey)}
        </Button>
      </div>

      {rows.length === 0 ? (
        <EmptyState
          icon={<FolderKanban />}
          title={t('empty.projects.title' as TranslationKey)}
          message={t('empty.projects.message' as TranslationKey)}
          action={
            <Button
              variant="primary"
              onClick={() => {
                setEditProject(null);
                setCreateOpen(true);
              }}
            >
              {t('empty.projects.action' as TranslationKey)}
            </Button>
          }
        />
      ) : (
        <div className="stack--sm">
          {rows.map(
            ({
              project,
              spent,
              received,
              remainingBudget,
              utilization,
              transactionCount,
            }) => (
              <Card
                key={project.id}
                interactive
                onClick={() => {
                  if (onOpenProject) onOpenProject(project.id);
                  else {
                    setEditProject(project);
                    setCreateOpen(true);
                  }
                }}
              >
                <div className="flex-row items-center justify-between gap-2">
                  <div className="flex-1" style={{ minWidth: 0 }}>
                    <div className="t-body t-semibold truncate">{project.name}</div>
                    <div className="t-caption t-muted">
                      {projectStatusLabel(project.status)}
                      {project.code ? ` • ${project.code}` : ''}
                    </div>
                  </div>
                  <IconButton
                    aria-label={t('app.edit' as TranslationKey)}
                    size="sm"
                    onClick={(e) => {
                      e.stopPropagation();
                      setEditProject(project);
                      setCreateOpen(true);
                    }}
                  >
                    <Pencil size={14} aria-hidden="true" />
                  </IconButton>
                </div>

                {project.budgetAmount !== null ? (
                  <div className="mt-3">
                    <div className="flex-row justify-between t-caption t-muted">
                      <span>
                        {t('project.spent' as TranslationKey)}: {formatMoneyPlain(spent)}
                      </span>
                      <span>
                        {t('project.remaining' as TranslationKey)}:{' '}
                        {formatMoneyPlain(remainingBudget ?? 0n)}
                      </span>
                    </div>
                    <ProgressBar
                      value={utilization ?? 0}
                      max={1}
                      variant={
                        (utilization ?? 0) > 1
                          ? 'danger'
                          : (utilization ?? 0) > 0.85
                            ? 'warning'
                            : 'primary'
                      }
                    />
                    <div className="t-caption t-muted mt-1">
                      {Math.round((utilization ?? 0) * 100)}%{' '}
                      {t('project.utilization' as TranslationKey)}
                    </div>
                  </div>
                ) : (
                  <div className="mt-2 flex-row justify-between t-caption t-muted">
                    <span>{t('project.noBudget' as TranslationKey)}</span>
                    <span>
                      {transactionCount} {t('account.transactionCount' as TranslationKey)}
                    </span>
                  </div>
                )}

                {received > 0n ? (
                  <div className="mt-2 t-caption" style={{ color: 'var(--income)' }}>
                    {t('project.received' as TranslationKey)}:{' '}
                    {formatMoneyPlain(received)}
                  </div>
                ) : null}
              </Card>
            )
          )}
        </div>
      )}

      <CreateProjectSheet
        open={createOpen}
        onClose={() => {
          setCreateOpen(false);
          setEditProject(null);
        }}
        editProject={editProject}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S11 — ReportsScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface ReportsScreenProps {
  onOpenTransaction?: (id: TransactionId) => void;
}

export function ReportsScreen({ onOpenTransaction }: ReportsScreenProps) {
  const { t } = useTranslation();
  const [startDate, setStartDate] = useState<string>(() => {
    const today = todayISO();
    const parts = getJalaliParts(today);
    if (!parts) return toJalali(today);
    const { jy, jm } = parts;
    return `${jy}/${String(jm).padStart(2, '0')}/01`;
  });
  const [endDate, setEndDate] = useState<string>(() => toJalali(todayISO()));
  const [report, setReport] = useState<PeriodReport | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    registerPerformanceSection('reports');
    return () => {
      unregisterPerformanceSection('reports');
    };
  }, []);

  useEffect(() => {
    if (!loading) {
      beginPerformanceWindow('reports');
      return () => {
        endPerformanceWindow('reports');
      };
    }
    return undefined;
  }, [loading]);

  const [exporting, setExporting] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const [accounts, setAccounts] = useState<AccountWithBalance[]>([]);
  const [parties, setParties] = useState<PartyWithStats[]>([]);
  const [projects, setProjects] = useState<ProjectWithStats[]>([]);
  const [categories, setCategories] = useState<Category[]>([]);

  useEffect(() => {
    void (async () => {
      const [a, p, pr, c] = await Promise.all([
        accountService.listWithBalances(true),
        partyService.listWithStats(true),
        projectService.listWithStats(),
        categoryService.list(true),
      ]);
      setAccounts(a);
      setParties(p);
      setProjects(pr);
      setCategories(c);
    })();
  }, []);

  const buildFilter = useCallback((): ReportFilter | null => {
    const s = parseJalaliSafe(startDate);
    const e = parseJalaliSafe(endDate);
    if (!s || !e) return null;
    if (s > e) return null;
    return {
      start: s,
      end: e,
      accountIds: [],
      partyIds: [],
      projectIds: [],
      categoryIds: [],
      types: [],
    };
  }, [startDate, endDate]);

  const generate = useCallback(async (): Promise<void> => {
    const filter = buildFilter();
    if (!filter) {
      setError(t('error.invalidDate' as TranslationKey));
      return;
    }
    setError(null);
    setLoading(true);

    const result = await reportService.generate(filter);

    setLoading(false);

    if (!result.ok) {
      setError(result.message);
      return;
    }

    setReport(result.value);
  }, [buildFilter, t]);

  useEffect(() => {
    void generate();
  }, [generate]);

  const presetButtons = [
    {
      label: t('report.preset.thisMonth' as TranslationKey),
      get: () => {
        const today = todayISO();
        const parts = getJalaliParts(today);
        if (!parts) return { start: toJalali(today), end: toJalali(today) };
        const { jy, jm } = parts;
        return {
          start: `${jy}/${String(jm).padStart(2, '0')}/01`,
          end: toJalali(today),
        };
      },
    },
    {
      label: t('report.preset.lastMonth' as TranslationKey),
      get: () => {
        const today = todayISO();
        const parts = getJalaliParts(today);
        if (!parts) return { start: '', end: '' };
        let { jy, jm } = parts;
        jm -= 1;
        if (jm < 1) {
          jm = 12;
          jy -= 1;
        }
        return {
          start: `${jy}/${String(jm).padStart(2, '0')}/01`,
          end: `${jy}/${String(jm).padStart(2, '0')}/30`,
        };
      },
    },
    {
      label: t('report.preset.last3Months' as TranslationKey),
      get: () => {
        const today = todayISO();
        const parts = getJalaliParts(today);
        if (!parts) return { start: '', end: '' };
        let { jy, jm } = parts;
        jm -= 2;
        if (jm < 1) {
          jm += 12;
          jy -= 1;
        }
        return {
          start: `${jy}/${String(jm).padStart(2, '0')}/01`,
          end: toJalali(today),
        };
      },
    },
  ];

  const handleExportExcel = useCallback(async (): Promise<void> => {
    if (!report || exporting) return;
    setExporting(true);

    try {
      const context: ExportContext = {
        accounts: accounts.map((a) => a.account),
        parties: parties.map((p) => p.party),
        projects: projects.map((p) => p.project),
        categories,
      };

      const result = await exportReport(report, context, {
        includeBreakdowns: true,
      });

      downloadBlob(result.data, result.fileName, result.mimeType);

      toast.success(t('export.success' as TranslationKey));
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : t('error.export' as TranslationKey)
      );
    } finally {
      setExporting(false);
    }
  }, [report, exporting, accounts, parties, projects, categories, t]);

  const handleShareSummary = useCallback(async (): Promise<void> => {
    if (!report) return;

    const lines = [
      `گزارش مالی`,
      `از ${toJalali(report.start)} تا ${toJalali(report.end)}`,
      ``,
      `موجودی ابتدای دوره: ${formatMoneyPlain(report.openingPosition)} تومان`,
      `مجموع ورودی‌ها: ${formatMoneyPlain(report.periodInflow)} تومان`,
      `مجموع خروجی‌ها: ${formatMoneyPlain(report.periodOutflow)} تومان`,
      `موجودی پایان دوره: ${formatMoneyPlain(report.closingPosition)} تومان`,
    ];

    const text = lines.join('\n');

    const result = await shareTextContent(text, t('report.title' as TranslationKey));
    if (result === 'copied') toast.success(t('toast.copied' as TranslationKey));
    if (result === 'failed') toast.error(t('error.share' as TranslationKey));
  }, [report, t]);

  const sparklineData = useMemo(() => {
    if (!report || report.transactions.length === 0) return [];
    const points: bigint[] = [];
    let running = report.openingPosition;
    const sortedAsc = [...report.transactions].sort((a, b) =>
      a.transactionDate < b.transactionDate ? -1 : 1
    );
    points.push(running);
    for (const tx of sortedAsc) {
      if (tx.type === TransactionType.DEPOSIT) running += tx.amount;
      else running -= tx.amount;
      points.push(running);
    }
    return points;
  }, [report]);

  const donutSlices = useMemo(() => {
    if (!report || report.byCategory.length === 0) return [];
    const palette = [
      '#8B7CFF',
      '#21C77A',
      '#FF5C68',
      '#F4B740',
      '#54A7FF',
      '#A79CFF',
      '#1FB46C',
      '#F04C58',
      '#C98A16',
      '#287ACC',
    ];
    return report.byCategory.slice(0, 8).map((c, i) => ({
      id: c.id,
      label: c.name,
      value: c.total,
      color: palette[i % palette.length]!,
    }));
  }, [report]);

  return (
    <div className="page">
      <div className="t-h2">{t('report.title' as TranslationKey)}</div>

      <div className="chip-row">
        {presetButtons.map((p) => (
          <Chip
            key={p.label}
            onClick={() => {
              const r = p.get();
              if (r.start) setStartDate(r.start);
              if (r.end) setEndDate(r.end);
            }}
          >
            {p.label}
          </Chip>
        ))}
      </div>

      <div className="grid-2">
        <Field label={t('report.dateFrom' as TranslationKey)}>
          <Input
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            placeholder="1405/06/01"
            dir="ltr"
          />
        </Field>
        <Field label={t('report.dateTo' as TranslationKey)}>
          <Input
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            placeholder="1405/06/30"
            dir="ltr"
          />
        </Field>
      </div>

      <Button
        variant="primary"
        block
        size="lg"
        leadingIcon={<RefreshCw size={16} />}
        onClick={generate}
        loading={loading}
      >
        {t('report.generate' as TranslationKey)}
      </Button>

      {error ? <Alert variant="danger">{error}</Alert> : null}

      {loading ? (
        <SkeletonStack count={3} />
      ) : report ? (
        <>
          {report.warnings.length > 0 ? (
            <div className="stack--sm">
              {report.warnings.map((w, i) => (
                <Alert
                  key={i}
                  variant={w.code === 'negative_balance' ? 'warning' : 'info'}
                >
                  {w.message}
                </Alert>
              ))}
            </div>
          ) : null}

          <Card>
            <div className="stack--sm">
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('report.openingPosition' as TranslationKey)}
                </span>
                <span className="amount">
                  <span className="amount-value" dir="ltr">
                    {formatMoneyPlain(report.openingPosition)}
                  </span>
                </span>
              </div>
              <Divider />
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('report.periodInflow' as TranslationKey)}
                </span>
                <span className="amount" style={{ color: 'var(--income)' }}>
                  <span className="amount-value" dir="ltr">
                    +{formatMoneyPlain(report.periodInflow)}
                  </span>
                </span>
              </div>
              <div className="flex-row justify-between">
                <span className="t-caption t-muted">
                  {t('report.periodOutflow' as TranslationKey)}
                </span>
                <span className="amount" style={{ color: 'var(--expense)' }}>
                  <span className="amount-value" dir="ltr">
                    −{formatMoneyPlain(report.periodOutflow)}
                  </span>
                </span>
              </div>
              <Divider />
              <div className="flex-row justify-between">
                <span className="t-body t-semibold">
                  {t('report.closingPosition' as TranslationKey)}
                </span>
                <span
                  className="amount"
                  style={{
                    color: report.closingPosition < 0n ? 'var(--warning)' : 'var(--text)',
                  }}
                >
                  <span className="amount-value" dir="ltr">
                    {formatMoneyPlain(report.closingPosition)}
                  </span>
                  <span className="amount-unit">{t('app.toman' as TranslationKey)}</span>
                </span>
              </div>
            </div>
          </Card>

          {sparklineData.length > 1 ? (
            <Card>
              <div className="t-caption t-muted mb-2">
                {t('report.title' as TranslationKey)}
              </div>
              <Sparkline
                data={sparklineData}
                variant={report.closingPosition < 0n ? 'warning' : 'primary'}
                height={80}
              />
            </Card>
          ) : null}

          {donutSlices.length > 0 ? (
            <Card>
              <div className="t-h3 mb-3">
                {t('report.breakdownByCategory' as TranslationKey)}
              </div>
              <DonutChart
                slices={donutSlices}
                totalLabel={t('app.total' as TranslationKey)}
              />
            </Card>
          ) : null}

          <div className="grid-2">
            <Button
              variant="secondary"
              block
              leadingIcon={<FileSpreadsheet size={16} />}
              onClick={handleExportExcel}
              loading={exporting}
            >
              {t('report.exportExcel' as TranslationKey)}
            </Button>
            <Button
              variant="secondary"
              block
              leadingIcon={<Share2 size={16} />}
              onClick={handleShareSummary}
            >
              {t('report.shareSummary' as TranslationKey)}
            </Button>
          </div>

          {report.transactions.length > 0 ? (
            <div className="page__section">
              <div className="page__section-title">
                {t('nav.transactions' as TranslationKey)} ({report.transactions.length})
              </div>
              <div className="list list--bordered">
                {report.transactions.slice(0, 50).map((tx) => (
                  <TransactionRowInline
                    key={tx.id}
                    tx={tx}
                    onClick={() => onOpenTransaction?.(tx.id)}
                  />
                ))}
              </div>
            </div>
          ) : (
            <EmptyState
              title={t('empty.reports.title' as TranslationKey)}
              message={t('empty.reports.message' as TranslationKey)}
            />
          )}
        </>
      ) : (
        <EmptyState
          title={t('empty.reports.title' as TranslationKey)}
          message={t('empty.reports.message' as TranslationKey)}
        />
      )}
    </div>
  );
}

function parseJalaliSafe(jalali: string): ISODate | null {
  const cleaned = normalizeDigits(jalali).replace(/[^\d/]/g, '');
  const parts = cleaned.split('/');
  if (parts.length !== 3) return null;

  const jy = Number(parts[0]);
  const jm = Number(parts[1]);
  const jd = Number(parts[2]);

  if (!Number.isFinite(jy) || !Number.isFinite(jm) || !Number.isFinite(jd)) {
    return null;
  }

  const result = fromJalali(jy, jm, jd);
  if (!result) return null;

  const mm = result.gm < 10 ? `0${result.gm}` : String(result.gm);
  const dd = result.gd < 10 ? `0${result.gd}` : String(result.gd);
  return `${result.gy}-${mm}-${dd}`;
}

// ═══════════════════════════════════════════════════════════════════════════
// S12 — ImportExportScreen
// ═══════════════════════════════════════════════════════════════════════════

export function ImportExportScreen() {
  const { t } = useTranslation();
  const [importSheet, setImportSheet] = useState<ParsedSheet | null>(null);
  const [mapping, setMapping] = useState<Record<number, ImportField>>({});
  const [mappingOpen, setMappingOpen] = useState(false);
  const [previewOpen, setPreviewOpen] = useState(false);
  const [fullExporting, setFullExporting] = useState(false);

  const handleTemplate = useCallback((): void => {
    const data = exportTemplate();
    downloadBlob(
      data,
      'import-template.xlsx',
      'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
    );
    toast.success(t('export.success' as TranslationKey));
  }, [t]);

  const handleFullExport = useCallback(async (): Promise<void> => {
    if (fullExporting) return;
    setFullExporting(true);
    try {
      const [accounts, parties, projects, categories, transactions] = await Promise.all([
        accountService.listWithBalances(true),
        partyService.listWithStats(true),
        projectService.listWithStats(),
        categoryService.list(true),
        transactionService.list(createEmptyTransactionFilter()),
      ]);

      const context: ExportContext = {
        accounts: accounts.map((a) => a.account),
        parties: parties.map((p) => p.party),
        projects: projects.map((p) => p.project),
        categories,
      };

      const result = await exportFullWorkbook(
        context,
        accounts.map((r) => ({
          account: r.account,
          totalInflow: r.balance.totalInflow,
          totalOutflow: r.balance.totalOutflow,
          balance: r.balance.balance,
          transactionCount: r.balance.transactionCount,
        })),
        parties.map((r) => ({
          party: r.party,
          received: r.received,
          paid: r.paid,
          transactionCount: r.transactionCount,
        })),
        projects.map((r) => ({
          project: r.project,
          spent: r.spent,
          received: r.received,
          remainingBudget: r.remainingBudget,
          utilization: r.utilization,
          transactionCount: r.transactionCount,
        })),
        transactions
      );

      downloadBlob(result.data, result.fileName, result.mimeType);
      toast.success(t('export.success' as TranslationKey));
    } catch (err) {
      toast.error(
        err instanceof Error ? err.message : t('error.export' as TranslationKey)
      );
    } finally {
      setFullExporting(false);
    }
  }, [fullExporting, t]);

  return (
    <div className="page">
      <div className="t-h2">{t('nav.importExport' as TranslationKey)}</div>

      <Card>
        <div className="card__header">
          <div className="card__title">{t('import.title' as TranslationKey)}</div>
        </div>
        <div className="stack--sm">
          <p className="t-small t-muted">
            {t('import.step.analyze' as TranslationKey)} →{' '}
            {t('import.step.map' as TranslationKey)} →{' '}
            {t('import.step.preview' as TranslationKey)} →{' '}
            {t('import.step.commit' as TranslationKey)}
          </p>
          <div className="grid-2">
            <Button
              variant="primary"
              block
              leadingIcon={<Upload size={16} />}
              onClick={() => setMappingOpen(true)}
            >
              {t('import.selectFile' as TranslationKey)}
            </Button>
            <Button
              variant="secondary"
              block
              leadingIcon={<Download size={16} />}
              onClick={handleTemplate}
            >
              {t('import.template.download' as TranslationKey)}
            </Button>
          </div>
        </div>
      </Card>

      <Card>
        <div className="card__header">
          <div className="card__title">{t('export.title' as TranslationKey)}</div>
        </div>
        <div className="stack--sm">
          <p className="t-small t-muted">{t('export.shareWarning' as TranslationKey)}</p>
          <Button
            variant="primary"
            block
            leadingIcon={<FileSpreadsheet size={16} />}
            onClick={handleFullExport}
            loading={fullExporting}
          >
            {t('export.full' as TranslationKey)}
          </Button>
        </div>
      </Card>

      <ImportMappingSheet
        open={mappingOpen}
        onClose={() => setMappingOpen(false)}
        onConfirmed={(sheet, map) => {
          setImportSheet(sheet);
          setMapping(map);
          setMappingOpen(false);
          setPreviewOpen(true);
        }}
      />

      <ImportPreviewSheet
        open={previewOpen}
        onClose={() => {
          setPreviewOpen(false);
          setImportSheet(null);
          setMapping({});
        }}
        sheet={importSheet}
        mapping={mapping}
      />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S13 — BackupScreen
// ═══════════════════════════════════════════════════════════════════════════

export function BackupScreen() {
  const { t } = useTranslation();
  const [lastBackup, setLastBackup] = useState<string | null>(null);
  const [createOpen, setCreateOpen] = useState(false);
  const [restoreOpen, setRestoreOpen] = useState(false);
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    void (async () => {
      const at = await settingsService.getLastBackupAt();
      setLastBackup(at);
    })();
  }, [dataVersion]);

  const relativeTime = useMemo(() => {
    if (!lastBackup) return t('backup.never' as TranslationKey);
    const diff = Date.now() - new Date(lastBackup).getTime();
    const days = Math.floor(diff / 86400000);
    const hours = Math.floor(diff / 3600000);
    const minutes = Math.floor(diff / 60000);
    if (minutes < 1) return t('time.justNow' as TranslationKey);
    if (hours < 1)
      return translate('time.minutesAgo' as TranslationKey, {
        count: minutes,
      });
    if (days < 1) return translate('time.hoursAgo' as TranslationKey, { count: hours });
    return translate('time.daysAgo' as TranslationKey, { count: days });
  }, [lastBackup, t]);

  const isStale = useMemo(() => {
    if (!lastBackup) return true;
    return Date.now() - new Date(lastBackup).getTime() > 7 * 86400000;
  }, [lastBackup]);

  return (
    <div className="page">
      <div className="t-h2">{t('backup.title' as TranslationKey)}</div>

      <Card>
        <div className="flex-row items-center gap-3">
          <div
            className="account-card__icon"
            style={{
              background: 'var(--primary-soft)',
              color: 'var(--primary)',
            }}
          >
            <DatabaseBackup aria-hidden="true" />
          </div>
          <div className="flex-1">
            <div className="t-caption t-muted">
              {t('backup.lastBackup' as TranslationKey)}
            </div>
            <div className="t-body t-semibold">{relativeTime}</div>
          </div>
          {isStale ? <Badge variant="warning" dot /> : <Badge variant="success" dot />}
        </div>

        {isStale ? (
          <Alert variant="warning" className="mt-3">
            {t('backup.reminder' as TranslationKey)}
          </Alert>
        ) : null}
      </Card>

      <div className="grid-2">
        <Button
          variant="primary"
          block
          size="lg"
          leadingIcon={<DatabaseBackup size={18} />}
          onClick={() => setCreateOpen(true)}
        >
          {t('backup.create' as TranslationKey)}
        </Button>
        <Button
          variant="secondary"
          block
          size="lg"
          leadingIcon={<Upload size={18} />}
          onClick={() => setRestoreOpen(true)}
        >
          {t('backup.restore' as TranslationKey)}
        </Button>
      </div>

      <Alert variant="info">{t('backup.differenceFromExcel' as TranslationKey)}</Alert>

      <CreateBackupSheet open={createOpen} onClose={() => setCreateOpen(false)} />

      <RestoreBackupSheet open={restoreOpen} onClose={() => setRestoreOpen(false)} />
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S14 — SettingsScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface SettingsScreenProps {
  onNavigateAbout?: () => void;
  onNavigateDiagnostics?: () => void;
  onNavigateBackup?: () => void;
  onNavigateImportExport?: () => void;
  onNavigateAudit?: () => void;
}

export function SettingsScreen({
  onNavigateAbout,
  onNavigateDiagnostics,
  onNavigateBackup,
  onNavigateImportExport,
  onNavigateAudit,
}: SettingsScreenProps) {
  const { t } = useTranslation();
  const theme = useAppStore((s) => s.theme);
  const language = useAppStore((s) => s.language);
  const companyName = useAppStore((s) => s.companyName);
  const privacyHideAmounts = useAppStore((s) => s.privacyHideAmounts);
  const setTheme = useAppStore((s) => s.setTheme);
  const setLanguage = useAppStore((s) => s.setLanguage);
  const setCompanyName = useAppStore((s) => s.setCompanyName);
  const setPrivacyHideAmounts = useAppStore((s) => s.setPrivacyHideAmounts);

  const [configured, setConfigured] = useState(false);
  const [biometricEnabled, setBiometricEnabled] = useState(false);
  const [lockTimeout, setLockTimeoutState] = useState(30);
  const [companyInput, setCompanyInput] = useState(companyName ?? '');
  const [setupPinOpen, setSetupPinOpen] = useState(false);
  const [changePinOpen, setChangePinOpen] = useState(false);
  const [removeSecurityOpen, setRemoveSecurityOpen] = useState(false);
  const [removePinInput, setRemovePinInput] = useState('');
  const [removeError, setRemoveError] = useState<string | null>(null);

  const refresh = useCallback(async (): Promise<void> => {
    const [c, b, lt] = await Promise.all([
      isConfigured(),
      isBiometricEnabled(),
      getLockTimeout(),
    ]);
    setConfigured(c);
    setBiometricEnabled(b);
    setLockTimeoutState(lt);
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  const handleLanguageChange = useCallback(
    async (lang: 'fa' | 'en'): Promise<void> => {
      setLanguage(lang);
      await changeLanguage(lang);
    },
    [setLanguage]
  );

  const handleCompanySave = useCallback((): void => {
    setCompanyName(companyInput.trim() || null);
    toast.success(t('toast.settings.saved' as TranslationKey));
  }, [companyInput, setCompanyName, t]);

  const handleEnableBiometric = useCallback(async (): Promise<void> => {
    const result = await enableBiometric();
    if (!result.success) {
      toast.error(result.error ?? t('error.generic' as TranslationKey));
      return;
    }
    toast.success(t('security.audit.biometricEnabled' as TranslationKey));
    void refresh();
  }, [refresh, t]);

  const handleDisableBiometric = useCallback(async (): Promise<void> => {
    await disableBiometric();
    toast.info(t('security.audit.biometricDisabled' as TranslationKey));
    void refresh();
  }, [refresh, t]);

  const handleRemoveSecurity = useCallback(async (): Promise<void> => {
    setRemoveError(null);
    if (!removePinInput) {
      setRemoveError(t('security.enterCurrentPIN' as TranslationKey));
      return;
    }
    const result = await removeAllSecurity(removePinInput);
    if (!result.success) {
      setRemoveError(result.error ?? t('security.wrongPIN' as TranslationKey));
      return;
    }
    toast.warning(t('security.audit.removed' as TranslationKey));
    setRemoveSecurityOpen(false);
    setRemovePinInput('');
    void refresh();
  }, [removePinInput, refresh, t]);

  const handleLockTimeoutChange = useCallback(
    async (seconds: number): Promise<void> => {
      if (!isSupportedLockTimeout(seconds)) return;
      await setLockTimeout(seconds);
      setLockTimeoutState(seconds);
      toast.success(t('toast.settings.saved' as TranslationKey));
    },
    [t]
  );

  return (
    <div className="page">
      <div className="t-h2">{t('settings.title' as TranslationKey)}</div>

      <Card>
        <div className="t-h3 mb-3">{t('settings.appearance' as TranslationKey)}</div>

        <div className="flex-row items-center justify-between gap-3 mb-3">
          <div className="flex-row items-center gap-2">
            <Palette size={18} aria-hidden="true" />
            <span className="t-body">{t('settings.theme' as TranslationKey)}</span>
          </div>
          <Tabs<'dark' | 'light'>
            value={theme}
            items={[
              {
                key: 'light',
                label: t('settings.theme.light' as TranslationKey),
              },
              {
                key: 'dark',
                label: t('settings.theme.dark' as TranslationKey),
              },
            ]}
            onChange={setTheme}
          />
        </div>

        <Divider />

        <div className="flex-row items-center justify-between gap-3 mt-3">
          <div className="flex-row items-center gap-2">
            <Languages size={18} aria-hidden="true" />
            <span className="t-body">{t('settings.language' as TranslationKey)}</span>
          </div>
          <Tabs<'fa' | 'en'>
            value={language}
            items={[
              {
                key: 'fa',
                label: t('settings.language.fa' as TranslationKey),
              },
              {
                key: 'en',
                label: t('settings.language.en' as TranslationKey),
              },
            ]}
            onChange={handleLanguageChange}
          />
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('settings.companyName' as TranslationKey)}</div>
        <div className="flex-row gap-2">
          <Input
            value={companyInput}
            onChange={(e) => setCompanyInput(e.target.value)}
            placeholder={t('settings.companyName' as TranslationKey)}
            maxLength={120}
          />
          <Button variant="primary" onClick={handleCompanySave}>
            {t('app.save' as TranslationKey)}
          </Button>
        </div>
        <div className="t-caption t-muted mt-2">
          {t('settings.companyNameHint' as TranslationKey)}
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('settings.security' as TranslationKey)}</div>

        <div className="stack--sm">
          <div className="flex-row items-center justify-between">
            <div className="flex-row items-center gap-2">
              <LockKeyhole size={18} aria-hidden="true" />
              <span className="t-body">
                {configured
                  ? t('security.enabled' as TranslationKey)
                  : t('security.disabled' as TranslationKey)}
              </span>
            </div>
            {configured ? (
              <Badge variant="success" dot>
                {t('app.active' as TranslationKey)}
              </Badge>
            ) : (
              <Badge variant="warning" dot>
                {t('app.inactive' as TranslationKey)}
              </Badge>
            )}
          </div>

          <Divider />

          {!configured ? (
            <Button
              variant="primary"
              block
              onClick={() => setSetupPinOpen(true)}
              leadingIcon={<LockKeyhole size={16} />}
            >
              {t('security.enable' as TranslationKey)}
            </Button>
          ) : (
            <>
              <Button variant="secondary" block onClick={() => setChangePinOpen(true)}>
                {t('security.changePIN' as TranslationKey)}
              </Button>

              <div className="flex-row items-center justify-between">
                <div className="flex-row items-center gap-2">
                  <Fingerprint size={18} aria-hidden="true" />
                  <span className="t-body">
                    {t('security.enableBiometric' as TranslationKey)}
                  </span>
                </div>
                <Switch
                  checked={biometricEnabled}
                  onChange={(v) => {
                    if (v) void handleEnableBiometric();
                    else void handleDisableBiometric();
                  }}
                  ariaLabel={t('security.enableBiometric' as TranslationKey)}
                />
              </div>

              <div className="flex-row items-center justify-between">
                <span className="t-body">
                  {t('security.lockTimeout' as TranslationKey)}
                </span>
                <Select<string>
                  value={String(lockTimeout)}
                  onChange={(v) => v && void handleLockTimeoutChange(Number(v))}
                  options={[
                    {
                      value: '0',
                      label: t('security.lockTimeout.immediate' as TranslationKey),
                    },
                    {
                      value: '30',
                      label: t('security.lockTimeout.30s' as TranslationKey),
                    },
                    {
                      value: '60',
                      label: t('security.lockTimeout.1m' as TranslationKey),
                    },
                    {
                      value: '300',
                      label: t('security.lockTimeout.5m' as TranslationKey),
                    },
                    {
                      value: '900',
                      label: t('security.lockTimeout.15m' as TranslationKey),
                    },
                  ]}
                />
              </div>

              <Divider />

              <Button
                variant="ghost"
                block
                onClick={() => setRemoveSecurityOpen(true)}
                style={{ color: 'var(--danger)' }}
              >
                {t('security.disable' as TranslationKey)}
              </Button>
            </>
          )}
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('settings.privacy' as TranslationKey)}</div>
        <div className="flex-row items-center justify-between">
          <span className="t-body">
            {t('settings.privacyHideAmounts' as TranslationKey)}
          </span>
          <Switch
            checked={privacyHideAmounts}
            onChange={setPrivacyHideAmounts}
            ariaLabel={t('settings.privacyHideAmounts' as TranslationKey)}
          />
        </div>
        <div className="t-caption t-muted mt-2">
          {t('settings.privacyDesc' as TranslationKey)}
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('settings.data' as TranslationKey)}</div>
        <div className="stack--sm">
          <MenuRow
            icon={<DatabaseBackup size={18} />}
            title={t('backup.title' as TranslationKey)}
            onClick={onNavigateBackup}
          />
          <MenuRow
            icon={<FileSpreadsheet size={18} />}
            title={t('nav.importExport' as TranslationKey)}
            onClick={onNavigateImportExport}
          />
          <MenuRow
            icon={<History size={18} />}
            title={t('audit.title' as TranslationKey)}
            onClick={onNavigateAudit}
          />
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('nav.about' as TranslationKey)}</div>
        <div className="stack--sm">
          <MenuRow
            icon={<Info size={18} />}
            title={t('about.title' as TranslationKey)}
            onClick={onNavigateAbout}
          />
          <MenuRow
            icon={<Activity size={18} />}
            title={t('diagnostics.title' as TranslationKey)}
            onClick={onNavigateDiagnostics}
          />
        </div>
      </Card>

      <SetupPinSheet
        open={setupPinOpen}
        onClose={() => {
          setSetupPinOpen(false);
          void refresh();
        }}
        mode="setup"
      />

      <SetupPinSheet
        open={changePinOpen}
        onClose={() => {
          setChangePinOpen(false);
          void refresh();
        }}
        mode="change"
      />

      <Modal
        open={removeSecurityOpen}
        onClose={() => {
          setRemoveSecurityOpen(false);
          setRemovePinInput('');
          setRemoveError(null);
        }}
        title={t('confirm.removeSecurity.title' as TranslationKey)}
        footer={
          <>
            <Button
              variant="ghost"
              onClick={() => {
                setRemoveSecurityOpen(false);
                setRemovePinInput('');
                setRemoveError(null);
              }}
            >
              {t('app.cancel' as TranslationKey)}
            </Button>
            <Button variant="danger" onClick={handleRemoveSecurity}>
              {t('app.confirm' as TranslationKey)}
            </Button>
          </>
        }
      >
        <div className="form">
          <p className="t-body">
            {t('confirm.removeSecurity.message' as TranslationKey)}
          </p>
          <Field
            label={t('security.currentPIN' as TranslationKey)}
            error={removeError}
            required
          >
            <Input
              type="password"
              inputMode="numeric"
              value={removePinInput}
              onChange={(e) =>
                setRemovePinInput(e.target.value.replace(/\D/g, '').slice(0, 6))
              }
              dir="ltr"
              autoFocus
            />
          </Field>
        </div>
      </Modal>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S15 — AlertsScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface AlertsScreenProps {
  onBack?: () => void;
}

export function AlertsScreen({ onBack }: AlertsScreenProps) {
  const { t } = useTranslation();
  const [alerts, setAlerts] = useState<AlertItem[]>([]);
  const [loading, setLoading] = useState(true);
  const dataVersion = useRefreshStore((s) => s.dataVersion);
  const bump = useRefreshStore((s) => s.bump);

  const load = useCallback(async (): Promise<void> => {
    setLoading(true);
    const list = await alertsService.getActive();
    setAlerts(list);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load, dataVersion]);

  const handleMarkAll = useCallback(async (): Promise<void> => {
    await alertsService.markAllRead();
    bump('alerts');
    toast.success(t('alert.markAllRead' as TranslationKey));
  }, [bump, t]);

  const handleMarkRead = useCallback(
    async (id: string): Promise<void> => {
      await alertsService.markRead(id);
      bump('alerts');
    },
    [bump]
  );

  return (
    <div className="page">
      <Header
        title={t('alert.title' as TranslationKey)}
        onBack={onBack}
        actions={
          alerts.length > 0 ? (
            <Button variant="ghost" size="sm" onClick={handleMarkAll}>
              {t('alert.markAllRead' as TranslationKey)}
            </Button>
          ) : null
        }
      />

      {loading ? (
        <SkeletonStack count={3} />
      ) : alerts.length === 0 ? (
        <EmptyState
          icon={<Bell />}
          title={t('empty.alerts.title' as TranslationKey)}
          message={t('empty.alerts.message' as TranslationKey)}
        />
      ) : (
        <div className="stack--sm">
          {alerts.map((alert) => (
            <Card
              key={alert.id}
              interactive
              onClick={() => void handleMarkRead(alert.id)}
              style={{
                borderInlineStartWidth: 3,
                borderInlineStartColor:
                  alert.severity === 'critical'
                    ? 'var(--danger)'
                    : alert.severity === 'warning'
                      ? 'var(--warning)'
                      : 'var(--info)',
                opacity: alert.readAt ? 0.7 : 1,
              }}
            >
              <div className="flex-row items-start gap-3">
                <div
                  className="tx-row__icon"
                  style={{
                    background:
                      alert.severity === 'critical'
                        ? 'var(--danger-soft)'
                        : alert.severity === 'warning'
                          ? 'var(--warning-soft)'
                          : 'var(--info-soft)',
                    color:
                      alert.severity === 'critical'
                        ? 'var(--danger)'
                        : alert.severity === 'warning'
                          ? 'var(--warning)'
                          : 'var(--info)',
                  }}
                >
                  {alert.severity === 'critical' || alert.severity === 'warning' ? (
                    <CircleAlert aria-hidden="true" />
                  ) : (
                    <Info aria-hidden="true" />
                  )}
                </div>
                <div className="flex-1" style={{ minWidth: 0 }}>
                  <div className="flex-row items-center gap-2">
                    <span className="t-body t-semibold">
                      {translate(
                        alert.messageKey as TranslationKey,
                        alert.messageParams ?? undefined
                      )}
                    </span>
                    {!alert.readAt ? <Badge variant="primary" dot /> : null}
                  </div>
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S16 — AuditHistoryScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface AuditHistoryScreenProps {
  onBack?: () => void;
}

export function AuditHistoryScreen({ onBack }: AuditHistoryScreenProps) {
  const { t } = useTranslation();
  const [events, setEvents] = useState<AuditEvent[]>([]);
  const [loading, setLoading] = useState(true);
  const [filterAction, setFilterAction] = useState<AuditAction | 'all'>('all');
  const dataVersion = useRefreshStore((s) => s.dataVersion);

  useEffect(() => {
    let cancelled = false;
    setLoading(true);
    void (async () => {
      const auditFilter: {
        action?: AuditAction;
        limit?: number;
      } = {
        limit: 200,
      };

      if (filterAction !== 'all') {
        auditFilter.action = filterAction;
      }

      const list = await auditService.list(auditFilter);
      if (cancelled) return;
      setEvents(list);
      setLoading(false);
    })();
    return () => {
      cancelled = true;
    };
  }, [filterAction, dataVersion]);

  const actionLabel = (action: AuditAction): string =>
    t(`audit.action.${action}` as TranslationKey);

  const entityLabel = (type: string): string => {
    const key = `audit.entity.${type}` as TranslationKey;
    const result = t(key);
    return result === key ? type : result;
  };

  return (
    <div className="page">
      <Header title={t('audit.title' as TranslationKey)} onBack={onBack} />

      <Select<AuditAction | 'all'>
        value={filterAction}
        onChange={(v) => v && setFilterAction(v)}
        options={[
          {
            value: 'all',
            label: t('audit.filter.allActions' as TranslationKey),
          },
          {
            value: AuditAction.CREATE,
            label: actionLabel(AuditAction.CREATE),
          },
          {
            value: AuditAction.EDIT,
            label: actionLabel(AuditAction.EDIT),
          },
          {
            value: AuditAction.DELETE,
            label: actionLabel(AuditAction.DELETE),
          },
          {
            value: AuditAction.RESTORE,
            label: actionLabel(AuditAction.RESTORE),
          },
          {
            value: AuditAction.SECURITY_CHANGE,
            label: actionLabel(AuditAction.SECURITY_CHANGE),
          },
          {
            value: AuditAction.BACKUP_RESTORE,
            label: actionLabel(AuditAction.BACKUP_RESTORE),
          },
          {
            value: AuditAction.IMPORT,
            label: actionLabel(AuditAction.IMPORT),
          },
        ]}
      />

      {loading ? (
        <SkeletonStack count={5} />
      ) : events.length === 0 ? (
        <EmptyState
          icon={<Activity />}
          title={t('empty.audit.title' as TranslationKey)}
          message={t('empty.audit.message' as TranslationKey)}
        />
      ) : (
        <div className="list list--bordered">
          {events.map((ev) => (
            <div key={ev.id} className="tx-row" style={{ alignItems: 'flex-start' }}>
              <div
                className="tx-row__icon"
                style={{
                  background: 'var(--surface-2)',
                  color: 'var(--text-muted)',
                }}
              >
                {ev.action === AuditAction.SECURITY_CHANGE ? (
                  <ShieldCheck aria-hidden="true" />
                ) : ev.action === AuditAction.BACKUP_RESTORE ? (
                  <DatabaseBackup aria-hidden="true" />
                ) : ev.action === AuditAction.DELETE ? (
                  <Trash2 aria-hidden="true" />
                ) : ev.action === AuditAction.CREATE ? (
                  <CircleCheck aria-hidden="true" />
                ) : (
                  <Pencil aria-hidden="true" />
                )}
              </div>
              <div className="tx-row__body">
                <div className="t-small t-semibold">
                  {actionLabel(ev.action)} • {entityLabel(ev.entityType)}
                </div>
                <div className="t-caption t-muted mt-1" dir="ltr">
                  {new Date(ev.createdAt).toLocaleString('fa-IR')}
                </div>
                {ev.actorLabel ? (
                  <div className="t-caption t-muted">
                    {t('tx.createdBy' as TranslationKey)}: {ev.actorLabel}
                  </div>
                ) : null}
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S17 — AboutScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface AboutScreenProps {
  onBack?: () => void;
}

export function AboutScreen({ onBack }: AboutScreenProps) {
  const { t } = useTranslation();
  const [schemaVersion, setSchemaVersion] = useState<number>(2);

  useEffect(() => {
    void (async () => {
      try {
        const { SCHEMA_VERSION } = await import('../db');
        setSchemaVersion(SCHEMA_VERSION);
      } catch {
        // silent
      }
    })();
  }, []);

  const buildDate = useMemo(() => new Date().toISOString().slice(0, 10), []);

  return (
    <div className="page">
      <Header title={t('about.title' as TranslationKey)} onBack={onBack} />

      <div className="flex-col items-center gap-3" style={{ padding: '24px 0' }}>
        <div
          style={{
            width: 72,
            height: 72,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
          }}
          aria-hidden="true"
        >
          <img
            src="./assets/svg/logo-mark.svg"
            alt=""
            width={72}
            height={72}
            decoding="async"
          />
        </div>
        <div className="t-h2">{t('app.name' as TranslationKey)}</div>
        <div className="t-caption t-muted">{t('app.tagline' as TranslationKey)}</div>
      </div>

      <Card>
        <div className="stack--sm">
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('about.appVersion' as TranslationKey)}
            </span>
            <span className="t-small t-semibold" dir="ltr">
              1.0.0
            </span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('about.schemaVersion' as TranslationKey)}
            </span>
            <span className="t-small t-semibold" dir="ltr">
              {schemaVersion}
            </span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('about.buildDate' as TranslationKey)}
            </span>
            <span className="t-small t-semibold" dir="ltr">
              {buildDate}
            </span>
          </div>
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-2">{t('about.developer' as TranslationKey)}</div>
        <div className="t-small t-muted">{t('about.developedBy' as TranslationKey)}</div>
        <div
          className="about__developer-name"
          dir="ltr"
          aria-label={t('about.developerName' as TranslationKey)}
        >
          {t('about.developerName' as TranslationKey)}
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-2">{t('about.contact' as TranslationKey)}</div>
        <div className="t-small t-muted mb-2">{t('about.support' as TranslationKey)}</div>
        <a
          className="btn btn--secondary btn--block"
          href="tel:+989156010120"
          dir="ltr"
          aria-label={`${t('about.support' as TranslationKey)} ${t('about.supportPhone' as TranslationKey)}`}
        >
          <span aria-hidden="true">☎</span>
          <span>{t('about.supportPhone' as TranslationKey)}</span>
        </a>
      </Card>

      <Card>
        <div className="t-h3 mb-2">{t('about.licenses' as TranslationKey)}</div>
        <div className="stack--sm">
          {[
            ['React', 'MIT'],
            ['Vite', 'MIT'],
            ['Capacitor', 'MIT'],
            ['SQLite', 'Public Domain'],
            ['SheetJS', 'Apache 2.0'],
            ['lucide-react', 'ISC'],
            ['motion', 'MIT'],
            ['zustand', 'MIT'],
            ['Vazirmatn', 'OFL'],
          ].map(([name, license]) => (
            <div key={name} className="flex-row justify-between t-caption">
              <span>{name}</span>
              <span className="t-dim">{license}</span>
            </div>
          ))}
        </div>
      </Card>

      <div className="t-caption t-dim t-center" style={{ padding: '16px 0' }}>
        © {new Date().getFullYear()}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S18 — DiagnosticsScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface DiagnosticsScreenProps {
  onBack?: () => void;
}

export function DiagnosticsScreen({ onBack }: DiagnosticsScreenProps) {
  const { t } = useTranslation();
  const [perf, setPerf] = useState<PerfDiagnostics | null>(null);
  const [resetting, setResetting] = useState(false);

  useEffect(() => {
    setPerf(getPerformanceDiagnostics());
  }, []);

  const handleReset = useCallback(async (): Promise<void> => {
    setResetting(true);
    await resetPerformanceProfile();
    setPerf(getPerformanceDiagnostics());
    setResetting(false);
    toast.success(t('toast.settings.saved' as TranslationKey));
  }, [t]);

  const platform = useMemo(() => {
    if (typeof navigator === 'undefined') return 'Unknown';
    const ua = navigator.userAgent;
    if (/Android/i.test(ua)) return 'Android';
    if (/iPhone|iPad/i.test(ua)) return 'iOS';
    if (/Windows/i.test(ua)) return 'Windows';
    if (/Mac/i.test(ua)) return 'macOS';
    if (/Linux/i.test(ua)) return 'Linux';
    return 'Unknown';
  }, []);

  return (
    <div className="page">
      <Header title={t('diagnostics.title' as TranslationKey)} onBack={onBack} />

      <Card>
        <div className="t-h3 mb-3">{t('diagnostics.title' as TranslationKey)}</div>
        <div className="stack--sm">
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.appVersion' as TranslationKey)}
            </span>
            <span className="t-small t-semibold" dir="ltr">
              1.0.0
            </span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.platform' as TranslationKey)}
            </span>
            <span className="t-small t-semibold">{platform}</span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.performanceTier' as TranslationKey)}
            </span>
            <Badge variant="primary" dot>
              {perf?.effectiveTier ?? 'P0'}
            </Badge>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.reducedMotion' as TranslationKey)}
            </span>
            <span className="t-small t-semibold">
              {perf?.prefersReducedMotion ? '✓' : '—'}
            </span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.reducedTransparency' as TranslationKey)}
            </span>
            <span className="t-small t-semibold">
              {perf?.prefersReducedTransparency ? '✓' : '—'}
            </span>
          </div>
        </div>
      </Card>

      <Card>
        <div className="t-h3 mb-3">{t('settings.performance' as TranslationKey)}</div>
        <div className="stack--sm">
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">Global Tier</span>
            <span className="t-small t-semibold">{getGlobalPerformanceTier()}</span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">Effective Tier</span>
            <span className="t-small t-semibold">{getEffectivePerformanceTier()}</span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.observerSupported' as TranslationKey)}
            </span>
            <span className="t-small t-semibold">
              {perf?.observerSupported ? '✓' : '—'}
            </span>
          </div>
          <div className="flex-row justify-between">
            <span className="t-caption t-muted">
              {t('diagnostics.activeSections' as TranslationKey)}
            </span>
            <span className="t-small t-semibold">{perf?.activeSectionCount ?? 0}</span>
          </div>
          <Divider />
          <Button
            variant="secondary"
            block
            loading={resetting}
            onClick={handleReset}
            leadingIcon={<RefreshCw size={16} />}
          >
            {t('diagnostics.resetProfile' as TranslationKey)}
          </Button>
        </div>
      </Card>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S19 — EducationScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface EducationScreenProps {
  onBack?: () => void;
}

export function EducationScreen({ onBack }: EducationScreenProps) {
  const { t } = useTranslation();
  const sections = [
    { icon: <Banknote size={18} />, title: t('education.quickStart.title' as TranslationKey), body: t('education.quickStart.body' as TranslationKey) },
    { icon: <ArrowDownLeft size={18} />, title: t('education.transaction.title' as TranslationKey), body: t('education.transaction.body' as TranslationKey) },
    { icon: <UsersRound size={18} />, title: t('education.parties.title' as TranslationKey), body: t('education.parties.body' as TranslationKey) },
    { icon: <FolderKanban size={18} />, title: t('education.projects.title' as TranslationKey), body: t('education.projects.body' as TranslationKey) },
    { icon: <CircleDollarSign size={18} />, title: t('education.categories.title' as TranslationKey), body: t('education.categories.body' as TranslationKey) },
    { icon: <FileSpreadsheet size={18} />, title: t('education.reports.title' as TranslationKey), body: t('education.reports.body' as TranslationKey) },
    { icon: <Download size={18} />, title: t('education.export.title' as TranslationKey), body: t('education.export.body' as TranslationKey) },
    { icon: <DatabaseBackup size={18} />, title: t('education.backup.title' as TranslationKey), body: t('education.backup.body' as TranslationKey) },
    { icon: <ShieldCheck size={18} />, title: t('education.security.title' as TranslationKey), body: t('education.security.body' as TranslationKey) },
    { icon: <CircleAlert size={18} />, title: t('education.troubleshooting.title' as TranslationKey), body: t('education.troubleshooting.body' as TranslationKey) },
  ];

  return (
    <div className="page">
      <Header title={t('education.title' as TranslationKey)} onBack={onBack} />
      <Card>
        <div className="t-body t-semibold">{t('education.intro.title' as TranslationKey)}</div>
        <div className="t-small t-muted mt-2">{t('education.intro.body' as TranslationKey)}</div>
      </Card>

      <div className="education-grid">
        {sections.map((section) => (
          <Card key={section.title}>
            <div className="education-card__icon" aria-hidden="true">{section.icon}</div>
            <div className="t-h3 mt-3">{section.title}</div>
            <p className="t-small t-muted education-card__body">{section.body}</p>
          </Card>
        ))}
      </div>
    </div>
  );
}

// ═══════════════════════════════════════════════════════════════════════════
// S19 — MoreScreen
// ═══════════════════════════════════════════════════════════════════════════

export interface MoreScreenProps {
  onNavigateParties: () => void;
  onNavigateProjects: () => void;
  onNavigateReports: () => void;
  onNavigateImportExport: () => void;
  onNavigateBackup: () => void;
  onNavigateSettings: () => void;
  onNavigateAbout: () => void;
  onNavigateEducation: () => void;
  onNavigateAudit: () => void;
  onNavigateAlerts: () => void;
}

export function MoreScreen({
  onNavigateParties,
  onNavigateProjects,
  onNavigateReports,
  onNavigateImportExport,
  onNavigateBackup,
  onNavigateSettings,
  onNavigateAbout,
  onNavigateEducation,
  onNavigateAudit,
  onNavigateAlerts,
}: MoreScreenProps) {
  const { t } = useTranslation();
  const alertsCount = useAlertsCount();

  return (
    <div className="page">
      <div className="t-h2">{t('nav.more' as TranslationKey)}</div>

      <div className="list list--bordered">
        <MenuRow
          icon={<UsersRound size={18} />}
          title={t('nav.parties' as TranslationKey)}
          onClick={onNavigateParties}
        />
        <MenuRow
          icon={<FolderKanban size={18} />}
          title={t('nav.projects' as TranslationKey)}
          onClick={onNavigateProjects}
        />
        <MenuRow
          icon={<CircleDollarSign size={18} />}
          title={t('nav.reports' as TranslationKey)}
          onClick={onNavigateReports}
        />
        <MenuRow
          icon={<Bell size={18} />}
          title={t('nav.alerts' as TranslationKey)}
          onClick={onNavigateAlerts}
          trailing={
            alertsCount > 0 ? (
              <Badge variant="danger" dot>
                {alertsCount}
              </Badge>
            ) : (
              <ChevronLeft className="menu-row__chevron" aria-hidden="true" />
            )
          }
        />
        <MenuRow
          icon={<FileSpreadsheet size={18} />}
          title={t('nav.importExport' as TranslationKey)}
          onClick={onNavigateImportExport}
        />
        <MenuRow
          icon={<DatabaseBackup size={18} />}
          title={t('nav.backup' as TranslationKey)}
          onClick={onNavigateBackup}
        />
        <MenuRow
          icon={<History size={18} />}
          title={t('nav.audit' as TranslationKey)}
          onClick={onNavigateAudit}
        />
        <MenuRow
          icon={<Settings size={18} />}
          title={t('nav.settings' as TranslationKey)}
          onClick={onNavigateSettings}
        />
        <MenuRow
          icon={<BookOpen size={18} />}
          title={t('nav.education' as TranslationKey)}
          onClick={onNavigateEducation}
        />
        <MenuRow
          icon={<Info size={18} />}
          title={t('nav.about' as TranslationKey)}
          onClick={onNavigateAbout}
        />
      </div>
    </div>
  );
}
