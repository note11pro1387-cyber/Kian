// ============================================================================
//  src/validation.ts
//  تمام Zod Schemaهای اعتبارسنجی
// ============================================================================
//
//  تغییرات SPEC v2.0:
//   - PIN_MAX_LENGTH از ۸ به ۶
//   - پیام‌های خطا با key جدید `validation.pin.length`
//   - Schemaهای `accountUpdateSchema`، `partyUpdateSchema`،
//     `projectUpdateSchema` با فیلد `status` تطبیق داده شدند
// ============================================================================

import { z } from 'zod';
import {
  TransactionType,
  TransactionStatus,
  AccountType,
  AccountStatus,
  PartyType,
  PartyRole,
  PartyStatus,
  ProjectStatus,
  CategoryType,
  CategoryStatus,
} from './types';
import type {
  Transaction,
  Account,
  Party,
  Project,
  Category,
  BackupHeader,
} from './types';
import { parseMoney, parseDate } from './formatters';

// ═══════════════════════════════════════════════════════════════════════════
// Constants — طبق SPEC v2.0
// ═══════════════════════════════════════════════════════════════════════════

export const MAX_AMOUNT = 999_999_999_999_999n;

export const PIN_MIN_LENGTH = 4;
export const PIN_MAX_LENGTH = 6;

export const PATTERN_MIN_POINTS = 4;

// ═══════════════════════════════════════════════════════════════════════════
// Enum tuples
// ═══════════════════════════════════════════════════════════════════════════

const transactionTypeValues = [
  TransactionType.DEPOSIT,
  TransactionType.EXPENSE,
] as const;

const transactionStatusValues = [
  TransactionStatus.ACTIVE,
  TransactionStatus.DELETED,
] as const;

const accountTypeValues = [
  AccountType.BANK,
  AccountType.CASH,
  AccountType.CARD,
  AccountType.TREASURY,
] as const;

const accountStatusValues = [
  AccountStatus.ACTIVE,
  AccountStatus.ARCHIVED,
] as const;

const partyTypeValues = [PartyType.PERSON, PartyType.COMPANY] as const;

const partyRoleValues = [
  PartyRole.CONTRACTOR,
  PartyRole.EMPLOYEE,
  PartyRole.CUSTOMER,
  PartyRole.SUPPLIER,
  PartyRole.OTHER,
] as const;

const partyStatusValues = [
  PartyStatus.ACTIVE,
  PartyStatus.ARCHIVED,
] as const;

const projectStatusValues = [
  ProjectStatus.ACTIVE,
  ProjectStatus.DONE,
  ProjectStatus.PAUSED,
  ProjectStatus.ARCHIVED,
] as const;

const categoryTypeValues = [
  CategoryType.EXPENSE,
  CategoryType.INCOME,
  CategoryType.BOTH,
] as const;

const categoryStatusValues = [
  CategoryStatus.ACTIVE,
  CategoryStatus.ARCHIVED,
] as const;

// ═══════════════════════════════════════════════════════════════════════════
// Primitives
// ═══════════════════════════════════════════════════════════════════════════

const nonEmptyString = (max: number, message: string) =>
  z.string().trim().min(1, message).max(max, message);

const optionalString = (max: number, message: string) =>
  z
    .string()
    .max(max, message)
    .nullable()
    .transform((v) => (v && v.trim().length > 0 ? v.trim() : null));

const nullableId = z.string().min(1).nullable();

const clockTimeSchema = z
  .string()
  .regex(/^([01][0-9]|2[0-3]):[0-5][0-9]$/, 'ساعت نامعتبر است')
  .nullable();

// ═══════════════════════════════════════════════════════════════════════════
// Money
// ═══════════════════════════════════════════════════════════════════════════

const moneyBaseSchema = z
  .union([z.bigint(), z.string(), z.number()])
  .transform((value, ctx) => {
    if (typeof value === 'bigint') return value;

    if (typeof value === 'number') {
      if (!Number.isSafeInteger(value)) {
        ctx.addIssue({
          code: 'custom',
          message: 'مبلغ نامعتبر است',
        });
        return z.NEVER;
      }
      return BigInt(value);
    }

    const parsed = parseMoney(value);
    if (parsed === null) {
      ctx.addIssue({
        code: 'custom',
        message: 'مبلغ نامعتبر است',
      });
      return z.NEVER;
    }
    return parsed;
  });

const positiveMoneySchema = moneyBaseSchema
  .refine((v) => v > 0n, { message: 'مبلغ باید بیشتر از صفر باشد' })
  .refine((v) => v <= MAX_AMOUNT, { message: 'مبلغ از حد مجاز بیشتر است' });

const nonNegativeMoneySchema = moneyBaseSchema
  .refine((v) => v >= 0n, { message: 'مبلغ نمی‌تواند منفی باشد' })
  .refine((v) => v <= MAX_AMOUNT, { message: 'مبلغ از حد مجاز بیشتر است' });

const optionalMoneySchema = moneyBaseSchema
  .refine((v) => v >= 0n, { message: 'مبلغ نمی‌تواند منفی باشد' })
  .refine((v) => v <= MAX_AMOUNT, { message: 'مبلغ از حد مجاز بیشتر است' })
  .nullable();

// ═══════════════════════════════════════════════════════════════════════════
// Date
// ═══════════════════════════════════════════════════════════════════════════

const dateSchema = z
  .string()
  .trim()
  .min(1, 'تاریخ الزامی است')
  .transform((value, ctx) => {
    const parsed = parseDate(value);
    if (!parsed) {
      ctx.addIssue({
        code: 'custom',
        message: 'تاریخ نامعتبر است',
      });
      return z.NEVER;
    }
    return parsed;
  });

const optionalDateSchema = z
  .string()
  .nullable()
  .transform((value, ctx) => {
    if (value === null || value.trim() === '') return null;
    const parsed = parseDate(value);
    if (!parsed) {
      ctx.addIssue({
        code: 'custom',
        message: 'تاریخ نامعتبر است',
      });
      return z.NEVER;
    }
    return parsed;
  });

const timestampSchema = z.string().min(1);

// ═══════════════════════════════════════════════════════════════════════════
// Transaction
// ═══════════════════════════════════════════════════════════════════════════

export const transactionCreateSchema = z
  .object({
    type: z.enum(transactionTypeValues, {
      message: 'نوع تراکنش نامعتبر است',
    }),
    amount: positiveMoneySchema,
    accountId: nonEmptyString(64, 'حساب را انتخاب کنید'),
    partyId: nullableId,
    categoryId: nullableId,
    customCategoryText: optionalString(80, 'متن بابت طولانی است'),
    projectId: nullableId,
    transactionDate: dateSchema,
    transactionTime: clockTimeSchema,
    referenceCode: optionalString(50, 'کد پیگیری طولانی است'),
    description: optionalString(500, 'توضیحات طولانی است'),
    createdBy: optionalString(80, 'نام ثبت‌کننده طولانی است'),
  })
  .superRefine((value, ctx) => {
    if (value.type === TransactionType.EXPENSE && !value.partyId) {
      ctx.addIssue({
        code: 'custom',
        path: ['partyId'],
        message: 'برای ثبت خرج، انتخاب طرف حساب الزامی است',
      });
    }
  });

export const transactionUpdateSchema = z
  .object({
    amount: positiveMoneySchema.optional(),
    accountId: nonEmptyString(64, 'حساب را انتخاب کنید').optional(),
    partyId: nullableId.optional(),
    categoryId: nullableId.optional(),
    customCategoryText: optionalString(80, 'متن بابت طولانی است').optional(),
    projectId: nullableId.optional(),
    transactionDate: dateSchema.optional(),
    transactionTime: clockTimeSchema.optional(),
    referenceCode: optionalString(50, 'کد پیگیری طولانی است').optional(),
    description: optionalString(500, 'توضیحات طولانی است').optional(),
    updatedBy: optionalString(80, 'نام ویرایش‌کننده طولانی است').optional(),
  })
  .superRefine((value, ctx) => {
    if (value.amount !== undefined && value.amount <= 0n) {
      ctx.addIssue({
        code: 'custom',
        path: ['amount'],
        message: 'مبلغ باید بیشتر از صفر باشد',
      });
    }
  });

// ═══════════════════════════════════════════════════════════════════════════
// Account
// ═══════════════════════════════════════════════════════════════════════════

const cardNumberSchema = z
  .string()
  .regex(/^\d{16}$/, 'شماره کارت باید ۱۶ رقم باشد')
  .nullable();

export const accountCreateSchema = z.object({
  name: nonEmptyString(100, 'نام حساب الزامی است'),
  type: z.enum(accountTypeValues, {
    message: 'نوع حساب نامعتبر است',
  }),
  bankName: optionalString(80, 'نام بانک طولانی است'),
  accountNumber: optionalString(30, 'شماره حساب طولانی است'),
  cardNumber: cardNumberSchema,
  description: optionalString(300, 'توضیحات طولانی است'),
  openingBalance: nonNegativeMoneySchema,
  openingBalanceDate: optionalDateSchema,
  sortOrder: z.number().int().min(0).default(0),
});

export const accountUpdateSchema = z.object({
  name: nonEmptyString(100, 'نام حساب الزامی است').optional(),
  bankName: optionalString(80, 'نام بانک طولانی است').optional(),
  accountNumber: optionalString(30, 'شماره حساب طولانی است').optional(),
  cardNumber: cardNumberSchema.optional(),
  description: optionalString(300, 'توضیحات طولانی است').optional(),
  openingBalance: nonNegativeMoneySchema.optional(),
  openingBalanceDate: optionalDateSchema.optional(),
  status: z.enum(accountStatusValues).optional(),
  sortOrder: z.number().int().min(0).optional(),
});

// ═══════════════════════════════════════════════════════════════════════════
// Party
// ═══════════════════════════════════════════════════════════════════════════

const phoneSchema = z
  .string()
  .regex(/^[+]?[\d\s\-()]{7,20}$/, 'شماره تماس نامعتبر است')
  .nullable();

export const partyCreateSchema = z.object({
  name: nonEmptyString(100, 'نام طرف حساب الزامی است'),
  type: z.enum(partyTypeValues, {
    message: 'نوع طرف حساب نامعتبر است',
  }),
  phone: phoneSchema,
  cardNumber: cardNumberSchema,
  accountNumber: optionalString(30, 'شماره حساب طولانی است'),
  role: z.enum(partyRoleValues).nullable(),
  notes: optionalString(500, 'یادداشت طولانی است'),
});

export const partyUpdateSchema = z.object({
  name: nonEmptyString(100, 'نام طرف حساب الزامی است').optional(),
  type: z.enum(partyTypeValues).optional(),
  phone: phoneSchema.optional(),
  cardNumber: cardNumberSchema.optional(),
  accountNumber: optionalString(30, 'شماره حساب طولانی است').optional(),
  role: z.enum(partyRoleValues).nullable().optional(),
  notes: optionalString(500, 'یادداشت طولانی است').optional(),
  status: z.enum(partyStatusValues).optional(),
});

// ═══════════════════════════════════════════════════════════════════════════
// Project
// ═══════════════════════════════════════════════════════════════════════════

export const projectCreateSchema = z.object({
  name: nonEmptyString(100, 'نام پروژه الزامی است'),
  code: optionalString(40, 'کد پروژه طولانی است'),
  status: z.enum(projectStatusValues, {
    message: 'وضعیت پروژه نامعتبر است',
  }),
  budgetAmount: optionalMoneySchema,
  description: optionalString(500, 'توضیحات طولانی است'),
});

export const projectUpdateSchema = z.object({
  name: nonEmptyString(100, 'نام پروژه الزامی است').optional(),
  code: optionalString(40, 'کد پروژه طولانی است').optional(),
  status: z.enum(projectStatusValues).optional(),
  budgetAmount: optionalMoneySchema.optional(),
  description: optionalString(500, 'توضیحات طولانی است').optional(),
});

// ═══════════════════════════════════════════════════════════════════════════
// Category
// ═══════════════════════════════════════════════════════════════════════════

export const categoryCreateSchema = z.object({
  parentId: nullableId,
  name: nonEmptyString(80, 'نام بابت الزامی است'),
  type: z.enum(categoryTypeValues, {
    message: 'نوع بابت نامعتبر است',
  }),
  sortOrder: z.number().int().min(0).default(0),
});

export const categoryUpdateSchema = z.object({
  name: nonEmptyString(80, 'نام بابت الزامی است').optional(),
  sortOrder: z.number().int().min(0).optional(),
  status: z.enum(categoryStatusValues).optional(),
});

// ═══════════════════════════════════════════════════════════════════════════
// Filter
// ═══════════════════════════════════════════════════════════════════════════

export const transactionFilterSchema = z.object({
  types: z.array(z.enum(transactionTypeValues)).default([]),
  accountIds: z.array(z.string().min(1)).default([]),
  partyIds: z.array(z.string().min(1)).default([]),
  projectIds: z.array(z.string().min(1)).default([]),
  categoryIds: z.array(z.string().min(1)).default([]),
  statuses: z.array(z.enum(transactionStatusValues)).default([]),
  dateFrom: optionalDateSchema,
  dateTo: optionalDateSchema,
  amountMin: optionalMoneySchema,
  amountMax: optionalMoneySchema,
  searchQuery: z.string().default(''),
});

export const reportFilterSchema = z.object({
  start: dateSchema,
  end: dateSchema,
  accountIds: z.array(z.string().min(1)).default([]),
  partyIds: z.array(z.string().min(1)).default([]),
  projectIds: z.array(z.string().min(1)).default([]),
  categoryIds: z.array(z.string().min(1)).default([]),
  types: z.array(z.enum(transactionTypeValues)).default([]),
});

// ═══════════════════════════════════════════════════════════════════════════
// Import / Export
// ═══════════════════════════════════════════════════════════════════════════

export const importMappingSchema = z.record(z.string(), z.string());

export const importCommitSchema = z.object({
  jobId: z.string().min(1),
  columnMap: z.record(z.string(), z.string()),
});

// ═══════════════════════════════════════════════════════════════════════════
// Backup
// ═══════════════════════════════════════════════════════════════════════════

export const backupHeaderSchema = z.object({
  magic: z.literal('FINSECURE1'),
  formatVersion: z.number().int().positive(),
  schemaVersion: z.number().int().positive(),
  appVersion: z.string().min(1),
  createdAt: timestampSchema,
  workspaceId: z.string().min(1),
  pbkdf2Salt: z.string().min(1),
  aesIv: z.string().min(1),
  checksum: z.string().min(1),
});

export const backupRestoreSchema = z.object({
  passphrase: z
    .string()
    .min(8, 'عبارت عبور باید حداقل ۸ کاراکتر باشد')
    .max(200, 'عبارت عبور طولانی است'),
  mode: z.enum(['merge', 'replace'] as const, {
    message: 'حالت بازیابی نامعتبر است',
  }),
});

export const backupCreateSchema = z.object({
  passphrase: z
    .string()
    .min(8, 'عبارت عبور باید حداقل ۸ کاراکتر باشد')
    .max(200, 'عبارت عبور طولانی است'),
});

// ═══════════════════════════════════════════════════════════════════════════
// Security
// ═══════════════════════════════════════════════════════════════════════════

/**
 * PIN — طبق SPEC v2.0 §۹.۲: 4 تا 6 رقم.
 */
export const pinSchema = z
  .string()
  .regex(
    new RegExp(`^\\d{${PIN_MIN_LENGTH},${PIN_MAX_LENGTH}}$`),
    `پین باید بین ${PIN_MIN_LENGTH} تا ${PIN_MAX_LENGTH} رقم باشد`
  );

export const patternSchema = z
  .string()
  .regex(/^\d+(-\d+){3,}$/, 'الگو باید حداقل ۴ نقطه داشته باشد');

export const securitySetupSchema = z
  .object({
    pin: pinSchema.nullable(),
    pattern: patternSchema.nullable(),
    biometricEnabled: z.boolean().default(false),
  })
  .superRefine((value, ctx) => {
    if (!value.pin && !value.pattern) {
      ctx.addIssue({
        code: 'custom',
        path: ['pin'],
        message: 'حداقل یکی از پین یا الگو باید تعیین شود',
      });
    }
    if (value.pin && value.pattern) {
      ctx.addIssue({
        code: 'custom',
        path: ['pin'],
        message: 'فقط یکی از پین یا الگو باید تعیین شود',
      });
    }
  });

export const recoveryCodeSchema = z
  .string()
  .regex(/^\d{4}$/, 'کد بازیابی باید ۴ رقم باشد');

export const lockTimeoutSchema = z.number().int().min(0).max(3600);

// ═══════════════════════════════════════════════════════════════════════════
// Settings
// ═══════════════════════════════════════════════════════════════════════════

export const appSettingsSchema = z.object({
  theme: z.enum(['dark', 'light'] as const),
  language: z.enum(['fa', 'en'] as const),
  companyName: z.string().max(120, 'نام شرکت طولانی است').nullable(),
  lastBackupAt: timestampSchema.nullable(),
  performanceTier: z.enum(['P0', 'P1', 'P2', 'P3', 'P4'] as const).nullable(),
  onboardingDone: z.boolean(),
  securityPromptCount: z.number().int().min(0).max(10),
  devicePrefix: z
    .string()
    .regex(/^[A-Z0-9]{3}$/, 'پیشوند دستگاه نامعتبر است')
    .nullable(),
  privacyHideAmounts: z.boolean(),
  assetCacheVersion: z.string().min(1),
});

// ═══════════════════════════════════════════════════════════════════════════
// Type inference helpers
// ═══════════════════════════════════════════════════════════════════════════

export type TransactionCreateFormValues = z.input<typeof transactionCreateSchema>;
export type TransactionCreateData = z.output<typeof transactionCreateSchema>;

export type TransactionUpdateFormValues = z.input<typeof transactionUpdateSchema>;
export type TransactionUpdateData = z.output<typeof transactionUpdateSchema>;

export type AccountCreateFormValues = z.input<typeof accountCreateSchema>;
export type AccountCreateData = z.output<typeof accountCreateSchema>;

export type AccountUpdateData = z.output<typeof accountUpdateSchema>;

export type PartyCreateFormValues = z.input<typeof partyCreateSchema>;
export type PartyCreateData = z.output<typeof partyCreateSchema>;

export type PartyUpdateData = z.output<typeof partyUpdateSchema>;

export type ProjectCreateFormValues = z.input<typeof projectCreateSchema>;
export type ProjectCreateData = z.output<typeof projectCreateSchema>;

export type ProjectUpdateData = z.output<typeof projectUpdateSchema>;

export type CategoryCreateData = z.output<typeof categoryCreateSchema>;
export type CategoryUpdateData = z.output<typeof categoryUpdateSchema>;

export type SecuritySetupData = z.output<typeof securitySetupSchema>;

export type BackupRestoreData = z.output<typeof backupRestoreSchema>;

export type ImportCommitData = z.output<typeof importCommitSchema>;

// ═══════════════════════════════════════════════════════════════════════════
// Guarded parsing helpers
// ═══════════════════════════════════════════════════════════════════════════

export interface ParsedOk<T> {
  ok: true;
  data: T;
}

export interface ParsedErr {
  ok: false;
  fieldErrors: Record<string, string>;
  formError: string | null;
}

export type ParsedResult<T> = ParsedOk<T> | ParsedErr;

/**
 * تجزیه‌ی یک ورودی با یک Zod Schema و تبدیل به ساختار قابل‌استفاده در فرم.
 * - اگر موفق: { ok: true, data }
 * - اگر ناموفق: { ok: false, fieldErrors, formError }
 */
export function parseWithSchema<T extends z.ZodTypeAny>(
  schema: T,
  input: unknown
): ParsedResult<z.output<T>> {
  const result = schema.safeParse(input);

  if (result.success) {
    return { ok: true, data: result.data };
  }

  const fieldErrors: Record<string, string> = {};
  let formError: string | null = null;

  for (const issue of result.error.issues) {
    const path = issue.path.join('.');
    if (path === '') {
      formError = issue.message;
    } else if (!fieldErrors[path]) {
      fieldErrors[path] = issue.message;
    }
  }

  return { ok: false, fieldErrors, formError };
}

// ═══════════════════════════════════════════════════════════════════════════
// Entity validators (post-load)
// ═══════════════════════════════════════════════════════════════════════════

export function validateTransactionEntity(
  entity: Transaction
): ParsedResult<Transaction> {
  if (entity.amount <= 0n) {
    return {
      ok: false,
      fieldErrors: { amount: 'مبلغ باید بیشتر از صفر باشد' },
      formError: null,
    };
  }

  if (entity.amount > MAX_AMOUNT) {
    return {
      ok: false,
      fieldErrors: { amount: 'مبلغ از حد مجاز بیشتر است' },
      formError: null,
    };
  }

  if (
    entity.type === TransactionType.EXPENSE &&
    entity.partyId === null
  ) {
    return {
      ok: false,
      fieldErrors: { partyId: 'طرف حساب خرج الزامی است' },
      formError: null,
    };
  }

  return { ok: true, data: entity };
}

export function validateAccountEntity(entity: Account): ParsedResult<Account> {
  if (entity.openingBalance < 0n) {
    return {
      ok: false,
      fieldErrors: { openingBalance: 'موجودی اولیه نمی‌تواند منفی باشد' },
      formError: null,
    };
  }
  if (entity.openingBalance > MAX_AMOUNT) {
    return {
      ok: false,
      fieldErrors: { openingBalance: 'موجودی اولیه از حد مجاز بیشتر است' },
      formError: null,
    };
  }
  return { ok: true, data: entity };
}

export function validatePartyEntity(entity: Party): ParsedResult<Party> {
  if (!entity.name.trim()) {
    return {
      ok: false,
      fieldErrors: { name: 'نام طرف حساب الزامی است' },
      formError: null,
    };
  }
  return { ok: true, data: entity };
}

export function validateProjectEntity(entity: Project): ParsedResult<Project> {
  if (!entity.name.trim()) {
    return {
      ok: false,
      fieldErrors: { name: 'نام پروژه الزامی است' },
      formError: null,
    };
  }
  if (entity.budgetAmount !== null && entity.budgetAmount < 0n) {
    return {
      ok: false,
      fieldErrors: { budgetAmount: 'بودجه نمی‌تواند منفی باشد' },
      formError: null,
    };
  }
  if (entity.budgetAmount !== null && entity.budgetAmount > MAX_AMOUNT) {
    return {
      ok: false,
      fieldErrors: { budgetAmount: 'بودجه از حد مجاز بیشتر است' },
      formError: null,
    };
  }
  return { ok: true, data: entity };
}

export function validateCategoryEntity(entity: Category): ParsedResult<Category> {
  if (!entity.name.trim()) {
    return {
      ok: false,
      fieldErrors: { name: 'نام بابت الزامی است' },
      formError: null,
    };
  }
  return { ok: true, data: entity };
}

export function validateBackupHeader(
  input: unknown
): ParsedResult<BackupHeader> {
  return parseWithSchema(backupHeaderSchema, input);
}

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════