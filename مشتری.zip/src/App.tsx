// src/App.tsx

import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
  type ReactNode,
} from 'react';

import {
  HashRouter,
  Navigate,
  Route,
  Routes,
  useLocation,
  useNavigate,
  useParams,
} from 'react-router';

import type { AccountId, PartyId, ProjectId, Transaction, TransactionId } from './types';

import { TransactionType } from './types';

import { initI18n, changeLanguage } from './i18n';

import {
  useAppStore,
  useFilterStore,
  useSecurityStore,
  useUIStore,
  UI_SHEET,
  runBootSequence,
  shutdownStore,
} from './store';

import { unlockApp } from './security';

import { startPerformanceEngine, stopPerformanceEngine } from './performance';

import {
  BottomNav,
  FAB,
  PrivacyOverlay,
  Sidebar,
  ToastContainer,
  type BottomNavKey,
  type SidebarKey,
} from './ui/components';

import {
  AboutScreen,
  AccountDetailScreen,
  AccountsListScreen,
  AlertsScreen,
  AuditHistoryScreen,
  BackupScreen,
  DashboardScreen,
  DiagnosticsScreen,
  EducationScreen,
  ImportExportScreen,
  MoreScreen,
  OnboardingScreen,
  PartiesListScreen,
  PartyDetailScreen,
  ProjectsListScreen,
  ReportsScreen,
  SettingsScreen,
  SplashScreen,
  TransactionDetailScreen,
  TransactionsListScreen,
} from './ui/screens';

import { AddTransactionSheet, LockScreenOverlay, SheetsHost } from './ui/sheets';

// ─── Edit Transaction Context ──────────────────────────────────────────

interface EditTransactionContextValue {
  openEdit: (tx: Transaction) => void;
}

const EditTransactionContext = createContext<EditTransactionContextValue>({
  openEdit: () => undefined,
});

function useEditTransaction(): EditTransactionContextValue {
  return useContext(EditTransactionContext);
}

// ─── PWA shortcut ──────────────────────────────────────────────────────

type ShortcutAction = 'deposit' | 'expense';

function readShortcutAction(): ShortcutAction | null {
  if (typeof window === 'undefined') return null;

  const searchParams = new URLSearchParams(window.location.search);
  const searchAction = searchParams.get('action');
  if (searchAction === 'deposit' || searchAction === 'expense') {
    return searchAction;
  }

  const hash = window.location.hash;
  const hashQueryIndex = hash.indexOf('?');
  if (hashQueryIndex >= 0) {
    const hashParams = new URLSearchParams(hash.slice(hashQueryIndex + 1));
    const hashAction = hashParams.get('action');
    if (hashAction === 'deposit' || hashAction === 'expense') {
      return hashAction;
    }
  }

  return null;
}

// ─── Route ↔ Nav helpers ───────────────────────────────────────────────

function routeToBottomKey(pathname: string): BottomNavKey {
  if (pathname === '/' || pathname.startsWith('/dashboard')) return 'home';
  if (pathname.startsWith('/transactions')) return 'transactions';
  if (pathname.startsWith('/accounts')) return 'accounts';
  return 'more';
}

function routeToSidebarKey(pathname: string): SidebarKey {
  if (pathname === '/' || pathname.startsWith('/dashboard')) return 'dashboard';
  if (pathname.startsWith('/transactions')) return 'transactions';
  if (pathname.startsWith('/accounts')) return 'accounts';
  if (pathname.startsWith('/parties')) return 'parties';
  if (pathname.startsWith('/projects')) return 'projects';
  if (pathname.startsWith('/reports')) return 'reports';
  if (pathname.startsWith('/import-export')) return 'importExport';
  if (pathname.startsWith('/backup')) return 'backup';
  if (pathname.startsWith('/settings')) return 'settings';
  if (pathname.startsWith('/about')) return 'about';
  return 'dashboard';
}

// ─── Route components ──────────────────────────────────────────────────

function DashboardRoute() {
  const navigate = useNavigate();
  return (
    <DashboardScreen
      onNavigateTransactions={() => navigate('/transactions')}
      onNavigateAccounts={() => navigate('/accounts')}
      onNavigateAlerts={() => navigate('/alerts')}
      onNavigateSettings={() => navigate('/settings')}
      onOpenTransaction={(id) => navigate(`/transactions/${id}`)}
    />
  );
}

function TransactionsListRoute() {
  const navigate = useNavigate();
  const filter = useFilterStore((s) => s.transactionsFilter);
  return (
    <TransactionsListScreen
      filter={filter}
      onOpenTransaction={(id) => navigate(`/transactions/${id}`)}
    />
  );
}

function TransactionDetailRoute() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { openEdit } = useEditTransaction();

  if (!id) return <Navigate to="/transactions" replace />;

  return (
    <TransactionDetailScreen
      transactionId={id as TransactionId}
      onBack={() => navigate(-1)}
      onEdit={openEdit}
    />
  );
}

function AccountsListRoute() {
  const navigate = useNavigate();
  return <AccountsListScreen onOpenAccount={(id) => navigate(`/accounts/${id}`)} />;
}

function AccountDetailRoute() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  if (!id) return <Navigate to="/accounts" replace />;

  return (
    <AccountDetailScreen
      accountId={id as AccountId}
      onBack={() => navigate(-1)}
      onOpenTransaction={(txId) => navigate(`/transactions/${txId}`)}
    />
  );
}

function PartiesListRoute() {
  const navigate = useNavigate();
  return <PartiesListScreen onOpenParty={(id) => navigate(`/parties/${id}`)} />;
}

function PartyDetailRoute() {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();

  if (!id) return <Navigate to="/parties" replace />;

  return (
    <PartyDetailScreen
      partyId={id as PartyId}
      onBack={() => navigate(-1)}
      onOpenTransaction={(txId) => navigate(`/transactions/${txId}`)}
    />
  );
}

function ProjectsListRoute() {
  const navigate = useNavigate();
  return (
    <ProjectsListScreen
      onOpenProject={(id: ProjectId) => navigate(`/reports?project=${id}`)}
    />
  );
}

function ReportsRoute() {
  const navigate = useNavigate();
  return <ReportsScreen onOpenTransaction={(id) => navigate(`/transactions/${id}`)} />;
}

function SettingsRoute() {
  const navigate = useNavigate();
  return (
    <SettingsScreen
      onNavigateAbout={() => navigate('/about')}
      onNavigateDiagnostics={() => navigate('/diagnostics')}
      onNavigateBackup={() => navigate('/backup')}
      onNavigateImportExport={() => navigate('/import-export')}
      onNavigateAudit={() => navigate('/audit')}
    />
  );
}

function AboutRoute() {
  const navigate = useNavigate();
  return <AboutScreen onBack={() => navigate(-1)} />;
}

function DiagnosticsRoute() {
  const navigate = useNavigate();
  return <DiagnosticsScreen onBack={() => navigate(-1)} />;
}

function EducationRoute() {
  const navigate = useNavigate();
  return <EducationScreen onBack={() => navigate(-1)} />;
}

function AlertsRoute() {
  const navigate = useNavigate();
  return <AlertsScreen onBack={() => navigate(-1)} />;
}

function AuditRoute() {
  const navigate = useNavigate();
  return <AuditHistoryScreen onBack={() => navigate(-1)} />;
}

function MoreRoute() {
  const navigate = useNavigate();
  return (
    <MoreScreen
      onNavigateParties={() => navigate('/parties')}
      onNavigateProjects={() => navigate('/projects')}
      onNavigateReports={() => navigate('/reports')}
      onNavigateImportExport={() => navigate('/import-export')}
      onNavigateBackup={() => navigate('/backup')}
      onNavigateSettings={() => navigate('/settings')}
      onNavigateAbout={() => navigate('/about')}
      onNavigateEducation={() => navigate('/education')}
      onNavigateAudit={() => navigate('/audit')}
      onNavigateAlerts={() => navigate('/alerts')}
    />
  );
}

function NotFoundRoute() {
  return <Navigate to="/" replace />;
}

// ─── AppLayout ─────────────────────────────────────────────────────────

interface AppLayoutProps {
  shortcutType: TransactionType | null;
  onCloseShortcut: () => void;
}

function AppLayout({ shortcutType, onCloseShortcut }: AppLayoutProps) {
  const location = useLocation();
  const navigate = useNavigate();
  const openSheet = useUIStore((s) => s.openSheet);

  const [editTransaction, setEditTransaction] = useState<Transaction | null>(null);

  const editCtxValue = useMemo<EditTransactionContextValue>(
    () => ({
      openEdit: (tx: Transaction) => setEditTransaction(tx),
    }),
    []
  );

  const bottomKey = useMemo(
    () => routeToBottomKey(location.pathname),
    [location.pathname]
  );
  const sidebarKey = useMemo(
    () => routeToSidebarKey(location.pathname),
    [location.pathname]
  );

  const handleBottomNavigate = useCallback(
    (key: BottomNavKey) => {
      switch (key) {
        case 'home':
          navigate('/');
          break;
        case 'transactions':
          navigate('/transactions');
          break;
        case 'accounts':
          navigate('/accounts');
          break;
        case 'more':
          navigate('/more');
          break;
      }
    },
    [navigate]
  );

  const handleSidebarNavigate = useCallback(
    (key: SidebarKey) => {
      switch (key) {
        case 'dashboard':
          navigate('/');
          break;
        case 'transactions':
          navigate('/transactions');
          break;
        case 'accounts':
          navigate('/accounts');
          break;
        case 'parties':
          navigate('/parties');
          break;
        case 'projects':
          navigate('/projects');
          break;
        case 'reports':
          navigate('/reports');
          break;
        case 'importExport':
          navigate('/import-export');
          break;
        case 'backup':
          navigate('/backup');
          break;
        case 'settings':
          navigate('/settings');
          break;
        case 'about':
          navigate('/about');
          break;
      }
    },
    [navigate]
  );

  const handleFabClick = useCallback(() => {
    openSheet(UI_SHEET.ADD_TRANSACTION);
  }, [openSheet]);

  return (
    <EditTransactionContext.Provider value={editCtxValue}>
      <div className="desktop-layout">
        <Sidebar active={sidebarKey} onNavigate={handleSidebarNavigate} />

        <div className="desktop-layout__main">
          <main className="app-shell__main">
            <Routes>
              <Route path="/" element={<DashboardRoute />} />
              <Route path="/dashboard" element={<DashboardRoute />} />
              <Route path="/transactions" element={<TransactionsListRoute />} />
              <Route path="/transactions/:id" element={<TransactionDetailRoute />} />
              <Route path="/accounts" element={<AccountsListRoute />} />
              <Route path="/accounts/:id" element={<AccountDetailRoute />} />
              <Route path="/parties" element={<PartiesListRoute />} />
              <Route path="/parties/:id" element={<PartyDetailRoute />} />
              <Route path="/projects" element={<ProjectsListRoute />} />
              <Route path="/reports" element={<ReportsRoute />} />
              <Route path="/import-export" element={<ImportExportScreen />} />
              <Route path="/backup" element={<BackupScreen />} />
              <Route path="/settings" element={<SettingsRoute />} />
              <Route path="/about" element={<AboutRoute />} />
              <Route path="/diagnostics" element={<DiagnosticsRoute />} />
              <Route path="/education" element={<EducationRoute />} />
              <Route path="/alerts" element={<AlertsRoute />} />
              <Route path="/audit" element={<AuditRoute />} />
              <Route path="/more" element={<MoreRoute />} />
              <Route path="*" element={<NotFoundRoute />} />
            </Routes>
          </main>

          <BottomNav active={bottomKey} onNavigate={handleBottomNavigate} />
        </div>

        <FAB onClick={handleFabClick} />
      </div>

      {editTransaction ? (
        <AddTransactionSheet
          open
          onClose={() => setEditTransaction(null)}
          editTransaction={editTransaction}
        />
      ) : null}

      {shortcutType ? (
        <AddTransactionSheet open onClose={onCloseShortcut} initialType={shortcutType} />
      ) : null}
    </EditTransactionContext.Provider>
  );
}

// ─── Gates ─────────────────────────────────────────────────────────────

function BootErrorScreen({ message }: { message: string }): ReactNode {
  return (
    <>
      <div className="app-shell">
        <div className="app-shell__main flex flex-col justify-center items-center">
          <div className="error-state">
            <div className="error-state__icon" aria-hidden="true">
              <svg
                viewBox="0 0 24 24"
                width="64"
                height="64"
                fill="none"
                stroke="currentColor"
                strokeWidth="1.5"
              >
                <circle cx="12" cy="12" r="10" />
                <line x1="12" y1="8" x2="12" y2="12" />
                <line x1="12" y1="16" x2="12.01" y2="16" />
              </svg>
            </div>
            <div className="error-state__title">خطا در راه‌اندازی</div>
            <div className="error-state__message">{message}</div>
            <div className="error-state__actions">
              <button
                type="button"
                className="btn btn--secondary"
                onClick={() => window.location.reload()}
              >
                تلاش دوباره
              </button>
            </div>
          </div>
        </div>
      </div>
      <ToastContainer />
    </>
  );
}

// ─── Root App ──────────────────────────────────────────────────────────

export function App() {
  const language = useAppStore((s) => s.language);
  const hydrated = useAppStore((s) => s.hydrated);
  const onboardingDone = useAppStore((s) => s.onboardingDone);
  const setOnboardingDone = useAppStore((s) => s.setOnboardingDone);

  const securityConfigured = useSecurityStore((s) => s.configured);
  const unlocked = useSecurityStore((s) => s.unlocked);
  const privacyOverlayActive = useSecurityStore((s) => s.privacyOverlayActive);
  const requiresRecoveryReset = useSecurityStore((s) => s.requiresRecoveryReset);

  const [bootError, setBootError] = useState<string | null>(null);
  const [shortcutType, setShortcutType] = useState<TransactionType | null>(null);

  useEffect(() => {
    let cancelled = false;

    void (async () => {
      try {
        initI18n(language);

        await runBootSequence();

        if (cancelled) return;

        await startPerformanceEngine();

        const action = readShortcutAction();
        if (action === TransactionType.DEPOSIT) {
          setShortcutType(TransactionType.DEPOSIT);
        } else if (action === TransactionType.EXPENSE) {
          setShortcutType(TransactionType.EXPENSE);
        }
      } catch (err) {
        if (!cancelled) {
          setBootError(err instanceof Error ? err.message : 'Boot failed');
        }
      }
    })();

    return () => {
      cancelled = true;
      stopPerformanceEngine();
      shutdownStore();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    void changeLanguage(language);
  }, [language]);

  const handleOnboardingComplete = useCallback(() => {
    setOnboardingDone(true);
  }, [setOnboardingDone]);

  const handleCloseShortcut = useCallback(() => {
    setShortcutType(null);
    if (typeof window !== 'undefined') {
      const { pathname, search, hash } = window.location;
      const clean = hash.replace(/\?[^#]*/, '');
      window.history.replaceState(null, '', `${pathname}${search}${clean}`);
    }
  }, []);

  if (bootError) {
    return <BootErrorScreen message={bootError} />;
  }

  if (!hydrated) {
    return (
      <>
        <SplashScreen />
        <ToastContainer />
      </>
    );
  }

  if (!onboardingDone) {
    return (
      <>
        <OnboardingScreen onComplete={handleOnboardingComplete} />
        <ToastContainer />
        <SheetsHost />
        <PrivacyOverlay open={privacyOverlayActive} />
      </>
    );
  }

  // No credential exists on a fresh installation. Never show LockScreen in that state.
  if (securityConfigured && requiresRecoveryReset) {
    return (
      <>
        <LockScreenOverlay open onUnlocked={() => unlockApp()} />
        <ToastContainer />
        <PrivacyOverlay open />
      </>
    );
  }

  if (securityConfigured && !unlocked) {
    return (
      <>
        <LockScreenOverlay open onUnlocked={() => unlockApp()} />
        <ToastContainer />
        <PrivacyOverlay open={privacyOverlayActive} />
      </>
    );
  }

  return (
    <>
      <HashRouter>
        <AppLayout shortcutType={shortcutType} onCloseShortcut={handleCloseShortcut} />
      </HashRouter>

      <ToastContainer />
      <SheetsHost />
      <PrivacyOverlay open={privacyOverlayActive} />
    </>
  );
}

export default App;
