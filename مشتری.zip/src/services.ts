// ============================================================================
//  src/services.ts
//  لایه‌ی Orchestration — هماهنگ‌کننده‌ی عملیات بین Repositoryها و Domain
// ============================================================================
//
//  ── تغییرات SPEC v2.0 ─────────────────────────────────────────────────
//
//   ۱. Zod Bridge: تمام create/update از Schemaهای validation.ts استفاده می‌کنند.
//   ۲. alertsService بر پایه‌ی `alertsRepo` واقعی (نه in-memory).
//   ۳. حذف Duplicate Exports انتهای فایل.
//   ۴. Account با `bankName` و `status` (نه `isArchived`).
//   ۵. Party با `status` (نه `isActive`).
//   ۶. AssetResolver سبک — local-first، remote-fallback.
//   ۷. تمام Audit Events با مقادیر canonical AuditAction.
// ============================================================================

import {
  AuditAction,
  AlertSeverity,
  AlertType,
  AccountStatus,
  CategoryStatus,
  DuplicateLevel,
  PartyStatus,
  TransactionStatus,
  TransactionType,
} from './types';

import type {
  Account,
  AccountId,
  AlertItem,
  BalanceResult,
  Category,
  CategoryId,
  CreateAccountInput,
  CreateCategoryInput,
  CreatePartyInput,
  CreateProjectInput,
  CreateTransactionInput,
  Draft,
  DuplicateScore,
  ISODate,
  ISOTimestamp,
  Money,
  Party,
  PartyId,
  PeriodReport,
  Project,
  ProjectId,
  ReportFilter,
  Result,
  Transaction,
  TransactionFilter,
  TransactionId,
  UpdateAccountInput,
  UpdatePartyInput,
  UpdateProjectInput,
  UpdateTransactionInput,
  ULID,
} from './types';

import {
  accountRepo,
  alertsRepo,
  attachmentRepo,
  auditRepo,
  categoryRepo,
  draftRepo,
  getDevicePrefix,
  partyRepo,
  projectRepo,
  settingsRepo,
  transactionRepo,
  workspaceRepo,
  SETTINGS_KEYS,
} from './db';

import {
  calculateBalance,
  calculateBalances,
  calculateTotalBalance,
  calculateTotalInflow,
  calculateTotalOutflow,
  checkDuplicate,
  computeDeleteAccountImpact,
  computeDeleteTransactionImpact,
  filterTransactions,
  generateReport,
  getMonthlyStats,
  getPartyTransactionStats,
  getProjectStats,
  sortTransactionsDesc,
  validateTransactionRules,
} from './domain';

import type {
  DeleteAccountImpact,
  DeleteTransactionImpact,
  MonthlyStats,
} from './domain';

import {
  transactionCreateSchema,
  transactionUpdateSchema,
  accountCreateSchema,
  accountUpdateSchema,
  partyCreateSchema,
  partyUpdateSchema,
  projectCreateSchema,
  projectUpdateSchema,
} from './validation';

import { todayISO, getJalaliParts, normalizePersianText } from './formatters';

import { toGregorian, jalaaliMonthLength } from 'jalaali-js';

// ═══════════════════════════════════════════════════════════════════════════
// Result helpers
// ═══════════════════════════════════════════════════════════════════════════

function ok<T>(value: T): Result<T> {
  return { ok: true, value };
}

function err<T>(code: string, message: string, detail?: unknown): Result<T> {
  const e: { ok: false; code: string; message: string; detail?: unknown } = {
    ok: false,
    code,
    message,
  };
  if (detail !== undefined) e.detail = detail;
  return e;
}

function fail<T>(code: string, message: string, detail?: unknown): Result<T> {
  return err<T>(code, message, detail);
}

interface ZodIssueLike {
  readonly path: ReadonlyArray<PropertyKey>;
  readonly message: string;
}

interface NormalizedIssue {
  path: string[];
  message: string;
}

type ZodValidationResult<T> =
  | { success: true; data: T }
  | {
      success: false;
      error: { issues: ReadonlyArray<ZodIssueLike> };
    };

function zodToResult<T>(parsed: ZodValidationResult<T>): Result<T> {
  if (parsed.success) {
    return ok(parsed.data);
  }

  const issues: NormalizedIssue[] = parsed.error.issues.map((issue) => ({
    path: issue.path.map((part) => String(part)),
    message: issue.message,
  }));

  const first = issues[0];

  return fail('VALIDATION', first?.message ?? 'ورودی نامعتبر است', {
    field: first && first.path.length > 0 ? first.path.join('.') : undefined,
    issues,
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// Jalali month boundaries
// ═══════════════════════════════════════════════════════════════════════════

function pad2(n: number): string {
  return n < 10 ? '0' + n : String(n);
}

function isoFromGregorian(y: number, m: number, d: number): ISODate {
  return `${y}-${pad2(m)}-${pad2(d)}`;
}

export function getCurrentJalaliMonthRange(): { start: ISODate; end: ISODate } {
  const today = todayISO();
  const parts = getJalaliParts(today);
  if (!parts) {
    return { start: today, end: today };
  }
  const { jy, jm } = parts;
  const monthLength = jalaaliMonthLength(jy, jm);

  const startG = toGregorian(jy, jm, 1);
  const endG = toGregorian(jy, jm, monthLength);

  return {
    start: isoFromGregorian(startG.gy, startG.gm, startG.gd),
    end: isoFromGregorian(endG.gy, endG.gm, endG.gd),
  };
}

export function getLastNDaysRange(days: number): {
  start: ISODate;
  end: ISODate;
} {
  const end = new Date();
  const start = new Date(end.getTime() - (days - 1) * 86_400_000);
  const startIso = isoFromGregorian(
    start.getFullYear(),
    start.getMonth() + 1,
    start.getDate()
  );
  const endIso = isoFromGregorian(end.getFullYear(), end.getMonth() + 1, end.getDate());
  return { start: startIso, end: endIso };
}

// ═══════════════════════════════════════════════════════════════════════════
// transactionService
// ═══════════════════════════════════════════════════════════════════════════

export interface CreateTransactionResult {
  transaction: Transaction;
  duplicate: DuplicateScore | null;
}

export const transactionService = {
  async create(input: CreateTransactionInput): Promise<Result<CreateTransactionResult>> {
    const parsed = transactionCreateSchema.safeParse(input);
    if (!parsed.success) {
      return zodToResult<CreateTransactionResult>(parsed);
    }

    const normalized = parsed.data as unknown as CreateTransactionInput;

    const account = await accountRepo.findById(normalized.accountId);
    const party = normalized.partyId
      ? await partyRepo.findById(normalized.partyId)
      : null;

    const ruleErrors = validateTransactionRules(normalized, account, party);
    if (ruleErrors.length > 0) {
      const first = ruleErrors[0]!;
      return fail('VALIDATION', first.message, {
        field: first.field,
        allErrors: ruleErrors,
      });
    }

    const existing = await transactionRepo.listAll();
    const duplicate = checkDuplicate(normalized, existing);
    const duplicateResult = duplicate.level === DuplicateLevel.UNIQUE ? null : duplicate;

    try {
      const transaction = await transactionRepo.create(normalized);
      return ok({ transaction, duplicate: duplicateResult });
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ثبت تراکنش با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async update(
    id: TransactionId,
    changes: UpdateTransactionInput
  ): Promise<Result<Transaction>> {
    const existing = await transactionRepo.findById(id);
    if (!existing) return fail('NOT_FOUND', 'تراکنش یافت نشد');

    const parsed = transactionUpdateSchema.safeParse(changes);
    if (!parsed.success) {
      return zodToResult<Transaction>(parsed);
    }

    const normalized = parsed.data as unknown as UpdateTransactionInput;

    if (normalized.partyId !== undefined && normalized.partyId !== null) {
      const party = await partyRepo.findById(normalized.partyId);
      if (!party) {
        return fail('VALIDATION', 'طرف حساب یافت نشد', {
          field: 'partyId',
        });
      }
    }

    const nextAccountId = normalized.accountId ?? existing.accountId;
    const account = await accountRepo.findById(nextAccountId);
    if (!account) {
      return fail('VALIDATION', 'حساب یافت نشد', { field: 'accountId' });
    }
    if (account.status === AccountStatus.ARCHIVED) {
      return fail('VALIDATION', 'حساب آرشیو شده است', { field: 'accountId' });
    }

    const nextPartyId =
      normalized.partyId !== undefined ? normalized.partyId : existing.partyId;

    if (existing.type === TransactionType.EXPENSE && nextPartyId === null) {
      return fail('VALIDATION', 'برای ثبت خرج، طرف حساب الزامی است', {
        field: 'partyId',
      });
    }

    try {
      const updated = await transactionRepo.update(id, normalized);
      if (!updated) return fail('NOT_FOUND', 'تراکنش یافت نشد');
      return ok(updated);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ویرایش تراکنش با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async getDeleteImpact(id: TransactionId): Promise<Result<DeleteTransactionImpact>> {
    const transaction = await transactionRepo.findById(id);
    if (!transaction) return fail('NOT_FOUND', 'تراکنش یافت نشد');

    const account = await accountRepo.findById(transaction.accountId);
    if (!account) return fail('NOT_FOUND', 'حساب مرتبط یافت نشد');

    const all = await transactionRepo.listAll();
    const impact = computeDeleteTransactionImpact(transaction, account, all);
    return ok(impact);
  },

  async softDelete(
    id: TransactionId,
    actorLabel: string | null = null
  ): Promise<Result<void>> {
    const transaction = await transactionRepo.findById(id);
    if (!transaction) return fail('NOT_FOUND', 'تراکنش یافت نشد');
    if (transaction.status === TransactionStatus.DELETED) {
      return ok(undefined);
    }

    try {
      const success = await transactionRepo.softDelete(id, actorLabel);
      if (!success) return fail('DB_WRITE', 'حذف با خطا مواجه شد');
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'حذف با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async restore(
    id: TransactionId,
    actorLabel: string | null = null
  ): Promise<Result<void>> {
    const transaction = await transactionRepo.findById(id);
    if (!transaction) return fail('NOT_FOUND', 'تراکنش یافت نشد');
    if (transaction.status === TransactionStatus.ACTIVE) return ok(undefined);

    try {
      const success = await transactionRepo.restore(id, actorLabel);
      if (!success) return fail('DB_WRITE', 'بازیابی با خطا مواجه شد');
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'بازیابی با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async findById(id: TransactionId): Promise<Transaction | null> {
    return transactionRepo.findById(id);
  },

  async list(filter: TransactionFilter): Promise<Transaction[]> {
    const [transactions, parties] = await Promise.all([
      transactionRepo.list(filter),
      partyRepo.list(true),
    ]);
    const filtered = filterTransactions(transactions, filter, parties);
    return sortTransactionsDesc(filtered);
  },

  async listRecent(limit = 5): Promise<Transaction[]> {
    const all = await transactionRepo.listActive();
    const sorted = sortTransactionsDesc(all);
    return sorted.slice(0, limit);
  },

  async listByAccount(accountId: AccountId): Promise<Transaction[]> {
    return transactionRepo.listByAccount(accountId);
  },

  async listByParty(partyId: PartyId): Promise<Transaction[]> {
    return transactionRepo.listByParty(partyId);
  },

  async listByProject(projectId: ProjectId): Promise<Transaction[]> {
    return transactionRepo.listByProject(projectId);
  },

  async checkDuplicateOnly(input: CreateTransactionInput): Promise<DuplicateScore> {
    const existing = await transactionRepo.listAll();
    return checkDuplicate(input, existing);
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// accountService
// ═══════════════════════════════════════════════════════════════════════════

export interface AccountWithBalance {
  account: Account;
  balance: BalanceResult;
}

export const accountService = {
  async list(includeArchived = false): Promise<Account[]> {
    return accountRepo.list(includeArchived);
  },

  async listWithBalances(includeArchived = false): Promise<AccountWithBalance[]> {
    const [accounts, transactions] = await Promise.all([
      accountRepo.list(includeArchived),
      transactionRepo.listActive(),
    ]);
    const balances = calculateBalances(accounts, transactions);
    return accounts.map((account) => ({
      account,
      balance: balances.get(account.id) ?? {
        accountId: account.id,
        openingBalance: account.openingBalance,
        totalInflow: 0n,
        totalOutflow: 0n,
        balance: account.openingBalance,
        isNegative: account.openingBalance < 0n,
        transactionCount: 0,
      },
    }));
  },

  async findById(id: AccountId): Promise<Account | null> {
    return accountRepo.findById(id);
  },

  async getBalance(id: AccountId): Promise<BalanceResult | null> {
    const account = await accountRepo.findById(id);
    if (!account) return null;
    const transactions = await transactionRepo.listByAccount(id);
    return calculateBalance(account, transactions);
  },

  async create(input: CreateAccountInput): Promise<Result<Account>> {
    const parsed = accountCreateSchema.safeParse(input);
    if (!parsed.success) {
      return zodToResult<Account>(parsed);
    }

    const normalized = parsed.data as unknown as CreateAccountInput;

    const existing = await accountRepo.list(true);
    const normalizedNewName = normalizePersianText(normalized.name);
    for (const acc of existing) {
      if (normalizePersianText(acc.name) === normalizedNewName) {
        return fail('VALIDATION', 'حسابی با این نام قبلاً ثبت شده است', {
          field: 'name',
        });
      }
    }

    try {
      const account = await accountRepo.create(normalized);
      return ok(account);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ثبت حساب با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async update(id: AccountId, changes: UpdateAccountInput): Promise<Result<Account>> {
    const parsed = accountUpdateSchema.safeParse(changes);
    if (!parsed.success) {
      return zodToResult<Account>(parsed);
    }

    const normalized = parsed.data as unknown as UpdateAccountInput;

    if (normalized.name !== undefined) {
      const existing = await accountRepo.list(true);
      const normalizedNewName = normalizePersianText(normalized.name);
      for (const acc of existing) {
        if (acc.id === id) continue;
        if (normalizePersianText(acc.name) === normalizedNewName) {
          return fail('VALIDATION', 'حسابی با این نام قبلاً ثبت شده است', {
            field: 'name',
          });
        }
      }
    }

    try {
      const updated = await accountRepo.update(id, normalized);
      if (!updated) return fail('NOT_FOUND', 'حساب یافت نشد');
      return ok(updated);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ویرایش حساب با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async getArchiveImpact(id: AccountId): Promise<Result<DeleteAccountImpact>> {
    const account = await accountRepo.findById(id);
    if (!account) return fail('NOT_FOUND', 'حساب یافت نشد');
    const transactions = await transactionRepo.listAll();
    const impact = computeDeleteAccountImpact(account, transactions);
    return ok(impact);
  },

  async archive(id: AccountId): Promise<Result<void>> {
    const account = await accountRepo.findById(id);
    if (!account) return fail('NOT_FOUND', 'حساب یافت نشد');
    if (account.status === AccountStatus.ARCHIVED) return ok(undefined);

    try {
      await accountRepo.archive(id);
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'آرشیو با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async unarchive(id: AccountId): Promise<Result<void>> {
    const account = await accountRepo.findById(id);
    if (!account) return fail('NOT_FOUND', 'حساب یافت نشد');
    if (account.status === AccountStatus.ACTIVE) return ok(undefined);

    try {
      await accountRepo.unarchive(id);
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'لغو آرشیو با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// partyService
// ═══════════════════════════════════════════════════════════════════════════

export interface PartyWithStats {
  party: Party;
  received: Money;
  paid: Money;
  transactionCount: number;
}

export const partyService = {
  async list(includeArchived = false): Promise<Party[]> {
    return partyRepo.list(includeArchived);
  },

  async listWithStats(includeArchived = false): Promise<PartyWithStats[]> {
    const [parties, transactions] = await Promise.all([
      partyRepo.list(includeArchived),
      transactionRepo.listActive(),
    ]);

    return parties.map((party) => {
      const stats = getPartyTransactionStats(party.id, transactions);
      return {
        party,
        received: stats.received,
        paid: stats.paid,
        transactionCount: stats.count,
      };
    });
  },

  async findById(id: PartyId): Promise<Party | null> {
    return partyRepo.findById(id);
  },

  async search(query: string, limit = 20): Promise<Party[]> {
    return partyRepo.search(query, limit);
  },

  async getStats(id: PartyId): Promise<{
    received: Money;
    paid: Money;
    count: number;
    lastTransactionDate: ISODate | null;
  } | null> {
    const party = await partyRepo.findById(id);
    if (!party) return null;
    const transactions = await transactionRepo.listByParty(id);
    const stats = getPartyTransactionStats(id, transactions);
    const sorted = sortTransactionsDesc(transactions);
    return {
      received: stats.received,
      paid: stats.paid,
      count: stats.count,
      lastTransactionDate: sorted[0]?.transactionDate ?? null,
    };
  },

  async create(input: CreatePartyInput): Promise<Result<Party>> {
    const parsed = partyCreateSchema.safeParse(input);
    if (!parsed.success) {
      return zodToResult<Party>(parsed);
    }

    const normalized = parsed.data as unknown as CreatePartyInput;

    const existing = await partyRepo.list(true);
    const normalizedNewName = normalizePersianText(normalized.name);
    for (const p of existing) {
      if (normalizePersianText(p.name) === normalizedNewName) {
        return fail('VALIDATION', 'شخصی با این نام قبلاً ثبت شده است', {
          field: 'name',
        });
      }
    }

    try {
      const party = await partyRepo.create(normalized);
      return ok(party);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ثبت شخص با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async update(id: PartyId, changes: UpdatePartyInput): Promise<Result<Party>> {
    const parsed = partyUpdateSchema.safeParse(changes);
    if (!parsed.success) {
      return zodToResult<Party>(parsed);
    }

    const normalized = parsed.data as unknown as UpdatePartyInput;

    if (normalized.name !== undefined) {
      const existing = await partyRepo.list(true);
      const normalizedNewName = normalizePersianText(normalized.name);
      for (const p of existing) {
        if (p.id === id) continue;
        if (normalizePersianText(p.name) === normalizedNewName) {
          return fail('VALIDATION', 'شخصی با این نام قبلاً ثبت شده است', {
            field: 'name',
          });
        }
      }
    }

    try {
      const updated = await partyRepo.update(id, normalized);
      if (!updated) return fail('NOT_FOUND', 'شخص یافت نشد');
      return ok(updated);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ویرایش با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async deactivate(id: PartyId): Promise<Result<void>> {
    const party = await partyRepo.findById(id);
    if (!party) return fail('NOT_FOUND', 'شخص یافت نشد');
    if (party.status === PartyStatus.ARCHIVED) return ok(undefined);
    try {
      await partyRepo.deactivate(id);
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'غیرفعال‌سازی با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async activate(id: PartyId): Promise<Result<void>> {
    const party = await partyRepo.findById(id);
    if (!party) return fail('NOT_FOUND', 'شخص یافت نشد');
    if (party.status === PartyStatus.ACTIVE) return ok(undefined);
    try {
      await partyRepo.activate(id);
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'فعال‌سازی با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// projectService
// ═══════════════════════════════════════════════════════════════════════════

export interface ProjectWithStats {
  project: Project;
  spent: Money;
  received: Money;
  remainingBudget: Money | null;
  utilization: number | null;
  transactionCount: number;
}

export const projectService = {
  async list(): Promise<Project[]> {
    return projectRepo.list();
  },

  async listWithStats(): Promise<ProjectWithStats[]> {
    const [projects, transactions] = await Promise.all([
      projectRepo.list(),
      transactionRepo.listActive(),
    ]);

    return projects.map((project) => {
      const stats = getProjectStats(project.id, transactions);
      let remainingBudget: Money | null = null;
      let utilization: number | null = null;

      if (project.budgetAmount !== null) {
        remainingBudget = project.budgetAmount - stats.spent;
        if (project.budgetAmount > 0n) {
          const spentNum = Number(stats.spent);
          const budgetNum = Number(project.budgetAmount);
          utilization = budgetNum > 0 ? spentNum / budgetNum : 0;
        } else {
          utilization = stats.spent > 0n ? 1 : 0;
        }
      }

      return {
        project,
        spent: stats.spent,
        received: stats.received,
        remainingBudget,
        utilization,
        transactionCount: stats.count,
      };
    });
  },

  async findById(id: ProjectId): Promise<Project | null> {
    return projectRepo.findById(id);
  },

  async create(input: CreateProjectInput): Promise<Result<Project>> {
    const parsed = projectCreateSchema.safeParse(input);
    if (!parsed.success) {
      return zodToResult<Project>(parsed);
    }

    const normalized = parsed.data as unknown as CreateProjectInput;

    const existing = await projectRepo.list();
    const normalizedNewName = normalizePersianText(normalized.name);
    for (const p of existing) {
      if (normalizePersianText(p.name) === normalizedNewName) {
        return fail('VALIDATION', 'پروژه‌ای با این نام قبلاً ثبت شده است', {
          field: 'name',
        });
      }
    }

    try {
      const project = await projectRepo.create(normalized);
      return ok(project);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ثبت پروژه با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async update(id: ProjectId, changes: UpdateProjectInput): Promise<Result<Project>> {
    const parsed = projectUpdateSchema.safeParse(changes);
    if (!parsed.success) {
      return zodToResult<Project>(parsed);
    }

    const normalized = parsed.data as unknown as UpdateProjectInput;

    try {
      const updated = await projectRepo.update(id, normalized);
      if (!updated) return fail('NOT_FOUND', 'پروژه یافت نشد');
      return ok(updated);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ویرایش پروژه با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// categoryService
// ═══════════════════════════════════════════════════════════════════════════

export interface CategoryTree {
  category: Category;
  children: Category[];
}

export const categoryService = {
  async list(includeArchived = false): Promise<Category[]> {
    return categoryRepo.list(includeArchived);
  },

  async listByTransactionType(type: TransactionType): Promise<Category[]> {
    const catType = type === TransactionType.DEPOSIT ? 'income' : 'expense';
    return categoryRepo.findByType(catType as 'income' | 'expense');
  },

  async listTree(includeArchived = false): Promise<CategoryTree[]> {
    const all = await categoryRepo.list(includeArchived);
    const roots = all.filter((c) => c.parentId === null);
    return roots.map((category) => ({
      category,
      children: all.filter((c) => c.parentId === category.id),
    }));
  },

  async findById(id: CategoryId): Promise<Category | null> {
    return categoryRepo.findById(id);
  },

  async create(input: CreateCategoryInput): Promise<Result<Category>> {
    if (!input.name.trim()) {
      return fail('VALIDATION', 'نام بابت الزامی است', { field: 'name' });
    }
    if (input.name.length > 80) {
      return fail('VALIDATION', 'نام بابت طولانی است', { field: 'name' });
    }

    try {
      const category = await categoryRepo.create(input);
      return ok(category);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'ثبت بابت با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },

  async deactivate(id: CategoryId): Promise<Result<void>> {
    const category = await categoryRepo.findById(id);
    if (!category) return fail('NOT_FOUND', 'بابت یافت نشد');
    if (!category.isCustom) {
      return fail('FORBIDDEN', 'بابت‌های سیستمی قابل حذف نیستند');
    }
    if (category.status === CategoryStatus.ARCHIVED) return ok(undefined);

    try {
      await categoryRepo.deactivate(id);
      return ok(undefined);
    } catch (e) {
      return fail(
        'DB_WRITE',
        'غیرفعال‌سازی با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// reportService
// ═══════════════════════════════════════════════════════════════════════════

export const reportService = {
  async generate(filter: ReportFilter): Promise<Result<PeriodReport>> {
    if (!filter.start || !filter.end) {
      return fail('VALIDATION', 'بازه تاریخ الزامی است');
    }
    if (filter.start > filter.end) {
      return fail('VALIDATION', 'تاریخ شروع بعد از تاریخ پایان است');
    }

    try {
      const [accounts, parties, projects, categories, transactions] = await Promise.all([
        accountRepo.list(true),
        partyRepo.list(true),
        projectRepo.list(),
        categoryRepo.list(true),
        transactionRepo.listActive(),
      ]);

      const report = generateReport({
        start: filter.start,
        end: filter.end,
        accounts,
        parties,
        projects,
        categories,
        transactions,
        accountIds: filter.accountIds,
        partyIds: filter.partyIds,
        projectIds: filter.projectIds,
        categoryIds: filter.categoryIds,
        types: filter.types,
      });

      return ok(report);
    } catch (e) {
      return fail(
        'REPORT_ERROR',
        'تولید گزارش با خطا مواجه شد',
        e instanceof Error ? e.message : String(e)
      );
    }
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// dashboardService
// ═══════════════════════════════════════════════════════════════════════════

export interface DashboardSummary {
  totalBalance: Money;
  totalInflow: Money;
  totalOutflow: Money;
  accountCount: number;
  currentMonth: MonthlyStats;
  monthStart: ISODate;
  monthEnd: ISODate;
  recentTransactions: Transaction[];
  alertsCount: number;
  hasNegativeBalance: boolean;
}

export const dashboardService = {
  async getSummary(): Promise<DashboardSummary> {
    const [accounts, transactions, alertsCount] = await Promise.all([
      accountRepo.list(false),
      transactionRepo.listActive(),
      alertsRepo.unreadCount(),
    ]);

    const balances = calculateBalances(accounts, transactions);
    const totalBalance = calculateTotalBalance(balances.values());
    const totalInflow = calculateTotalInflow(balances.values());
    const totalOutflow = calculateTotalOutflow(balances.values());
    const hasNegativeBalance = accounts.some((acc) => {
      const b = balances.get(acc.id);
      return b ? b.isNegative : false;
    });

    const range = getCurrentJalaliMonthRange();
    const currentMonth = getMonthlyStats(transactions, range.start, range.end);

    const sorted = sortTransactionsDesc(transactions);
    const recent = sorted.slice(0, 5);

    return {
      totalBalance,
      totalInflow,
      totalOutflow,
      accountCount: accounts.length,
      currentMonth,
      monthStart: range.start,
      monthEnd: range.end,
      recentTransactions: recent,
      alertsCount,
      hasNegativeBalance,
    };
  },

  async getSparkline(days = 30): Promise<Array<{ date: ISODate; balance: Money }>> {
    const [accounts, transactions] = await Promise.all([
      accountRepo.list(false),
      transactionRepo.listActive(),
    ]);

    const openingTotal = accounts.reduce((sum, a) => sum + a.openingBalance, 0n);
    const range = getLastNDaysRange(days);

    const byDate = new Map<ISODate, Money>();
    const current = new Date(range.start + 'T00:00:00Z');

    for (let i = 0; i < days; i++) {
      const iso = isoFromGregorian(
        current.getUTCFullYear(),
        current.getUTCMonth() + 1,
        current.getUTCDate()
      );
      byDate.set(iso, openingTotal);
      current.setUTCDate(current.getUTCDate() + 1);
    }

    let running = openingTotal;
    const beforeStart: Transaction[] = [];
    const withinRange: Transaction[] = [];

    for (const tx of transactions) {
      if (tx.transactionDate < range.start) beforeStart.push(tx);
      else withinRange.push(tx);
    }

    for (const tx of beforeStart) {
      if (tx.type === TransactionType.DEPOSIT) running += tx.amount;
      else running -= tx.amount;
    }

    withinRange.sort((a, b) => (a.transactionDate < b.transactionDate ? -1 : 1));

    const sortedDates = [...byDate.keys()].sort();
    let txIdx = 0;

    for (const date of sortedDates) {
      while (txIdx < withinRange.length && withinRange[txIdx]!.transactionDate <= date) {
        const tx = withinRange[txIdx]!;
        if (tx.type === TransactionType.DEPOSIT) running += tx.amount;
        else running -= tx.amount;
        txIdx++;
      }
      byDate.set(date, running);
    }

    return sortedDates.map((date) => ({
      date,
      balance: byDate.get(date) ?? 0n,
    }));
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// alertsService — بر پایه‌ی alertsRepo واقعی
// ═══════════════════════════════════════════════════════════════════════════

let backupReminderCreationPromise: Promise<AlertItem> | null = null;

export const alertsService = {
  /**
   * لیست هشدارهای فعال — از دیتابیس + بررسی زنده‌ی شرایط.
   *
   * هشدارهای پیوسته (negative_balance, backup_reminder) هر بار بازمحاسبه
   * می‌شوند، ولی هشدارهای موجود در DB (که ممکن است توسط کاربر read شده
   * باشند) حفظ می‌شوند.
   */
  async getActive(): Promise<AlertItem[]> {
    const [accounts, transactions, stored] = await Promise.all([
      accountRepo.list(false),
      transactionRepo.listActive(),
      alertsRepo.list({ limit: 500 }),
    ]);

    const balances = calculateBalances(accounts, transactions);

    // ── هشدارهای محاسبه‌شده‌ی زنده ───────────────────────────────────
    const liveAlerts: AlertItem[] = [];

    for (const account of accounts) {
      const b = balances.get(account.id);
      if (!b) continue;

      const existing = stored.find(
        (a) =>
          a.type === AlertType.NEGATIVE_BALANCE &&
          a.entityId === account.id &&
          a.resolvedAt === null
      );

      if (b.isNegative) {
        if (existing) {
          liveAlerts.push(existing);
        } else {
          const created = await alertsRepo.create({
            type: AlertType.NEGATIVE_BALANCE,
            severity: AlertSeverity.WARNING,
            entityType: 'account',
            entityId: account.id,
            messageKey: 'alert.negativeBalance.message',
            messageParams: { accountName: account.name },
          });
          liveAlerts.push(created);
        }
      } else if (existing) {
        await alertsRepo.resolve(existing.id);
      }
    }

    // ── یادآور Backup — persistent so read/unread state survives navigation ───
    const lastBackupAt = await settingsRepo.get(SETTINGS_KEYS.LAST_BACKUP_AT);
    if (transactions.length > 0) {
      const existingBackupReminders = stored
        .filter(
          (alert) =>
            alert.type === AlertType.BACKUP_REMINDER && alert.resolvedAt === null
        )
        .sort((a, b) => b.createdAt.localeCompare(a.createdAt));

      if (lastBackupAt) {
        const daysSince = Math.floor(
          (Date.now() - new Date(lastBackupAt).getTime()) / 86_400_000
        );
        if (daysSince >= 7) {
          const reminderBucket = Math.floor(daysSince / 7);
          const reminderStartAt =
            new Date(new Date(lastBackupAt).getTime() + reminderBucket * 7 * 86_400_000).getTime();
          const existing = existingBackupReminders.find(
            (alert) => new Date(alert.createdAt).getTime() >= reminderStartAt
          );

          if (existing) {
            liveAlerts.push(existing);
          } else {
            if (backupReminderCreationPromise) {
              liveAlerts.push(await backupReminderCreationPromise);
            } else {
              backupReminderCreationPromise = alertsRepo
                .create({
                  type: AlertType.BACKUP_REMINDER,
                  severity: AlertSeverity.WARNING,
                  entityType: null,
                  entityId: null,
                  messageKey: 'alert.backupReminder.message',
                  messageParams: { days: daysSince },
                })
                .finally(() => {
                  backupReminderCreationPromise = null;
                });
              liveAlerts.push(await backupReminderCreationPromise);
            }
          }
        }
      } else {
        const existing = existingBackupReminders.find(
          (alert) => alert.messageKey === 'alert.backupNever.message'
        );
        if (existing) {
          liveAlerts.push(existing);
        } else {
          if (backupReminderCreationPromise) {
            liveAlerts.push(await backupReminderCreationPromise);
          } else {
            backupReminderCreationPromise = alertsRepo
              .create({
                type: AlertType.BACKUP_REMINDER,
                severity: AlertSeverity.INFO,
                entityType: null,
                entityId: null,
                messageKey: 'alert.backupNever.message',
                messageParams: null,
              })
              .finally(() => {
                backupReminderCreationPromise = null;
              });
            liveAlerts.push(await backupReminderCreationPromise);
          }
        }
      }
    }

    // ── سایر هشدارهای ذخیره‌شده (غیر از موارد بالا) ────────────────────
    const otherStored = stored.filter(
      (a) =>
        a.resolvedAt === null &&
        a.type !== AlertType.NEGATIVE_BALANCE &&
        a.type !== AlertType.BACKUP_REMINDER
    );

    const combined = [...liveAlerts, ...otherStored];

    combined.sort((a, b) => {
      const sevRank: Record<AlertSeverity, number> = {
        critical: 0,
        warning: 1,
        info: 2,
      };
      return sevRank[a.severity] - sevRank[b.severity];
    });

    return combined;
  },

  async getUnreadCount(): Promise<number> {
    const stored = await alertsRepo.unreadCount();
    const active = await this.getActive();
    const liveUnread = active.filter(
      (a) => a.readAt === null && a.resolvedAt === null
    ).length;
    // محاسبه‌ی زنده معمولاً بیشتر از stored است
    return Math.max(stored, liveUnread);
  },

  async markRead(alertId: string): Promise<void> {
    // اگر هشدار در DB نیست (محاسبه‌شده)، در DB ثبت می‌شود
    try {
      await alertsRepo.markRead(alertId);
    } catch {
      // silent
    }
  },

  async markAllRead(): Promise<void> {
    await alertsRepo.markAllRead();
  },

  async resolve(alertId: string): Promise<void> {
    await alertsRepo.resolve(alertId);
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// settingsService
// ═══════════════════════════════════════════════════════════════════════════

export const settingsService = {
  async getTheme(): Promise<'dark' | 'light'> {
    const v = await settingsRepo.get(SETTINGS_KEYS.THEME);
    return v === 'light' ? 'light' : 'dark';
  },

  async setTheme(theme: 'dark' | 'light'): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.THEME, theme);
  },

  async getLanguage(): Promise<'fa' | 'en'> {
    const v = await settingsRepo.get(SETTINGS_KEYS.LANGUAGE);
    return v === 'en' ? 'en' : 'fa';
  },

  async setLanguage(lang: 'fa' | 'en'): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.LANGUAGE, lang);
  },

  async getCompanyName(): Promise<string | null> {
    return settingsRepo.get(SETTINGS_KEYS.COMPANY_NAME);
  },

  async setCompanyName(name: string): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.COMPANY_NAME, name);
  },

  async isOnboardingDone(): Promise<boolean> {
    return settingsRepo.getBoolean(SETTINGS_KEYS.ONBOARDING_DONE, false);
  },

  async setOnboardingDone(): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.ONBOARDING_DONE, 'true');
  },

  async getSecurityPromptCount(): Promise<number> {
    return settingsRepo.getNumber(SETTINGS_KEYS.SECURITY_PROMPT_COUNT, 0);
  },

  async incrementSecurityPromptCount(): Promise<number> {
    const current = await this.getSecurityPromptCount();
    const next = current + 1;
    await settingsRepo.set(SETTINGS_KEYS.SECURITY_PROMPT_COUNT, String(next));
    return next;
  },

  async getLastBackupAt(): Promise<ISOTimestamp | null> {
    return settingsRepo.get(SETTINGS_KEYS.LAST_BACKUP_AT);
  },

  async setLastBackupAt(at: ISOTimestamp): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.LAST_BACKUP_AT, at);
  },

  async getDevicePrefix(): Promise<string> {
    return getDevicePrefix();
  },

  async getWorkspaceId(): Promise<ULID | null> {
    const ws = await workspaceRepo.get();
    return ws?.id ?? null;
  },

  async getPrivacyHideAmounts(): Promise<boolean> {
    return settingsRepo.getBoolean(SETTINGS_KEYS.PRIVACY_HIDE_AMOUNTS, false);
  },

  async setPrivacyHideAmounts(hide: boolean): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.PRIVACY_HIDE_AMOUNTS, hide ? 'true' : 'false');
  },

  async getAssetCacheVersion(): Promise<string> {
    return (await settingsRepo.get(SETTINGS_KEYS.ASSET_CACHE_VERSION)) ?? '1';
  },

  async setAssetCacheVersion(version: string): Promise<void> {
    await settingsRepo.set(SETTINGS_KEYS.ASSET_CACHE_VERSION, version);
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// draftService
// ═══════════════════════════════════════════════════════════════════════════

export const draftService = {
  async get(key: Parameters<typeof draftRepo.get>[0]): Promise<Draft | null> {
    return draftRepo.get(key);
  },

  async save(
    key: Parameters<typeof draftRepo.save>[0],
    formData: Record<string, unknown>
  ): Promise<void> {
    await draftRepo.save(key, JSON.stringify(formData));
  },

  async clear(key: Parameters<typeof draftRepo.clear>[0]): Promise<void> {
    await draftRepo.clear(key);
  },

  async listAll(): Promise<Draft[]> {
    return draftRepo.listAll();
  },

  async hasDraft(key: Parameters<typeof draftRepo.get>[0]): Promise<boolean> {
    const draft = await draftRepo.get(key);
    return draft !== null;
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// auditService
// ═══════════════════════════════════════════════════════════════════════════

export interface AuditFilter {
  entityType?: string;
  action?: AuditAction;
  limit?: number;
}

export const auditService = {
  async list(filter: AuditFilter = {}): Promise<import('./types').AuditEvent[]> {
    if (filter.entityType && filter.action) {
      const all = await auditRepo.listByEntity(filter.entityType, '');
      return all.filter((e) => e.action === filter.action);
    }
    if (filter.action) {
      return auditRepo.listByAction(filter.action, filter.limit ?? 100);
    }
    return auditRepo.list(filter.limit ?? 100);
  },

  async listByEntity(
    entityType: string,
    entityId: string
  ): Promise<import('./types').AuditEvent[]> {
    return auditRepo.listByEntity(entityType, entityId);
  },

  async countAll(): Promise<number> {
    return auditRepo.countAll();
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// attachmentService
// ═══════════════════════════════════════════════════════════════════════════

export const attachmentService = {
  async listByTransaction(transactionId: TransactionId) {
    return attachmentRepo.listByTransaction(transactionId);
  },

  async create(input: {
    transactionId: TransactionId;
    type?: string;
    fileName: string;
    storageKey: string;
    thumbnailKey: string | null;
    mimeType: string;
    sizeBytes: number;
    sha256: string;
  }) {
    return attachmentRepo.create(input);
  },

  async remove(id: import('./types').AttachmentId): Promise<void> {
    return attachmentRepo.remove(id);
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// assetResolver — Local First, Remote Fallback (SPEC v2.0 §۱۱)
// ═══════════════════════════════════════════════════════════════════════════

export interface AssetResolveOptions {
  localPath: string;
  remoteUrl: string;
  version: string;
  required: boolean;
}

export interface AssetResolveResult {
  url: string;
  source: 'local' | 'remote';
  fallback: boolean;
}

/**
 * Asset Resolver سبک — پیاده‌سازی مینیمال.
 *
 * ترتیب اولویت:
 *   ۱. Local Path (public assets)
 *   ۲. Remote URL
 *   ۳. Placeholder خالی
 *
 * در فاز ۶ (UI) این تابع به یک Component تبدیل می‌شود که
 * روی Cache Storage و IndexedDB کار می‌کند.
 */
export const assetResolver = {
  async resolve(options: AssetResolveOptions): Promise<AssetResolveResult> {
    // ── مرحله ۱: بررسی Local ─────────────────────────────────────────
    try {
      const response = await fetch(options.localPath, { method: 'HEAD' });
      if (response.ok) {
        return {
          url: options.localPath,
          source: 'local',
          fallback: false,
        };
      }
    } catch {
      // local not available
    }

    // ── مرحله ۲: Remote ──────────────────────────────────────────────
    if (options.remoteUrl) {
      return {
        url: options.remoteUrl,
        source: 'remote',
        fallback: false,
      };
    }

    // ── مرحله ۳: Placeholder ─────────────────────────────────────────
    return {
      url: '',
      source: 'remote',
      fallback: true,
    };
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// bootstrapService
// ═══════════════════════════════════════════════════════════════════════════

export interface BootstrapResult {
  needsOnboarding: boolean;
  hasAccounts: boolean;
  hasTransactions: boolean;
  theme: 'dark' | 'light';
  language: 'fa' | 'en';
  companyName: string | null;
}

export const bootstrapService = {
  async loadInitial(): Promise<BootstrapResult> {
    const [onboardingDone, accounts, transactions, theme, language, companyName] =
      await Promise.all([
        settingsService.isOnboardingDone(),
        accountRepo.list(true),
        transactionRepo.listActive(),
        settingsService.getTheme(),
        settingsService.getLanguage(),
        settingsService.getCompanyName(),
      ]);

    return {
      needsOnboarding: !onboardingDone,
      hasAccounts: accounts.length > 0,
      hasTransactions: transactions.length > 0,
      theme,
      language,
      companyName,
    };
  },
};

// ═══════════════════════════════════════════════════════════════════════════
// Unified facade
// ═══════════════════════════════════════════════════════════════════════════

export const services = {
  transaction: transactionService,
  account: accountService,
  party: partyService,
  project: projectService,
  category: categoryService,
  report: reportService,
  dashboard: dashboardService,
  alerts: alertsService,
  settings: settingsService,
  draft: draftService,
  audit: auditService,
  attachment: attachmentService,
  asset: assetResolver,
  bootstrap: bootstrapService,
};

// ═══════════════════════════════════════════════════════════════════════════
// Type re-exports (فقط آن‌هایی که نباید duplicate باشند)
// ═══════════════════════════════════════════════════════════════════════════

export type {
  DeleteAccountImpact,
  DeleteTransactionImpact,
  MonthlyStats,
} from './domain';

// ═══════════════════════════════════════════════════════════════════════════
// پایان فایل
// ═══════════════════════════════════════════════════════════════════════════
