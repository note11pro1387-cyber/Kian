// playwright.config.ts

import { defineConfig, devices } from '@playwright/test';

export default defineConfig({
  testDir: './tests/e2e',
  testMatch: '**/*.e2e.{ts,tsx}',

  timeout: 30_000,
  expect: {
    timeout: 5_000,
  },

  fullyParallel: false,
  workers: process.env.CI ? 1 : 2,

  retries: process.env.CI ? 2 : 0,

  forbidOnly: !!process.env.CI,

  reporter: process.env.CI
    ? [
        ['list'],
        ['html', { outputFolder: 'playwright-report', open: 'never' }],
        ['json', { outputFile: 'test-results/results.json' }],
      ]
    : [
        ['list'],
        ['html', { outputFolder: 'playwright-report', open: 'on-failure' }],
      ],

  outputDir: 'test-results',
  preserveOutput: 'failures-only',

  use: {
    baseURL: process.env.PLAYWRIGHT_BASE_URL ?? 'http://localhost:4173',

    locale: 'fa-IR',
    timezoneId: 'Asia/Tehran',
    colorScheme: 'dark',

    viewport: { width: 390, height: 844 },

    navigationTimeout: 15_000,
    actionTimeout: 10_000,

    screenshot: 'only-on-failure',
    video: 'retain-on-failure',
    trace: 'retain-on-failure',
    ignoreHTTPSErrors: false,

    storageState: undefined,
    permissions: [],

    launchOptions: {
      args: [
        '--disable-dev-shm-usage',
        '--no-sandbox',
        '--enable-features=SharedArrayBuffer',
      ],
    },
  },

  projects: [
    {
      name: 'chromium-mobile',
      use: {
        ...devices['Pixel 7'],
        locale: 'fa-IR',
        colorScheme: 'dark',
      },
    },
  ],

  webServer: process.env.PLAYWRIGHT_NO_SERVER
    ? undefined
    : {
        command:
          'npm run build:only && npm run preview -- --port 4173 --strictPort',
        url: 'http://localhost:4173',
        reuseExistingServer: !process.env.CI,
        timeout: 120_000,
        stdout: 'pipe',
        stderr: 'pipe',
        env: {
          NODE_ENV: 'production',
        },
      },

  metadata: {
    project: 'Financial Management App',
    version: '1.0.0',
    language: 'fa-IR',
    timezone: 'Asia/Tehran',
  },
});
